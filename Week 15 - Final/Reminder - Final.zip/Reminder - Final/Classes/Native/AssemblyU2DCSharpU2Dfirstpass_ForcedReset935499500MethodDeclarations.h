﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// ForcedReset
struct ForcedReset_t935499500;

#include "codegen/il2cpp-codegen.h"

// System.Void ForcedReset::.ctor()
extern "C"  void ForcedReset__ctor_m2681315165 (ForcedReset_t935499500 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void ForcedReset::Update()
extern "C"  void ForcedReset_Update_m2865376280 (ForcedReset_t935499500 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
