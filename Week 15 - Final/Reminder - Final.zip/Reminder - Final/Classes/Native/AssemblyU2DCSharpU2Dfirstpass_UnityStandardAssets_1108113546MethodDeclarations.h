﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// UnityStandardAssets.Utility.AutoMobileShaderSwitch
struct AutoMobileShaderSwitch_t1108113546;

#include "codegen/il2cpp-codegen.h"

// System.Void UnityStandardAssets.Utility.AutoMobileShaderSwitch::.ctor()
extern "C"  void AutoMobileShaderSwitch__ctor_m1791957656 (AutoMobileShaderSwitch_t1108113546 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Utility.AutoMobileShaderSwitch::OnEnable()
extern "C"  void AutoMobileShaderSwitch_OnEnable_m1278171348 (AutoMobileShaderSwitch_t1108113546 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
