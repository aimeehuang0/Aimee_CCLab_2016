﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// UnityStandardAssets.Effects.ExplosionFireAndDebris
struct ExplosionFireAndDebris_t1174895067;
// System.Collections.IEnumerator
struct IEnumerator_t1466026749;
// UnityEngine.Transform
struct Transform_t3275118058;

#include "codegen/il2cpp-codegen.h"
#include "UnityEngine_UnityEngine_Transform3275118058.h"
#include "UnityEngine_UnityEngine_Vector32243707580.h"

// System.Void UnityStandardAssets.Effects.ExplosionFireAndDebris::.ctor()
extern "C"  void ExplosionFireAndDebris__ctor_m2696159835 (ExplosionFireAndDebris_t1174895067 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Collections.IEnumerator UnityStandardAssets.Effects.ExplosionFireAndDebris::Start()
extern "C"  Il2CppObject * ExplosionFireAndDebris_Start_m1121229021 (ExplosionFireAndDebris_t1174895067 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Effects.ExplosionFireAndDebris::AddFire(UnityEngine.Transform,UnityEngine.Vector3,UnityEngine.Vector3)
extern "C"  void ExplosionFireAndDebris_AddFire_m2480179925 (ExplosionFireAndDebris_t1174895067 * __this, Transform_t3275118058 * ___t0, Vector3_t2243707580  ___pos1, Vector3_t2243707580  ___normal2, const MethodInfo* method) IL2CPP_METHOD_ATTR;
