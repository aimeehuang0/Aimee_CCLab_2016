﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// EventSystemChecker
struct EventSystemChecker_t3549249260;

#include "codegen/il2cpp-codegen.h"

// System.Void EventSystemChecker::.ctor()
extern "C"  void EventSystemChecker__ctor_m2412713481 (EventSystemChecker_t3549249260 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void EventSystemChecker::Awake()
extern "C"  void EventSystemChecker_Awake_m7473574 (EventSystemChecker_t3549249260 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
