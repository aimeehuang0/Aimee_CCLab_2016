﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// UnityStandardAssets.Effects.AfterburnerPhysicsForce
struct AfterburnerPhysicsForce_t706380940;

#include "codegen/il2cpp-codegen.h"

// System.Void UnityStandardAssets.Effects.AfterburnerPhysicsForce::.ctor()
extern "C"  void AfterburnerPhysicsForce__ctor_m3476603960 (AfterburnerPhysicsForce_t706380940 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Effects.AfterburnerPhysicsForce::OnEnable()
extern "C"  void AfterburnerPhysicsForce_OnEnable_m1079265472 (AfterburnerPhysicsForce_t706380940 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Effects.AfterburnerPhysicsForce::FixedUpdate()
extern "C"  void AfterburnerPhysicsForce_FixedUpdate_m745083999 (AfterburnerPhysicsForce_t706380940 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Effects.AfterburnerPhysicsForce::OnDrawGizmosSelected()
extern "C"  void AfterburnerPhysicsForce_OnDrawGizmosSelected_m3429823921 (AfterburnerPhysicsForce_t706380940 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
