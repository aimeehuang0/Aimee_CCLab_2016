﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// UnityStandardAssets.Utility.WaypointCircuit/WaypointList
struct WaypointList_t2985503331;

#include "codegen/il2cpp-codegen.h"

// System.Void UnityStandardAssets.Utility.WaypointCircuit/WaypointList::.ctor()
extern "C"  void WaypointList__ctor_m342333168 (WaypointList_t2985503331 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
