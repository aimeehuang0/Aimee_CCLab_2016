﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>


#include "mscorlib_System_Object2689449295.h"
#include "UnityEngine_UnityEngine_ScreenOrientation4019489636.h"

#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Vuforia.AndroidUnityPlayer
struct  AndroidUnityPlayer_t852788525  : public Il2CppObject
{
public:
	// UnityEngine.ScreenOrientation Vuforia.AndroidUnityPlayer::mScreenOrientation
	int32_t ___mScreenOrientation_2;
	// UnityEngine.ScreenOrientation Vuforia.AndroidUnityPlayer::mJavaScreenOrientation
	int32_t ___mJavaScreenOrientation_3;
	// System.Int32 Vuforia.AndroidUnityPlayer::mFramesSinceLastOrientationReset
	int32_t ___mFramesSinceLastOrientationReset_4;
	// System.Int32 Vuforia.AndroidUnityPlayer::mFramesSinceLastJavaOrientationCheck
	int32_t ___mFramesSinceLastJavaOrientationCheck_5;

public:
	inline static int32_t get_offset_of_mScreenOrientation_2() { return static_cast<int32_t>(offsetof(AndroidUnityPlayer_t852788525, ___mScreenOrientation_2)); }
	inline int32_t get_mScreenOrientation_2() const { return ___mScreenOrientation_2; }
	inline int32_t* get_address_of_mScreenOrientation_2() { return &___mScreenOrientation_2; }
	inline void set_mScreenOrientation_2(int32_t value)
	{
		___mScreenOrientation_2 = value;
	}

	inline static int32_t get_offset_of_mJavaScreenOrientation_3() { return static_cast<int32_t>(offsetof(AndroidUnityPlayer_t852788525, ___mJavaScreenOrientation_3)); }
	inline int32_t get_mJavaScreenOrientation_3() const { return ___mJavaScreenOrientation_3; }
	inline int32_t* get_address_of_mJavaScreenOrientation_3() { return &___mJavaScreenOrientation_3; }
	inline void set_mJavaScreenOrientation_3(int32_t value)
	{
		___mJavaScreenOrientation_3 = value;
	}

	inline static int32_t get_offset_of_mFramesSinceLastOrientationReset_4() { return static_cast<int32_t>(offsetof(AndroidUnityPlayer_t852788525, ___mFramesSinceLastOrientationReset_4)); }
	inline int32_t get_mFramesSinceLastOrientationReset_4() const { return ___mFramesSinceLastOrientationReset_4; }
	inline int32_t* get_address_of_mFramesSinceLastOrientationReset_4() { return &___mFramesSinceLastOrientationReset_4; }
	inline void set_mFramesSinceLastOrientationReset_4(int32_t value)
	{
		___mFramesSinceLastOrientationReset_4 = value;
	}

	inline static int32_t get_offset_of_mFramesSinceLastJavaOrientationCheck_5() { return static_cast<int32_t>(offsetof(AndroidUnityPlayer_t852788525, ___mFramesSinceLastJavaOrientationCheck_5)); }
	inline int32_t get_mFramesSinceLastJavaOrientationCheck_5() const { return ___mFramesSinceLastJavaOrientationCheck_5; }
	inline int32_t* get_address_of_mFramesSinceLastJavaOrientationCheck_5() { return &___mFramesSinceLastJavaOrientationCheck_5; }
	inline void set_mFramesSinceLastJavaOrientationCheck_5(int32_t value)
	{
		___mFramesSinceLastJavaOrientationCheck_5 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
