﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// UnityStandardAssets.Effects.FireLight
struct FireLight_t2590751060;

#include "codegen/il2cpp-codegen.h"

// System.Void UnityStandardAssets.Effects.FireLight::.ctor()
extern "C"  void FireLight__ctor_m228236560 (FireLight_t2590751060 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Effects.FireLight::Start()
extern "C"  void FireLight_Start_m507323680 (FireLight_t2590751060 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Effects.FireLight::Update()
extern "C"  void FireLight_Update_m2546825693 (FireLight_t2590751060 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Effects.FireLight::Extinguish()
extern "C"  void FireLight_Extinguish_m1907496486 (FireLight_t2590751060 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
