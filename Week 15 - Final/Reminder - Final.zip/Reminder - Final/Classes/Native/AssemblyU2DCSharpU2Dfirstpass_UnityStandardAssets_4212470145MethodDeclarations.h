﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// UnityStandardAssets.Effects.Hose
struct Hose_t4212470145;

#include "codegen/il2cpp-codegen.h"

// System.Void UnityStandardAssets.Effects.Hose::.ctor()
extern "C"  void Hose__ctor_m3750411899 (Hose_t4212470145 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Effects.Hose::Update()
extern "C"  void Hose_Update_m3912864572 (Hose_t4212470145 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
