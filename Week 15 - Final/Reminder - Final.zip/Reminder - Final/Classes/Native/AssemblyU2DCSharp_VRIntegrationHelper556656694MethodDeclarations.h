﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// VRIntegrationHelper
struct VRIntegrationHelper_t556656694;

#include "codegen/il2cpp-codegen.h"

// System.Void VRIntegrationHelper::.ctor()
extern "C"  void VRIntegrationHelper__ctor_m4069773343 (VRIntegrationHelper_t556656694 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void VRIntegrationHelper::Awake()
extern "C"  void VRIntegrationHelper_Awake_m681899862 (VRIntegrationHelper_t556656694 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void VRIntegrationHelper::Start()
extern "C"  void VRIntegrationHelper_Start_m536586683 (VRIntegrationHelper_t556656694 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void VRIntegrationHelper::OnVuforiaStarted()
extern "C"  void VRIntegrationHelper_OnVuforiaStarted_m1154042475 (VRIntegrationHelper_t556656694 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void VRIntegrationHelper::LateUpdate()
extern "C"  void VRIntegrationHelper_LateUpdate_m4039758880 (VRIntegrationHelper_t556656694 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void VRIntegrationHelper::OnPreRender()
extern "C"  void VRIntegrationHelper_OnPreRender_m1211949763 (VRIntegrationHelper_t556656694 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void VRIntegrationHelper::.cctor()
extern "C"  void VRIntegrationHelper__cctor_m708693476 (Il2CppObject * __this /* static, unused */, const MethodInfo* method) IL2CPP_METHOD_ATTR;
