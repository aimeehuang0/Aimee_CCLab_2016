﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// Vuforia.PropBehaviour
struct PropBehaviour_t966064926;

#include "codegen/il2cpp-codegen.h"

// System.Void Vuforia.PropBehaviour::.ctor()
extern "C"  void PropBehaviour__ctor_m2238867581 (PropBehaviour_t966064926 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
