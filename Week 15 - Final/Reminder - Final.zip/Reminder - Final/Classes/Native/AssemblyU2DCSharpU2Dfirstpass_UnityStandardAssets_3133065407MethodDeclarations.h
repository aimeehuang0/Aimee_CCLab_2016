﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// UnityStandardAssets.Utility.TimedObjectDestructor
struct TimedObjectDestructor_t3133065407;

#include "codegen/il2cpp-codegen.h"

// System.Void UnityStandardAssets.Utility.TimedObjectDestructor::.ctor()
extern "C"  void TimedObjectDestructor__ctor_m3311361529 (TimedObjectDestructor_t3133065407 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Utility.TimedObjectDestructor::Awake()
extern "C"  void TimedObjectDestructor_Awake_m1816050160 (TimedObjectDestructor_t3133065407 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Utility.TimedObjectDestructor::DestroyNow()
extern "C"  void TimedObjectDestructor_DestroyNow_m626704733 (TimedObjectDestructor_t3133065407 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
