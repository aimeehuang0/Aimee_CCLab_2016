﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <cstring>
#include <string.h>
#include <stdio.h>
#include <cmath>
#include <limits>
#include <assert.h>


#include "class-internals.h"
#include "codegen/il2cpp-codegen.h"
#include "mscorlib_System_Runtime_InteropServices_DispIdAttri607560947.h"
#include "mscorlib_System_Runtime_InteropServices_ErrorWrapp2775489663.h"
#include "mscorlib_System_Runtime_InteropServices_ExternalEx1252662682.h"
#include "mscorlib_System_Runtime_InteropServices_GCHandle3409268066.h"
#include "mscorlib_System_Runtime_InteropServices_GCHandleTy1970708122.h"
#include "mscorlib_System_Runtime_InteropServices_InterfaceT4113096249.h"
#include "mscorlib_System_Runtime_InteropServices_Marshal785896760.h"
#include "mscorlib_System_Runtime_InteropServices_MarshalDir1326890414.h"
#include "mscorlib_System_Runtime_InteropServices_PreserveSi1564965109.h"
#include "mscorlib_System_Runtime_InteropServices_SafeHandle2733794115.h"
#include "mscorlib_System_Runtime_InteropServices_TypeLibImp2390314680.h"
#include "mscorlib_System_Runtime_InteropServices_TypeLibVer3346496961.h"
#include "mscorlib_System_Runtime_InteropServices_UnmanagedT2550630890.h"
#include "mscorlib_System_Runtime_Remoting_Activation_Activa1532663650.h"
#include "mscorlib_System_Runtime_Remoting_Activation_AppDoma834876328.h"
#include "mscorlib_System_Runtime_Remoting_Activation_Constr2284932402.h"
#include "mscorlib_System_Runtime_Remoting_Activation_Contex1784331636.h"
#include "mscorlib_System_Runtime_Remoting_Activation_RemoteA213750447.h"
#include "mscorlib_System_Runtime_Remoting_Activation_UrlAtt1544437301.h"
#include "mscorlib_System_Runtime_Remoting_ChannelInfo709892715.h"
#include "mscorlib_System_Runtime_Remoting_Channels_ChannelS2007814595.h"
#include "mscorlib_System_Runtime_Remoting_Channels_CrossAppD816071813.h"
#include "mscorlib_System_Runtime_Remoting_Channels_CrossApp2471623380.h"
#include "mscorlib_System_Runtime_Remoting_Channels_CrossApp2368859578.h"
#include "mscorlib_System_Runtime_Remoting_Channels_SinkProv2645445792.h"
#include "mscorlib_System_Runtime_Remoting_Contexts_Context502196753.h"
#include "mscorlib_System_Runtime_Remoting_Contexts_DynamicP2282532998.h"
#include "mscorlib_System_Runtime_Remoting_Contexts_DynamicP1839195831.h"
#include "mscorlib_System_Runtime_Remoting_Contexts_ContextC3978189709.h"
#include "mscorlib_System_Runtime_Remoting_Contexts_ContextAt197102333.h"
#include "mscorlib_System_Runtime_Remoting_Contexts_CrossCon2302426108.h"
#include "mscorlib_System_Runtime_Remoting_Contexts_Synchron3073724998.h"
#include "mscorlib_System_Runtime_Remoting_Contexts_Synchron3779986825.h"
#include "mscorlib_System_Runtime_Remoting_Contexts_Synchroni462987365.h"
#include "mscorlib_System_Runtime_Remoting_Lifetime_LeaseMan1025868639.h"
#include "mscorlib_System_Runtime_Remoting_Lifetime_LeaseSin3007073869.h"
#include "mscorlib_System_Runtime_Remoting_Lifetime_Lifetime2939669377.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_ArgInfo3252846202.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_ArgInfo688271106.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_AsyncRe2232356043.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_ClientC3236389774.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_Constru1254994451.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_Constru2993650247.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_EnvoyTe3043186997.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_Header2756440555.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_LogicalC725724420.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_CallCon2648008188.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_MethodC2461541281.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_MethodC1516131009.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_MethodD1742974787.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_MethodDi492828146.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_MethodRe981009581.h"



#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize400 = { sizeof (DispIdAttribute_t607560947), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable400[1] = 
{
	DispIdAttribute_t607560947::get_offset_of_id_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize401 = { sizeof (ErrorWrapper_t2775489663), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable401[1] = 
{
	ErrorWrapper_t2775489663::get_offset_of_errorCode_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize402 = { sizeof (ExternalException_t1252662682), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize403 = { sizeof (GCHandle_t3409268066)+ sizeof (Il2CppObject), sizeof(GCHandle_t3409268066 ), 0, 0 };
extern const int32_t g_FieldOffsetTable403[1] = 
{
	GCHandle_t3409268066::get_offset_of_handle_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize404 = { sizeof (GCHandleType_t1970708122)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable404[5] = 
{
	GCHandleType_t1970708122::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize405 = { sizeof (InterfaceTypeAttribute_t4113096249), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable405[1] = 
{
	InterfaceTypeAttribute_t4113096249::get_offset_of_intType_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize406 = { sizeof (Marshal_t785896760), -1, sizeof(Marshal_t785896760_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable406[2] = 
{
	Marshal_t785896760_StaticFields::get_offset_of_SystemMaxDBCSCharSize_0(),
	Marshal_t785896760_StaticFields::get_offset_of_SystemDefaultCharSize_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize407 = { sizeof (MarshalDirectiveException_t1326890414), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable407[1] = 
{
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize408 = { sizeof (PreserveSigAttribute_t1564965109), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize409 = { sizeof (SafeHandle_t2733794115), sizeof(void*), 0, 0 };
extern const int32_t g_FieldOffsetTable409[4] = 
{
	SafeHandle_t2733794115::get_offset_of_handle_0(),
	SafeHandle_t2733794115::get_offset_of_invalid_handle_value_1(),
	SafeHandle_t2733794115::get_offset_of_refcount_2(),
	SafeHandle_t2733794115::get_offset_of_owns_handle_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize410 = { sizeof (TypeLibImportClassAttribute_t2390314680), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable410[1] = 
{
	TypeLibImportClassAttribute_t2390314680::get_offset_of__importClass_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize411 = { sizeof (TypeLibVersionAttribute_t3346496961), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable411[2] = 
{
	TypeLibVersionAttribute_t3346496961::get_offset_of_major_0(),
	TypeLibVersionAttribute_t3346496961::get_offset_of_minor_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize412 = { sizeof (UnmanagedType_t2550630890)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable412[36] = 
{
	UnmanagedType_t2550630890::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize413 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize414 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize415 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize416 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize417 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize418 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize419 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize420 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize421 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize422 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize423 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize424 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize425 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize426 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize427 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize428 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize429 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize430 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize431 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize432 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize433 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize434 = { sizeof (ActivationServices_t1532663650), -1, sizeof(ActivationServices_t1532663650_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable434[1] = 
{
	ActivationServices_t1532663650_StaticFields::get_offset_of__constructionActivator_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize435 = { sizeof (AppDomainLevelActivator_t834876328), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable435[2] = 
{
	AppDomainLevelActivator_t834876328::get_offset_of__activationUrl_0(),
	AppDomainLevelActivator_t834876328::get_offset_of__next_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize436 = { sizeof (ConstructionLevelActivator_t2284932402), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize437 = { sizeof (ContextLevelActivator_t1784331636), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable437[1] = 
{
	ContextLevelActivator_t1784331636::get_offset_of_m_NextActivator_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize438 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize439 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize440 = { sizeof (RemoteActivator_t213750447), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize441 = { sizeof (UrlAttribute_t1544437301), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable441[1] = 
{
	UrlAttribute_t1544437301::get_offset_of_url_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize442 = { sizeof (ChannelInfo_t709892715), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable442[1] = 
{
	ChannelInfo_t709892715::get_offset_of_channelData_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize443 = { sizeof (ChannelServices_t2007814595), -1, sizeof(ChannelServices_t2007814595_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable443[5] = 
{
	ChannelServices_t2007814595_StaticFields::get_offset_of_registeredChannels_0(),
	ChannelServices_t2007814595_StaticFields::get_offset_of_delayedClientChannels_1(),
	ChannelServices_t2007814595_StaticFields::get_offset_of__crossContextSink_2(),
	ChannelServices_t2007814595_StaticFields::get_offset_of_CrossContextUrl_3(),
	ChannelServices_t2007814595_StaticFields::get_offset_of_oldStartModeTypes_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize444 = { sizeof (CrossAppDomainData_t816071813), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable444[3] = 
{
	CrossAppDomainData_t816071813::get_offset_of__ContextID_0(),
	CrossAppDomainData_t816071813::get_offset_of__DomainID_1(),
	CrossAppDomainData_t816071813::get_offset_of__processGuid_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize445 = { sizeof (CrossAppDomainChannel_t2471623380), -1, sizeof(CrossAppDomainChannel_t2471623380_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable445[1] = 
{
	CrossAppDomainChannel_t2471623380_StaticFields::get_offset_of_s_lock_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize446 = { sizeof (CrossAppDomainSink_t2368859578), -1, sizeof(CrossAppDomainSink_t2368859578_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable446[3] = 
{
	CrossAppDomainSink_t2368859578_StaticFields::get_offset_of_s_sinks_0(),
	CrossAppDomainSink_t2368859578_StaticFields::get_offset_of_processMessageMethod_1(),
	CrossAppDomainSink_t2368859578::get_offset_of__domainID_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize447 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize448 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize449 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize450 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize451 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize452 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize453 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize454 = { sizeof (SinkProviderData_t2645445792), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable454[3] = 
{
	SinkProviderData_t2645445792::get_offset_of_sinkName_0(),
	SinkProviderData_t2645445792::get_offset_of_children_1(),
	SinkProviderData_t2645445792::get_offset_of_properties_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize455 = { sizeof (Context_t502196753), -1, sizeof(Context_t502196753_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable455[14] = 
{
	Context_t502196753::get_offset_of_domain_id_0(),
	Context_t502196753::get_offset_of_context_id_1(),
	Context_t502196753::get_offset_of_static_data_2(),
	Context_t502196753_StaticFields::get_offset_of_default_server_context_sink_3(),
	Context_t502196753::get_offset_of_server_context_sink_chain_4(),
	Context_t502196753::get_offset_of_client_context_sink_chain_5(),
	Context_t502196753::get_offset_of_datastore_6(),
	Context_t502196753::get_offset_of_context_properties_7(),
	Context_t502196753::get_offset_of_frozen_8(),
	Context_t502196753_StaticFields::get_offset_of_global_count_9(),
	Context_t502196753_StaticFields::get_offset_of_namedSlots_10(),
	Context_t502196753_StaticFields::get_offset_of_global_dynamic_properties_11(),
	Context_t502196753::get_offset_of_context_dynamic_properties_12(),
	Context_t502196753::get_offset_of_callback_object_13(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize456 = { sizeof (DynamicPropertyCollection_t2282532998), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable456[1] = 
{
	DynamicPropertyCollection_t2282532998::get_offset_of__properties_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize457 = { sizeof (DynamicPropertyReg_t1839195831), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable457[2] = 
{
	DynamicPropertyReg_t1839195831::get_offset_of_Property_0(),
	DynamicPropertyReg_t1839195831::get_offset_of_Sink_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize458 = { sizeof (ContextCallbackObject_t3978189709), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize459 = { sizeof (ContextAttribute_t197102333), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable459[1] = 
{
	ContextAttribute_t197102333::get_offset_of_AttributeName_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize460 = { sizeof (CrossContextChannel_t2302426108), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize461 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize462 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize463 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize464 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize465 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize466 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize467 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize468 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize469 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize470 = { sizeof (SynchronizationAttribute_t3073724998), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable470[5] = 
{
	SynchronizationAttribute_t3073724998::get_offset_of__bReEntrant_1(),
	SynchronizationAttribute_t3073724998::get_offset_of__flavor_2(),
	SynchronizationAttribute_t3073724998::get_offset_of__lockCount_3(),
	SynchronizationAttribute_t3073724998::get_offset_of__mutex_4(),
	SynchronizationAttribute_t3073724998::get_offset_of__ownerThread_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize471 = { sizeof (SynchronizedClientContextSink_t3779986825), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable471[2] = 
{
	SynchronizedClientContextSink_t3779986825::get_offset_of__next_0(),
	SynchronizedClientContextSink_t3779986825::get_offset_of__att_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize472 = { sizeof (SynchronizedServerContextSink_t462987365), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable472[2] = 
{
	SynchronizedServerContextSink_t462987365::get_offset_of__next_0(),
	SynchronizedServerContextSink_t462987365::get_offset_of__att_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize473 = { sizeof (LeaseManager_t1025868639), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable473[2] = 
{
	LeaseManager_t1025868639::get_offset_of__objects_0(),
	LeaseManager_t1025868639::get_offset_of__timer_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize474 = { sizeof (LeaseSink_t3007073869), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable474[1] = 
{
	LeaseSink_t3007073869::get_offset_of__nextSink_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize475 = { sizeof (LifetimeServices_t2939669377), -1, sizeof(LifetimeServices_t2939669377_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable475[5] = 
{
	LifetimeServices_t2939669377_StaticFields::get_offset_of__leaseManagerPollTime_0(),
	LifetimeServices_t2939669377_StaticFields::get_offset_of__leaseTime_1(),
	LifetimeServices_t2939669377_StaticFields::get_offset_of__renewOnCallTime_2(),
	LifetimeServices_t2939669377_StaticFields::get_offset_of__sponsorshipTimeout_3(),
	LifetimeServices_t2939669377_StaticFields::get_offset_of__leaseManager_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize476 = { sizeof (ArgInfoType_t3252846202)+ sizeof (Il2CppObject), sizeof(uint8_t), 0, 0 };
extern const int32_t g_FieldOffsetTable476[3] = 
{
	ArgInfoType_t3252846202::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize477 = { sizeof (ArgInfo_t688271106), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable477[3] = 
{
	ArgInfo_t688271106::get_offset_of__paramMap_0(),
	ArgInfo_t688271106::get_offset_of__inoutArgCount_1(),
	ArgInfo_t688271106::get_offset_of__method_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize478 = { sizeof (AsyncResult_t2232356043), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable478[15] = 
{
	AsyncResult_t2232356043::get_offset_of_async_state_0(),
	AsyncResult_t2232356043::get_offset_of_handle_1(),
	AsyncResult_t2232356043::get_offset_of_async_delegate_2(),
	AsyncResult_t2232356043::get_offset_of_data_3(),
	AsyncResult_t2232356043::get_offset_of_object_data_4(),
	AsyncResult_t2232356043::get_offset_of_sync_completed_5(),
	AsyncResult_t2232356043::get_offset_of_completed_6(),
	AsyncResult_t2232356043::get_offset_of_endinvoke_called_7(),
	AsyncResult_t2232356043::get_offset_of_async_callback_8(),
	AsyncResult_t2232356043::get_offset_of_current_9(),
	AsyncResult_t2232356043::get_offset_of_original_10(),
	AsyncResult_t2232356043::get_offset_of_gchandle_11(),
	AsyncResult_t2232356043::get_offset_of_call_message_12(),
	AsyncResult_t2232356043::get_offset_of_message_ctrl_13(),
	AsyncResult_t2232356043::get_offset_of_reply_message_14(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize479 = { sizeof (ClientContextTerminatorSink_t3236389774), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable479[1] = 
{
	ClientContextTerminatorSink_t3236389774::get_offset_of__context_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize480 = { sizeof (ConstructionCall_t1254994451), -1, sizeof(ConstructionCall_t1254994451_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable480[7] = 
{
	ConstructionCall_t1254994451::get_offset_of__activator_11(),
	ConstructionCall_t1254994451::get_offset_of__activationAttributes_12(),
	ConstructionCall_t1254994451::get_offset_of__contextProperties_13(),
	ConstructionCall_t1254994451::get_offset_of__activationType_14(),
	ConstructionCall_t1254994451::get_offset_of__activationTypeName_15(),
	ConstructionCall_t1254994451::get_offset_of__isContextOk_16(),
	ConstructionCall_t1254994451_StaticFields::get_offset_of_U3CU3Ef__switchU24map20_17(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize481 = { sizeof (ConstructionCallDictionary_t2993650247), -1, sizeof(ConstructionCallDictionary_t2993650247_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable481[3] = 
{
	ConstructionCallDictionary_t2993650247_StaticFields::get_offset_of_InternalKeys_6(),
	ConstructionCallDictionary_t2993650247_StaticFields::get_offset_of_U3CU3Ef__switchU24map23_7(),
	ConstructionCallDictionary_t2993650247_StaticFields::get_offset_of_U3CU3Ef__switchU24map24_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize482 = { sizeof (EnvoyTerminatorSink_t3043186997), -1, sizeof(EnvoyTerminatorSink_t3043186997_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable482[1] = 
{
	EnvoyTerminatorSink_t3043186997_StaticFields::get_offset_of_Instance_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize483 = { sizeof (Header_t2756440555), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable483[4] = 
{
	Header_t2756440555::get_offset_of_HeaderNamespace_0(),
	Header_t2756440555::get_offset_of_MustUnderstand_1(),
	Header_t2756440555::get_offset_of_Name_2(),
	Header_t2756440555::get_offset_of_Value_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize484 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize485 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize486 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize487 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize488 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize489 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize490 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize491 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize492 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize493 = { sizeof (LogicalCallContext_t725724420), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable493[2] = 
{
	LogicalCallContext_t725724420::get_offset_of__data_0(),
	LogicalCallContext_t725724420::get_offset_of__remotingData_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize494 = { sizeof (CallContextRemotingData_t2648008188), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable494[1] = 
{
	CallContextRemotingData_t2648008188::get_offset_of__logicalCallID_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize495 = { sizeof (MethodCall_t2461541281), -1, sizeof(MethodCall_t2461541281_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable495[11] = 
{
	MethodCall_t2461541281::get_offset_of__uri_0(),
	MethodCall_t2461541281::get_offset_of__typeName_1(),
	MethodCall_t2461541281::get_offset_of__methodName_2(),
	MethodCall_t2461541281::get_offset_of__args_3(),
	MethodCall_t2461541281::get_offset_of__methodSignature_4(),
	MethodCall_t2461541281::get_offset_of__methodBase_5(),
	MethodCall_t2461541281::get_offset_of__callContext_6(),
	MethodCall_t2461541281::get_offset_of__genericArguments_7(),
	MethodCall_t2461541281::get_offset_of_ExternalProperties_8(),
	MethodCall_t2461541281::get_offset_of_InternalProperties_9(),
	MethodCall_t2461541281_StaticFields::get_offset_of_U3CU3Ef__switchU24map1F_10(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize496 = { sizeof (MethodCallDictionary_t1516131009), -1, sizeof(MethodCallDictionary_t1516131009_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable496[1] = 
{
	MethodCallDictionary_t1516131009_StaticFields::get_offset_of_InternalKeys_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize497 = { sizeof (MethodDictionary_t1742974787), -1, sizeof(MethodDictionary_t1742974787_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable497[6] = 
{
	MethodDictionary_t1742974787::get_offset_of__internalProperties_0(),
	MethodDictionary_t1742974787::get_offset_of__message_1(),
	MethodDictionary_t1742974787::get_offset_of__methodKeys_2(),
	MethodDictionary_t1742974787::get_offset_of__ownProperties_3(),
	MethodDictionary_t1742974787_StaticFields::get_offset_of_U3CU3Ef__switchU24map21_4(),
	MethodDictionary_t1742974787_StaticFields::get_offset_of_U3CU3Ef__switchU24map22_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize498 = { sizeof (DictionaryEnumerator_t492828146), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable498[3] = 
{
	DictionaryEnumerator_t492828146::get_offset_of__methodDictionary_0(),
	DictionaryEnumerator_t492828146::get_offset_of__hashtableEnum_1(),
	DictionaryEnumerator_t492828146::get_offset_of__posMethod_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize499 = { sizeof (MethodReturnDictionary_t981009581), -1, sizeof(MethodReturnDictionary_t981009581_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable499[2] = 
{
	MethodReturnDictionary_t981009581_StaticFields::get_offset_of_InternalReturnKeys_6(),
	MethodReturnDictionary_t981009581_StaticFields::get_offset_of_InternalExceptionKeys_7(),
};
#ifdef __clang__
#pragma clang diagnostic pop
#endif
