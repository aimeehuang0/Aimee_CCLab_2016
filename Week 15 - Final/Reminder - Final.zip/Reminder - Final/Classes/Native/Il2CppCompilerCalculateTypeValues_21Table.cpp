﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <cstring>
#include <string.h>
#include <stdio.h>
#include <cmath>
#include <limits>
#include <assert.h>


#include "class-internals.h"
#include "codegen/il2cpp-codegen.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_2871423837.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_U769078069.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_U420114983.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_1135469853.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_Ut56702769.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_U707185157.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_1764217217.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_3133065407.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_2375210762.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_2985503331.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_U318924311.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_2206407592.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_1659392090.h"
#include "AssemblyU2DUnityScript_U3CModuleU3E3783534214.h"
#include "AssemblyU2DUnityScript_CameraFlyScript1126393843.h"



#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2100 = { sizeof (TimedObjectActivator_t2871423837), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2100[1] = 
{
	TimedObjectActivator_t2871423837::get_offset_of_entries_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2101 = { sizeof (Action_t769078069)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2101[6] = 
{
	Action_t769078069::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2102 = { sizeof (Entry_t420114983), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2102[3] = 
{
	Entry_t420114983::get_offset_of_target_0(),
	Entry_t420114983::get_offset_of_action_1(),
	Entry_t420114983::get_offset_of_delay_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2103 = { sizeof (Entries_t1135469853), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2103[1] = 
{
	Entries_t1135469853::get_offset_of_entries_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2104 = { sizeof (U3CActivateU3Ec__Iterator0_t56702769), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2104[4] = 
{
	U3CActivateU3Ec__Iterator0_t56702769::get_offset_of_entry_0(),
	U3CActivateU3Ec__Iterator0_t56702769::get_offset_of_U24current_1(),
	U3CActivateU3Ec__Iterator0_t56702769::get_offset_of_U24disposing_2(),
	U3CActivateU3Ec__Iterator0_t56702769::get_offset_of_U24PC_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2105 = { sizeof (U3CDeactivateU3Ec__Iterator1_t707185157), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2105[4] = 
{
	U3CDeactivateU3Ec__Iterator1_t707185157::get_offset_of_entry_0(),
	U3CDeactivateU3Ec__Iterator1_t707185157::get_offset_of_U24current_1(),
	U3CDeactivateU3Ec__Iterator1_t707185157::get_offset_of_U24disposing_2(),
	U3CDeactivateU3Ec__Iterator1_t707185157::get_offset_of_U24PC_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2106 = { sizeof (U3CReloadLevelU3Ec__Iterator2_t1764217217), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2106[4] = 
{
	U3CReloadLevelU3Ec__Iterator2_t1764217217::get_offset_of_entry_0(),
	U3CReloadLevelU3Ec__Iterator2_t1764217217::get_offset_of_U24current_1(),
	U3CReloadLevelU3Ec__Iterator2_t1764217217::get_offset_of_U24disposing_2(),
	U3CReloadLevelU3Ec__Iterator2_t1764217217::get_offset_of_U24PC_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2107 = { sizeof (TimedObjectDestructor_t3133065407), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2107[2] = 
{
	TimedObjectDestructor_t3133065407::get_offset_of_m_TimeOut_2(),
	TimedObjectDestructor_t3133065407::get_offset_of_m_DetachChildren_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2108 = { sizeof (WaypointCircuit_t2375210762), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2108[16] = 
{
	WaypointCircuit_t2375210762::get_offset_of_waypointList_2(),
	WaypointCircuit_t2375210762::get_offset_of_smoothRoute_3(),
	WaypointCircuit_t2375210762::get_offset_of_numPoints_4(),
	WaypointCircuit_t2375210762::get_offset_of_points_5(),
	WaypointCircuit_t2375210762::get_offset_of_distances_6(),
	WaypointCircuit_t2375210762::get_offset_of_editorVisualisationSubsteps_7(),
	WaypointCircuit_t2375210762::get_offset_of_U3CLengthU3Ek__BackingField_8(),
	WaypointCircuit_t2375210762::get_offset_of_p0n_9(),
	WaypointCircuit_t2375210762::get_offset_of_p1n_10(),
	WaypointCircuit_t2375210762::get_offset_of_p2n_11(),
	WaypointCircuit_t2375210762::get_offset_of_p3n_12(),
	WaypointCircuit_t2375210762::get_offset_of_i_13(),
	WaypointCircuit_t2375210762::get_offset_of_P0_14(),
	WaypointCircuit_t2375210762::get_offset_of_P1_15(),
	WaypointCircuit_t2375210762::get_offset_of_P2_16(),
	WaypointCircuit_t2375210762::get_offset_of_P3_17(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2109 = { sizeof (WaypointList_t2985503331), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2109[2] = 
{
	WaypointList_t2985503331::get_offset_of_circuit_0(),
	WaypointList_t2985503331::get_offset_of_items_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2110 = { sizeof (RoutePoint_t318924311)+ sizeof (Il2CppObject), sizeof(RoutePoint_t318924311 ), 0, 0 };
extern const int32_t g_FieldOffsetTable2110[2] = 
{
	RoutePoint_t318924311::get_offset_of_position_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	RoutePoint_t318924311::get_offset_of_direction_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2111 = { sizeof (WaypointProgressTracker_t2206407592), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2111[15] = 
{
	WaypointProgressTracker_t2206407592::get_offset_of_circuit_2(),
	WaypointProgressTracker_t2206407592::get_offset_of_lookAheadForTargetOffset_3(),
	WaypointProgressTracker_t2206407592::get_offset_of_lookAheadForTargetFactor_4(),
	WaypointProgressTracker_t2206407592::get_offset_of_lookAheadForSpeedOffset_5(),
	WaypointProgressTracker_t2206407592::get_offset_of_lookAheadForSpeedFactor_6(),
	WaypointProgressTracker_t2206407592::get_offset_of_progressStyle_7(),
	WaypointProgressTracker_t2206407592::get_offset_of_pointToPointThreshold_8(),
	WaypointProgressTracker_t2206407592::get_offset_of_U3CtargetPointU3Ek__BackingField_9(),
	WaypointProgressTracker_t2206407592::get_offset_of_U3CspeedPointU3Ek__BackingField_10(),
	WaypointProgressTracker_t2206407592::get_offset_of_U3CprogressPointU3Ek__BackingField_11(),
	WaypointProgressTracker_t2206407592::get_offset_of_target_12(),
	WaypointProgressTracker_t2206407592::get_offset_of_progressDistance_13(),
	WaypointProgressTracker_t2206407592::get_offset_of_progressNum_14(),
	WaypointProgressTracker_t2206407592::get_offset_of_lastPosition_15(),
	WaypointProgressTracker_t2206407592::get_offset_of_speed_16(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2112 = { sizeof (ProgressStyle_t1659392090)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2112[3] = 
{
	ProgressStyle_t1659392090::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2113 = { sizeof (U3CModuleU3E_t3783534224), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2114 = { sizeof (CameraFlyScript_t1126393843), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2114[1] = 
{
	CameraFlyScript_t1126393843::get_offset_of_Speed_2(),
};
#ifdef __clang__
#pragma clang diagnostic pop
#endif
