﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// UnityStandardAssets.Utility.FOVKick/<FOVKickDown>c__Iterator1
struct U3CFOVKickDownU3Ec__Iterator1_t1597325334;
// System.Object
struct Il2CppObject;

#include "codegen/il2cpp-codegen.h"

// System.Void UnityStandardAssets.Utility.FOVKick/<FOVKickDown>c__Iterator1::.ctor()
extern "C"  void U3CFOVKickDownU3Ec__Iterator1__ctor_m2215016177 (U3CFOVKickDownU3Ec__Iterator1_t1597325334 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Boolean UnityStandardAssets.Utility.FOVKick/<FOVKickDown>c__Iterator1::MoveNext()
extern "C"  bool U3CFOVKickDownU3Ec__Iterator1_MoveNext_m3482038055 (U3CFOVKickDownU3Ec__Iterator1_t1597325334 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Object UnityStandardAssets.Utility.FOVKick/<FOVKickDown>c__Iterator1::System.Collections.Generic.IEnumerator<object>.get_Current()
extern "C"  Il2CppObject * U3CFOVKickDownU3Ec__Iterator1_System_Collections_Generic_IEnumeratorU3CobjectU3E_get_Current_m3977423835 (U3CFOVKickDownU3Ec__Iterator1_t1597325334 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Object UnityStandardAssets.Utility.FOVKick/<FOVKickDown>c__Iterator1::System.Collections.IEnumerator.get_Current()
extern "C"  Il2CppObject * U3CFOVKickDownU3Ec__Iterator1_System_Collections_IEnumerator_get_Current_m1330670403 (U3CFOVKickDownU3Ec__Iterator1_t1597325334 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Utility.FOVKick/<FOVKickDown>c__Iterator1::Dispose()
extern "C"  void U3CFOVKickDownU3Ec__Iterator1_Dispose_m4205816002 (U3CFOVKickDownU3Ec__Iterator1_t1597325334 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Utility.FOVKick/<FOVKickDown>c__Iterator1::Reset()
extern "C"  void U3CFOVKickDownU3Ec__Iterator1_Reset_m2878063492 (U3CFOVKickDownU3Ec__Iterator1_t1597325334 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
