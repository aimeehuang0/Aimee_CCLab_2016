﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// MouseLook
struct MouseLook_t2643707144;

#include "codegen/il2cpp-codegen.h"

// System.Void MouseLook::.ctor()
extern "C"  void MouseLook__ctor_m1062050195 (MouseLook_t2643707144 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void MouseLook::Update()
extern "C"  void MouseLook_Update_m1706128328 (MouseLook_t2643707144 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void MouseLook::Start()
extern "C"  void MouseLook_Start_m3145701487 (MouseLook_t2643707144 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Single MouseLook::ClampAngle(System.Single,System.Single,System.Single)
extern "C"  float MouseLook_ClampAngle_m2357187678 (Il2CppObject * __this /* static, unused */, float ___angle0, float ___min1, float ___max2, const MethodInfo* method) IL2CPP_METHOD_ATTR;
