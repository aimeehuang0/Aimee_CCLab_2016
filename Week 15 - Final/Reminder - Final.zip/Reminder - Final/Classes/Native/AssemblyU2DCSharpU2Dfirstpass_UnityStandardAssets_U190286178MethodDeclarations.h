﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// UnityStandardAssets.Utility.ParticleSystemDestroyer
struct ParticleSystemDestroyer_t190286178;
// System.Collections.IEnumerator
struct IEnumerator_t1466026749;

#include "codegen/il2cpp-codegen.h"

// System.Void UnityStandardAssets.Utility.ParticleSystemDestroyer::.ctor()
extern "C"  void ParticleSystemDestroyer__ctor_m4266701090 (ParticleSystemDestroyer_t190286178 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Collections.IEnumerator UnityStandardAssets.Utility.ParticleSystemDestroyer::Start()
extern "C"  Il2CppObject * ParticleSystemDestroyer_Start_m4031364958 (ParticleSystemDestroyer_t190286178 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Utility.ParticleSystemDestroyer::Stop()
extern "C"  void ParticleSystemDestroyer_Stop_m945327188 (ParticleSystemDestroyer_t190286178 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
