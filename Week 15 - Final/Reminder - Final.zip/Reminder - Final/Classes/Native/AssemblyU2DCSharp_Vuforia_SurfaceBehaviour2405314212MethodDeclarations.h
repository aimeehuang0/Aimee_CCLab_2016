﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// Vuforia.SurfaceBehaviour
struct SurfaceBehaviour_t2405314212;

#include "codegen/il2cpp-codegen.h"

// System.Void Vuforia.SurfaceBehaviour::.ctor()
extern "C"  void SurfaceBehaviour__ctor_m1448804633 (SurfaceBehaviour_t2405314212 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
