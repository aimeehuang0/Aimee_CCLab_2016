﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// UnityStandardAssets.Utility.AutoMobileShaderSwitch/ReplacementDefinition
struct ReplacementDefinition_t4021787953;

#include "codegen/il2cpp-codegen.h"

// System.Void UnityStandardAssets.Utility.AutoMobileShaderSwitch/ReplacementDefinition::.ctor()
extern "C"  void ReplacementDefinition__ctor_m3376485542 (ReplacementDefinition_t4021787953 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
