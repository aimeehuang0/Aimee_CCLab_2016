﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// UnityStandardAssets.Utility.AutoMoveAndRotate
struct AutoMoveAndRotate_t2592441618;

#include "codegen/il2cpp-codegen.h"

// System.Void UnityStandardAssets.Utility.AutoMoveAndRotate::.ctor()
extern "C"  void AutoMoveAndRotate__ctor_m4023033122 (AutoMoveAndRotate_t2592441618 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Utility.AutoMoveAndRotate::Start()
extern "C"  void AutoMoveAndRotate_Start_m3825934166 (AutoMoveAndRotate_t2592441618 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Utility.AutoMoveAndRotate::Update()
extern "C"  void AutoMoveAndRotate_Update_m3362279711 (AutoMoveAndRotate_t2592441618 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
