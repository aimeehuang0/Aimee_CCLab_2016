﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <cstring>
#include <string.h>
#include <stdio.h>
#include <cmath>
#include <limits>
#include <assert.h>


#include "class-internals.h"
#include "codegen/il2cpp-codegen.h"
#include "mscorlib_System_Text_DecoderFallbackBuffer4206371382.h"
#include "mscorlib_System_Text_DecoderFallbackException561423693.h"
#include "mscorlib_System_Text_DecoderReplacementFallback3042394152.h"
#include "mscorlib_System_Text_DecoderReplacementFallbackBuf3471122670.h"
#include "mscorlib_System_Text_EncoderExceptionFallback1520212111.h"
#include "mscorlib_System_Text_EncoderExceptionFallbackBuffe2027398699.h"
#include "mscorlib_System_Text_EncoderFallback1756452756.h"
#include "mscorlib_System_Text_EncoderFallbackBuffer3883615514.h"
#include "mscorlib_System_Text_EncoderFallbackException1447984975.h"
#include "mscorlib_System_Text_EncoderReplacementFallback4228544112.h"
#include "mscorlib_System_Text_EncoderReplacementFallbackBuf1313574570.h"
#include "mscorlib_System_Text_Encoding663144255.h"
#include "mscorlib_System_Text_Encoding_ForwardingDecoder2155223679.h"
#include "mscorlib_System_Text_Latin1Encoding3483306430.h"
#include "mscorlib_System_Text_StringBuilder1221177846.h"
#include "mscorlib_System_Text_UTF32Encoding549530865.h"
#include "mscorlib_System_Text_UTF32Encoding_UTF32Decoder2654498546.h"
#include "mscorlib_System_Text_UTF7Encoding741406939.h"
#include "mscorlib_System_Text_UTF7Encoding_UTF7Decoder3571436826.h"
#include "mscorlib_System_Text_UTF8Encoding111055448.h"
#include "mscorlib_System_Text_UTF8Encoding_UTF8Decoder2447592404.h"
#include "mscorlib_System_Text_UnicodeEncoding4081757012.h"
#include "mscorlib_System_Text_UnicodeEncoding_UnicodeDecode1968329522.h"
#include "mscorlib_System_Threading_CompressedStack1568001503.h"
#include "mscorlib_System_Threading_EventResetMode4116945436.h"
#include "mscorlib_System_Threading_EventWaitHandle2091316307.h"
#include "mscorlib_System_Threading_ExecutionContext1392266323.h"
#include "mscorlib_System_Threading_Interlocked1625106012.h"
#include "mscorlib_System_Threading_ManualResetEvent926074657.h"
#include "mscorlib_System_Threading_Monitor3228523394.h"
#include "mscorlib_System_Threading_Mutex297030111.h"
#include "mscorlib_System_Threading_NativeEventCalls1850675218.h"
#include "mscorlib_System_Threading_SynchronizationLockExcept117698316.h"
#include "mscorlib_System_Threading_Thread241561612.h"
#include "mscorlib_System_Threading_ThreadAbortException1150575753.h"
#include "mscorlib_System_Threading_ThreadInterruptedException63303933.h"
#include "mscorlib_System_Threading_ThreadPool3989917080.h"
#include "mscorlib_System_Threading_ThreadState1158972609.h"
#include "mscorlib_System_Threading_ThreadStateException1404755912.h"
#include "mscorlib_System_Threading_Timer791717973.h"
#include "mscorlib_System_Threading_Timer_TimerComparer876299723.h"
#include "mscorlib_System_Threading_Timer_Scheduler697594.h"
#include "mscorlib_System_Threading_WaitHandle677569169.h"
#include "mscorlib_System_AccessViolationException182079320.h"
#include "mscorlib_System_ActivationContext1572332809.h"
#include "mscorlib_System_Activator1850728717.h"
#include "mscorlib_System_AppDomain2719102437.h"
#include "mscorlib_System_AppDomainManager54965696.h"
#include "mscorlib_System_AppDomainSetup611332832.h"
#include "mscorlib_System_ApplicationException474868623.h"
#include "mscorlib_System_ApplicationIdentity3292367950.h"
#include "mscorlib_System_ArgumentException3259014390.h"
#include "mscorlib_System_ArgumentNullException628810857.h"
#include "mscorlib_System_ArgumentOutOfRangeException279959794.h"
#include "mscorlib_System_ArithmeticException3261462543.h"
#include "mscorlib_System_ArrayTypeMismatchException2071164632.h"
#include "mscorlib_System_AssemblyLoadEventArgs4233815743.h"
#include "mscorlib_System_AttributeTargets1984597432.h"
#include "mscorlib_System_BitConverter3195628829.h"
#include "mscorlib_System_Buffer3497320070.h"
#include "mscorlib_System_CharEnumerator1926099410.h"
#include "mscorlib_System_Console2311202731.h"
#include "mscorlib_System_ContextBoundObject4264702438.h"
#include "mscorlib_System_Convert2607082565.h"
#include "mscorlib_System_DBNull972229383.h"
#include "mscorlib_System_DateTime693205669.h"
#include "mscorlib_System_DateTime_Which4078252770.h"
#include "mscorlib_System_DateTimeKind2186819611.h"
#include "mscorlib_System_DateTimeOffset1362988906.h"
#include "mscorlib_System_DateTimeUtils1974353808.h"
#include "mscorlib_System_DayOfWeek721777893.h"
#include "mscorlib_System_DelegateData1572802995.h"
#include "mscorlib_System_DelegateSerializationHolder753405077.h"
#include "mscorlib_System_DelegateSerializationHolder_Delega3215410094.h"
#include "mscorlib_System_DivideByZeroException1660837001.h"
#include "mscorlib_System_DllNotFoundException3636280042.h"
#include "mscorlib_System_EntryPointNotFoundException3956266210.h"
#include "mscorlib_System_MonoEnumInfo2335995564.h"
#include "mscorlib_System_MonoEnumInfo_SByteComparer4284068120.h"
#include "mscorlib_System_MonoEnumInfo_ShortComparer1280224355.h"
#include "mscorlib_System_MonoEnumInfo_IntComparer1754594706.h"
#include "mscorlib_System_MonoEnumInfo_LongComparer3923115571.h"
#include "mscorlib_System_Environment3662374671.h"
#include "mscorlib_System_Environment_SpecialFolder1519540278.h"
#include "mscorlib_System_EventArgs3289624707.h"
#include "mscorlib_System_ExecutionEngineException1360775125.h"
#include "mscorlib_System_FieldAccessException1797813379.h"
#include "mscorlib_System_FlagsAttribute859561169.h"
#include "mscorlib_System_FormatException2948921286.h"
#include "mscorlib_System_GC2902933594.h"
#include "mscorlib_System_Guid2533601593.h"
#include "mscorlib_System_IndexOutOfRangeException3527622107.h"
#include "mscorlib_System_InvalidCastException3625212209.h"
#include "mscorlib_System_InvalidOperationException721527559.h"
#include "mscorlib_System_LoaderOptimization1143026982.h"
#include "mscorlib_System_LocalDataStoreSlot486331200.h"
#include "mscorlib_System_Math2022911894.h"
#include "mscorlib_System_MemberAccessException2005094827.h"



#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize700 = { sizeof (DecoderFallbackBuffer_t4206371382), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize701 = { sizeof (DecoderFallbackException_t561423693), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable701[2] = 
{
	DecoderFallbackException_t561423693::get_offset_of_bytes_unknown_13(),
	DecoderFallbackException_t561423693::get_offset_of_index_14(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize702 = { sizeof (DecoderReplacementFallback_t3042394152), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable702[1] = 
{
	DecoderReplacementFallback_t3042394152::get_offset_of_replacement_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize703 = { sizeof (DecoderReplacementFallbackBuffer_t3471122670), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable703[3] = 
{
	DecoderReplacementFallbackBuffer_t3471122670::get_offset_of_fallback_assigned_0(),
	DecoderReplacementFallbackBuffer_t3471122670::get_offset_of_current_1(),
	DecoderReplacementFallbackBuffer_t3471122670::get_offset_of_replacement_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize704 = { sizeof (EncoderExceptionFallback_t1520212111), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize705 = { sizeof (EncoderExceptionFallbackBuffer_t2027398699), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize706 = { sizeof (EncoderFallback_t1756452756), -1, sizeof(EncoderFallback_t1756452756_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable706[3] = 
{
	EncoderFallback_t1756452756_StaticFields::get_offset_of_exception_fallback_0(),
	EncoderFallback_t1756452756_StaticFields::get_offset_of_replacement_fallback_1(),
	EncoderFallback_t1756452756_StaticFields::get_offset_of_standard_safe_fallback_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize707 = { sizeof (EncoderFallbackBuffer_t3883615514), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize708 = { sizeof (EncoderFallbackException_t1447984975), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable708[4] = 
{
	EncoderFallbackException_t1447984975::get_offset_of_char_unknown_13(),
	EncoderFallbackException_t1447984975::get_offset_of_char_unknown_high_14(),
	EncoderFallbackException_t1447984975::get_offset_of_char_unknown_low_15(),
	EncoderFallbackException_t1447984975::get_offset_of_index_16(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize709 = { sizeof (EncoderReplacementFallback_t4228544112), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable709[1] = 
{
	EncoderReplacementFallback_t4228544112::get_offset_of_replacement_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize710 = { sizeof (EncoderReplacementFallbackBuffer_t1313574570), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable710[3] = 
{
	EncoderReplacementFallbackBuffer_t1313574570::get_offset_of_replacement_0(),
	EncoderReplacementFallbackBuffer_t1313574570::get_offset_of_current_1(),
	EncoderReplacementFallbackBuffer_t1313574570::get_offset_of_fallback_assigned_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize711 = { sizeof (Encoding_t663144255), -1, sizeof(Encoding_t663144255_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable711[28] = 
{
	Encoding_t663144255::get_offset_of_codePage_0(),
	Encoding_t663144255::get_offset_of_windows_code_page_1(),
	Encoding_t663144255::get_offset_of_is_readonly_2(),
	Encoding_t663144255::get_offset_of_decoder_fallback_3(),
	Encoding_t663144255::get_offset_of_encoder_fallback_4(),
	Encoding_t663144255_StaticFields::get_offset_of_i18nAssembly_5(),
	Encoding_t663144255_StaticFields::get_offset_of_i18nDisabled_6(),
	Encoding_t663144255_StaticFields::get_offset_of_encodings_7(),
	Encoding_t663144255::get_offset_of_body_name_8(),
	Encoding_t663144255::get_offset_of_encoding_name_9(),
	Encoding_t663144255::get_offset_of_header_name_10(),
	Encoding_t663144255::get_offset_of_is_mail_news_display_11(),
	Encoding_t663144255::get_offset_of_is_mail_news_save_12(),
	Encoding_t663144255::get_offset_of_is_browser_save_13(),
	Encoding_t663144255::get_offset_of_is_browser_display_14(),
	Encoding_t663144255::get_offset_of_web_name_15(),
	Encoding_t663144255_StaticFields::get_offset_of_asciiEncoding_16(),
	Encoding_t663144255_StaticFields::get_offset_of_bigEndianEncoding_17(),
	Encoding_t663144255_StaticFields::get_offset_of_defaultEncoding_18(),
	Encoding_t663144255_StaticFields::get_offset_of_utf7Encoding_19(),
	Encoding_t663144255_StaticFields::get_offset_of_utf8EncodingWithMarkers_20(),
	Encoding_t663144255_StaticFields::get_offset_of_utf8EncodingWithoutMarkers_21(),
	Encoding_t663144255_StaticFields::get_offset_of_unicodeEncoding_22(),
	Encoding_t663144255_StaticFields::get_offset_of_isoLatin1Encoding_23(),
	Encoding_t663144255_StaticFields::get_offset_of_utf8EncodingUnsafe_24(),
	Encoding_t663144255_StaticFields::get_offset_of_utf32Encoding_25(),
	Encoding_t663144255_StaticFields::get_offset_of_bigEndianUTF32Encoding_26(),
	Encoding_t663144255_StaticFields::get_offset_of_lockobj_27(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize712 = { sizeof (ForwardingDecoder_t2155223679), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable712[1] = 
{
	ForwardingDecoder_t2155223679::get_offset_of_encoding_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize713 = { sizeof (Latin1Encoding_t3483306430), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize714 = { sizeof (StringBuilder_t1221177846), sizeof(char*), 0, 0 };
extern const int32_t g_FieldOffsetTable714[5] = 
{
	0,
	StringBuilder_t1221177846::get_offset_of__length_1(),
	StringBuilder_t1221177846::get_offset_of__str_2(),
	StringBuilder_t1221177846::get_offset_of__cached_str_3(),
	StringBuilder_t1221177846::get_offset_of__maxCapacity_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize715 = { sizeof (UTF32Encoding_t549530865), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable715[2] = 
{
	UTF32Encoding_t549530865::get_offset_of_bigEndian_28(),
	UTF32Encoding_t549530865::get_offset_of_byteOrderMark_29(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize716 = { sizeof (UTF32Decoder_t2654498546), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable716[3] = 
{
	UTF32Decoder_t2654498546::get_offset_of_bigEndian_2(),
	UTF32Decoder_t2654498546::get_offset_of_leftOverByte_3(),
	UTF32Decoder_t2654498546::get_offset_of_leftOverLength_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize717 = { sizeof (UTF7Encoding_t741406939), -1, sizeof(UTF7Encoding_t741406939_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable717[3] = 
{
	UTF7Encoding_t741406939::get_offset_of_allowOptionals_28(),
	UTF7Encoding_t741406939_StaticFields::get_offset_of_encodingRules_29(),
	UTF7Encoding_t741406939_StaticFields::get_offset_of_base64Values_30(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize718 = { sizeof (UTF7Decoder_t3571436826), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable718[1] = 
{
	UTF7Decoder_t3571436826::get_offset_of_leftOver_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize719 = { sizeof (UTF8Encoding_t111055448), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable719[1] = 
{
	UTF8Encoding_t111055448::get_offset_of_emitIdentifier_28(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize720 = { sizeof (UTF8Decoder_t2447592404), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable720[2] = 
{
	UTF8Decoder_t2447592404::get_offset_of_leftOverBits_2(),
	UTF8Decoder_t2447592404::get_offset_of_leftOverCount_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize721 = { sizeof (UnicodeEncoding_t4081757012), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable721[2] = 
{
	UnicodeEncoding_t4081757012::get_offset_of_bigEndian_28(),
	UnicodeEncoding_t4081757012::get_offset_of_byteOrderMark_29(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize722 = { sizeof (UnicodeDecoder_t1968329522), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable722[2] = 
{
	UnicodeDecoder_t1968329522::get_offset_of_bigEndian_2(),
	UnicodeDecoder_t1968329522::get_offset_of_leftOverByte_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize723 = { sizeof (CompressedStack_t1568001503), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable723[1] = 
{
	CompressedStack_t1568001503::get_offset_of__list_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize724 = { sizeof (EventResetMode_t4116945436)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable724[3] = 
{
	EventResetMode_t4116945436::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize725 = { sizeof (EventWaitHandle_t2091316307), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize726 = { sizeof (ExecutionContext_t1392266323), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable726[3] = 
{
	ExecutionContext_t1392266323::get_offset_of__sc_0(),
	ExecutionContext_t1392266323::get_offset_of__suppressFlow_1(),
	ExecutionContext_t1392266323::get_offset_of__capture_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize727 = { sizeof (Interlocked_t1625106012), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize728 = { sizeof (ManualResetEvent_t926074657), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize729 = { sizeof (Monitor_t3228523394), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize730 = { sizeof (Mutex_t297030111), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize731 = { sizeof (NativeEventCalls_t1850675218), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize732 = { sizeof (SynchronizationLockException_t117698316), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize733 = { sizeof (Thread_t241561612), -1, sizeof(Thread_t241561612_StaticFields), sizeof(Thread_t241561612_ThreadStaticFields) };
extern const int32_t g_FieldOffsetTable733[52] = 
{
	Thread_t241561612::get_offset_of_lock_thread_id_0(),
	Thread_t241561612::get_offset_of_system_thread_handle_1(),
	Thread_t241561612::get_offset_of_cached_culture_info_2(),
	Thread_t241561612::get_offset_of_unused0_3(),
	Thread_t241561612::get_offset_of_threadpool_thread_4(),
	Thread_t241561612::get_offset_of_name_5(),
	Thread_t241561612::get_offset_of_name_len_6(),
	Thread_t241561612::get_offset_of_state_7(),
	Thread_t241561612::get_offset_of_abort_exc_8(),
	Thread_t241561612::get_offset_of_abort_state_handle_9(),
	Thread_t241561612::get_offset_of_thread_id_10(),
	Thread_t241561612::get_offset_of_start_notify_11(),
	Thread_t241561612::get_offset_of_stack_ptr_12(),
	Thread_t241561612::get_offset_of_static_data_13(),
	Thread_t241561612::get_offset_of_jit_data_14(),
	Thread_t241561612::get_offset_of_lock_data_15(),
	Thread_t241561612::get_offset_of_current_appcontext_16(),
	Thread_t241561612::get_offset_of_stack_size_17(),
	Thread_t241561612::get_offset_of_start_obj_18(),
	Thread_t241561612::get_offset_of_appdomain_refs_19(),
	Thread_t241561612::get_offset_of_interruption_requested_20(),
	Thread_t241561612::get_offset_of_suspend_event_21(),
	Thread_t241561612::get_offset_of_suspended_event_22(),
	Thread_t241561612::get_offset_of_resume_event_23(),
	Thread_t241561612::get_offset_of_synch_cs_24(),
	Thread_t241561612::get_offset_of_serialized_culture_info_25(),
	Thread_t241561612::get_offset_of_serialized_culture_info_len_26(),
	Thread_t241561612::get_offset_of_serialized_ui_culture_info_27(),
	Thread_t241561612::get_offset_of_serialized_ui_culture_info_len_28(),
	Thread_t241561612::get_offset_of_thread_dump_requested_29(),
	Thread_t241561612::get_offset_of_end_stack_30(),
	Thread_t241561612::get_offset_of_thread_interrupt_requested_31(),
	Thread_t241561612::get_offset_of_apartment_state_32(),
	Thread_t241561612::get_offset_of_critical_region_level_33(),
	Thread_t241561612::get_offset_of_small_id_34(),
	Thread_t241561612::get_offset_of_manage_callback_35(),
	Thread_t241561612::get_offset_of_pending_exception_36(),
	Thread_t241561612::get_offset_of_ec_to_set_37(),
	Thread_t241561612::get_offset_of_interrupt_on_stop_38(),
	Thread_t241561612::get_offset_of_unused3_39(),
	Thread_t241561612::get_offset_of_unused4_40(),
	Thread_t241561612::get_offset_of_unused5_41(),
	Thread_t241561612::get_offset_of_unused6_42(),
	THREAD_STATIC_FIELD_OFFSET,
	THREAD_STATIC_FIELD_OFFSET,
	Thread_t241561612::get_offset_of_threadstart_45(),
	Thread_t241561612::get_offset_of_managed_id_46(),
	Thread_t241561612::get_offset_of__principal_47(),
	Thread_t241561612_StaticFields::get_offset_of_datastorehash_48(),
	Thread_t241561612_StaticFields::get_offset_of_datastore_lock_49(),
	Thread_t241561612::get_offset_of_in_currentculture_50(),
	Thread_t241561612_StaticFields::get_offset_of_culture_lock_51(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize734 = { sizeof (ThreadAbortException_t1150575753), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize735 = { sizeof (ThreadInterruptedException_t63303933), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize736 = { sizeof (ThreadPool_t3989917080), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize737 = { sizeof (ThreadState_t1158972609)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable737[11] = 
{
	ThreadState_t1158972609::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize738 = { sizeof (ThreadStateException_t1404755912), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize739 = { sizeof (Timer_t791717973), -1, sizeof(Timer_t791717973_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable739[7] = 
{
	Timer_t791717973_StaticFields::get_offset_of_scheduler_1(),
	Timer_t791717973::get_offset_of_callback_2(),
	Timer_t791717973::get_offset_of_state_3(),
	Timer_t791717973::get_offset_of_due_time_ms_4(),
	Timer_t791717973::get_offset_of_period_ms_5(),
	Timer_t791717973::get_offset_of_next_run_6(),
	Timer_t791717973::get_offset_of_disposed_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize740 = { sizeof (TimerComparer_t876299723), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize741 = { sizeof (Scheduler_t697594), -1, sizeof(Scheduler_t697594_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable741[2] = 
{
	Scheduler_t697594_StaticFields::get_offset_of_instance_0(),
	Scheduler_t697594::get_offset_of_list_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize742 = { sizeof (WaitHandle_t677569169), -1, sizeof(WaitHandle_t677569169_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable742[4] = 
{
	0,
	WaitHandle_t677569169::get_offset_of_safe_wait_handle_2(),
	WaitHandle_t677569169_StaticFields::get_offset_of_InvalidHandle_3(),
	WaitHandle_t677569169::get_offset_of_disposed_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize743 = { sizeof (AccessViolationException_t182079320), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize744 = { sizeof (ActivationContext_t1572332809), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable744[1] = 
{
	ActivationContext_t1572332809::get_offset_of__disposed_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize745 = { sizeof (Activator_t1850728717), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize746 = { sizeof (AppDomain_t2719102437), -1, sizeof(AppDomain_t2719102437_StaticFields), sizeof(AppDomain_t2719102437_ThreadStaticFields) };
extern const int32_t g_FieldOffsetTable746[21] = 
{
	AppDomain_t2719102437::get_offset_of__mono_app_domain_1(),
	AppDomain_t2719102437_StaticFields::get_offset_of__process_guid_2(),
	THREAD_STATIC_FIELD_OFFSET,
	THREAD_STATIC_FIELD_OFFSET,
	THREAD_STATIC_FIELD_OFFSET,
	AppDomain_t2719102437::get_offset_of__evidence_6(),
	AppDomain_t2719102437::get_offset_of__granted_7(),
	AppDomain_t2719102437::get_offset_of__principalPolicy_8(),
	THREAD_STATIC_FIELD_OFFSET,
	AppDomain_t2719102437_StaticFields::get_offset_of_default_domain_10(),
	AppDomain_t2719102437::get_offset_of__domain_manager_11(),
	AppDomain_t2719102437::get_offset_of__activation_12(),
	AppDomain_t2719102437::get_offset_of__applicationIdentity_13(),
	AppDomain_t2719102437::get_offset_of_AssemblyLoad_14(),
	AppDomain_t2719102437::get_offset_of_AssemblyResolve_15(),
	AppDomain_t2719102437::get_offset_of_DomainUnload_16(),
	AppDomain_t2719102437::get_offset_of_ProcessExit_17(),
	AppDomain_t2719102437::get_offset_of_ResourceResolve_18(),
	AppDomain_t2719102437::get_offset_of_TypeResolve_19(),
	AppDomain_t2719102437::get_offset_of_UnhandledException_20(),
	AppDomain_t2719102437::get_offset_of_ReflectionOnlyAssemblyResolve_21(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize747 = { sizeof (AppDomainManager_t54965696), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize748 = { sizeof (AppDomainSetup_t611332832), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable748[22] = 
{
	AppDomainSetup_t611332832::get_offset_of_application_base_0(),
	AppDomainSetup_t611332832::get_offset_of_application_name_1(),
	AppDomainSetup_t611332832::get_offset_of_cache_path_2(),
	AppDomainSetup_t611332832::get_offset_of_configuration_file_3(),
	AppDomainSetup_t611332832::get_offset_of_dynamic_base_4(),
	AppDomainSetup_t611332832::get_offset_of_license_file_5(),
	AppDomainSetup_t611332832::get_offset_of_private_bin_path_6(),
	AppDomainSetup_t611332832::get_offset_of_private_bin_path_probe_7(),
	AppDomainSetup_t611332832::get_offset_of_shadow_copy_directories_8(),
	AppDomainSetup_t611332832::get_offset_of_shadow_copy_files_9(),
	AppDomainSetup_t611332832::get_offset_of_publisher_policy_10(),
	AppDomainSetup_t611332832::get_offset_of_path_changed_11(),
	AppDomainSetup_t611332832::get_offset_of_loader_optimization_12(),
	AppDomainSetup_t611332832::get_offset_of_disallow_binding_redirects_13(),
	AppDomainSetup_t611332832::get_offset_of_disallow_code_downloads_14(),
	AppDomainSetup_t611332832::get_offset_of__activationArguments_15(),
	AppDomainSetup_t611332832::get_offset_of_domain_initializer_16(),
	AppDomainSetup_t611332832::get_offset_of_application_trust_17(),
	AppDomainSetup_t611332832::get_offset_of_domain_initializer_args_18(),
	AppDomainSetup_t611332832::get_offset_of_application_trust_xml_19(),
	AppDomainSetup_t611332832::get_offset_of_disallow_appbase_probe_20(),
	AppDomainSetup_t611332832::get_offset_of_configuration_bytes_21(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize749 = { sizeof (ApplicationException_t474868623), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize750 = { sizeof (ApplicationIdentity_t3292367950), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable750[1] = 
{
	ApplicationIdentity_t3292367950::get_offset_of__fullName_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize751 = { sizeof (ArgumentException_t3259014390), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable751[2] = 
{
	0,
	ArgumentException_t3259014390::get_offset_of_param_name_12(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize752 = { sizeof (ArgumentNullException_t628810857), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable752[1] = 
{
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize753 = { sizeof (ArgumentOutOfRangeException_t279959794), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable753[1] = 
{
	ArgumentOutOfRangeException_t279959794::get_offset_of_actual_value_13(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize754 = { sizeof (ArithmeticException_t3261462543), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize755 = { sizeof (ArrayTypeMismatchException_t2071164632), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable755[1] = 
{
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize756 = { sizeof (AssemblyLoadEventArgs_t4233815743), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize757 = { sizeof (AttributeTargets_t1984597432)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable757[17] = 
{
	AttributeTargets_t1984597432::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize758 = { sizeof (BitConverter_t3195628829), -1, sizeof(BitConverter_t3195628829_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable758[2] = 
{
	BitConverter_t3195628829_StaticFields::get_offset_of_SwappedWordsInDouble_0(),
	BitConverter_t3195628829_StaticFields::get_offset_of_IsLittleEndian_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize759 = { sizeof (Buffer_t3497320070), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize760 = { sizeof (CharEnumerator_t1926099410), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable760[3] = 
{
	CharEnumerator_t1926099410::get_offset_of_str_0(),
	CharEnumerator_t1926099410::get_offset_of_index_1(),
	CharEnumerator_t1926099410::get_offset_of_length_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize761 = { sizeof (Console_t2311202731), -1, sizeof(Console_t2311202731_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable761[5] = 
{
	Console_t2311202731_StaticFields::get_offset_of_stdout_0(),
	Console_t2311202731_StaticFields::get_offset_of_stderr_1(),
	Console_t2311202731_StaticFields::get_offset_of_stdin_2(),
	Console_t2311202731_StaticFields::get_offset_of_inputEncoding_3(),
	Console_t2311202731_StaticFields::get_offset_of_outputEncoding_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize762 = { sizeof (ContextBoundObject_t4264702438), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize763 = { sizeof (Convert_t2607082565), -1, sizeof(Convert_t2607082565_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable763[2] = 
{
	Convert_t2607082565_StaticFields::get_offset_of_DBNull_0(),
	Convert_t2607082565_StaticFields::get_offset_of_conversionTable_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize764 = { sizeof (DBNull_t972229383), -1, sizeof(DBNull_t972229383_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable764[1] = 
{
	DBNull_t972229383_StaticFields::get_offset_of_Value_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize765 = { sizeof (DateTime_t693205669)+ sizeof (Il2CppObject), -1, sizeof(DateTime_t693205669_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable765[15] = 
{
	DateTime_t693205669::get_offset_of_ticks_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	DateTime_t693205669::get_offset_of_kind_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	DateTime_t693205669_StaticFields::get_offset_of_MaxValue_2(),
	DateTime_t693205669_StaticFields::get_offset_of_MinValue_3(),
	DateTime_t693205669_StaticFields::get_offset_of_ParseTimeFormats_4(),
	DateTime_t693205669_StaticFields::get_offset_of_ParseYearDayMonthFormats_5(),
	DateTime_t693205669_StaticFields::get_offset_of_ParseYearMonthDayFormats_6(),
	DateTime_t693205669_StaticFields::get_offset_of_ParseDayMonthYearFormats_7(),
	DateTime_t693205669_StaticFields::get_offset_of_ParseMonthDayYearFormats_8(),
	DateTime_t693205669_StaticFields::get_offset_of_MonthDayShortFormats_9(),
	DateTime_t693205669_StaticFields::get_offset_of_DayMonthShortFormats_10(),
	DateTime_t693205669_StaticFields::get_offset_of_daysmonth_11(),
	DateTime_t693205669_StaticFields::get_offset_of_daysmonthleap_12(),
	DateTime_t693205669_StaticFields::get_offset_of_to_local_time_span_object_13(),
	DateTime_t693205669_StaticFields::get_offset_of_last_now_14(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize766 = { sizeof (Which_t4078252770)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable766[5] = 
{
	Which_t4078252770::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize767 = { sizeof (DateTimeKind_t2186819611)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable767[4] = 
{
	DateTimeKind_t2186819611::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize768 = { sizeof (DateTimeOffset_t1362988906)+ sizeof (Il2CppObject), -1, sizeof(DateTimeOffset_t1362988906_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable768[4] = 
{
	DateTimeOffset_t1362988906_StaticFields::get_offset_of_MaxValue_0(),
	DateTimeOffset_t1362988906_StaticFields::get_offset_of_MinValue_1(),
	DateTimeOffset_t1362988906::get_offset_of_dt_2() + static_cast<int32_t>(sizeof(Il2CppObject)),
	DateTimeOffset_t1362988906::get_offset_of_utc_offset_3() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize769 = { sizeof (DateTimeUtils_t1974353808), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize770 = { sizeof (DayOfWeek_t721777893)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable770[8] = 
{
	DayOfWeek_t721777893::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize771 = { sizeof (DelegateData_t1572802995), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable771[2] = 
{
	DelegateData_t1572802995::get_offset_of_target_type_0(),
	DelegateData_t1572802995::get_offset_of_method_name_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize772 = { sizeof (DelegateSerializationHolder_t753405077), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable772[1] = 
{
	DelegateSerializationHolder_t753405077::get_offset_of__delegate_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize773 = { sizeof (DelegateEntry_t3215410094), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable773[7] = 
{
	DelegateEntry_t3215410094::get_offset_of_type_0(),
	DelegateEntry_t3215410094::get_offset_of_assembly_1(),
	DelegateEntry_t3215410094::get_offset_of_target_2(),
	DelegateEntry_t3215410094::get_offset_of_targetTypeAssembly_3(),
	DelegateEntry_t3215410094::get_offset_of_targetTypeName_4(),
	DelegateEntry_t3215410094::get_offset_of_methodName_5(),
	DelegateEntry_t3215410094::get_offset_of_delegateEntry_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize774 = { sizeof (DivideByZeroException_t1660837001), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable774[1] = 
{
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize775 = { sizeof (DllNotFoundException_t3636280042), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable775[1] = 
{
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize776 = { sizeof (EntryPointNotFoundException_t3956266210), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable776[1] = 
{
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize777 = { sizeof (MonoEnumInfo_t2335995564)+ sizeof (Il2CppObject), -1, sizeof(MonoEnumInfo_t2335995564_StaticFields), sizeof(MonoEnumInfo_t2335995564_ThreadStaticFields) };
extern const int32_t g_FieldOffsetTable777[11] = 
{
	MonoEnumInfo_t2335995564::get_offset_of_utype_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	MonoEnumInfo_t2335995564::get_offset_of_values_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	MonoEnumInfo_t2335995564::get_offset_of_names_2() + static_cast<int32_t>(sizeof(Il2CppObject)),
	MonoEnumInfo_t2335995564::get_offset_of_name_hash_3() + static_cast<int32_t>(sizeof(Il2CppObject)),
	THREAD_STATIC_FIELD_OFFSET,
	MonoEnumInfo_t2335995564_StaticFields::get_offset_of_global_cache_5(),
	MonoEnumInfo_t2335995564_StaticFields::get_offset_of_global_cache_monitor_6(),
	MonoEnumInfo_t2335995564_StaticFields::get_offset_of_sbyte_comparer_7(),
	MonoEnumInfo_t2335995564_StaticFields::get_offset_of_short_comparer_8(),
	MonoEnumInfo_t2335995564_StaticFields::get_offset_of_int_comparer_9(),
	MonoEnumInfo_t2335995564_StaticFields::get_offset_of_long_comparer_10(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize778 = { sizeof (SByteComparer_t4284068120), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize779 = { sizeof (ShortComparer_t1280224355), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize780 = { sizeof (IntComparer_t1754594706), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize781 = { sizeof (LongComparer_t3923115571), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize782 = { sizeof (Environment_t3662374671), -1, sizeof(Environment_t3662374671_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable782[2] = 
{
	0,
	Environment_t3662374671_StaticFields::get_offset_of_os_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize783 = { sizeof (SpecialFolder_t1519540278)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable783[24] = 
{
	SpecialFolder_t1519540278::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize784 = { sizeof (EventArgs_t3289624707), -1, sizeof(EventArgs_t3289624707_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable784[1] = 
{
	EventArgs_t3289624707_StaticFields::get_offset_of_Empty_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize785 = { sizeof (ExecutionEngineException_t1360775125), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize786 = { sizeof (FieldAccessException_t1797813379), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize787 = { sizeof (FlagsAttribute_t859561169), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize788 = { sizeof (FormatException_t2948921286), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable788[1] = 
{
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize789 = { sizeof (GC_t2902933594), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize790 = { sizeof (Guid_t2533601593)+ sizeof (Il2CppObject), sizeof(Guid_t2533601593 ), sizeof(Guid_t2533601593_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable790[14] = 
{
	Guid_t2533601593::get_offset_of__a_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Guid_t2533601593::get_offset_of__b_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Guid_t2533601593::get_offset_of__c_2() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Guid_t2533601593::get_offset_of__d_3() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Guid_t2533601593::get_offset_of__e_4() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Guid_t2533601593::get_offset_of__f_5() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Guid_t2533601593::get_offset_of__g_6() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Guid_t2533601593::get_offset_of__h_7() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Guid_t2533601593::get_offset_of__i_8() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Guid_t2533601593::get_offset_of__j_9() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Guid_t2533601593::get_offset_of__k_10() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Guid_t2533601593_StaticFields::get_offset_of_Empty_11(),
	Guid_t2533601593_StaticFields::get_offset_of__rngAccess_12(),
	Guid_t2533601593_StaticFields::get_offset_of__rng_13(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize791 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize792 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize793 = { sizeof (IndexOutOfRangeException_t3527622107), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize794 = { sizeof (InvalidCastException_t3625212209), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable794[1] = 
{
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize795 = { sizeof (InvalidOperationException_t721527559), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable795[1] = 
{
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize796 = { sizeof (LoaderOptimization_t1143026982)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable796[7] = 
{
	LoaderOptimization_t1143026982::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize797 = { sizeof (LocalDataStoreSlot_t486331200), -1, sizeof(LocalDataStoreSlot_t486331200_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable797[5] = 
{
	LocalDataStoreSlot_t486331200::get_offset_of_slot_0(),
	LocalDataStoreSlot_t486331200::get_offset_of_thread_local_1(),
	LocalDataStoreSlot_t486331200_StaticFields::get_offset_of_lock_obj_2(),
	LocalDataStoreSlot_t486331200_StaticFields::get_offset_of_slot_bitmap_thread_3(),
	LocalDataStoreSlot_t486331200_StaticFields::get_offset_of_slot_bitmap_context_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize798 = { sizeof (Math_t2022911894), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize799 = { sizeof (MemberAccessException_t2005094827), -1, 0, 0 };
#ifdef __clang__
#pragma clang diagnostic pop
#endif
