﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <cstring>
#include <string.h>
#include <stdio.h>
#include <cmath>
#include <limits>
#include <assert.h>


#include "class-internals.h"
#include "codegen/il2cpp-codegen.h"
#include "mscorlib_U3CModuleU3E3783534214.h"
#include "mscorlib_System_Object2689449295.h"
#include "mscorlib_System_ValueType3507792607.h"
#include "mscorlib_System_Attribute542643598.h"
#include "mscorlib_System_Int322071877448.h"
#include "mscorlib_System_SerializableAttribute2780967079.h"
#include "mscorlib_System_AttributeUsageAttribute1057435127.h"
#include "mscorlib_System_Runtime_InteropServices_ComVisible2245573759.h"
#include "mscorlib_System_Int64909078037.h"
#include "mscorlib_System_UInt322149682021.h"
#include "mscorlib_System_CLSCompliantAttribute809966061.h"
#include "mscorlib_System_UInt642909196914.h"
#include "mscorlib_System_Byte3683104436.h"
#include "mscorlib_System_SByte454417549.h"
#include "mscorlib_System_Int164041245914.h"
#include "mscorlib_System_UInt16986882611.h"
#include "mscorlib_System_Char3454481338.h"
#include "mscorlib_System_String2029220233.h"
#include "mscorlib_System_Single2076509932.h"
#include "mscorlib_System_Double4078015681.h"
#include "mscorlib_System_Decimal724701077.h"
#include "mscorlib_System_Boolean3825574718.h"
#include "mscorlib_System_IntPtr2504060609.h"
#include "mscorlib_System_UIntPtr1549717846.h"
#include "mscorlib_System_MulticastDelegate3201952435.h"
#include "mscorlib_System_Delegate3022476291.h"
#include "mscorlib_System_Enum2459695545.h"
#include "mscorlib_System_Array3829468939.h"
#include "mscorlib_System_Array_SimpleEnumerator4019359169.h"
#include "mscorlib_System_Array_Swapper2637371637.h"
#include "mscorlib_System_Void1841601450.h"
#include "mscorlib_System_Type1303803226.h"
#include "mscorlib_System_Reflection_MemberInfo4043097260.h"
#include "mscorlib_System_Exception1927440687.h"
#include "mscorlib_System_RuntimeFieldHandle2331729674.h"
#include "mscorlib_System_RuntimeTypeHandle2330101084.h"
#include "mscorlib_System_ParamArrayAttribute2144993728.h"
#include "mscorlib_System_Runtime_InteropServices_OutAttribu1539424546.h"
#include "mscorlib_System_ObsoleteAttribute3878847927.h"
#include "mscorlib_System_Runtime_InteropServices_DllImportA3000813225.h"
#include "mscorlib_System_Runtime_InteropServices_MarshalAsA2900773360.h"
#include "mscorlib_System_Runtime_InteropServices_InAttribut1394050551.h"
#include "mscorlib_System_Runtime_InteropServices_GuidAttribu222072359.h"
#include "mscorlib_System_Runtime_InteropServices_ComImportAt468083054.h"
#include "mscorlib_System_Runtime_InteropServices_OptionalAtt827982902.h"
#include "mscorlib_System_Runtime_CompilerServices_CompilerGe497097752.h"
#include "mscorlib_System_Runtime_CompilerServices_Internals1037732567.h"
#include "mscorlib_System_Runtime_CompilerServices_RuntimeCo2430705542.h"
#include "mscorlib_System_Diagnostics_DebuggerHiddenAttribute638884887.h"
#include "mscorlib_System_Reflection_DefaultMemberAttribute889804479.h"
#include "mscorlib_System_Runtime_CompilerServices_DecimalCon569828555.h"
#include "mscorlib_System_Runtime_InteropServices_FieldOffse1553145711.h"
#include "mscorlib_System_RuntimeArgumentHandle3259266975.h"
#include "mscorlib_System_AsyncCallback163412349.h"
#include "mscorlib_System_TypedReference1025199857.h"
#include "mscorlib_System_ArgIterator2628088752.h"
#include "mscorlib_System_MarshalByRefObject1285298191.h"
#include "mscorlib_System_Runtime_CompilerServices_RuntimeHel266230107.h"
#include "mscorlib_Locale4255929014.h"
#include "mscorlib_System_MonoTODOAttribute3487514019.h"
#include "mscorlib_System_MonoDocumentationNoteAttribute1101545345.h"
#include "mscorlib_Microsoft_Win32_SafeHandles_SafeHandleZer1177681199.h"
#include "mscorlib_Microsoft_Win32_SafeHandles_SafeWaitHandle481461830.h"
#include "mscorlib_Mono_Globalization_Unicode_CodePointIndex1073906970.h"
#include "mscorlib_Mono_Globalization_Unicode_CodePointIndex2011406615.h"
#include "mscorlib_Mono_Globalization_Unicode_TailoringInfo1449609243.h"
#include "mscorlib_Mono_Globalization_Unicode_Contraction1673853792.h"
#include "mscorlib_Mono_Globalization_Unicode_ContractionCom1150321365.h"
#include "mscorlib_Mono_Globalization_Unicode_Level2Map3322505726.h"
#include "mscorlib_Mono_Globalization_Unicode_Level2MapCompar914717527.h"
#include "mscorlib_Mono_Globalization_Unicode_MSCompatUnicod1231687219.h"
#include "mscorlib_Mono_Globalization_Unicode_MSCompatUnicod2040269023.h"
#include "mscorlib_Mono_Globalization_Unicode_SimpleCollator4081201584.h"



#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize0 = { sizeof (U3CModuleU3E_t3783534214), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1 = { sizeof (Il2CppObject), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2 = { sizeof (ValueType_t3507792607), sizeof(ValueType_t3507792607_marshaled_pinvoke), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3 = { sizeof (Attribute_t542643598), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize4 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize5 = { sizeof (Int32_t2071877448)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable5[3] = 
{
	0,
	0,
	Int32_t2071877448::get_offset_of_m_value_2() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize6 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize7 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize8 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize9 = { 0, 0, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize10 = { sizeof (SerializableAttribute_t2780967079), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize11 = { sizeof (AttributeUsageAttribute_t1057435127), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable11[3] = 
{
	AttributeUsageAttribute_t1057435127::get_offset_of_valid_on_0(),
	AttributeUsageAttribute_t1057435127::get_offset_of_allow_multiple_1(),
	AttributeUsageAttribute_t1057435127::get_offset_of_inherited_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize12 = { sizeof (ComVisibleAttribute_t2245573759), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable12[1] = 
{
	ComVisibleAttribute_t2245573759::get_offset_of_Visible_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize13 = { 0, 0, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize14 = { sizeof (Int64_t909078037)+ sizeof (Il2CppObject), sizeof(int64_t), 0, 0 };
extern const int32_t g_FieldOffsetTable14[1] = 
{
	Int64_t909078037::get_offset_of_m_value_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize15 = { sizeof (UInt32_t2149682021)+ sizeof (Il2CppObject), sizeof(uint32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable15[1] = 
{
	UInt32_t2149682021::get_offset_of_m_value_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize16 = { sizeof (CLSCompliantAttribute_t809966061), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable16[1] = 
{
	CLSCompliantAttribute_t809966061::get_offset_of_is_compliant_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize17 = { sizeof (UInt64_t2909196914)+ sizeof (Il2CppObject), sizeof(uint64_t), 0, 0 };
extern const int32_t g_FieldOffsetTable17[1] = 
{
	UInt64_t2909196914::get_offset_of_m_value_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize18 = { sizeof (Byte_t3683104436)+ sizeof (Il2CppObject), sizeof(uint8_t), 0, 0 };
extern const int32_t g_FieldOffsetTable18[3] = 
{
	0,
	0,
	Byte_t3683104436::get_offset_of_m_value_2() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize19 = { sizeof (SByte_t454417549)+ sizeof (Il2CppObject), sizeof(int8_t), 0, 0 };
extern const int32_t g_FieldOffsetTable19[1] = 
{
	SByte_t454417549::get_offset_of_m_value_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize20 = { sizeof (Int16_t4041245914)+ sizeof (Il2CppObject), sizeof(int16_t), 0, 0 };
extern const int32_t g_FieldOffsetTable20[1] = 
{
	Int16_t4041245914::get_offset_of_m_value_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize21 = { sizeof (UInt16_t986882611)+ sizeof (Il2CppObject), sizeof(uint16_t), 0, 0 };
extern const int32_t g_FieldOffsetTable21[3] = 
{
	0,
	0,
	UInt16_t986882611::get_offset_of_m_value_2() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize22 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize23 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize24 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize25 = { 0, 0, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize26 = { sizeof (Char_t3454481338)+ sizeof (Il2CppObject), 1, sizeof(Char_t3454481338_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable26[10] = 
{
	0,
	0,
	Char_t3454481338::get_offset_of_m_value_2() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Char_t3454481338_StaticFields::get_offset_of_category_data_3(),
	Char_t3454481338_StaticFields::get_offset_of_numeric_data_4(),
	Char_t3454481338_StaticFields::get_offset_of_numeric_data_values_5(),
	Char_t3454481338_StaticFields::get_offset_of_to_lower_data_low_6(),
	Char_t3454481338_StaticFields::get_offset_of_to_lower_data_high_7(),
	Char_t3454481338_StaticFields::get_offset_of_to_upper_data_low_8(),
	Char_t3454481338_StaticFields::get_offset_of_to_upper_data_high_9(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize27 = { sizeof (String_t), sizeof(char*), sizeof(String_t_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable27[4] = 
{
	String_t::get_offset_of_length_0(),
	String_t::get_offset_of_start_char_1(),
	String_t_StaticFields::get_offset_of_Empty_2(),
	String_t_StaticFields::get_offset_of_WhiteChars_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize28 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize29 = { 0, 0, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize30 = { sizeof (Single_t2076509932)+ sizeof (Il2CppObject), sizeof(float), 0, 0 };
extern const int32_t g_FieldOffsetTable30[8] = 
{
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	Single_t2076509932::get_offset_of_m_value_7() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize31 = { sizeof (Double_t4078015681)+ sizeof (Il2CppObject), sizeof(double), 0, 0 };
extern const int32_t g_FieldOffsetTable31[14] = 
{
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	Double_t4078015681::get_offset_of_m_value_13() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize32 = { sizeof (Decimal_t724701077)+ sizeof (Il2CppObject), sizeof(Decimal_t724701077 ), sizeof(Decimal_t724701077_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable32[9] = 
{
	Decimal_t724701077_StaticFields::get_offset_of_MinValue_0(),
	Decimal_t724701077_StaticFields::get_offset_of_MaxValue_1(),
	Decimal_t724701077_StaticFields::get_offset_of_MinusOne_2(),
	Decimal_t724701077_StaticFields::get_offset_of_One_3(),
	Decimal_t724701077_StaticFields::get_offset_of_MaxValueDiv10_4(),
	Decimal_t724701077::get_offset_of_flags_5() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Decimal_t724701077::get_offset_of_hi_6() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Decimal_t724701077::get_offset_of_lo_7() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Decimal_t724701077::get_offset_of_mid_8() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize33 = { sizeof (Boolean_t3825574718)+ sizeof (Il2CppObject), 4, sizeof(Boolean_t3825574718_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable33[3] = 
{
	Boolean_t3825574718_StaticFields::get_offset_of_FalseString_0(),
	Boolean_t3825574718_StaticFields::get_offset_of_TrueString_1(),
	Boolean_t3825574718::get_offset_of_m_value_2() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize34 = { sizeof (IntPtr_t)+ sizeof (Il2CppObject), sizeof(intptr_t), sizeof(IntPtr_t_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable34[2] = 
{
	IntPtr_t::get_offset_of_m_value_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	IntPtr_t_StaticFields::get_offset_of_Zero_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize35 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize36 = { sizeof (UIntPtr_t)+ sizeof (Il2CppObject), sizeof(uintptr_t), sizeof(UIntPtr_t_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable36[2] = 
{
	UIntPtr_t_StaticFields::get_offset_of_Zero_0(),
	UIntPtr_t::get_offset_of__pointer_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize37 = { sizeof (MulticastDelegate_t3201952435), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable37[2] = 
{
	MulticastDelegate_t3201952435::get_offset_of_prev_9(),
	MulticastDelegate_t3201952435::get_offset_of_kpm_next_10(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize38 = { sizeof (Delegate_t3022476291), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable38[9] = 
{
	Delegate_t3022476291::get_offset_of_method_ptr_0(),
	Delegate_t3022476291::get_offset_of_invoke_impl_1(),
	Delegate_t3022476291::get_offset_of_m_target_2(),
	Delegate_t3022476291::get_offset_of_method_3(),
	Delegate_t3022476291::get_offset_of_delegate_trampoline_4(),
	Delegate_t3022476291::get_offset_of_method_code_5(),
	Delegate_t3022476291::get_offset_of_method_info_6(),
	Delegate_t3022476291::get_offset_of_original_method_info_7(),
	Delegate_t3022476291::get_offset_of_data_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize39 = { sizeof (Enum_t2459695545), sizeof(Enum_t2459695545_marshaled_pinvoke), sizeof(Enum_t2459695545_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable39[1] = 
{
	Enum_t2459695545_StaticFields::get_offset_of_split_char_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize40 = { sizeof (Il2CppArray), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize41 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable41[2] = 
{
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize42 = { sizeof (SimpleEnumerator_t4019359169), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable42[3] = 
{
	SimpleEnumerator_t4019359169::get_offset_of_enumeratee_0(),
	SimpleEnumerator_t4019359169::get_offset_of_currentpos_1(),
	SimpleEnumerator_t4019359169::get_offset_of_length_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize43 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable43[1] = 
{
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize44 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable44[4] = 
{
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize45 = { sizeof (Swapper_t2637371637), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize46 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize47 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize48 = { 0, 0, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize49 = { 0, 0, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize50 = { sizeof (Void_t1841601450)+ sizeof (Il2CppObject), 1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize51 = { sizeof (Type_t), -1, sizeof(Type_t_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable51[8] = 
{
	0,
	Type_t::get_offset_of__impl_1(),
	Type_t_StaticFields::get_offset_of_Delimiter_2(),
	Type_t_StaticFields::get_offset_of_EmptyTypes_3(),
	Type_t_StaticFields::get_offset_of_FilterAttribute_4(),
	Type_t_StaticFields::get_offset_of_FilterName_5(),
	Type_t_StaticFields::get_offset_of_FilterNameIgnoreCase_6(),
	Type_t_StaticFields::get_offset_of_Missing_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize52 = { sizeof (MemberInfo_t), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize53 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize54 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize55 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize56 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize57 = { sizeof (Exception_t1927440687), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable57[11] = 
{
	Exception_t1927440687::get_offset_of_trace_ips_0(),
	Exception_t1927440687::get_offset_of_inner_exception_1(),
	Exception_t1927440687::get_offset_of_message_2(),
	Exception_t1927440687::get_offset_of_help_link_3(),
	Exception_t1927440687::get_offset_of_class_name_4(),
	Exception_t1927440687::get_offset_of_stack_trace_5(),
	Exception_t1927440687::get_offset_of__remoteStackTraceString_6(),
	Exception_t1927440687::get_offset_of_remote_stack_index_7(),
	Exception_t1927440687::get_offset_of_hresult_8(),
	Exception_t1927440687::get_offset_of_source_9(),
	Exception_t1927440687::get_offset_of__data_10(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize58 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize59 = { sizeof (RuntimeFieldHandle_t2331729674)+ sizeof (Il2CppObject), sizeof(RuntimeFieldHandle_t2331729674 ), 0, 0 };
extern const int32_t g_FieldOffsetTable59[1] = 
{
	RuntimeFieldHandle_t2331729674::get_offset_of_value_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize60 = { sizeof (RuntimeTypeHandle_t2330101084)+ sizeof (Il2CppObject), sizeof(RuntimeTypeHandle_t2330101084 ), 0, 0 };
extern const int32_t g_FieldOffsetTable60[1] = 
{
	RuntimeTypeHandle_t2330101084::get_offset_of_value_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize61 = { sizeof (ParamArrayAttribute_t2144993728), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize62 = { sizeof (OutAttribute_t1539424546), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize63 = { sizeof (ObsoleteAttribute_t3878847927), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable63[2] = 
{
	ObsoleteAttribute_t3878847927::get_offset_of__message_0(),
	ObsoleteAttribute_t3878847927::get_offset_of__error_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize64 = { sizeof (DllImportAttribute_t3000813225), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable64[9] = 
{
	DllImportAttribute_t3000813225::get_offset_of_CallingConvention_0(),
	DllImportAttribute_t3000813225::get_offset_of_CharSet_1(),
	DllImportAttribute_t3000813225::get_offset_of_Dll_2(),
	DllImportAttribute_t3000813225::get_offset_of_EntryPoint_3(),
	DllImportAttribute_t3000813225::get_offset_of_ExactSpelling_4(),
	DllImportAttribute_t3000813225::get_offset_of_PreserveSig_5(),
	DllImportAttribute_t3000813225::get_offset_of_SetLastError_6(),
	DllImportAttribute_t3000813225::get_offset_of_BestFitMapping_7(),
	DllImportAttribute_t3000813225::get_offset_of_ThrowOnUnmappableChar_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize65 = { sizeof (MarshalAsAttribute_t2900773360), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable65[7] = 
{
	MarshalAsAttribute_t2900773360::get_offset_of_utype_0(),
	MarshalAsAttribute_t2900773360::get_offset_of_ArraySubType_1(),
	MarshalAsAttribute_t2900773360::get_offset_of_MarshalCookie_2(),
	MarshalAsAttribute_t2900773360::get_offset_of_MarshalType_3(),
	MarshalAsAttribute_t2900773360::get_offset_of_MarshalTypeRef_4(),
	MarshalAsAttribute_t2900773360::get_offset_of_SizeConst_5(),
	MarshalAsAttribute_t2900773360::get_offset_of_SizeParamIndex_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize66 = { sizeof (InAttribute_t1394050551), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize67 = { sizeof (GuidAttribute_t222072359), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable67[1] = 
{
	GuidAttribute_t222072359::get_offset_of_guidValue_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize68 = { sizeof (ComImportAttribute_t468083054), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize69 = { sizeof (OptionalAttribute_t827982902), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize70 = { sizeof (CompilerGeneratedAttribute_t497097752), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize71 = { sizeof (InternalsVisibleToAttribute_t1037732567), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable71[2] = 
{
	InternalsVisibleToAttribute_t1037732567::get_offset_of_assemblyName_0(),
	InternalsVisibleToAttribute_t1037732567::get_offset_of_all_visible_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize72 = { sizeof (RuntimeCompatibilityAttribute_t2430705542), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable72[1] = 
{
	RuntimeCompatibilityAttribute_t2430705542::get_offset_of_wrap_non_exception_throws_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize73 = { sizeof (DebuggerHiddenAttribute_t638884887), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize74 = { sizeof (DefaultMemberAttribute_t889804479), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable74[1] = 
{
	DefaultMemberAttribute_t889804479::get_offset_of_member_name_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize75 = { sizeof (DecimalConstantAttribute_t569828555), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable75[5] = 
{
	DecimalConstantAttribute_t569828555::get_offset_of_scale_0(),
	DecimalConstantAttribute_t569828555::get_offset_of_sign_1(),
	DecimalConstantAttribute_t569828555::get_offset_of_hi_2(),
	DecimalConstantAttribute_t569828555::get_offset_of_mid_3(),
	DecimalConstantAttribute_t569828555::get_offset_of_low_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize76 = { sizeof (FieldOffsetAttribute_t1553145711), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable76[1] = 
{
	FieldOffsetAttribute_t1553145711::get_offset_of_val_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize77 = { sizeof (RuntimeArgumentHandle_t3259266975)+ sizeof (Il2CppObject), sizeof(RuntimeArgumentHandle_t3259266975 ), 0, 0 };
extern const int32_t g_FieldOffsetTable77[1] = 
{
	RuntimeArgumentHandle_t3259266975::get_offset_of_args_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize78 = { sizeof (AsyncCallback_t163412349), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize79 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize80 = { sizeof (TypedReference_t1025199857)+ sizeof (Il2CppObject), sizeof(TypedReference_t1025199857 ), 0, 0 };
extern const int32_t g_FieldOffsetTable80[3] = 
{
	TypedReference_t1025199857::get_offset_of_type_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	TypedReference_t1025199857::get_offset_of_value_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	TypedReference_t1025199857::get_offset_of_klass_2() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize81 = { sizeof (ArgIterator_t2628088752)+ sizeof (Il2CppObject), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable81[4] = 
{
	ArgIterator_t2628088752::get_offset_of_sig_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	ArgIterator_t2628088752::get_offset_of_args_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	ArgIterator_t2628088752::get_offset_of_next_arg_2() + static_cast<int32_t>(sizeof(Il2CppObject)),
	ArgIterator_t2628088752::get_offset_of_num_args_3() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize82 = { sizeof (MarshalByRefObject_t1285298191), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable82[1] = 
{
	MarshalByRefObject_t1285298191::get_offset_of__identity_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize83 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable83[2] = 
{
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize84 = { sizeof (RuntimeHelpers_t266230107), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize85 = { sizeof (Locale_t4255929014), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize86 = { sizeof (MonoTODOAttribute_t3487514019), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable86[1] = 
{
	MonoTODOAttribute_t3487514019::get_offset_of_comment_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize87 = { sizeof (MonoDocumentationNoteAttribute_t1101545345), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize88 = { sizeof (SafeHandleZeroOrMinusOneIsInvalid_t1177681199), sizeof(void*), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize89 = { sizeof (SafeWaitHandle_t481461830), sizeof(void*), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize90 = { sizeof (CodePointIndexer_t1073906970), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable90[4] = 
{
	CodePointIndexer_t1073906970::get_offset_of_ranges_0(),
	CodePointIndexer_t1073906970::get_offset_of_TotalCount_1(),
	CodePointIndexer_t1073906970::get_offset_of_defaultIndex_2(),
	CodePointIndexer_t1073906970::get_offset_of_defaultCP_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize91 = { sizeof (TableRange_t2011406615)+ sizeof (Il2CppObject), sizeof(TableRange_t2011406615 ), 0, 0 };
extern const int32_t g_FieldOffsetTable91[5] = 
{
	TableRange_t2011406615::get_offset_of_Start_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	TableRange_t2011406615::get_offset_of_End_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	TableRange_t2011406615::get_offset_of_Count_2() + static_cast<int32_t>(sizeof(Il2CppObject)),
	TableRange_t2011406615::get_offset_of_IndexStart_3() + static_cast<int32_t>(sizeof(Il2CppObject)),
	TableRange_t2011406615::get_offset_of_IndexEnd_4() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize92 = { sizeof (TailoringInfo_t1449609243), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable92[4] = 
{
	TailoringInfo_t1449609243::get_offset_of_LCID_0(),
	TailoringInfo_t1449609243::get_offset_of_TailoringIndex_1(),
	TailoringInfo_t1449609243::get_offset_of_TailoringCount_2(),
	TailoringInfo_t1449609243::get_offset_of_FrenchSort_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize93 = { sizeof (Contraction_t1673853792), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable93[3] = 
{
	Contraction_t1673853792::get_offset_of_Source_0(),
	Contraction_t1673853792::get_offset_of_Replacement_1(),
	Contraction_t1673853792::get_offset_of_SortKey_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize94 = { sizeof (ContractionComparer_t1150321365), -1, sizeof(ContractionComparer_t1150321365_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable94[1] = 
{
	ContractionComparer_t1150321365_StaticFields::get_offset_of_Instance_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize95 = { sizeof (Level2Map_t3322505726), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable95[2] = 
{
	Level2Map_t3322505726::get_offset_of_Source_0(),
	Level2Map_t3322505726::get_offset_of_Replace_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize96 = { sizeof (Level2MapComparer_t914717527), -1, sizeof(Level2MapComparer_t914717527_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable96[1] = 
{
	Level2MapComparer_t914717527_StaticFields::get_offset_of_Instance_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize97 = { sizeof (MSCompatUnicodeTable_t1231687219), -1, sizeof(MSCompatUnicodeTable_t1231687219_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable97[22] = 
{
	MSCompatUnicodeTable_t1231687219_StaticFields::get_offset_of_MaxExpansionLength_0(),
	MSCompatUnicodeTable_t1231687219_StaticFields::get_offset_of_ignorableFlags_1(),
	MSCompatUnicodeTable_t1231687219_StaticFields::get_offset_of_categories_2(),
	MSCompatUnicodeTable_t1231687219_StaticFields::get_offset_of_level1_3(),
	MSCompatUnicodeTable_t1231687219_StaticFields::get_offset_of_level2_4(),
	MSCompatUnicodeTable_t1231687219_StaticFields::get_offset_of_level3_5(),
	MSCompatUnicodeTable_t1231687219_StaticFields::get_offset_of_cjkCHScategory_6(),
	MSCompatUnicodeTable_t1231687219_StaticFields::get_offset_of_cjkCHTcategory_7(),
	MSCompatUnicodeTable_t1231687219_StaticFields::get_offset_of_cjkJAcategory_8(),
	MSCompatUnicodeTable_t1231687219_StaticFields::get_offset_of_cjkKOcategory_9(),
	MSCompatUnicodeTable_t1231687219_StaticFields::get_offset_of_cjkCHSlv1_10(),
	MSCompatUnicodeTable_t1231687219_StaticFields::get_offset_of_cjkCHTlv1_11(),
	MSCompatUnicodeTable_t1231687219_StaticFields::get_offset_of_cjkJAlv1_12(),
	MSCompatUnicodeTable_t1231687219_StaticFields::get_offset_of_cjkKOlv1_13(),
	MSCompatUnicodeTable_t1231687219_StaticFields::get_offset_of_cjkKOlv2_14(),
	MSCompatUnicodeTable_t1231687219_StaticFields::get_offset_of_tailoringArr_15(),
	MSCompatUnicodeTable_t1231687219_StaticFields::get_offset_of_tailoringInfos_16(),
	MSCompatUnicodeTable_t1231687219_StaticFields::get_offset_of_forLock_17(),
	MSCompatUnicodeTable_t1231687219_StaticFields::get_offset_of_isReady_18(),
	MSCompatUnicodeTable_t1231687219_StaticFields::get_offset_of_U3CU3Ef__switchU24map2_19(),
	MSCompatUnicodeTable_t1231687219_StaticFields::get_offset_of_U3CU3Ef__switchU24map3_20(),
	MSCompatUnicodeTable_t1231687219_StaticFields::get_offset_of_U3CU3Ef__switchU24map4_21(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize98 = { sizeof (MSCompatUnicodeTableUtil_t2040269023), -1, sizeof(MSCompatUnicodeTableUtil_t2040269023_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable98[7] = 
{
	MSCompatUnicodeTableUtil_t2040269023_StaticFields::get_offset_of_Ignorable_0(),
	MSCompatUnicodeTableUtil_t2040269023_StaticFields::get_offset_of_Category_1(),
	MSCompatUnicodeTableUtil_t2040269023_StaticFields::get_offset_of_Level1_2(),
	MSCompatUnicodeTableUtil_t2040269023_StaticFields::get_offset_of_Level2_3(),
	MSCompatUnicodeTableUtil_t2040269023_StaticFields::get_offset_of_Level3_4(),
	MSCompatUnicodeTableUtil_t2040269023_StaticFields::get_offset_of_CjkCHS_5(),
	MSCompatUnicodeTableUtil_t2040269023_StaticFields::get_offset_of_Cjk_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize99 = { sizeof (SimpleCollator_t4081201584), -1, sizeof(SimpleCollator_t4081201584_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable99[13] = 
{
	SimpleCollator_t4081201584_StaticFields::get_offset_of_QuickCheckDisabled_0(),
	SimpleCollator_t4081201584_StaticFields::get_offset_of_invariant_1(),
	SimpleCollator_t4081201584::get_offset_of_textInfo_2(),
	SimpleCollator_t4081201584::get_offset_of_frenchSort_3(),
	SimpleCollator_t4081201584::get_offset_of_cjkCatTable_4(),
	SimpleCollator_t4081201584::get_offset_of_cjkLv1Table_5(),
	SimpleCollator_t4081201584::get_offset_of_cjkIndexer_6(),
	SimpleCollator_t4081201584::get_offset_of_cjkLv2Table_7(),
	SimpleCollator_t4081201584::get_offset_of_cjkLv2Indexer_8(),
	SimpleCollator_t4081201584::get_offset_of_lcid_9(),
	SimpleCollator_t4081201584::get_offset_of_contractions_10(),
	SimpleCollator_t4081201584::get_offset_of_level2Maps_11(),
	SimpleCollator_t4081201584::get_offset_of_unsafeFlags_12(),
};
#ifdef __clang__
#pragma clang diagnostic pop
#endif
