﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// UnityStandardAssets.Utility.TimedObjectActivator/Entry
struct Entry_t420114983;

#include "codegen/il2cpp-codegen.h"

// System.Void UnityStandardAssets.Utility.TimedObjectActivator/Entry::.ctor()
extern "C"  void Entry__ctor_m609958660 (Entry_t420114983 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
