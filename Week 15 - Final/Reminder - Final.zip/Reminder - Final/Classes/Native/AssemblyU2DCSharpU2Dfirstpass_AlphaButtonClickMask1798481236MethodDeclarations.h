﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// AlphaButtonClickMask
struct AlphaButtonClickMask_t1798481236;
// UnityEngine.Camera
struct Camera_t189460977;

#include "codegen/il2cpp-codegen.h"
#include "UnityEngine_UnityEngine_Vector22243707579.h"
#include "UnityEngine_UnityEngine_Camera189460977.h"

// System.Void AlphaButtonClickMask::.ctor()
extern "C"  void AlphaButtonClickMask__ctor_m637836257 (AlphaButtonClickMask_t1798481236 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void AlphaButtonClickMask::Start()
extern "C"  void AlphaButtonClickMask_Start_m233381265 (AlphaButtonClickMask_t1798481236 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Boolean AlphaButtonClickMask::IsRaycastLocationValid(UnityEngine.Vector2,UnityEngine.Camera)
extern "C"  bool AlphaButtonClickMask_IsRaycastLocationValid_m964310473 (AlphaButtonClickMask_t1798481236 * __this, Vector2_t2243707579  ___sp0, Camera_t189460977 * ___eventCamera1, const MethodInfo* method) IL2CPP_METHOD_ATTR;
