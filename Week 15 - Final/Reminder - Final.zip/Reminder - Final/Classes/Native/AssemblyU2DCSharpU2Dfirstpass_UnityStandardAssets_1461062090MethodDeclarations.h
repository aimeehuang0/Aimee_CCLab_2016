﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// UnityStandardAssets.Effects.SmokeParticles
struct SmokeParticles_t1461062090;

#include "codegen/il2cpp-codegen.h"

// System.Void UnityStandardAssets.Effects.SmokeParticles::.ctor()
extern "C"  void SmokeParticles__ctor_m223952722 (SmokeParticles_t1461062090 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Effects.SmokeParticles::Start()
extern "C"  void SmokeParticles_Start_m2329564950 (SmokeParticles_t1461062090 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
