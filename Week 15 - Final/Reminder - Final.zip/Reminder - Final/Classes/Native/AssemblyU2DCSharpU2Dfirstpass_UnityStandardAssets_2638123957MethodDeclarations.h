﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// UnityStandardAssets.Effects.WaterHoseParticles
struct WaterHoseParticles_t2638123957;
// UnityEngine.GameObject
struct GameObject_t1756533147;

#include "codegen/il2cpp-codegen.h"
#include "UnityEngine_UnityEngine_GameObject1756533147.h"

// System.Void UnityStandardAssets.Effects.WaterHoseParticles::.ctor()
extern "C"  void WaterHoseParticles__ctor_m1856713709 (WaterHoseParticles_t2638123957 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Effects.WaterHoseParticles::Start()
extern "C"  void WaterHoseParticles_Start_m2606761125 (WaterHoseParticles_t2638123957 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Effects.WaterHoseParticles::OnParticleCollision(UnityEngine.GameObject)
extern "C"  void WaterHoseParticles_OnParticleCollision_m3603214754 (WaterHoseParticles_t2638123957 * __this, GameObject_t1756533147 * ___other0, const MethodInfo* method) IL2CPP_METHOD_ATTR;
