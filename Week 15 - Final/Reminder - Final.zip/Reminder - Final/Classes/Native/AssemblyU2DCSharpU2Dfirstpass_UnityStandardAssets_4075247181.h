﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>

// UnityEngine.Camera
struct Camera_t189460977;
// UnityStandardAssets.Utility.DragRigidbody
struct DragRigidbody_t2127994057;
// System.Object
struct Il2CppObject;

#include "mscorlib_System_Object2689449295.h"
#include "UnityEngine_UnityEngine_Ray2469606224.h"

#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityStandardAssets.Utility.DragRigidbody/<DragObject>c__Iterator0
struct  U3CDragObjectU3Ec__Iterator0_t4075247181  : public Il2CppObject
{
public:
	// System.Single UnityStandardAssets.Utility.DragRigidbody/<DragObject>c__Iterator0::<oldDrag>__0
	float ___U3ColdDragU3E__0_0;
	// System.Single UnityStandardAssets.Utility.DragRigidbody/<DragObject>c__Iterator0::<oldAngularDrag>__1
	float ___U3ColdAngularDragU3E__1_1;
	// UnityEngine.Camera UnityStandardAssets.Utility.DragRigidbody/<DragObject>c__Iterator0::<mainCamera>__2
	Camera_t189460977 * ___U3CmainCameraU3E__2_2;
	// UnityEngine.Ray UnityStandardAssets.Utility.DragRigidbody/<DragObject>c__Iterator0::<ray>__3
	Ray_t2469606224  ___U3CrayU3E__3_3;
	// System.Single UnityStandardAssets.Utility.DragRigidbody/<DragObject>c__Iterator0::distance
	float ___distance_4;
	// UnityStandardAssets.Utility.DragRigidbody UnityStandardAssets.Utility.DragRigidbody/<DragObject>c__Iterator0::$this
	DragRigidbody_t2127994057 * ___U24this_5;
	// System.Object UnityStandardAssets.Utility.DragRigidbody/<DragObject>c__Iterator0::$current
	Il2CppObject * ___U24current_6;
	// System.Boolean UnityStandardAssets.Utility.DragRigidbody/<DragObject>c__Iterator0::$disposing
	bool ___U24disposing_7;
	// System.Int32 UnityStandardAssets.Utility.DragRigidbody/<DragObject>c__Iterator0::$PC
	int32_t ___U24PC_8;

public:
	inline static int32_t get_offset_of_U3ColdDragU3E__0_0() { return static_cast<int32_t>(offsetof(U3CDragObjectU3Ec__Iterator0_t4075247181, ___U3ColdDragU3E__0_0)); }
	inline float get_U3ColdDragU3E__0_0() const { return ___U3ColdDragU3E__0_0; }
	inline float* get_address_of_U3ColdDragU3E__0_0() { return &___U3ColdDragU3E__0_0; }
	inline void set_U3ColdDragU3E__0_0(float value)
	{
		___U3ColdDragU3E__0_0 = value;
	}

	inline static int32_t get_offset_of_U3ColdAngularDragU3E__1_1() { return static_cast<int32_t>(offsetof(U3CDragObjectU3Ec__Iterator0_t4075247181, ___U3ColdAngularDragU3E__1_1)); }
	inline float get_U3ColdAngularDragU3E__1_1() const { return ___U3ColdAngularDragU3E__1_1; }
	inline float* get_address_of_U3ColdAngularDragU3E__1_1() { return &___U3ColdAngularDragU3E__1_1; }
	inline void set_U3ColdAngularDragU3E__1_1(float value)
	{
		___U3ColdAngularDragU3E__1_1 = value;
	}

	inline static int32_t get_offset_of_U3CmainCameraU3E__2_2() { return static_cast<int32_t>(offsetof(U3CDragObjectU3Ec__Iterator0_t4075247181, ___U3CmainCameraU3E__2_2)); }
	inline Camera_t189460977 * get_U3CmainCameraU3E__2_2() const { return ___U3CmainCameraU3E__2_2; }
	inline Camera_t189460977 ** get_address_of_U3CmainCameraU3E__2_2() { return &___U3CmainCameraU3E__2_2; }
	inline void set_U3CmainCameraU3E__2_2(Camera_t189460977 * value)
	{
		___U3CmainCameraU3E__2_2 = value;
		Il2CppCodeGenWriteBarrier(&___U3CmainCameraU3E__2_2, value);
	}

	inline static int32_t get_offset_of_U3CrayU3E__3_3() { return static_cast<int32_t>(offsetof(U3CDragObjectU3Ec__Iterator0_t4075247181, ___U3CrayU3E__3_3)); }
	inline Ray_t2469606224  get_U3CrayU3E__3_3() const { return ___U3CrayU3E__3_3; }
	inline Ray_t2469606224 * get_address_of_U3CrayU3E__3_3() { return &___U3CrayU3E__3_3; }
	inline void set_U3CrayU3E__3_3(Ray_t2469606224  value)
	{
		___U3CrayU3E__3_3 = value;
	}

	inline static int32_t get_offset_of_distance_4() { return static_cast<int32_t>(offsetof(U3CDragObjectU3Ec__Iterator0_t4075247181, ___distance_4)); }
	inline float get_distance_4() const { return ___distance_4; }
	inline float* get_address_of_distance_4() { return &___distance_4; }
	inline void set_distance_4(float value)
	{
		___distance_4 = value;
	}

	inline static int32_t get_offset_of_U24this_5() { return static_cast<int32_t>(offsetof(U3CDragObjectU3Ec__Iterator0_t4075247181, ___U24this_5)); }
	inline DragRigidbody_t2127994057 * get_U24this_5() const { return ___U24this_5; }
	inline DragRigidbody_t2127994057 ** get_address_of_U24this_5() { return &___U24this_5; }
	inline void set_U24this_5(DragRigidbody_t2127994057 * value)
	{
		___U24this_5 = value;
		Il2CppCodeGenWriteBarrier(&___U24this_5, value);
	}

	inline static int32_t get_offset_of_U24current_6() { return static_cast<int32_t>(offsetof(U3CDragObjectU3Ec__Iterator0_t4075247181, ___U24current_6)); }
	inline Il2CppObject * get_U24current_6() const { return ___U24current_6; }
	inline Il2CppObject ** get_address_of_U24current_6() { return &___U24current_6; }
	inline void set_U24current_6(Il2CppObject * value)
	{
		___U24current_6 = value;
		Il2CppCodeGenWriteBarrier(&___U24current_6, value);
	}

	inline static int32_t get_offset_of_U24disposing_7() { return static_cast<int32_t>(offsetof(U3CDragObjectU3Ec__Iterator0_t4075247181, ___U24disposing_7)); }
	inline bool get_U24disposing_7() const { return ___U24disposing_7; }
	inline bool* get_address_of_U24disposing_7() { return &___U24disposing_7; }
	inline void set_U24disposing_7(bool value)
	{
		___U24disposing_7 = value;
	}

	inline static int32_t get_offset_of_U24PC_8() { return static_cast<int32_t>(offsetof(U3CDragObjectU3Ec__Iterator0_t4075247181, ___U24PC_8)); }
	inline int32_t get_U24PC_8() const { return ___U24PC_8; }
	inline int32_t* get_address_of_U24PC_8() { return &___U24PC_8; }
	inline void set_U24PC_8(int32_t value)
	{
		___U24PC_8 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
