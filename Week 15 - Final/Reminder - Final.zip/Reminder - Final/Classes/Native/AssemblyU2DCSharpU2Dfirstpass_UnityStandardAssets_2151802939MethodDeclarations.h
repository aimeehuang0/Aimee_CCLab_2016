﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// UnityStandardAssets.Effects.ExtinguishableParticleSystem
struct ExtinguishableParticleSystem_t2151802939;

#include "codegen/il2cpp-codegen.h"

// System.Void UnityStandardAssets.Effects.ExtinguishableParticleSystem::.ctor()
extern "C"  void ExtinguishableParticleSystem__ctor_m2160722091 (ExtinguishableParticleSystem_t2151802939 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Effects.ExtinguishableParticleSystem::Start()
extern "C"  void ExtinguishableParticleSystem_Start_m3527085255 (ExtinguishableParticleSystem_t2151802939 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Effects.ExtinguishableParticleSystem::Extinguish()
extern "C"  void ExtinguishableParticleSystem_Extinguish_m2894402301 (ExtinguishableParticleSystem_t2151802939 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
