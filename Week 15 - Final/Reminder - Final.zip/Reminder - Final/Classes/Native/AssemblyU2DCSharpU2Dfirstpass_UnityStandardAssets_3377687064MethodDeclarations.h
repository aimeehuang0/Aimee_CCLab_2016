﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// UnityStandardAssets.Effects.ParticleSystemMultiplier
struct ParticleSystemMultiplier_t3377687064;

#include "codegen/il2cpp-codegen.h"

// System.Void UnityStandardAssets.Effects.ParticleSystemMultiplier::.ctor()
extern "C"  void ParticleSystemMultiplier__ctor_m154743810 (ParticleSystemMultiplier_t3377687064 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Effects.ParticleSystemMultiplier::Start()
extern "C"  void ParticleSystemMultiplier_Start_m4045190642 (ParticleSystemMultiplier_t3377687064 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
