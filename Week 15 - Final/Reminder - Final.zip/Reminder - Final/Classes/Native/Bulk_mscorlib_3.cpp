﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <cstring>
#include <string.h>
#include <stdio.h>
#include <cmath>
#include <limits>
#include <assert.h>

// System.OverflowException
struct OverflowException_t1075868493;
// System.String
struct String_t;
// System.Runtime.Serialization.SerializationInfo
struct SerializationInfo_t228987430;
// System.ParamArrayAttribute
struct ParamArrayAttribute_t2144993728;
// System.PlatformNotSupportedException
struct PlatformNotSupportedException_t3778770305;
// System.RankException
struct RankException_t1539875949;
// System.Reflection.AmbiguousMatchException
struct AmbiguousMatchException_t1406414556;
// System.Reflection.Assembly
struct Assembly_t4268412390;
// System.Type
struct Type_t;
// System.Object[]
struct ObjectU5BU5D_t3614634134;
// System.Reflection.Module
struct Module_t4282841206;
// System.Type[]
struct TypeU5BU5D_t1664964607;
// System.Reflection.AssemblyName
struct AssemblyName_t894705941;
// System.Reflection.Module[]
struct ModuleU5BU5D_t3593287923;
// System.Reflection.Assembly/ResolveEventHolder
struct ResolveEventHolder_t1761494505;
// System.Reflection.AssemblyCompanyAttribute
struct AssemblyCompanyAttribute_t2851673381;
// System.Reflection.AssemblyConfigurationAttribute
struct AssemblyConfigurationAttribute_t1678917172;
// System.Reflection.AssemblyCopyrightAttribute
struct AssemblyCopyrightAttribute_t177123295;
// System.Reflection.AssemblyDefaultAliasAttribute
struct AssemblyDefaultAliasAttribute_t1774139159;
// System.Reflection.AssemblyDelaySignAttribute
struct AssemblyDelaySignAttribute_t2705758496;
// System.Reflection.AssemblyDescriptionAttribute
struct AssemblyDescriptionAttribute_t1018387888;
// System.Reflection.AssemblyFileVersionAttribute
struct AssemblyFileVersionAttribute_t2897687916;
// System.Reflection.AssemblyInformationalVersionAttribute
struct AssemblyInformationalVersionAttribute_t3037389657;
// System.Reflection.AssemblyKeyFileAttribute
struct AssemblyKeyFileAttribute_t605245443;
// System.Version
struct Version_t1755874712;
// System.Byte[]
struct ByteU5BU5D_t3397334013;
// System.Object
struct Il2CppObject;
// System.Reflection.AssemblyProductAttribute
struct AssemblyProductAttribute_t1523443169;
// System.Reflection.AssemblyTitleAttribute
struct AssemblyTitleAttribute_t92945912;
// System.Reflection.AssemblyTrademarkAttribute
struct AssemblyTrademarkAttribute_t3740556705;
// System.Reflection.Binder
struct Binder_t3404612058;
// System.Reflection.ParameterInfo[]
struct ParameterInfoU5BU5D_t2275869610;
// System.Globalization.CultureInfo
struct CultureInfo_t3500843524;
// System.Reflection.MethodBase
struct MethodBase_t904190842;
// System.Reflection.MethodBase[]
struct MethodBaseU5BU5D_t2597254495;
// System.Reflection.Binder/Default
struct Default_t3956931304;
// System.Reflection.ParameterModifier[]
struct ParameterModifierU5BU5D_t963192633;
// System.String[]
struct StringU5BU5D_t1642385972;
// System.Reflection.PropertyInfo
struct PropertyInfo_t;
// System.Reflection.PropertyInfo[]
struct PropertyInfoU5BU5D_t1736152084;
// System.Reflection.ConstructorInfo
struct ConstructorInfo_t2851816542;
// System.Reflection.CustomAttributeData
struct CustomAttributeData_t3093286891;
// System.Reflection.CustomAttributeTypedArgument[]
struct CustomAttributeTypedArgumentU5BU5D_t1075686591;
// System.Collections.ObjectModel.ReadOnlyCollection`1<System.Reflection.CustomAttributeTypedArgument>
struct ReadOnlyCollection_1_t1683983606;
// System.Reflection.CustomAttributeNamedArgument[]
struct CustomAttributeNamedArgumentU5BU5D_t3304067486;
// System.Collections.ObjectModel.ReadOnlyCollection`1<System.Reflection.CustomAttributeNamedArgument>
struct ReadOnlyCollection_1_t279943235;
// System.Collections.Generic.IList`1<System.Reflection.CustomAttributeTypedArgument>
struct IList_1_t2039138515;
// System.Collections.Generic.IList`1<System.Reflection.CustomAttributeNamedArgument>
struct IList_1_t635098144;
// System.Collections.Generic.IList`1<System.Reflection.CustomAttributeData>
struct IList_1_t3634227492;
// System.Reflection.MemberInfo
struct MemberInfo_t;
// System.Reflection.ParameterInfo
struct ParameterInfo_t2249040075;
// System.Reflection.DefaultMemberAttribute
struct DefaultMemberAttribute_t889804479;
// System.Reflection.Emit.AssemblyBuilder
struct AssemblyBuilder_t1646117627;
// System.Exception
struct Exception_t1927440687;
// System.Reflection.Emit.ByRefType
struct ByRefType_t1587086384;
// System.Reflection.Emit.ConstructorBuilder
struct ConstructorBuilder_t700974433;
// System.Reflection.Emit.TypeBuilder
struct TypeBuilder_t3308873219;
// System.Type[][]
struct TypeU5BU5DU5BU5D_t2318378278;
// System.Reflection.Emit.ILGenerator
struct ILGenerator_t99948092;
// System.Reflection.Emit.DerivedType
struct DerivedType_t1016359113;
// System.Reflection.EventInfo
struct EventInfo_t;
// System.Reflection.FieldInfo
struct FieldInfo_t;
// System.Reflection.FieldInfo[]
struct FieldInfoU5BU5D_t125053523;
// System.Reflection.MethodInfo
struct MethodInfo_t;
// System.Reflection.MethodInfo[]
struct MethodInfoU5BU5D_t152480188;
// System.Reflection.ConstructorInfo[]
struct ConstructorInfoU5BU5D_t1996683371;
// System.Reflection.Emit.EnumBuilder
struct EnumBuilder_t2808714468;
// System.Reflection.Emit.FieldBuilder
struct FieldBuilder_t2784804005;
// System.Reflection.Emit.UnmanagedMarshal
struct UnmanagedMarshal_t4270021860;
// System.Reflection.Emit.GenericTypeParameterBuilder
struct GenericTypeParameterBuilder_t1370236603;
// System.Reflection.Emit.TokenGenerator
struct TokenGenerator_t4150817334;
// System.Reflection.Emit.MethodBuilder
struct MethodBuilder_t644187984;
// System.Reflection.Emit.ModuleBuilder
struct ModuleBuilder_t4156028127;
// System.Reflection.Emit.ModuleBuilderTokenGenerator
struct ModuleBuilderTokenGenerator_t578872653;
// System.Reflection.Emit.ParameterBuilder
struct ParameterBuilder_t3344728474;
// System.Runtime.InteropServices.MarshalAsAttribute
struct MarshalAsAttribute_t2900773360;
// System.Reflection.EventInfo/AddEventAdapter
struct AddEventAdapter_t1766862959;
// System.Delegate
struct Delegate_t3022476291;
// System.IAsyncResult
struct IAsyncResult_t1999651008;
// System.AsyncCallback
struct AsyncCallback_t163412349;
// System.Reflection.MemberFilter
struct MemberFilter_t3405857066;
// System.Reflection.MemberInfoSerializationHolder
struct MemberInfoSerializationHolder_t2799051170;
// System.Reflection.Missing
struct Missing_t1033855606;
// System.Reflection.MonoCMethod
struct MonoCMethod_t611352247;
// System.Reflection.MonoEvent
struct MonoEvent_t;
// System.Reflection.MonoField
struct MonoField_t;
// System.Reflection.MonoGenericCMethod
struct MonoGenericCMethod_t2923423538;
// System.Reflection.MonoGenericMethod
struct MonoGenericMethod_t;
// System.Reflection.MonoMethod
struct MonoMethod_t;
// System.Runtime.InteropServices.DllImportAttribute
struct DllImportAttribute_t3000813225;
// System.Reflection.MonoProperty
struct MonoProperty_t;
// System.Reflection.MonoProperty/GetterAdapter
struct GetterAdapter_t1423755509;
// System.Reflection.Pointer
struct Pointer_t937075087;
// System.Reflection.StrongNameKeyPair
struct StrongNameKeyPair_t4090869089;
// System.Reflection.TargetException
struct TargetException_t1572104820;
// System.Reflection.TargetInvocationException
struct TargetInvocationException_t4098620458;
// System.Reflection.TargetParameterCountException
struct TargetParameterCountException_t1554451430;
// System.Reflection.TypeFilter
struct TypeFilter_t2905709404;
// System.ResolveEventArgs
struct ResolveEventArgs_t1859808873;
// System.ResolveEventHandler
struct ResolveEventHandler_t3842432458;
// System.Resources.NeutralResourcesLanguageAttribute
struct NeutralResourcesLanguageAttribute_t3267676636;
// System.Resources.ResourceManager
struct ResourceManager_t264715885;
// System.Resources.ResourceReader
struct ResourceReader_t2463923611;
// System.IO.Stream
struct Stream_t3255436806;
// System.Collections.IEnumerator
struct IEnumerator_t1466026749;
// System.Resources.ResourceReader/ResourceCacheItem[]
struct ResourceCacheItemU5BU5D_t2265014744;
// System.Collections.IDictionaryEnumerator
struct IDictionaryEnumerator_t259680273;

#include "class-internals.h"
#include "codegen/il2cpp-codegen.h"
#include "mscorlib_System_Array3829468939.h"
#include "mscorlib_System_OverflowException1075868493.h"
#include "mscorlib_System_OverflowException1075868493MethodDeclarations.h"
#include "mscorlib_System_Void1841601450.h"
#include "mscorlib_Locale4255929014MethodDeclarations.h"
#include "mscorlib_System_ArithmeticException3261462543MethodDeclarations.h"
#include "mscorlib_System_Exception1927440687MethodDeclarations.h"
#include "mscorlib_System_String2029220233.h"
#include "mscorlib_System_Int322071877448.h"
#include "mscorlib_System_Runtime_Serialization_Serialization228987430.h"
#include "mscorlib_System_Runtime_Serialization_StreamingCon1417235061.h"
#include "mscorlib_System_ParamArrayAttribute2144993728.h"
#include "mscorlib_System_ParamArrayAttribute2144993728MethodDeclarations.h"
#include "mscorlib_System_Attribute542643598MethodDeclarations.h"
#include "mscorlib_System_PlatformID1006634368.h"
#include "mscorlib_System_PlatformID1006634368MethodDeclarations.h"
#include "mscorlib_System_PlatformNotSupportedException3778770305.h"
#include "mscorlib_System_PlatformNotSupportedException3778770305MethodDeclarations.h"
#include "mscorlib_System_NotSupportedException1793819818MethodDeclarations.h"
#include "mscorlib_System_RankException1539875949.h"
#include "mscorlib_System_RankException1539875949MethodDeclarations.h"
#include "mscorlib_System_SystemException3877406272MethodDeclarations.h"
#include "mscorlib_System_Reflection_AmbiguousMatchException1406414556.h"
#include "mscorlib_System_Reflection_AmbiguousMatchException1406414556MethodDeclarations.h"
#include "mscorlib_System_Reflection_Assembly4268412390.h"
#include "mscorlib_System_Reflection_Assembly4268412390MethodDeclarations.h"
#include "mscorlib_System_Object2689449295MethodDeclarations.h"
#include "mscorlib_System_Reflection_Assembly_ResolveEventHo1761494505MethodDeclarations.h"
#include "mscorlib_System_Reflection_Assembly_ResolveEventHo1761494505.h"
#include "mscorlib_System_Boolean3825574718.h"
#include "mscorlib_System_String2029220233MethodDeclarations.h"
#include "mscorlib_System_Type1303803226.h"
#include "mscorlib_System_MonoCustomAttrs2976585698MethodDeclarations.h"
#include "mscorlib_ArrayTypes.h"
#include "mscorlib_System_Object2689449295.h"
#include "mscorlib_System_IntPtr2504060609.h"
#include "mscorlib_System_Reflection_Module4282841206.h"
#include "mscorlib_System_ArgumentNullException628810857MethodDeclarations.h"
#include "mscorlib_System_ArgumentException3259014390MethodDeclarations.h"
#include "mscorlib_System_ArgumentNullException628810857.h"
#include "mscorlib_System_ArgumentException3259014390.h"
#include "mscorlib_System_Reflection_AssemblyName894705941.h"
#include "mscorlib_System_Security_SecurityManager3191249573MethodDeclarations.h"
#include "mscorlib_System_Reflection_AssemblyName894705941MethodDeclarations.h"
#include "mscorlib_System_AppDomain2719102437MethodDeclarations.h"
#include "mscorlib_System_AppDomain2719102437.h"
#include "mscorlib_System_Reflection_Module4282841206MethodDeclarations.h"
#include "mscorlib_System_Collections_ArrayList4252133567MethodDeclarations.h"
#include "mscorlib_System_Type1303803226MethodDeclarations.h"
#include "mscorlib_System_Collections_ArrayList4252133567.h"
#include "mscorlib_System_RuntimeTypeHandle2330101084.h"
#include "mscorlib_System_Reflection_AssemblyCompanyAttribut2851673381.h"
#include "mscorlib_System_Reflection_AssemblyCompanyAttribut2851673381MethodDeclarations.h"
#include "mscorlib_System_Reflection_AssemblyConfigurationAt1678917172.h"
#include "mscorlib_System_Reflection_AssemblyConfigurationAt1678917172MethodDeclarations.h"
#include "mscorlib_System_Reflection_AssemblyCopyrightAttribu177123295.h"
#include "mscorlib_System_Reflection_AssemblyCopyrightAttribu177123295MethodDeclarations.h"
#include "mscorlib_System_Reflection_AssemblyDefaultAliasAtt1774139159.h"
#include "mscorlib_System_Reflection_AssemblyDefaultAliasAtt1774139159MethodDeclarations.h"
#include "mscorlib_System_Reflection_AssemblyDelaySignAttrib2705758496.h"
#include "mscorlib_System_Reflection_AssemblyDelaySignAttrib2705758496MethodDeclarations.h"
#include "mscorlib_System_Reflection_AssemblyDescriptionAttr1018387888.h"
#include "mscorlib_System_Reflection_AssemblyDescriptionAttr1018387888MethodDeclarations.h"
#include "mscorlib_System_Reflection_AssemblyFileVersionAttr2897687916.h"
#include "mscorlib_System_Reflection_AssemblyFileVersionAttr2897687916MethodDeclarations.h"
#include "mscorlib_System_Reflection_AssemblyInformationalVe3037389657.h"
#include "mscorlib_System_Reflection_AssemblyInformationalVe3037389657MethodDeclarations.h"
#include "mscorlib_System_Reflection_AssemblyKeyFileAttribute605245443.h"
#include "mscorlib_System_Reflection_AssemblyKeyFileAttribute605245443MethodDeclarations.h"
#include "mscorlib_System_Configuration_Assemblies_AssemblyV1223556284.h"
#include "mscorlib_System_Runtime_Serialization_Serialization228987430MethodDeclarations.h"
#include "mscorlib_System_Globalization_CultureInfo3500843524MethodDeclarations.h"
#include "mscorlib_System_Version1755874712.h"
#include "mscorlib_System_Byte3683104436.h"
#include "mscorlib_System_Configuration_Assemblies_AssemblyH4147282775.h"
#include "mscorlib_System_Reflection_StrongNameKeyPair4090869089.h"
#include "mscorlib_System_Reflection_AssemblyNameFlags1794031440.h"
#include "mscorlib_System_Globalization_CultureInfo3500843524.h"
#include "mscorlib_System_Text_StringBuilder1221177846MethodDeclarations.h"
#include "mscorlib_System_Version1755874712MethodDeclarations.h"
#include "mscorlib_System_Text_StringBuilder1221177846.h"
#include "mscorlib_System_Byte3683104436MethodDeclarations.h"
#include "mscorlib_Mono_Security_Cryptography_CryptoConvert4146607874MethodDeclarations.h"
#include "mscorlib_System_Security_Cryptography_Cryptographi3349726436.h"
#include "mscorlib_System_Security_Cryptography_RSA3719518354.h"
#include "mscorlib_System_Security_SecurityException887327375MethodDeclarations.h"
#include "mscorlib_System_Security_SecurityException887327375.h"
#include "mscorlib_System_Security_Cryptography_SHA13336793149MethodDeclarations.h"
#include "mscorlib_System_Security_Cryptography_HashAlgorith2624936259MethodDeclarations.h"
#include "mscorlib_System_Array3829468939MethodDeclarations.h"
#include "mscorlib_System_Security_Cryptography_HashAlgorith2624936259.h"
#include "mscorlib_System_Security_Cryptography_SHA13336793149.h"
#include "mscorlib_System_Reflection_AssemblyNameFlags1794031440MethodDeclarations.h"
#include "mscorlib_System_Reflection_AssemblyProductAttribut1523443169.h"
#include "mscorlib_System_Reflection_AssemblyProductAttribut1523443169MethodDeclarations.h"
#include "mscorlib_System_Reflection_AssemblyTitleAttribute92945912.h"
#include "mscorlib_System_Reflection_AssemblyTitleAttribute92945912MethodDeclarations.h"
#include "mscorlib_System_Reflection_AssemblyTrademarkAttrib3740556705.h"
#include "mscorlib_System_Reflection_AssemblyTrademarkAttrib3740556705MethodDeclarations.h"
#include "mscorlib_System_Reflection_Binder3404612058.h"
#include "mscorlib_System_Reflection_Binder3404612058MethodDeclarations.h"
#include "mscorlib_System_Reflection_Binder_Default3956931304MethodDeclarations.h"
#include "mscorlib_System_Reflection_Binder_Default3956931304.h"
#include "mscorlib_System_Reflection_ParameterInfo2249040075.h"
#include "mscorlib_System_Reflection_TargetParameterCountExc1554451430MethodDeclarations.h"
#include "mscorlib_System_Reflection_TargetParameterCountExc1554451430.h"
#include "mscorlib_System_Reflection_ParameterInfo2249040075MethodDeclarations.h"
#include "mscorlib_System_Reflection_MethodBase904190842.h"
#include "mscorlib_System_Reflection_MemberInfo4043097260MethodDeclarations.h"
#include "mscorlib_System_Reflection_MemberInfo4043097260.h"
#include "mscorlib_System_Reflection_MethodBase904190842MethodDeclarations.h"
#include "mscorlib_System_Reflection_BindingFlags1082350898.h"
#include "mscorlib_System_Reflection_ParameterModifier1820634920.h"
#include "mscorlib_System_Enum2459695545MethodDeclarations.h"
#include "mscorlib_System_Convert2607082565MethodDeclarations.h"
#include "mscorlib_System_Char3454481338.h"
#include "mscorlib_System_Double4078015681.h"
#include "mscorlib_System_Single2076509932.h"
#include "mscorlib_System_TypeCode2536926201.h"
#include "mscorlib_System_Reflection_CallingConventions1097349142.h"
#include "mscorlib_System_Reflection_PropertyInfo2253729065.h"
#include "mscorlib_System_Reflection_PropertyInfo2253729065MethodDeclarations.h"
#include "mscorlib_System_Reflection_BindingFlags1082350898MethodDeclarations.h"
#include "mscorlib_System_Reflection_CallingConventions1097349142MethodDeclarations.h"
#include "mscorlib_System_Reflection_ConstructorInfo2851816542.h"
#include "mscorlib_System_Reflection_ConstructorInfo2851816542MethodDeclarations.h"
#include "mscorlib_System_Reflection_MemberTypes3343038963.h"
#include "mscorlib_System_Reflection_CustomAttributeData3093286891.h"
#include "mscorlib_System_Reflection_CustomAttributeData3093286891MethodDeclarations.h"
#include "mscorlib_System_Reflection_CustomAttributeTypedArg1498197914.h"
#include "mscorlib_System_Collections_ObjectModel_ReadOnlyCo1683983606.h"
#include "mscorlib_System_Reflection_CustomAttributeNamedArgum94157543.h"
#include "mscorlib_System_Collections_ObjectModel_ReadOnlyCol279943235.h"
#include "mscorlib_System_Reflection_CustomAttributeTypedArg1498197914MethodDeclarations.h"
#include "mscorlib_System_Reflection_CustomAttributeNamedArgum94157543MethodDeclarations.h"
#include "mscorlib_System_Reflection_DefaultMemberAttribute889804479.h"
#include "mscorlib_System_Reflection_DefaultMemberAttribute889804479MethodDeclarations.h"
#include "mscorlib_System_Reflection_Emit_AssemblyBuilder1646117627.h"
#include "mscorlib_System_Reflection_Emit_AssemblyBuilder1646117627MethodDeclarations.h"
#include "mscorlib_System_Exception1927440687.h"
#include "mscorlib_System_Reflection_Emit_ModuleBuilder4156028127.h"
#include "mscorlib_System_Reflection_Emit_ModuleBuilder4156028127MethodDeclarations.h"
#include "mscorlib_System_NotSupportedException1793819818.h"
#include "mscorlib_Mono_Security_StrongName117835354MethodDeclarations.h"
#include "mscorlib_Mono_Security_StrongName117835354.h"
#include "mscorlib_System_Reflection_Emit_ByRefType1587086384.h"
#include "mscorlib_System_Reflection_Emit_ByRefType1587086384MethodDeclarations.h"
#include "mscorlib_System_Reflection_Emit_DerivedType1016359113MethodDeclarations.h"
#include "mscorlib_System_Reflection_Emit_ConstructorBuilder700974433.h"
#include "mscorlib_System_Reflection_Emit_ConstructorBuilder700974433MethodDeclarations.h"
#include "mscorlib_System_Reflection_Emit_TypeBuilder3308873219.h"
#include "mscorlib_System_Reflection_MethodAttributes790385034.h"
#include "mscorlib_System_Reflection_Emit_TypeBuilder3308873219MethodDeclarations.h"
#include "mscorlib_System_Reflection_Emit_MethodToken3991686330.h"
#include "mscorlib_System_Reflection_Emit_MethodToken3991686330MethodDeclarations.h"
#include "mscorlib_System_Reflection_Emit_ParameterBuilder3344728474.h"
#include "mscorlib_System_RuntimeMethodHandle894824333.h"
#include "mscorlib_System_Reflection_Emit_ILGenerator99948092.h"
#include "mscorlib_System_Reflection_Emit_ILGenerator99948092MethodDeclarations.h"
#include "mscorlib_System_InvalidOperationException721527559MethodDeclarations.h"
#include "mscorlib_System_Reflection_MethodImplAttributes1541361196.h"
#include "mscorlib_System_InvalidOperationException721527559.h"
#include "mscorlib_System_Reflection_Emit_DerivedType1016359113.h"
#include "mscorlib_System_Reflection_EventInfo4258285342.h"
#include "mscorlib_System_Reflection_FieldInfo255040150.h"
#include "mscorlib_System_Reflection_MethodInfo3330546337.h"
#include "mscorlib_System_Reflection_TypeAttributes2229518203.h"
#include "mscorlib_System_Reflection_Emit_EnumBuilder2808714468.h"
#include "mscorlib_System_Reflection_Emit_EnumBuilder2808714468MethodDeclarations.h"
#include "mscorlib_System_Reflection_Emit_FieldBuilder2784804005.h"
#include "mscorlib_System_Reflection_Emit_FieldBuilder2784804005MethodDeclarations.h"
#include "mscorlib_System_Reflection_FieldAttributes1122705193.h"
#include "mscorlib_System_RuntimeFieldHandle2331729674.h"
#include "mscorlib_System_Reflection_Emit_UnmanagedMarshal4270021860.h"
#include "mscorlib_System_Reflection_Emit_GenericTypeParamet1370236603.h"
#include "mscorlib_System_Reflection_Emit_GenericTypeParamet1370236603MethodDeclarations.h"
#include "mscorlib_System_Reflection_Emit_MethodBuilder644187984MethodDeclarations.h"
#include "mscorlib_System_Reflection_Emit_MethodBuilder644187984.h"
#include "mscorlib_System_Reflection_Emit_ILTokenInfo149559338.h"
#include "mscorlib_System_Reflection_Emit_OpCode2247480392.h"
#include "mscorlib_System_Reflection_Emit_StackBehaviour1390406961.h"
#include "mscorlib_System_Reflection_Emit_OpCode2247480392MethodDeclarations.h"
#include "mscorlib_System_Reflection_Emit_ILGenerator_LabelD3712112744.h"
#include "mscorlib_System_Reflection_Emit_ILGenerator_LabelF4090909514.h"
#include "mscorlib_System_Reflection_Emit_ILGenerator_LabelD3712112744MethodDeclarations.h"
#include "mscorlib_System_Reflection_Emit_ILGenerator_LabelF4090909514MethodDeclarations.h"
#include "mscorlib_System_Reflection_Emit_ILTokenInfo149559338MethodDeclarations.h"
#include "mscorlib_System_TypeLoadException723359155MethodDeclarations.h"
#include "mscorlib_System_TypeLoadException723359155.h"
#include "mscorlib_System_Reflection_Emit_ModuleBuilderTokenG578872653MethodDeclarations.h"
#include "mscorlib_System_Reflection_Emit_ModuleBuilderTokenG578872653.h"
#include "mscorlib_System_Reflection_Emit_OpCodeNames1907134268.h"
#include "mscorlib_System_Reflection_Emit_OpCodeNames1907134268MethodDeclarations.h"
#include "mscorlib_System_Reflection_Emit_OpCodes3494785031.h"
#include "mscorlib_System_Reflection_Emit_OpCodes3494785031MethodDeclarations.h"
#include "mscorlib_System_Reflection_Emit_ParameterBuilder3344728474MethodDeclarations.h"
#include "mscorlib_System_Reflection_ParameterAttributes1266705348.h"
#include "mscorlib_System_Reflection_Emit_StackBehaviour1390406961MethodDeclarations.h"
#include "mscorlib_System_Reflection_FieldInfo255040150MethodDeclarations.h"
#include "mscorlib_System_Reflection_Emit_UnmanagedMarshal4270021860MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_MarshalAsA2900773360.h"
#include "mscorlib_System_Runtime_InteropServices_MarshalAsA2900773360MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_UnmanagedT2550630890.h"
#include "mscorlib_System_Int164041245914.h"
#include "mscorlib_System_Reflection_EventAttributes2989788983.h"
#include "mscorlib_System_Reflection_EventAttributes2989788983MethodDeclarations.h"
#include "mscorlib_System_Reflection_EventInfo4258285342MethodDeclarations.h"
#include "mscorlib_System_Reflection_EventInfo_AddEventAdapt1766862959.h"
#include "mscorlib_System_Reflection_EventInfo_AddEventAdapt1766862959MethodDeclarations.h"
#include "mscorlib_System_Delegate3022476291.h"
#include "mscorlib_System_AsyncCallback163412349.h"
#include "mscorlib_System_Reflection_FieldAttributes1122705193MethodDeclarations.h"
#include "mscorlib_System_IntPtr2504060609MethodDeclarations.h"
#include "mscorlib_System_RuntimeFieldHandle2331729674MethodDeclarations.h"
#include "mscorlib_System_SystemException3877406272.h"
#include "mscorlib_System_NonSerializedAttribute399263003MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_FieldOffse1553145711MethodDeclarations.h"
#include "mscorlib_System_NonSerializedAttribute399263003.h"
#include "mscorlib_System_Runtime_InteropServices_FieldOffse1553145711.h"
#include "mscorlib_System_Reflection_MemberFilter3405857066.h"
#include "mscorlib_System_Reflection_MemberFilter3405857066MethodDeclarations.h"
#include "mscorlib_System_Reflection_MemberInfoSerialization2799051170.h"
#include "mscorlib_System_Reflection_MemberInfoSerialization2799051170MethodDeclarations.h"
#include "mscorlib_System_Runtime_Serialization_Serialization753258759.h"
#include "mscorlib_System_Runtime_Serialization_Serialization753258759MethodDeclarations.h"
#include "mscorlib_System_Reflection_MethodInfo3330546337MethodDeclarations.h"
#include "mscorlib_System_Reflection_MemberTypes3343038963MethodDeclarations.h"
#include "mscorlib_System_Reflection_MethodAttributes790385034MethodDeclarations.h"
#include "mscorlib_System_RuntimeMethodHandle894824333MethodDeclarations.h"
#include "mscorlib_System_Reflection_MethodImplAttributes1541361196MethodDeclarations.h"
#include "mscorlib_System_Reflection_Missing1033855606.h"
#include "mscorlib_System_Reflection_Missing1033855606MethodDeclarations.h"
#include "mscorlib_System_Reflection_TypeFilter2905709404MethodDeclarations.h"
#include "mscorlib_System_Reflection_TypeFilter2905709404.h"
#include "mscorlib_System_UnitySerializationHolder2045574117MethodDeclarations.h"
#include "mscorlib_System_Reflection_MonoCMethod611352247.h"
#include "mscorlib_System_Reflection_MonoCMethod611352247MethodDeclarations.h"
#include "mscorlib_System_Reflection_MonoMethodInfo3646562144MethodDeclarations.h"
#include "mscorlib_System_MemberAccessException2005094827MethodDeclarations.h"
#include "mscorlib_System_Reflection_TargetInvocationExcepti4098620458MethodDeclarations.h"
#include "mscorlib_System_MethodAccessException4093255254.h"
#include "mscorlib_System_MemberAccessException2005094827.h"
#include "mscorlib_System_Reflection_TargetInvocationExcepti4098620458.h"
#include "mscorlib_System_Reflection_MonoMethod116053496MethodDeclarations.h"
#include "mscorlib_System_Reflection_MonoEvent2188687691.h"
#include "mscorlib_System_Reflection_MonoEvent2188687691MethodDeclarations.h"
#include "mscorlib_System_Reflection_MonoEventInfo2190036573MethodDeclarations.h"
#include "mscorlib_System_Reflection_MonoEventInfo2190036573.h"
#include "mscorlib_System_Reflection_MonoField3600053525.h"
#include "mscorlib_System_Reflection_MonoField3600053525MethodDeclarations.h"
#include "mscorlib_System_Reflection_TargetException1572104820MethodDeclarations.h"
#include "mscorlib_System_Reflection_TargetException1572104820.h"
#include "mscorlib_System_FieldAccessException1797813379MethodDeclarations.h"
#include "mscorlib_System_FieldAccessException1797813379.h"
#include "mscorlib_System_Reflection_MonoGenericCMethod2923423538.h"
#include "mscorlib_System_Reflection_MonoGenericCMethod2923423538MethodDeclarations.h"
#include "mscorlib_System_Reflection_MonoGenericMethod1068099169.h"
#include "mscorlib_System_Reflection_MonoGenericMethod1068099169MethodDeclarations.h"
#include "mscorlib_System_Reflection_MonoMethod116053496.h"
#include "mscorlib_System_Threading_ThreadAbortException1150575753.h"
#include "mscorlib_System_Runtime_InteropServices_DllImportA3000813225.h"
#include "mscorlib_System_Runtime_InteropServices_PreserveSi1564965109MethodDeclarations.h"
#include "mscorlib_System_Reflection_MonoMethodInfo3646562144.h"
#include "mscorlib_System_Runtime_InteropServices_PreserveSi1564965109.h"
#include "mscorlib_System_Reflection_MonoProperty2242413552.h"
#include "mscorlib_System_Reflection_MonoProperty2242413552MethodDeclarations.h"
#include "mscorlib_System_Reflection_PInfo957350482.h"
#include "mscorlib_System_Reflection_MonoPropertyInfo486106184MethodDeclarations.h"
#include "mscorlib_System_Reflection_MonoPropertyInfo486106184.h"
#include "mscorlib_System_Reflection_PropertyAttributes883448530.h"
#include "mscorlib_System_Reflection_MonoProperty_GetterAdap1423755509.h"
#include "mscorlib_System_Delegate3022476291MethodDeclarations.h"
#include "mscorlib_System_MethodAccessException4093255254MethodDeclarations.h"
#include "mscorlib_System_Reflection_MonoProperty_GetterAdap1423755509MethodDeclarations.h"
#include "mscorlib_System_Reflection_ParameterAttributes1266705348MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_InAttribut1394050551MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_OptionalAtt827982902MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_OutAttribu1539424546MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_InAttribut1394050551.h"
#include "mscorlib_System_Runtime_InteropServices_OptionalAtt827982902.h"
#include "mscorlib_System_Runtime_InteropServices_OutAttribu1539424546.h"
#include "mscorlib_System_Reflection_ParameterModifier1820634920MethodDeclarations.h"
#include "mscorlib_System_Reflection_PInfo957350482MethodDeclarations.h"
#include "mscorlib_System_Reflection_Pointer937075087.h"
#include "mscorlib_System_Reflection_Pointer937075087MethodDeclarations.h"
#include "mscorlib_System_Reflection_ProcessorArchitecture1620065459.h"
#include "mscorlib_System_Reflection_ProcessorArchitecture1620065459MethodDeclarations.h"
#include "mscorlib_System_Reflection_PropertyAttributes883448530MethodDeclarations.h"
#include "mscorlib_System_Reflection_StrongNameKeyPair4090869089MethodDeclarations.h"
#include "mscorlib_System_Reflection_TypeAttributes2229518203MethodDeclarations.h"
#include "mscorlib_System_ResolveEventArgs1859808873.h"
#include "mscorlib_System_ResolveEventArgs1859808873MethodDeclarations.h"
#include "mscorlib_System_EventArgs3289624707MethodDeclarations.h"
#include "mscorlib_System_ResolveEventHandler3842432458.h"
#include "mscorlib_System_ResolveEventHandler3842432458MethodDeclarations.h"
#include "mscorlib_System_Resources_NeutralResourcesLanguage3267676636.h"
#include "mscorlib_System_Resources_NeutralResourcesLanguage3267676636MethodDeclarations.h"
#include "mscorlib_System_Resources_PredefinedResourceType3623697780.h"
#include "mscorlib_System_Resources_PredefinedResourceType3623697780MethodDeclarations.h"
#include "mscorlib_System_Resources_ResourceManager264715885.h"
#include "mscorlib_System_Resources_ResourceManager264715885MethodDeclarations.h"
#include "mscorlib_System_Collections_Hashtable909839986MethodDeclarations.h"
#include "mscorlib_System_Collections_Hashtable909839986.h"
#include "mscorlib_System_Resources_ResourceReader2463923611.h"
#include "mscorlib_System_Resources_ResourceReader2463923611MethodDeclarations.h"
#include "mscorlib_System_IO_Stream3255436806.h"
#include "mscorlib_System_Text_Encoding663144255MethodDeclarations.h"
#include "mscorlib_System_IO_BinaryReader2491843768MethodDeclarations.h"
#include "mscorlib_System_Runtime_Serialization_Formatters_B1866979105MethodDeclarations.h"
#include "mscorlib_System_IO_Stream3255436806MethodDeclarations.h"
#include "mscorlib_System_Text_Encoding663144255.h"
#include "mscorlib_System_IO_BinaryReader2491843768.h"
#include "mscorlib_System_Runtime_Serialization_StreamingCon1417235061MethodDeclarations.h"
#include "mscorlib_System_Runtime_Serialization_StreamingCon4264247603.h"
#include "mscorlib_System_Runtime_Serialization_Formatters_B1866979105.h"
#include "mscorlib_System_IO_FileStream1695958676MethodDeclarations.h"
#include "mscorlib_System_IO_FileStream1695958676.h"
#include "mscorlib_System_IO_FileMode236403845.h"
#include "mscorlib_System_IO_FileAccess4282042064.h"
#include "mscorlib_System_IO_FileShare3362491215.h"
#include "mscorlib_System_Int64909078037.h"
#include "mscorlib_System_IO_EndOfStreamException1711658693.h"
#include "mscorlib_System_IO_SeekOrigin2475945306.h"
#include "mscorlib_System_Int322071877448MethodDeclarations.h"
#include "mscorlib_System_Resources_ResourceReader_ResourceI3933049236.h"
#include "mscorlib_System_Resources_ResourceReader_ResourceI3933049236MethodDeclarations.h"
#include "mscorlib_System_IO_MemoryStream743994179MethodDeclarations.h"
#include "mscorlib_System_UInt16986882611.h"
#include "mscorlib_System_SByte454417549.h"
#include "mscorlib_System_UInt322149682021.h"
#include "mscorlib_System_UInt642909196914.h"
#include "mscorlib_System_Decimal724701077.h"
#include "mscorlib_System_DateTime693205669.h"
#include "mscorlib_System_DateTime693205669MethodDeclarations.h"
#include "mscorlib_System_TimeSpan3430258949.h"
#include "mscorlib_System_TimeSpan3430258949MethodDeclarations.h"
#include "mscorlib_System_IO_MemoryStream743994179.h"
#include "mscorlib_System_Resources_ResourceReader_ResourceCa333236149.h"
#include "mscorlib_System_Threading_Monitor3228523394MethodDeclarations.h"
#include "mscorlib_System_Resources_ResourceReader_ResourceCa333236149MethodDeclarations.h"
#include "mscorlib_System_Resources_ResourceReader_ResourceE2665690338MethodDeclarations.h"
#include "mscorlib_System_Resources_ResourceReader_ResourceE2665690338.h"

// System.Int32 System.Array::IndexOf<System.Object>(!!0[],!!0)
extern "C"  int32_t Array_IndexOf_TisIl2CppObject_m2032877681_gshared (Il2CppObject * __this /* static, unused */, ObjectU5BU5D_t3614634134* p0, Il2CppObject * p1, const MethodInfo* method);
#define Array_IndexOf_TisIl2CppObject_m2032877681(__this /* static, unused */, p0, p1, method) ((  int32_t (*) (Il2CppObject * /* static, unused */, ObjectU5BU5D_t3614634134*, Il2CppObject *, const MethodInfo*))Array_IndexOf_TisIl2CppObject_m2032877681_gshared)(__this /* static, unused */, p0, p1, method)
// System.Int32 System.Array::IndexOf<System.Type>(!!0[],!!0)
#define Array_IndexOf_TisType_t_m4216821136(__this /* static, unused */, p0, p1, method) ((  int32_t (*) (Il2CppObject * /* static, unused */, TypeU5BU5D_t1664964607*, Type_t *, const MethodInfo*))Array_IndexOf_TisIl2CppObject_m2032877681_gshared)(__this /* static, unused */, p0, p1, method)
// !!0[] System.Reflection.CustomAttributeData::UnboxValues<System.Reflection.CustomAttributeTypedArgument>(System.Object[])
extern "C"  CustomAttributeTypedArgumentU5BU5D_t1075686591* CustomAttributeData_UnboxValues_TisCustomAttributeTypedArgument_t1498197914_m2561215702_gshared (Il2CppObject * __this /* static, unused */, ObjectU5BU5D_t3614634134* p0, const MethodInfo* method);
#define CustomAttributeData_UnboxValues_TisCustomAttributeTypedArgument_t1498197914_m2561215702(__this /* static, unused */, p0, method) ((  CustomAttributeTypedArgumentU5BU5D_t1075686591* (*) (Il2CppObject * /* static, unused */, ObjectU5BU5D_t3614634134*, const MethodInfo*))CustomAttributeData_UnboxValues_TisCustomAttributeTypedArgument_t1498197914_m2561215702_gshared)(__this /* static, unused */, p0, method)
// System.Collections.ObjectModel.ReadOnlyCollection`1<!!0> System.Array::AsReadOnly<System.Reflection.CustomAttributeTypedArgument>(!!0[])
extern "C"  ReadOnlyCollection_1_t1683983606 * Array_AsReadOnly_TisCustomAttributeTypedArgument_t1498197914_m2855930084_gshared (Il2CppObject * __this /* static, unused */, CustomAttributeTypedArgumentU5BU5D_t1075686591* p0, const MethodInfo* method);
#define Array_AsReadOnly_TisCustomAttributeTypedArgument_t1498197914_m2855930084(__this /* static, unused */, p0, method) ((  ReadOnlyCollection_1_t1683983606 * (*) (Il2CppObject * /* static, unused */, CustomAttributeTypedArgumentU5BU5D_t1075686591*, const MethodInfo*))Array_AsReadOnly_TisCustomAttributeTypedArgument_t1498197914_m2855930084_gshared)(__this /* static, unused */, p0, method)
// !!0[] System.Reflection.CustomAttributeData::UnboxValues<System.Reflection.CustomAttributeNamedArgument>(System.Object[])
extern "C"  CustomAttributeNamedArgumentU5BU5D_t3304067486* CustomAttributeData_UnboxValues_TisCustomAttributeNamedArgument_t94157543_m2789115353_gshared (Il2CppObject * __this /* static, unused */, ObjectU5BU5D_t3614634134* p0, const MethodInfo* method);
#define CustomAttributeData_UnboxValues_TisCustomAttributeNamedArgument_t94157543_m2789115353(__this /* static, unused */, p0, method) ((  CustomAttributeNamedArgumentU5BU5D_t3304067486* (*) (Il2CppObject * /* static, unused */, ObjectU5BU5D_t3614634134*, const MethodInfo*))CustomAttributeData_UnboxValues_TisCustomAttributeNamedArgument_t94157543_m2789115353_gshared)(__this /* static, unused */, p0, method)
// System.Collections.ObjectModel.ReadOnlyCollection`1<!!0> System.Array::AsReadOnly<System.Reflection.CustomAttributeNamedArgument>(!!0[])
extern "C"  ReadOnlyCollection_1_t279943235 * Array_AsReadOnly_TisCustomAttributeNamedArgument_t94157543_m2935638619_gshared (Il2CppObject * __this /* static, unused */, CustomAttributeNamedArgumentU5BU5D_t3304067486* p0, const MethodInfo* method);
#define Array_AsReadOnly_TisCustomAttributeNamedArgument_t94157543_m2935638619(__this /* static, unused */, p0, method) ((  ReadOnlyCollection_1_t279943235 * (*) (Il2CppObject * /* static, unused */, CustomAttributeNamedArgumentU5BU5D_t3304067486*, const MethodInfo*))Array_AsReadOnly_TisCustomAttributeNamedArgument_t94157543_m2935638619_gshared)(__this /* static, unused */, p0, method)
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void System.OverflowException::.ctor()
extern Il2CppCodeGenString* _stringLiteral1124468381;
extern const uint32_t OverflowException__ctor_m2564269836_MetadataUsageId;
extern "C"  void OverflowException__ctor_m2564269836 (OverflowException_t1075868493 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (OverflowException__ctor_m2564269836_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		String_t* L_0 = Locale_GetText_m1954433032(NULL /*static, unused*/, _stringLiteral1124468381, /*hidden argument*/NULL);
		ArithmeticException__ctor_m4208398840(__this, L_0, /*hidden argument*/NULL);
		Exception_set_HResult_m2376998645(__this, ((int32_t)-2146233066), /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.OverflowException::.ctor(System.String)
extern "C"  void OverflowException__ctor_m3249894750 (OverflowException_t1075868493 * __this, String_t* ___message0, const MethodInfo* method)
{
	{
		String_t* L_0 = ___message0;
		ArithmeticException__ctor_m4208398840(__this, L_0, /*hidden argument*/NULL);
		Exception_set_HResult_m2376998645(__this, ((int32_t)-2146233066), /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.OverflowException::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern "C"  void OverflowException__ctor_m2230275335 (OverflowException_t1075868493 * __this, SerializationInfo_t228987430 * ___info0, StreamingContext_t1417235061  ___context1, const MethodInfo* method)
{
	{
		SerializationInfo_t228987430 * L_0 = ___info0;
		StreamingContext_t1417235061  L_1 = ___context1;
		ArithmeticException__ctor_m104771799(__this, L_0, L_1, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.ParamArrayAttribute::.ctor()
extern "C"  void ParamArrayAttribute__ctor_m2215984741 (ParamArrayAttribute_t2144993728 * __this, const MethodInfo* method)
{
	{
		Attribute__ctor_m1730479323(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.PlatformNotSupportedException::.ctor()
extern Il2CppCodeGenString* _stringLiteral3018961310;
extern const uint32_t PlatformNotSupportedException__ctor_m782561872_MetadataUsageId;
extern "C"  void PlatformNotSupportedException__ctor_m782561872 (PlatformNotSupportedException_t3778770305 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (PlatformNotSupportedException__ctor_m782561872_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		String_t* L_0 = Locale_GetText_m1954433032(NULL /*static, unused*/, _stringLiteral3018961310, /*hidden argument*/NULL);
		NotSupportedException__ctor_m836173213(__this, L_0, /*hidden argument*/NULL);
		Exception_set_HResult_m2376998645(__this, ((int32_t)-2146233031), /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.PlatformNotSupportedException::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern "C"  void PlatformNotSupportedException__ctor_m3301654967 (PlatformNotSupportedException_t3778770305 * __this, SerializationInfo_t228987430 * ___info0, StreamingContext_t1417235061  ___context1, const MethodInfo* method)
{
	{
		SerializationInfo_t228987430 * L_0 = ___info0;
		StreamingContext_t1417235061  L_1 = ___context1;
		NotSupportedException__ctor_m422639464(__this, L_0, L_1, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.RankException::.ctor()
extern Il2CppCodeGenString* _stringLiteral3468799055;
extern const uint32_t RankException__ctor_m2119191472_MetadataUsageId;
extern "C"  void RankException__ctor_m2119191472 (RankException_t1539875949 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (RankException__ctor_m2119191472_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		String_t* L_0 = Locale_GetText_m1954433032(NULL /*static, unused*/, _stringLiteral3468799055, /*hidden argument*/NULL);
		SystemException__ctor_m4001391027(__this, L_0, /*hidden argument*/NULL);
		Exception_set_HResult_m2376998645(__this, ((int32_t)-2146233065), /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.RankException::.ctor(System.String)
extern "C"  void RankException__ctor_m998508686 (RankException_t1539875949 * __this, String_t* ___message0, const MethodInfo* method)
{
	{
		String_t* L_0 = ___message0;
		SystemException__ctor_m4001391027(__this, L_0, /*hidden argument*/NULL);
		Exception_set_HResult_m2376998645(__this, ((int32_t)-2146233065), /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.RankException::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern "C"  void RankException__ctor_m800781665 (RankException_t1539875949 * __this, SerializationInfo_t228987430 * ___info0, StreamingContext_t1417235061  ___context1, const MethodInfo* method)
{
	{
		SerializationInfo_t228987430 * L_0 = ___info0;
		StreamingContext_t1417235061  L_1 = ___context1;
		SystemException__ctor_m2688248668(__this, L_0, L_1, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Reflection.AmbiguousMatchException::.ctor()
extern Il2CppCodeGenString* _stringLiteral2591063177;
extern const uint32_t AmbiguousMatchException__ctor_m2088048346_MetadataUsageId;
extern "C"  void AmbiguousMatchException__ctor_m2088048346 (AmbiguousMatchException_t1406414556 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AmbiguousMatchException__ctor_m2088048346_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		SystemException__ctor_m4001391027(__this, _stringLiteral2591063177, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Reflection.AmbiguousMatchException::.ctor(System.String)
extern "C"  void AmbiguousMatchException__ctor_m3811079160 (AmbiguousMatchException_t1406414556 * __this, String_t* ___message0, const MethodInfo* method)
{
	{
		String_t* L_0 = ___message0;
		SystemException__ctor_m4001391027(__this, L_0, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Reflection.AmbiguousMatchException::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern "C"  void AmbiguousMatchException__ctor_m3001998225 (AmbiguousMatchException_t1406414556 * __this, SerializationInfo_t228987430 * ___info0, StreamingContext_t1417235061  ___context1, const MethodInfo* method)
{
	{
		SerializationInfo_t228987430 * L_0 = ___info0;
		StreamingContext_t1417235061  L_1 = ___context1;
		SystemException__ctor_m2688248668(__this, L_0, L_1, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Reflection.Assembly::.ctor()
extern Il2CppClass* ResolveEventHolder_t1761494505_il2cpp_TypeInfo_var;
extern const uint32_t Assembly__ctor_m1050192922_MetadataUsageId;
extern "C"  void Assembly__ctor_m1050192922 (Assembly_t4268412390 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Assembly__ctor_m1050192922_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		ResolveEventHolder_t1761494505 * L_0 = (ResolveEventHolder_t1761494505 *)il2cpp_codegen_object_new(ResolveEventHolder_t1761494505_il2cpp_TypeInfo_var);
		ResolveEventHolder__ctor_m2004627747(L_0, /*hidden argument*/NULL);
		__this->set_resolve_event_holder_1(L_0);
		return;
	}
}
// System.String System.Reflection.Assembly::get_code_base(System.Boolean)
extern "C"  String_t* Assembly_get_code_base_m3637877060 (Assembly_t4268412390 * __this, bool ___escaped0, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef String_t* (*Assembly_get_code_base_m3637877060_ftn) (Assembly_t4268412390 *, bool);
	return  ((Assembly_get_code_base_m3637877060_ftn)mscorlib::System::Reflection::Assembly::get_code_base) (__this, ___escaped0);
}
// System.String System.Reflection.Assembly::get_fullname()
extern "C"  String_t* Assembly_get_fullname_m3149819070 (Assembly_t4268412390 * __this, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef String_t* (*Assembly_get_fullname_m3149819070_ftn) (Assembly_t4268412390 *);
	return  ((Assembly_get_fullname_m3149819070_ftn)mscorlib::System::Reflection::Assembly::get_fullname) (__this);
}
// System.String System.Reflection.Assembly::get_location()
extern "C"  String_t* Assembly_get_location_m2976332497 (Assembly_t4268412390 * __this, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef String_t* (*Assembly_get_location_m2976332497_ftn) (Assembly_t4268412390 *);
	return  ((Assembly_get_location_m2976332497_ftn)mscorlib::System::Reflection::Assembly::get_location) (__this);
}
// System.String System.Reflection.Assembly::GetCodeBase(System.Boolean)
extern "C"  String_t* Assembly_GetCodeBase_m2735209720 (Assembly_t4268412390 * __this, bool ___escaped0, const MethodInfo* method)
{
	String_t* V_0 = NULL;
	{
		bool L_0 = ___escaped0;
		String_t* L_1 = Assembly_get_code_base_m3637877060(__this, L_0, /*hidden argument*/NULL);
		V_0 = L_1;
		String_t* L_2 = V_0;
		return L_2;
	}
}
// System.String System.Reflection.Assembly::get_FullName()
extern "C"  String_t* Assembly_get_FullName_m1064037566 (Assembly_t4268412390 * __this, const MethodInfo* method)
{
	{
		String_t* L_0 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Reflection.Assembly::ToString() */, __this);
		return L_0;
	}
}
// System.String System.Reflection.Assembly::get_Location()
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern const uint32_t Assembly_get_Location_m3981013809_MetadataUsageId;
extern "C"  String_t* Assembly_get_Location_m3981013809 (Assembly_t4268412390 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Assembly_get_Location_m3981013809_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	String_t* V_0 = NULL;
	{
		bool L_0 = __this->get_fromByteArray_8();
		if (!L_0)
		{
			goto IL_0011;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_1 = ((String_t_StaticFields*)String_t_il2cpp_TypeInfo_var->static_fields)->get_Empty_2();
		return L_1;
	}

IL_0011:
	{
		String_t* L_2 = Assembly_get_location_m2976332497(__this, /*hidden argument*/NULL);
		V_0 = L_2;
		String_t* L_3 = V_0;
		return L_3;
	}
}
// System.Boolean System.Reflection.Assembly::IsDefined(System.Type,System.Boolean)
extern Il2CppClass* MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var;
extern const uint32_t Assembly_IsDefined_m2841897391_MetadataUsageId;
extern "C"  bool Assembly_IsDefined_m2841897391 (Assembly_t4268412390 * __this, Type_t * ___attributeType0, bool ___inherit1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Assembly_IsDefined_m2841897391_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Type_t * L_0 = ___attributeType0;
		bool L_1 = ___inherit1;
		IL2CPP_RUNTIME_CLASS_INIT(MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var);
		bool L_2 = MonoCustomAttrs_IsDefined_m3820363041(NULL /*static, unused*/, __this, L_0, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.Object[] System.Reflection.Assembly::GetCustomAttributes(System.Type,System.Boolean)
extern Il2CppClass* MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var;
extern const uint32_t Assembly_GetCustomAttributes_m95309865_MetadataUsageId;
extern "C"  ObjectU5BU5D_t3614634134* Assembly_GetCustomAttributes_m95309865 (Assembly_t4268412390 * __this, Type_t * ___attributeType0, bool ___inherit1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Assembly_GetCustomAttributes_m95309865_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Type_t * L_0 = ___attributeType0;
		bool L_1 = ___inherit1;
		IL2CPP_RUNTIME_CLASS_INIT(MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var);
		ObjectU5BU5D_t3614634134* L_2 = MonoCustomAttrs_GetCustomAttributes_m939426263(NULL /*static, unused*/, __this, L_0, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.IntPtr System.Reflection.Assembly::GetManifestResourceInternal(System.String,System.Int32&,System.Reflection.Module&)
extern "C"  IntPtr_t Assembly_GetManifestResourceInternal_m2581727816 (Assembly_t4268412390 * __this, String_t* ___name0, int32_t* ___size1, Module_t4282841206 ** ___module2, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef IntPtr_t (*Assembly_GetManifestResourceInternal_m2581727816_ftn) (Assembly_t4268412390 *, String_t*, int32_t*, Module_t4282841206 **);
	return  ((Assembly_GetManifestResourceInternal_m2581727816_ftn)mscorlib::System::Reflection::Assembly::GetManifestResourceInternal) (__this, ___name0, ___size1, ___module2);
}
// System.Type[] System.Reflection.Assembly::GetTypes(System.Boolean)
extern "C"  TypeU5BU5D_t1664964607* Assembly_GetTypes_m1317253146 (Assembly_t4268412390 * __this, bool ___exportedOnly0, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef TypeU5BU5D_t1664964607* (*Assembly_GetTypes_m1317253146_ftn) (Assembly_t4268412390 *, bool);
	return  ((Assembly_GetTypes_m1317253146_ftn)mscorlib::System::Reflection::Assembly::GetTypes) (__this, ___exportedOnly0);
}
// System.Type[] System.Reflection.Assembly::GetTypes()
extern "C"  TypeU5BU5D_t1664964607* Assembly_GetTypes_m382057419 (Assembly_t4268412390 * __this, const MethodInfo* method)
{
	{
		TypeU5BU5D_t1664964607* L_0 = VirtFuncInvoker1< TypeU5BU5D_t1664964607*, bool >::Invoke(10 /* System.Type[] System.Reflection.Assembly::GetTypes(System.Boolean) */, __this, (bool)0);
		return L_0;
	}
}
// System.Type System.Reflection.Assembly::GetType(System.String,System.Boolean)
extern "C"  Type_t * Assembly_GetType_m2805031155 (Assembly_t4268412390 * __this, String_t* ___name0, bool ___throwOnError1, const MethodInfo* method)
{
	{
		String_t* L_0 = ___name0;
		bool L_1 = ___throwOnError1;
		Type_t * L_2 = Assembly_GetType_m2765594712(__this, L_0, L_1, (bool)0, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.Type System.Reflection.Assembly::GetType(System.String)
extern "C"  Type_t * Assembly_GetType_m2378249586 (Assembly_t4268412390 * __this, String_t* ___name0, const MethodInfo* method)
{
	{
		String_t* L_0 = ___name0;
		Type_t * L_1 = Assembly_GetType_m2765594712(__this, L_0, (bool)0, (bool)0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Type System.Reflection.Assembly::InternalGetType(System.Reflection.Module,System.String,System.Boolean,System.Boolean)
extern "C"  Type_t * Assembly_InternalGetType_m1990879055 (Assembly_t4268412390 * __this, Module_t4282841206 * ___module0, String_t* ___name1, bool ___throwOnError2, bool ___ignoreCase3, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef Type_t * (*Assembly_InternalGetType_m1990879055_ftn) (Assembly_t4268412390 *, Module_t4282841206 *, String_t*, bool, bool);
	return  ((Assembly_InternalGetType_m1990879055_ftn)mscorlib::System::Reflection::Assembly::InternalGetType) (__this, ___module0, ___name1, ___throwOnError2, ___ignoreCase3);
}
// System.Type System.Reflection.Assembly::GetType(System.String,System.Boolean,System.Boolean)
extern Il2CppClass* ArgumentNullException_t628810857_il2cpp_TypeInfo_var;
extern Il2CppClass* ArgumentException_t3259014390_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral2328218955;
extern Il2CppCodeGenString* _stringLiteral345660856;
extern const uint32_t Assembly_GetType_m2765594712_MetadataUsageId;
extern "C"  Type_t * Assembly_GetType_m2765594712 (Assembly_t4268412390 * __this, String_t* ___name0, bool ___throwOnError1, bool ___ignoreCase2, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Assembly_GetType_m2765594712_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		String_t* L_0 = ___name0;
		if (L_0)
		{
			goto IL_000d;
		}
	}
	{
		String_t* L_1 = ___name0;
		ArgumentNullException_t628810857 * L_2 = (ArgumentNullException_t628810857 *)il2cpp_codegen_object_new(ArgumentNullException_t628810857_il2cpp_TypeInfo_var);
		ArgumentNullException__ctor_m3380712306(L_2, L_1, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_2);
	}

IL_000d:
	{
		String_t* L_3 = ___name0;
		NullCheck(L_3);
		int32_t L_4 = String_get_Length_m1606060069(L_3, /*hidden argument*/NULL);
		if (L_4)
		{
			goto IL_0028;
		}
	}
	{
		ArgumentException_t3259014390 * L_5 = (ArgumentException_t3259014390 *)il2cpp_codegen_object_new(ArgumentException_t3259014390_il2cpp_TypeInfo_var);
		ArgumentException__ctor_m544251339(L_5, _stringLiteral2328218955, _stringLiteral345660856, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_5);
	}

IL_0028:
	{
		String_t* L_6 = ___name0;
		bool L_7 = ___throwOnError1;
		bool L_8 = ___ignoreCase2;
		Type_t * L_9 = Assembly_InternalGetType_m1990879055(__this, (Module_t4282841206 *)NULL, L_6, L_7, L_8, /*hidden argument*/NULL);
		return L_9;
	}
}
// System.Void System.Reflection.Assembly::FillName(System.Reflection.Assembly,System.Reflection.AssemblyName)
extern "C"  void Assembly_FillName_m1934025015 (Il2CppObject * __this /* static, unused */, Assembly_t4268412390 * ___ass0, AssemblyName_t894705941 * ___aname1, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef void (*Assembly_FillName_m1934025015_ftn) (Assembly_t4268412390 *, AssemblyName_t894705941 *);
	 ((Assembly_FillName_m1934025015_ftn)mscorlib::System::Reflection::Assembly::FillName) (___ass0, ___aname1);
}
// System.Reflection.AssemblyName System.Reflection.Assembly::GetName(System.Boolean)
extern Il2CppClass* SecurityManager_t3191249573_il2cpp_TypeInfo_var;
extern const uint32_t Assembly_GetName_m3984565618_MetadataUsageId;
extern "C"  AssemblyName_t894705941 * Assembly_GetName_m3984565618 (Assembly_t4268412390 * __this, bool ___copiedName0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Assembly_GetName_m3984565618_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(SecurityManager_t3191249573_il2cpp_TypeInfo_var);
		bool L_0 = SecurityManager_get_SecurityEnabled_m51574294(NULL /*static, unused*/, /*hidden argument*/NULL);
		if (!L_0)
		{
			goto IL_0012;
		}
	}
	{
		Assembly_GetCodeBase_m2735209720(__this, (bool)1, /*hidden argument*/NULL);
	}

IL_0012:
	{
		AssemblyName_t894705941 * L_1 = VirtFuncInvoker0< AssemblyName_t894705941 * >::Invoke(17 /* System.Reflection.AssemblyName System.Reflection.Assembly::UnprotectedGetName() */, __this);
		return L_1;
	}
}
// System.Reflection.AssemblyName System.Reflection.Assembly::GetName()
extern "C"  AssemblyName_t894705941 * Assembly_GetName_m790410837 (Assembly_t4268412390 * __this, const MethodInfo* method)
{
	{
		AssemblyName_t894705941 * L_0 = VirtFuncInvoker1< AssemblyName_t894705941 *, bool >::Invoke(15 /* System.Reflection.AssemblyName System.Reflection.Assembly::GetName(System.Boolean) */, __this, (bool)0);
		return L_0;
	}
}
// System.Reflection.AssemblyName System.Reflection.Assembly::UnprotectedGetName()
extern Il2CppClass* AssemblyName_t894705941_il2cpp_TypeInfo_var;
extern const uint32_t Assembly_UnprotectedGetName_m3014607408_MetadataUsageId;
extern "C"  AssemblyName_t894705941 * Assembly_UnprotectedGetName_m3014607408 (Assembly_t4268412390 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Assembly_UnprotectedGetName_m3014607408_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	AssemblyName_t894705941 * V_0 = NULL;
	{
		AssemblyName_t894705941 * L_0 = (AssemblyName_t894705941 *)il2cpp_codegen_object_new(AssemblyName_t894705941_il2cpp_TypeInfo_var);
		AssemblyName__ctor_m2505746587(L_0, /*hidden argument*/NULL);
		V_0 = L_0;
		AssemblyName_t894705941 * L_1 = V_0;
		Assembly_FillName_m1934025015(NULL /*static, unused*/, __this, L_1, /*hidden argument*/NULL);
		AssemblyName_t894705941 * L_2 = V_0;
		return L_2;
	}
}
// System.String System.Reflection.Assembly::ToString()
extern "C"  String_t* Assembly_ToString_m3970658759 (Assembly_t4268412390 * __this, const MethodInfo* method)
{
	{
		String_t* L_0 = __this->get_assemblyName_9();
		if (!L_0)
		{
			goto IL_0012;
		}
	}
	{
		String_t* L_1 = __this->get_assemblyName_9();
		return L_1;
	}

IL_0012:
	{
		String_t* L_2 = Assembly_get_fullname_m3149819070(__this, /*hidden argument*/NULL);
		__this->set_assemblyName_9(L_2);
		String_t* L_3 = __this->get_assemblyName_9();
		return L_3;
	}
}
// System.Reflection.Assembly System.Reflection.Assembly::Load(System.String)
extern "C"  Assembly_t4268412390 * Assembly_Load_m902205655 (Il2CppObject * __this /* static, unused */, String_t* ___assemblyString0, const MethodInfo* method)
{
	{
		AppDomain_t2719102437 * L_0 = AppDomain_get_CurrentDomain_m3432767403(NULL /*static, unused*/, /*hidden argument*/NULL);
		String_t* L_1 = ___assemblyString0;
		NullCheck(L_0);
		Assembly_t4268412390 * L_2 = AppDomain_Load_m3276140461(L_0, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.Reflection.Module System.Reflection.Assembly::GetModule(System.String)
extern Il2CppClass* ArgumentNullException_t628810857_il2cpp_TypeInfo_var;
extern Il2CppClass* ArgumentException_t3259014390_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral2328218955;
extern Il2CppCodeGenString* _stringLiteral3246678936;
extern const uint32_t Assembly_GetModule_m2064378601_MetadataUsageId;
extern "C"  Module_t4282841206 * Assembly_GetModule_m2064378601 (Assembly_t4268412390 * __this, String_t* ___name0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Assembly_GetModule_m2064378601_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ModuleU5BU5D_t3593287923* V_0 = NULL;
	Module_t4282841206 * V_1 = NULL;
	ModuleU5BU5D_t3593287923* V_2 = NULL;
	int32_t V_3 = 0;
	{
		String_t* L_0 = ___name0;
		if (L_0)
		{
			goto IL_0011;
		}
	}
	{
		ArgumentNullException_t628810857 * L_1 = (ArgumentNullException_t628810857 *)il2cpp_codegen_object_new(ArgumentNullException_t628810857_il2cpp_TypeInfo_var);
		ArgumentNullException__ctor_m3380712306(L_1, _stringLiteral2328218955, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_1);
	}

IL_0011:
	{
		String_t* L_2 = ___name0;
		NullCheck(L_2);
		int32_t L_3 = String_get_Length_m1606060069(L_2, /*hidden argument*/NULL);
		if (L_3)
		{
			goto IL_0027;
		}
	}
	{
		ArgumentException_t3259014390 * L_4 = (ArgumentException_t3259014390 *)il2cpp_codegen_object_new(ArgumentException_t3259014390_il2cpp_TypeInfo_var);
		ArgumentException__ctor_m3739475201(L_4, _stringLiteral3246678936, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_4);
	}

IL_0027:
	{
		ModuleU5BU5D_t3593287923* L_5 = Assembly_GetModules_m2242070953(__this, (bool)1, /*hidden argument*/NULL);
		V_0 = L_5;
		ModuleU5BU5D_t3593287923* L_6 = V_0;
		V_2 = L_6;
		V_3 = 0;
		goto IL_0053;
	}

IL_0038:
	{
		ModuleU5BU5D_t3593287923* L_7 = V_2;
		int32_t L_8 = V_3;
		NullCheck(L_7);
		int32_t L_9 = L_8;
		Module_t4282841206 * L_10 = (L_7)->GetAt(static_cast<il2cpp_array_size_t>(L_9));
		V_1 = L_10;
		Module_t4282841206 * L_11 = V_1;
		NullCheck(L_11);
		String_t* L_12 = Module_get_ScopeName_m207704721(L_11, /*hidden argument*/NULL);
		String_t* L_13 = ___name0;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_14 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_12, L_13, /*hidden argument*/NULL);
		if (!L_14)
		{
			goto IL_004f;
		}
	}
	{
		Module_t4282841206 * L_15 = V_1;
		return L_15;
	}

IL_004f:
	{
		int32_t L_16 = V_3;
		V_3 = ((int32_t)((int32_t)L_16+(int32_t)1));
	}

IL_0053:
	{
		int32_t L_17 = V_3;
		ModuleU5BU5D_t3593287923* L_18 = V_2;
		NullCheck(L_18);
		if ((((int32_t)L_17) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_18)->max_length)))))))
		{
			goto IL_0038;
		}
	}
	{
		return (Module_t4282841206 *)NULL;
	}
}
// System.Reflection.Module[] System.Reflection.Assembly::GetModulesInternal()
extern "C"  ModuleU5BU5D_t3593287923* Assembly_GetModulesInternal_m666827793 (Assembly_t4268412390 * __this, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef ModuleU5BU5D_t3593287923* (*Assembly_GetModulesInternal_m666827793_ftn) (Assembly_t4268412390 *);
	return  ((Assembly_GetModulesInternal_m666827793_ftn)mscorlib::System::Reflection::Assembly::GetModulesInternal) (__this);
}
// System.Reflection.Module[] System.Reflection.Assembly::GetModules(System.Boolean)
extern const Il2CppType* Module_t4282841206_0_0_0_var;
extern Il2CppClass* ArrayList_t4252133567_il2cpp_TypeInfo_var;
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern Il2CppClass* ModuleU5BU5D_t3593287923_il2cpp_TypeInfo_var;
extern const uint32_t Assembly_GetModules_m2242070953_MetadataUsageId;
extern "C"  ModuleU5BU5D_t3593287923* Assembly_GetModules_m2242070953 (Assembly_t4268412390 * __this, bool ___getResourceModules0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Assembly_GetModules_m2242070953_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ModuleU5BU5D_t3593287923* V_0 = NULL;
	ArrayList_t4252133567 * V_1 = NULL;
	Module_t4282841206 * V_2 = NULL;
	ModuleU5BU5D_t3593287923* V_3 = NULL;
	int32_t V_4 = 0;
	{
		ModuleU5BU5D_t3593287923* L_0 = VirtFuncInvoker0< ModuleU5BU5D_t3593287923* >::Invoke(19 /* System.Reflection.Module[] System.Reflection.Assembly::GetModulesInternal() */, __this);
		V_0 = L_0;
		bool L_1 = ___getResourceModules0;
		if (L_1)
		{
			goto IL_005e;
		}
	}
	{
		ModuleU5BU5D_t3593287923* L_2 = V_0;
		NullCheck(L_2);
		ArrayList_t4252133567 * L_3 = (ArrayList_t4252133567 *)il2cpp_codegen_object_new(ArrayList_t4252133567_il2cpp_TypeInfo_var);
		ArrayList__ctor_m1467563650(L_3, (((int32_t)((int32_t)(((Il2CppArray *)L_2)->max_length)))), /*hidden argument*/NULL);
		V_1 = L_3;
		ModuleU5BU5D_t3593287923* L_4 = V_0;
		V_3 = L_4;
		V_4 = 0;
		goto IL_003e;
	}

IL_0020:
	{
		ModuleU5BU5D_t3593287923* L_5 = V_3;
		int32_t L_6 = V_4;
		NullCheck(L_5);
		int32_t L_7 = L_6;
		Module_t4282841206 * L_8 = (L_5)->GetAt(static_cast<il2cpp_array_size_t>(L_7));
		V_2 = L_8;
		Module_t4282841206 * L_9 = V_2;
		NullCheck(L_9);
		bool L_10 = Module_IsResource_m663979284(L_9, /*hidden argument*/NULL);
		if (L_10)
		{
			goto IL_0038;
		}
	}
	{
		ArrayList_t4252133567 * L_11 = V_1;
		Module_t4282841206 * L_12 = V_2;
		NullCheck(L_11);
		VirtFuncInvoker1< int32_t, Il2CppObject * >::Invoke(30 /* System.Int32 System.Collections.ArrayList::Add(System.Object) */, L_11, L_12);
	}

IL_0038:
	{
		int32_t L_13 = V_4;
		V_4 = ((int32_t)((int32_t)L_13+(int32_t)1));
	}

IL_003e:
	{
		int32_t L_14 = V_4;
		ModuleU5BU5D_t3593287923* L_15 = V_3;
		NullCheck(L_15);
		if ((((int32_t)L_14) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_15)->max_length)))))))
		{
			goto IL_0020;
		}
	}
	{
		ArrayList_t4252133567 * L_16 = V_1;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_17 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Module_t4282841206_0_0_0_var), /*hidden argument*/NULL);
		NullCheck(L_16);
		Il2CppArray * L_18 = VirtFuncInvoker1< Il2CppArray *, Type_t * >::Invoke(48 /* System.Array System.Collections.ArrayList::ToArray(System.Type) */, L_16, L_17);
		return ((ModuleU5BU5D_t3593287923*)Castclass(L_18, ModuleU5BU5D_t3593287923_il2cpp_TypeInfo_var));
	}

IL_005e:
	{
		ModuleU5BU5D_t3593287923* L_19 = V_0;
		return L_19;
	}
}
// System.Reflection.Assembly System.Reflection.Assembly::GetExecutingAssembly()
extern "C"  Assembly_t4268412390 * Assembly_GetExecutingAssembly_m776016337 (Il2CppObject * __this /* static, unused */, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef Assembly_t4268412390 * (*Assembly_GetExecutingAssembly_m776016337_ftn) ();
	return  ((Assembly_GetExecutingAssembly_m776016337_ftn)mscorlib::System::Reflection::Assembly::GetExecutingAssembly) ();
}
// System.Void System.Reflection.Assembly/ResolveEventHolder::.ctor()
extern "C"  void ResolveEventHolder__ctor_m2004627747 (ResolveEventHolder_t1761494505 * __this, const MethodInfo* method)
{
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Reflection.AssemblyCompanyAttribute::.ctor(System.String)
extern "C"  void AssemblyCompanyAttribute__ctor_m1217508649 (AssemblyCompanyAttribute_t2851673381 * __this, String_t* ___company0, const MethodInfo* method)
{
	{
		Attribute__ctor_m1730479323(__this, /*hidden argument*/NULL);
		String_t* L_0 = ___company0;
		__this->set_name_0(L_0);
		return;
	}
}
// System.Void System.Reflection.AssemblyConfigurationAttribute::.ctor(System.String)
extern "C"  void AssemblyConfigurationAttribute__ctor_m2611941870 (AssemblyConfigurationAttribute_t1678917172 * __this, String_t* ___configuration0, const MethodInfo* method)
{
	{
		Attribute__ctor_m1730479323(__this, /*hidden argument*/NULL);
		String_t* L_0 = ___configuration0;
		__this->set_name_0(L_0);
		return;
	}
}
// System.Void System.Reflection.AssemblyCopyrightAttribute::.ctor(System.String)
extern "C"  void AssemblyCopyrightAttribute__ctor_m2712202383 (AssemblyCopyrightAttribute_t177123295 * __this, String_t* ___copyright0, const MethodInfo* method)
{
	{
		Attribute__ctor_m1730479323(__this, /*hidden argument*/NULL);
		String_t* L_0 = ___copyright0;
		__this->set_name_0(L_0);
		return;
	}
}
// System.Void System.Reflection.AssemblyDefaultAliasAttribute::.ctor(System.String)
extern "C"  void AssemblyDefaultAliasAttribute__ctor_m746891723 (AssemblyDefaultAliasAttribute_t1774139159 * __this, String_t* ___defaultAlias0, const MethodInfo* method)
{
	{
		Attribute__ctor_m1730479323(__this, /*hidden argument*/NULL);
		String_t* L_0 = ___defaultAlias0;
		__this->set_name_0(L_0);
		return;
	}
}
// System.Void System.Reflection.AssemblyDelaySignAttribute::.ctor(System.Boolean)
extern "C"  void AssemblyDelaySignAttribute__ctor_m793760213 (AssemblyDelaySignAttribute_t2705758496 * __this, bool ___delaySign0, const MethodInfo* method)
{
	{
		Attribute__ctor_m1730479323(__this, /*hidden argument*/NULL);
		bool L_0 = ___delaySign0;
		__this->set_delay_0(L_0);
		return;
	}
}
// System.Void System.Reflection.AssemblyDescriptionAttribute::.ctor(System.String)
extern "C"  void AssemblyDescriptionAttribute__ctor_m3307088082 (AssemblyDescriptionAttribute_t1018387888 * __this, String_t* ___description0, const MethodInfo* method)
{
	{
		Attribute__ctor_m1730479323(__this, /*hidden argument*/NULL);
		String_t* L_0 = ___description0;
		__this->set_name_0(L_0);
		return;
	}
}
// System.Void System.Reflection.AssemblyFileVersionAttribute::.ctor(System.String)
extern Il2CppClass* ArgumentNullException_t628810857_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral3617362;
extern const uint32_t AssemblyFileVersionAttribute__ctor_m2026149866_MetadataUsageId;
extern "C"  void AssemblyFileVersionAttribute__ctor_m2026149866 (AssemblyFileVersionAttribute_t2897687916 * __this, String_t* ___version0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AssemblyFileVersionAttribute__ctor_m2026149866_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Attribute__ctor_m1730479323(__this, /*hidden argument*/NULL);
		String_t* L_0 = ___version0;
		if (L_0)
		{
			goto IL_0017;
		}
	}
	{
		ArgumentNullException_t628810857 * L_1 = (ArgumentNullException_t628810857 *)il2cpp_codegen_object_new(ArgumentNullException_t628810857_il2cpp_TypeInfo_var);
		ArgumentNullException__ctor_m3380712306(L_1, _stringLiteral3617362, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_1);
	}

IL_0017:
	{
		String_t* L_2 = ___version0;
		__this->set_name_0(L_2);
		return;
	}
}
// System.Void System.Reflection.AssemblyInformationalVersionAttribute::.ctor(System.String)
extern "C"  void AssemblyInformationalVersionAttribute__ctor_m376831533 (AssemblyInformationalVersionAttribute_t3037389657 * __this, String_t* ___informationalVersion0, const MethodInfo* method)
{
	{
		Attribute__ctor_m1730479323(__this, /*hidden argument*/NULL);
		String_t* L_0 = ___informationalVersion0;
		__this->set_name_0(L_0);
		return;
	}
}
// System.Void System.Reflection.AssemblyKeyFileAttribute::.ctor(System.String)
extern "C"  void AssemblyKeyFileAttribute__ctor_m1072556611 (AssemblyKeyFileAttribute_t605245443 * __this, String_t* ___keyFile0, const MethodInfo* method)
{
	{
		Attribute__ctor_m1730479323(__this, /*hidden argument*/NULL);
		String_t* L_0 = ___keyFile0;
		__this->set_name_0(L_0);
		return;
	}
}
// System.Void System.Reflection.AssemblyName::.ctor()
extern "C"  void AssemblyName__ctor_m2505746587 (AssemblyName_t894705941 * __this, const MethodInfo* method)
{
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		__this->set_versioncompat_12(1);
		return;
	}
}
// System.Void System.Reflection.AssemblyName::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern const Il2CppType* Version_t1755874712_0_0_0_var;
extern const Il2CppType* ByteU5BU5D_t3397334013_0_0_0_var;
extern const Il2CppType* AssemblyHashAlgorithm_t4147282775_0_0_0_var;
extern const Il2CppType* StrongNameKeyPair_t4090869089_0_0_0_var;
extern const Il2CppType* AssemblyVersionCompatibility_t1223556284_0_0_0_var;
extern const Il2CppType* AssemblyNameFlags_t1794031440_0_0_0_var;
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern Il2CppClass* Version_t1755874712_il2cpp_TypeInfo_var;
extern Il2CppClass* ByteU5BU5D_t3397334013_il2cpp_TypeInfo_var;
extern Il2CppClass* Int32_t2071877448_il2cpp_TypeInfo_var;
extern Il2CppClass* StrongNameKeyPair_t4090869089_il2cpp_TypeInfo_var;
extern Il2CppClass* CultureInfo_t3500843524_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral594030812;
extern Il2CppCodeGenString* _stringLiteral1952199827;
extern Il2CppCodeGenString* _stringLiteral1734555969;
extern Il2CppCodeGenString* _stringLiteral2167127169;
extern Il2CppCodeGenString* _stringLiteral2837183762;
extern Il2CppCodeGenString* _stringLiteral3684797936;
extern Il2CppCodeGenString* _stringLiteral2448232678;
extern Il2CppCodeGenString* _stringLiteral1836058351;
extern Il2CppCodeGenString* _stringLiteral180760614;
extern Il2CppCodeGenString* _stringLiteral3706305741;
extern const uint32_t AssemblyName__ctor_m609734316_MetadataUsageId;
extern "C"  void AssemblyName__ctor_m609734316 (AssemblyName_t894705941 * __this, SerializationInfo_t228987430 * ___si0, StreamingContext_t1417235061  ___sc1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AssemblyName__ctor_m609734316_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		SerializationInfo_t228987430 * L_0 = ___si0;
		NullCheck(L_0);
		String_t* L_1 = SerializationInfo_GetString_m547109409(L_0, _stringLiteral594030812, /*hidden argument*/NULL);
		__this->set_name_0(L_1);
		SerializationInfo_t228987430 * L_2 = ___si0;
		NullCheck(L_2);
		String_t* L_3 = SerializationInfo_GetString_m547109409(L_2, _stringLiteral1952199827, /*hidden argument*/NULL);
		__this->set_codebase_1(L_3);
		SerializationInfo_t228987430 * L_4 = ___si0;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_5 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Version_t1755874712_0_0_0_var), /*hidden argument*/NULL);
		NullCheck(L_4);
		Il2CppObject * L_6 = SerializationInfo_GetValue_m1127314592(L_4, _stringLiteral1734555969, L_5, /*hidden argument*/NULL);
		__this->set_version_13(((Version_t1755874712 *)CastclassSealed(L_6, Version_t1755874712_il2cpp_TypeInfo_var)));
		SerializationInfo_t228987430 * L_7 = ___si0;
		Type_t * L_8 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(ByteU5BU5D_t3397334013_0_0_0_var), /*hidden argument*/NULL);
		NullCheck(L_7);
		Il2CppObject * L_9 = SerializationInfo_GetValue_m1127314592(L_7, _stringLiteral2167127169, L_8, /*hidden argument*/NULL);
		__this->set_publicKey_10(((ByteU5BU5D_t3397334013*)Castclass(L_9, ByteU5BU5D_t3397334013_il2cpp_TypeInfo_var)));
		SerializationInfo_t228987430 * L_10 = ___si0;
		Type_t * L_11 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(ByteU5BU5D_t3397334013_0_0_0_var), /*hidden argument*/NULL);
		NullCheck(L_10);
		Il2CppObject * L_12 = SerializationInfo_GetValue_m1127314592(L_10, _stringLiteral2837183762, L_11, /*hidden argument*/NULL);
		__this->set_keyToken_11(((ByteU5BU5D_t3397334013*)Castclass(L_12, ByteU5BU5D_t3397334013_il2cpp_TypeInfo_var)));
		SerializationInfo_t228987430 * L_13 = ___si0;
		Type_t * L_14 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(AssemblyHashAlgorithm_t4147282775_0_0_0_var), /*hidden argument*/NULL);
		NullCheck(L_13);
		Il2CppObject * L_15 = SerializationInfo_GetValue_m1127314592(L_13, _stringLiteral3684797936, L_14, /*hidden argument*/NULL);
		__this->set_hashalg_8(((*(int32_t*)((int32_t*)UnBox (L_15, Int32_t2071877448_il2cpp_TypeInfo_var)))));
		SerializationInfo_t228987430 * L_16 = ___si0;
		Type_t * L_17 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(StrongNameKeyPair_t4090869089_0_0_0_var), /*hidden argument*/NULL);
		NullCheck(L_16);
		Il2CppObject * L_18 = SerializationInfo_GetValue_m1127314592(L_16, _stringLiteral2448232678, L_17, /*hidden argument*/NULL);
		__this->set_keypair_9(((StrongNameKeyPair_t4090869089 *)CastclassClass(L_18, StrongNameKeyPair_t4090869089_il2cpp_TypeInfo_var)));
		SerializationInfo_t228987430 * L_19 = ___si0;
		Type_t * L_20 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(AssemblyVersionCompatibility_t1223556284_0_0_0_var), /*hidden argument*/NULL);
		NullCheck(L_19);
		Il2CppObject * L_21 = SerializationInfo_GetValue_m1127314592(L_19, _stringLiteral1836058351, L_20, /*hidden argument*/NULL);
		__this->set_versioncompat_12(((*(int32_t*)((int32_t*)UnBox (L_21, Int32_t2071877448_il2cpp_TypeInfo_var)))));
		SerializationInfo_t228987430 * L_22 = ___si0;
		Type_t * L_23 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(AssemblyNameFlags_t1794031440_0_0_0_var), /*hidden argument*/NULL);
		NullCheck(L_22);
		Il2CppObject * L_24 = SerializationInfo_GetValue_m1127314592(L_22, _stringLiteral180760614, L_23, /*hidden argument*/NULL);
		__this->set_flags_7(((*(int32_t*)((int32_t*)UnBox (L_24, Int32_t2071877448_il2cpp_TypeInfo_var)))));
		SerializationInfo_t228987430 * L_25 = ___si0;
		NullCheck(L_25);
		int32_t L_26 = SerializationInfo_GetInt32_m4039439501(L_25, _stringLiteral3706305741, /*hidden argument*/NULL);
		V_0 = L_26;
		int32_t L_27 = V_0;
		if ((((int32_t)L_27) == ((int32_t)(-1))))
		{
			goto IL_0127;
		}
	}
	{
		int32_t L_28 = V_0;
		CultureInfo_t3500843524 * L_29 = (CultureInfo_t3500843524 *)il2cpp_codegen_object_new(CultureInfo_t3500843524_il2cpp_TypeInfo_var);
		CultureInfo__ctor_m3417484387(L_29, L_28, /*hidden argument*/NULL);
		__this->set_cultureinfo_6(L_29);
	}

IL_0127:
	{
		return;
	}
}
// System.String System.Reflection.AssemblyName::get_Name()
extern "C"  String_t* AssemblyName_get_Name_m1815759940 (AssemblyName_t894705941 * __this, const MethodInfo* method)
{
	{
		String_t* L_0 = __this->get_name_0();
		return L_0;
	}
}
// System.Reflection.AssemblyNameFlags System.Reflection.AssemblyName::get_Flags()
extern "C"  int32_t AssemblyName_get_Flags_m1290091392 (AssemblyName_t894705941 * __this, const MethodInfo* method)
{
	{
		int32_t L_0 = __this->get_flags_7();
		return L_0;
	}
}
// System.String System.Reflection.AssemblyName::get_FullName()
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* StringBuilder_t1221177846_il2cpp_TypeInfo_var;
extern Il2CppClass* CultureInfo_t3500843524_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral3774245231;
extern Il2CppCodeGenString* _stringLiteral1256080173;
extern Il2CppCodeGenString* _stringLiteral3350611209;
extern Il2CppCodeGenString* _stringLiteral3574561019;
extern Il2CppCodeGenString* _stringLiteral1653664622;
extern Il2CppCodeGenString* _stringLiteral3231012720;
extern Il2CppCodeGenString* _stringLiteral130462888;
extern const uint32_t AssemblyName_get_FullName_m1606421515_MetadataUsageId;
extern "C"  String_t* AssemblyName_get_FullName_m1606421515 (AssemblyName_t894705941 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AssemblyName_get_FullName_m1606421515_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	StringBuilder_t1221177846 * V_0 = NULL;
	ByteU5BU5D_t3397334013* V_1 = NULL;
	int32_t V_2 = 0;
	{
		String_t* L_0 = __this->get_name_0();
		if (L_0)
		{
			goto IL_0011;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_1 = ((String_t_StaticFields*)String_t_il2cpp_TypeInfo_var->static_fields)->get_Empty_2();
		return L_1;
	}

IL_0011:
	{
		StringBuilder_t1221177846 * L_2 = (StringBuilder_t1221177846 *)il2cpp_codegen_object_new(StringBuilder_t1221177846_il2cpp_TypeInfo_var);
		StringBuilder__ctor_m3946851802(L_2, /*hidden argument*/NULL);
		V_0 = L_2;
		StringBuilder_t1221177846 * L_3 = V_0;
		String_t* L_4 = __this->get_name_0();
		NullCheck(L_3);
		StringBuilder_Append_m3636508479(L_3, L_4, /*hidden argument*/NULL);
		Version_t1755874712 * L_5 = AssemblyName_get_Version_m3495645648(__this, /*hidden argument*/NULL);
		bool L_6 = Version_op_Inequality_m828629926(NULL /*static, unused*/, L_5, (Version_t1755874712 *)NULL, /*hidden argument*/NULL);
		if (!L_6)
		{
			goto IL_0053;
		}
	}
	{
		StringBuilder_t1221177846 * L_7 = V_0;
		NullCheck(L_7);
		StringBuilder_Append_m3636508479(L_7, _stringLiteral3774245231, /*hidden argument*/NULL);
		StringBuilder_t1221177846 * L_8 = V_0;
		Version_t1755874712 * L_9 = AssemblyName_get_Version_m3495645648(__this, /*hidden argument*/NULL);
		NullCheck(L_9);
		String_t* L_10 = Version_ToString_m18049552(L_9, /*hidden argument*/NULL);
		NullCheck(L_8);
		StringBuilder_Append_m3636508479(L_8, L_10, /*hidden argument*/NULL);
	}

IL_0053:
	{
		CultureInfo_t3500843524 * L_11 = __this->get_cultureinfo_6();
		if (!L_11)
		{
			goto IL_00a7;
		}
	}
	{
		StringBuilder_t1221177846 * L_12 = V_0;
		NullCheck(L_12);
		StringBuilder_Append_m3636508479(L_12, _stringLiteral1256080173, /*hidden argument*/NULL);
		CultureInfo_t3500843524 * L_13 = __this->get_cultureinfo_6();
		NullCheck(L_13);
		int32_t L_14 = VirtFuncInvoker0< int32_t >::Invoke(6 /* System.Int32 System.Globalization.CultureInfo::get_LCID() */, L_13);
		IL2CPP_RUNTIME_CLASS_INIT(CultureInfo_t3500843524_il2cpp_TypeInfo_var);
		CultureInfo_t3500843524 * L_15 = CultureInfo_get_InvariantCulture_m398972276(NULL /*static, unused*/, /*hidden argument*/NULL);
		NullCheck(L_15);
		int32_t L_16 = VirtFuncInvoker0< int32_t >::Invoke(6 /* System.Int32 System.Globalization.CultureInfo::get_LCID() */, L_15);
		if ((!(((uint32_t)L_14) == ((uint32_t)L_16))))
		{
			goto IL_0095;
		}
	}
	{
		StringBuilder_t1221177846 * L_17 = V_0;
		NullCheck(L_17);
		StringBuilder_Append_m3636508479(L_17, _stringLiteral3350611209, /*hidden argument*/NULL);
		goto IL_00a7;
	}

IL_0095:
	{
		StringBuilder_t1221177846 * L_18 = V_0;
		CultureInfo_t3500843524 * L_19 = __this->get_cultureinfo_6();
		NullCheck(L_19);
		String_t* L_20 = VirtFuncInvoker0< String_t* >::Invoke(7 /* System.String System.Globalization.CultureInfo::get_Name() */, L_19);
		NullCheck(L_18);
		StringBuilder_Append_m3636508479(L_18, L_20, /*hidden argument*/NULL);
	}

IL_00a7:
	{
		ByteU5BU5D_t3397334013* L_21 = AssemblyName_InternalGetPublicKeyToken_m3706025887(__this, /*hidden argument*/NULL);
		V_1 = L_21;
		ByteU5BU5D_t3397334013* L_22 = V_1;
		if (!L_22)
		{
			goto IL_0105;
		}
	}
	{
		ByteU5BU5D_t3397334013* L_23 = V_1;
		NullCheck(L_23);
		if ((((int32_t)((int32_t)(((Il2CppArray *)L_23)->max_length)))))
		{
			goto IL_00cd;
		}
	}
	{
		StringBuilder_t1221177846 * L_24 = V_0;
		NullCheck(L_24);
		StringBuilder_Append_m3636508479(L_24, _stringLiteral3574561019, /*hidden argument*/NULL);
		goto IL_0105;
	}

IL_00cd:
	{
		StringBuilder_t1221177846 * L_25 = V_0;
		NullCheck(L_25);
		StringBuilder_Append_m3636508479(L_25, _stringLiteral1653664622, /*hidden argument*/NULL);
		V_2 = 0;
		goto IL_00fc;
	}

IL_00e0:
	{
		StringBuilder_t1221177846 * L_26 = V_0;
		ByteU5BU5D_t3397334013* L_27 = V_1;
		int32_t L_28 = V_2;
		NullCheck(L_27);
		String_t* L_29 = Byte_ToString_m1309661918(((L_27)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_28))), _stringLiteral3231012720, /*hidden argument*/NULL);
		NullCheck(L_26);
		StringBuilder_Append_m3636508479(L_26, L_29, /*hidden argument*/NULL);
		int32_t L_30 = V_2;
		V_2 = ((int32_t)((int32_t)L_30+(int32_t)1));
	}

IL_00fc:
	{
		int32_t L_31 = V_2;
		ByteU5BU5D_t3397334013* L_32 = V_1;
		NullCheck(L_32);
		if ((((int32_t)L_31) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_32)->max_length)))))))
		{
			goto IL_00e0;
		}
	}

IL_0105:
	{
		int32_t L_33 = AssemblyName_get_Flags_m1290091392(__this, /*hidden argument*/NULL);
		if (!((int32_t)((int32_t)L_33&(int32_t)((int32_t)256))))
		{
			goto IL_0122;
		}
	}
	{
		StringBuilder_t1221177846 * L_34 = V_0;
		NullCheck(L_34);
		StringBuilder_Append_m3636508479(L_34, _stringLiteral130462888, /*hidden argument*/NULL);
	}

IL_0122:
	{
		StringBuilder_t1221177846 * L_35 = V_0;
		NullCheck(L_35);
		String_t* L_36 = StringBuilder_ToString_m1507807375(L_35, /*hidden argument*/NULL);
		return L_36;
	}
}
// System.Version System.Reflection.AssemblyName::get_Version()
extern "C"  Version_t1755874712 * AssemblyName_get_Version_m3495645648 (AssemblyName_t894705941 * __this, const MethodInfo* method)
{
	{
		Version_t1755874712 * L_0 = __this->get_version_13();
		return L_0;
	}
}
// System.Void System.Reflection.AssemblyName::set_Version(System.Version)
extern "C"  void AssemblyName_set_Version_m1012722441 (AssemblyName_t894705941 * __this, Version_t1755874712 * ___value0, const MethodInfo* method)
{
	int32_t V_0 = 0;
	{
		Version_t1755874712 * L_0 = ___value0;
		__this->set_version_13(L_0);
		Version_t1755874712 * L_1 = ___value0;
		bool L_2 = Version_op_Equality_m24249905(NULL /*static, unused*/, L_1, (Version_t1755874712 *)NULL, /*hidden argument*/NULL);
		if (!L_2)
		{
			goto IL_003a;
		}
	}
	{
		int32_t L_3 = 0;
		V_0 = L_3;
		__this->set_revision_5(L_3);
		int32_t L_4 = V_0;
		int32_t L_5 = L_4;
		V_0 = L_5;
		__this->set_build_4(L_5);
		int32_t L_6 = V_0;
		int32_t L_7 = L_6;
		V_0 = L_7;
		__this->set_minor_3(L_7);
		int32_t L_8 = V_0;
		__this->set_major_2(L_8);
		goto IL_006a;
	}

IL_003a:
	{
		Version_t1755874712 * L_9 = ___value0;
		NullCheck(L_9);
		int32_t L_10 = Version_get_Major_m3385239713(L_9, /*hidden argument*/NULL);
		__this->set_major_2(L_10);
		Version_t1755874712 * L_11 = ___value0;
		NullCheck(L_11);
		int32_t L_12 = Version_get_Minor_m3449134197(L_11, /*hidden argument*/NULL);
		__this->set_minor_3(L_12);
		Version_t1755874712 * L_13 = ___value0;
		NullCheck(L_13);
		int32_t L_14 = Version_get_Build_m4207539494(L_13, /*hidden argument*/NULL);
		__this->set_build_4(L_14);
		Version_t1755874712 * L_15 = ___value0;
		NullCheck(L_15);
		int32_t L_16 = Version_get_Revision_m654005649(L_15, /*hidden argument*/NULL);
		__this->set_revision_5(L_16);
	}

IL_006a:
	{
		return;
	}
}
// System.String System.Reflection.AssemblyName::ToString()
extern "C"  String_t* AssemblyName_ToString_m354334942 (AssemblyName_t894705941 * __this, const MethodInfo* method)
{
	String_t* V_0 = NULL;
	String_t* G_B3_0 = NULL;
	{
		String_t* L_0 = AssemblyName_get_FullName_m1606421515(__this, /*hidden argument*/NULL);
		V_0 = L_0;
		String_t* L_1 = V_0;
		if (!L_1)
		{
			goto IL_0013;
		}
	}
	{
		String_t* L_2 = V_0;
		G_B3_0 = L_2;
		goto IL_0019;
	}

IL_0013:
	{
		String_t* L_3 = Object_ToString_m853381981(__this, /*hidden argument*/NULL);
		G_B3_0 = L_3;
	}

IL_0019:
	{
		return G_B3_0;
	}
}
// System.Boolean System.Reflection.AssemblyName::get_IsPublicKeyValid()
extern Il2CppClass* CryptographicException_t3349726436_il2cpp_TypeInfo_var;
extern const uint32_t AssemblyName_get_IsPublicKeyValid_m188320564_MetadataUsageId;
extern "C"  bool AssemblyName_get_IsPublicKeyValid_m188320564 (AssemblyName_t894705941 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AssemblyName_get_IsPublicKeyValid_m188320564_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	uint8_t V_2 = 0x0;
	bool V_3 = false;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		ByteU5BU5D_t3397334013* L_0 = __this->get_publicKey_10();
		NullCheck(L_0);
		if ((!(((uint32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_0)->max_length))))) == ((uint32_t)((int32_t)16)))))
		{
			goto IL_003e;
		}
	}
	{
		V_0 = 0;
		V_1 = 0;
		goto IL_0027;
	}

IL_0018:
	{
		int32_t L_1 = V_1;
		ByteU5BU5D_t3397334013* L_2 = __this->get_publicKey_10();
		int32_t L_3 = V_0;
		int32_t L_4 = L_3;
		V_0 = ((int32_t)((int32_t)L_4+(int32_t)1));
		NullCheck(L_2);
		int32_t L_5 = L_4;
		uint8_t L_6 = (L_2)->GetAt(static_cast<il2cpp_array_size_t>(L_5));
		V_1 = ((int32_t)((int32_t)L_1+(int32_t)L_6));
	}

IL_0027:
	{
		int32_t L_7 = V_0;
		ByteU5BU5D_t3397334013* L_8 = __this->get_publicKey_10();
		NullCheck(L_8);
		if ((((int32_t)L_7) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_8)->max_length)))))))
		{
			goto IL_0018;
		}
	}
	{
		int32_t L_9 = V_1;
		if ((!(((uint32_t)L_9) == ((uint32_t)4))))
		{
			goto IL_003e;
		}
	}
	{
		return (bool)1;
	}

IL_003e:
	{
		ByteU5BU5D_t3397334013* L_10 = __this->get_publicKey_10();
		NullCheck(L_10);
		int32_t L_11 = 0;
		uint8_t L_12 = (L_10)->GetAt(static_cast<il2cpp_array_size_t>(L_11));
		V_2 = L_12;
		uint8_t L_13 = V_2;
		if ((((int32_t)L_13) == ((int32_t)6)))
		{
			goto IL_00a4;
		}
	}
	{
		uint8_t L_14 = V_2;
		if ((((int32_t)L_14) == ((int32_t)7)))
		{
			goto IL_00c7;
		}
	}
	{
		uint8_t L_15 = V_2;
		if ((((int32_t)L_15) == ((int32_t)0)))
		{
			goto IL_0061;
		}
	}
	{
		goto IL_00cc;
	}

IL_0061:
	{
		ByteU5BU5D_t3397334013* L_16 = __this->get_publicKey_10();
		NullCheck(L_16);
		if ((((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_16)->max_length))))) <= ((int32_t)((int32_t)12))))
		{
			goto IL_009f;
		}
	}
	{
		ByteU5BU5D_t3397334013* L_17 = __this->get_publicKey_10();
		NullCheck(L_17);
		int32_t L_18 = ((int32_t)12);
		uint8_t L_19 = (L_17)->GetAt(static_cast<il2cpp_array_size_t>(L_18));
		if ((!(((uint32_t)L_19) == ((uint32_t)6))))
		{
			goto IL_009f;
		}
	}

IL_007f:
	try
	{ // begin try (depth: 1)
		{
			ByteU5BU5D_t3397334013* L_20 = __this->get_publicKey_10();
			CryptoConvert_FromCapiPublicKeyBlob_m812595523(NULL /*static, unused*/, L_20, ((int32_t)12), /*hidden argument*/NULL);
			V_3 = (bool)1;
			goto IL_00ce;
		}

IL_0094:
		{
			; // IL_0094: leave IL_009f
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__exception_local = (Exception_t1927440687 *)e.ex;
		if(il2cpp_codegen_class_is_assignable_from (CryptographicException_t3349726436_il2cpp_TypeInfo_var, e.ex->object.klass))
			goto CATCH_0099;
		throw e;
	}

CATCH_0099:
	{ // begin catch(System.Security.Cryptography.CryptographicException)
		goto IL_009f;
	} // end catch (depth: 1)

IL_009f:
	{
		goto IL_00cc;
	}

IL_00a4:
	try
	{ // begin try (depth: 1)
		{
			ByteU5BU5D_t3397334013* L_21 = __this->get_publicKey_10();
			CryptoConvert_FromCapiPublicKeyBlob_m547807126(NULL /*static, unused*/, L_21, /*hidden argument*/NULL);
			V_3 = (bool)1;
			goto IL_00ce;
		}

IL_00b7:
		{
			; // IL_00b7: leave IL_00c2
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__exception_local = (Exception_t1927440687 *)e.ex;
		if(il2cpp_codegen_class_is_assignable_from (CryptographicException_t3349726436_il2cpp_TypeInfo_var, e.ex->object.klass))
			goto CATCH_00bc;
		throw e;
	}

CATCH_00bc:
	{ // begin catch(System.Security.Cryptography.CryptographicException)
		goto IL_00c2;
	} // end catch (depth: 1)

IL_00c2:
	{
		goto IL_00cc;
	}

IL_00c7:
	{
		goto IL_00cc;
	}

IL_00cc:
	{
		return (bool)0;
	}

IL_00ce:
	{
		bool L_22 = V_3;
		return L_22;
	}
}
// System.Byte[] System.Reflection.AssemblyName::InternalGetPublicKeyToken()
extern Il2CppClass* ByteU5BU5D_t3397334013_il2cpp_TypeInfo_var;
extern Il2CppClass* SecurityException_t887327375_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral2662378774;
extern const uint32_t AssemblyName_InternalGetPublicKeyToken_m3706025887_MetadataUsageId;
extern "C"  ByteU5BU5D_t3397334013* AssemblyName_InternalGetPublicKeyToken_m3706025887 (AssemblyName_t894705941 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AssemblyName_InternalGetPublicKeyToken_m3706025887_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ByteU5BU5D_t3397334013* L_0 = __this->get_keyToken_11();
		if (!L_0)
		{
			goto IL_0012;
		}
	}
	{
		ByteU5BU5D_t3397334013* L_1 = __this->get_keyToken_11();
		return L_1;
	}

IL_0012:
	{
		ByteU5BU5D_t3397334013* L_2 = __this->get_publicKey_10();
		if (L_2)
		{
			goto IL_001f;
		}
	}
	{
		return (ByteU5BU5D_t3397334013*)NULL;
	}

IL_001f:
	{
		ByteU5BU5D_t3397334013* L_3 = __this->get_publicKey_10();
		NullCheck(L_3);
		if ((((int32_t)((int32_t)(((Il2CppArray *)L_3)->max_length)))))
		{
			goto IL_0033;
		}
	}
	{
		return ((ByteU5BU5D_t3397334013*)SZArrayNew(ByteU5BU5D_t3397334013_il2cpp_TypeInfo_var, (uint32_t)0));
	}

IL_0033:
	{
		bool L_4 = AssemblyName_get_IsPublicKeyValid_m188320564(__this, /*hidden argument*/NULL);
		if (L_4)
		{
			goto IL_0049;
		}
	}
	{
		SecurityException_t887327375 * L_5 = (SecurityException_t887327375 *)il2cpp_codegen_object_new(SecurityException_t887327375_il2cpp_TypeInfo_var);
		SecurityException__ctor_m1484114982(L_5, _stringLiteral2662378774, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_5);
	}

IL_0049:
	{
		ByteU5BU5D_t3397334013* L_6 = AssemblyName_ComputePublicKeyToken_m2254215863(__this, /*hidden argument*/NULL);
		return L_6;
	}
}
// System.Byte[] System.Reflection.AssemblyName::ComputePublicKeyToken()
extern Il2CppClass* ByteU5BU5D_t3397334013_il2cpp_TypeInfo_var;
extern const uint32_t AssemblyName_ComputePublicKeyToken_m2254215863_MetadataUsageId;
extern "C"  ByteU5BU5D_t3397334013* AssemblyName_ComputePublicKeyToken_m2254215863 (AssemblyName_t894705941 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AssemblyName_ComputePublicKeyToken_m2254215863_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	HashAlgorithm_t2624936259 * V_0 = NULL;
	ByteU5BU5D_t3397334013* V_1 = NULL;
	ByteU5BU5D_t3397334013* V_2 = NULL;
	{
		SHA1_t3336793149 * L_0 = SHA1_Create_m139442991(NULL /*static, unused*/, /*hidden argument*/NULL);
		V_0 = L_0;
		HashAlgorithm_t2624936259 * L_1 = V_0;
		ByteU5BU5D_t3397334013* L_2 = __this->get_publicKey_10();
		NullCheck(L_1);
		ByteU5BU5D_t3397334013* L_3 = HashAlgorithm_ComputeHash_m3637856778(L_1, L_2, /*hidden argument*/NULL);
		V_1 = L_3;
		V_2 = ((ByteU5BU5D_t3397334013*)SZArrayNew(ByteU5BU5D_t3397334013_il2cpp_TypeInfo_var, (uint32_t)8));
		ByteU5BU5D_t3397334013* L_4 = V_1;
		ByteU5BU5D_t3397334013* L_5 = V_1;
		NullCheck(L_5);
		ByteU5BU5D_t3397334013* L_6 = V_2;
		Array_Copy_m3808317496(NULL /*static, unused*/, (Il2CppArray *)(Il2CppArray *)L_4, ((int32_t)((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_5)->max_length))))-(int32_t)8)), (Il2CppArray *)(Il2CppArray *)L_6, 0, 8, /*hidden argument*/NULL);
		ByteU5BU5D_t3397334013* L_7 = V_2;
		Array_Reverse_m3433347928(NULL /*static, unused*/, (Il2CppArray *)(Il2CppArray *)L_7, 0, 8, /*hidden argument*/NULL);
		ByteU5BU5D_t3397334013* L_8 = V_2;
		return L_8;
	}
}
// System.Void System.Reflection.AssemblyName::SetPublicKey(System.Byte[])
extern "C"  void AssemblyName_SetPublicKey_m1491402438 (AssemblyName_t894705941 * __this, ByteU5BU5D_t3397334013* ___publicKey0, const MethodInfo* method)
{
	{
		ByteU5BU5D_t3397334013* L_0 = ___publicKey0;
		if (L_0)
		{
			goto IL_0019;
		}
	}
	{
		int32_t L_1 = __this->get_flags_7();
		__this->set_flags_7(((int32_t)((int32_t)L_1^(int32_t)1)));
		goto IL_0027;
	}

IL_0019:
	{
		int32_t L_2 = __this->get_flags_7();
		__this->set_flags_7(((int32_t)((int32_t)L_2|(int32_t)1)));
	}

IL_0027:
	{
		ByteU5BU5D_t3397334013* L_3 = ___publicKey0;
		__this->set_publicKey_10(L_3);
		return;
	}
}
// System.Void System.Reflection.AssemblyName::SetPublicKeyToken(System.Byte[])
extern "C"  void AssemblyName_SetPublicKeyToken_m3032035167 (AssemblyName_t894705941 * __this, ByteU5BU5D_t3397334013* ___publicKeyToken0, const MethodInfo* method)
{
	{
		ByteU5BU5D_t3397334013* L_0 = ___publicKeyToken0;
		__this->set_keyToken_11(L_0);
		return;
	}
}
// System.Void System.Reflection.AssemblyName::GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern Il2CppClass* ArgumentNullException_t628810857_il2cpp_TypeInfo_var;
extern Il2CppClass* AssemblyHashAlgorithm_t4147282775_il2cpp_TypeInfo_var;
extern Il2CppClass* AssemblyVersionCompatibility_t1223556284_il2cpp_TypeInfo_var;
extern Il2CppClass* AssemblyNameFlags_t1794031440_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral2792112382;
extern Il2CppCodeGenString* _stringLiteral594030812;
extern Il2CppCodeGenString* _stringLiteral2167127169;
extern Il2CppCodeGenString* _stringLiteral2837183762;
extern Il2CppCodeGenString* _stringLiteral3706305741;
extern Il2CppCodeGenString* _stringLiteral1952199827;
extern Il2CppCodeGenString* _stringLiteral1734555969;
extern Il2CppCodeGenString* _stringLiteral3684797936;
extern Il2CppCodeGenString* _stringLiteral416540412;
extern Il2CppCodeGenString* _stringLiteral2448232678;
extern Il2CppCodeGenString* _stringLiteral1836058351;
extern Il2CppCodeGenString* _stringLiteral180760614;
extern Il2CppCodeGenString* _stringLiteral556236101;
extern const uint32_t AssemblyName_GetObjectData_m1221677827_MetadataUsageId;
extern "C"  void AssemblyName_GetObjectData_m1221677827 (AssemblyName_t894705941 * __this, SerializationInfo_t228987430 * ___info0, StreamingContext_t1417235061  ___context1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AssemblyName_GetObjectData_m1221677827_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	String_t* G_B4_0 = NULL;
	SerializationInfo_t228987430 * G_B4_1 = NULL;
	String_t* G_B3_0 = NULL;
	SerializationInfo_t228987430 * G_B3_1 = NULL;
	int32_t G_B5_0 = 0;
	String_t* G_B5_1 = NULL;
	SerializationInfo_t228987430 * G_B5_2 = NULL;
	{
		SerializationInfo_t228987430 * L_0 = ___info0;
		if (L_0)
		{
			goto IL_0011;
		}
	}
	{
		ArgumentNullException_t628810857 * L_1 = (ArgumentNullException_t628810857 *)il2cpp_codegen_object_new(ArgumentNullException_t628810857_il2cpp_TypeInfo_var);
		ArgumentNullException__ctor_m3380712306(L_1, _stringLiteral2792112382, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_1);
	}

IL_0011:
	{
		SerializationInfo_t228987430 * L_2 = ___info0;
		String_t* L_3 = __this->get_name_0();
		NullCheck(L_2);
		SerializationInfo_AddValue_m1740888931(L_2, _stringLiteral594030812, L_3, /*hidden argument*/NULL);
		SerializationInfo_t228987430 * L_4 = ___info0;
		ByteU5BU5D_t3397334013* L_5 = __this->get_publicKey_10();
		NullCheck(L_4);
		SerializationInfo_AddValue_m1740888931(L_4, _stringLiteral2167127169, (Il2CppObject *)(Il2CppObject *)L_5, /*hidden argument*/NULL);
		SerializationInfo_t228987430 * L_6 = ___info0;
		ByteU5BU5D_t3397334013* L_7 = __this->get_keyToken_11();
		NullCheck(L_6);
		SerializationInfo_AddValue_m1740888931(L_6, _stringLiteral2837183762, (Il2CppObject *)(Il2CppObject *)L_7, /*hidden argument*/NULL);
		SerializationInfo_t228987430 * L_8 = ___info0;
		CultureInfo_t3500843524 * L_9 = __this->get_cultureinfo_6();
		G_B3_0 = _stringLiteral3706305741;
		G_B3_1 = L_8;
		if (!L_9)
		{
			G_B4_0 = _stringLiteral3706305741;
			G_B4_1 = L_8;
			goto IL_0065;
		}
	}
	{
		CultureInfo_t3500843524 * L_10 = __this->get_cultureinfo_6();
		NullCheck(L_10);
		int32_t L_11 = VirtFuncInvoker0< int32_t >::Invoke(6 /* System.Int32 System.Globalization.CultureInfo::get_LCID() */, L_10);
		G_B5_0 = L_11;
		G_B5_1 = G_B3_0;
		G_B5_2 = G_B3_1;
		goto IL_0066;
	}

IL_0065:
	{
		G_B5_0 = (-1);
		G_B5_1 = G_B4_0;
		G_B5_2 = G_B4_1;
	}

IL_0066:
	{
		NullCheck(G_B5_2);
		SerializationInfo_AddValue_m902275108(G_B5_2, G_B5_1, G_B5_0, /*hidden argument*/NULL);
		SerializationInfo_t228987430 * L_12 = ___info0;
		String_t* L_13 = __this->get_codebase_1();
		NullCheck(L_12);
		SerializationInfo_AddValue_m1740888931(L_12, _stringLiteral1952199827, L_13, /*hidden argument*/NULL);
		SerializationInfo_t228987430 * L_14 = ___info0;
		Version_t1755874712 * L_15 = AssemblyName_get_Version_m3495645648(__this, /*hidden argument*/NULL);
		NullCheck(L_14);
		SerializationInfo_AddValue_m1740888931(L_14, _stringLiteral1734555969, L_15, /*hidden argument*/NULL);
		SerializationInfo_t228987430 * L_16 = ___info0;
		int32_t L_17 = __this->get_hashalg_8();
		int32_t L_18 = L_17;
		Il2CppObject * L_19 = Box(AssemblyHashAlgorithm_t4147282775_il2cpp_TypeInfo_var, &L_18);
		NullCheck(L_16);
		SerializationInfo_AddValue_m1740888931(L_16, _stringLiteral3684797936, L_19, /*hidden argument*/NULL);
		SerializationInfo_t228987430 * L_20 = ___info0;
		int32_t L_21 = ((int32_t)0);
		Il2CppObject * L_22 = Box(AssemblyHashAlgorithm_t4147282775_il2cpp_TypeInfo_var, &L_21);
		NullCheck(L_20);
		SerializationInfo_AddValue_m1740888931(L_20, _stringLiteral416540412, L_22, /*hidden argument*/NULL);
		SerializationInfo_t228987430 * L_23 = ___info0;
		StrongNameKeyPair_t4090869089 * L_24 = __this->get_keypair_9();
		NullCheck(L_23);
		SerializationInfo_AddValue_m1740888931(L_23, _stringLiteral2448232678, L_24, /*hidden argument*/NULL);
		SerializationInfo_t228987430 * L_25 = ___info0;
		int32_t L_26 = __this->get_versioncompat_12();
		int32_t L_27 = L_26;
		Il2CppObject * L_28 = Box(AssemblyVersionCompatibility_t1223556284_il2cpp_TypeInfo_var, &L_27);
		NullCheck(L_25);
		SerializationInfo_AddValue_m1740888931(L_25, _stringLiteral1836058351, L_28, /*hidden argument*/NULL);
		SerializationInfo_t228987430 * L_29 = ___info0;
		int32_t L_30 = __this->get_flags_7();
		int32_t L_31 = L_30;
		Il2CppObject * L_32 = Box(AssemblyNameFlags_t1794031440_il2cpp_TypeInfo_var, &L_31);
		NullCheck(L_29);
		SerializationInfo_AddValue_m1740888931(L_29, _stringLiteral180760614, L_32, /*hidden argument*/NULL);
		SerializationInfo_t228987430 * L_33 = ___info0;
		NullCheck(L_33);
		SerializationInfo_AddValue_m1740888931(L_33, _stringLiteral556236101, NULL, /*hidden argument*/NULL);
		return;
	}
}
// System.Object System.Reflection.AssemblyName::Clone()
extern Il2CppClass* AssemblyName_t894705941_il2cpp_TypeInfo_var;
extern const uint32_t AssemblyName_Clone_m3390118349_MetadataUsageId;
extern "C"  Il2CppObject * AssemblyName_Clone_m3390118349 (AssemblyName_t894705941 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AssemblyName_Clone_m3390118349_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	AssemblyName_t894705941 * V_0 = NULL;
	{
		AssemblyName_t894705941 * L_0 = (AssemblyName_t894705941 *)il2cpp_codegen_object_new(AssemblyName_t894705941_il2cpp_TypeInfo_var);
		AssemblyName__ctor_m2505746587(L_0, /*hidden argument*/NULL);
		V_0 = L_0;
		AssemblyName_t894705941 * L_1 = V_0;
		String_t* L_2 = __this->get_name_0();
		NullCheck(L_1);
		L_1->set_name_0(L_2);
		AssemblyName_t894705941 * L_3 = V_0;
		String_t* L_4 = __this->get_codebase_1();
		NullCheck(L_3);
		L_3->set_codebase_1(L_4);
		AssemblyName_t894705941 * L_5 = V_0;
		int32_t L_6 = __this->get_major_2();
		NullCheck(L_5);
		L_5->set_major_2(L_6);
		AssemblyName_t894705941 * L_7 = V_0;
		int32_t L_8 = __this->get_minor_3();
		NullCheck(L_7);
		L_7->set_minor_3(L_8);
		AssemblyName_t894705941 * L_9 = V_0;
		int32_t L_10 = __this->get_build_4();
		NullCheck(L_9);
		L_9->set_build_4(L_10);
		AssemblyName_t894705941 * L_11 = V_0;
		int32_t L_12 = __this->get_revision_5();
		NullCheck(L_11);
		L_11->set_revision_5(L_12);
		AssemblyName_t894705941 * L_13 = V_0;
		Version_t1755874712 * L_14 = __this->get_version_13();
		NullCheck(L_13);
		L_13->set_version_13(L_14);
		AssemblyName_t894705941 * L_15 = V_0;
		CultureInfo_t3500843524 * L_16 = __this->get_cultureinfo_6();
		NullCheck(L_15);
		L_15->set_cultureinfo_6(L_16);
		AssemblyName_t894705941 * L_17 = V_0;
		int32_t L_18 = __this->get_flags_7();
		NullCheck(L_17);
		L_17->set_flags_7(L_18);
		AssemblyName_t894705941 * L_19 = V_0;
		int32_t L_20 = __this->get_hashalg_8();
		NullCheck(L_19);
		L_19->set_hashalg_8(L_20);
		AssemblyName_t894705941 * L_21 = V_0;
		StrongNameKeyPair_t4090869089 * L_22 = __this->get_keypair_9();
		NullCheck(L_21);
		L_21->set_keypair_9(L_22);
		AssemblyName_t894705941 * L_23 = V_0;
		ByteU5BU5D_t3397334013* L_24 = __this->get_publicKey_10();
		NullCheck(L_23);
		L_23->set_publicKey_10(L_24);
		AssemblyName_t894705941 * L_25 = V_0;
		ByteU5BU5D_t3397334013* L_26 = __this->get_keyToken_11();
		NullCheck(L_25);
		L_25->set_keyToken_11(L_26);
		AssemblyName_t894705941 * L_27 = V_0;
		int32_t L_28 = __this->get_versioncompat_12();
		NullCheck(L_27);
		L_27->set_versioncompat_12(L_28);
		AssemblyName_t894705941 * L_29 = V_0;
		return L_29;
	}
}
// System.Void System.Reflection.AssemblyName::OnDeserialization(System.Object)
extern "C"  void AssemblyName_OnDeserialization_m2683521459 (AssemblyName_t894705941 * __this, Il2CppObject * ___sender0, const MethodInfo* method)
{
	{
		Version_t1755874712 * L_0 = __this->get_version_13();
		AssemblyName_set_Version_m1012722441(__this, L_0, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Reflection.AssemblyProductAttribute::.ctor(System.String)
extern "C"  void AssemblyProductAttribute__ctor_m1807437213 (AssemblyProductAttribute_t1523443169 * __this, String_t* ___product0, const MethodInfo* method)
{
	{
		Attribute__ctor_m1730479323(__this, /*hidden argument*/NULL);
		String_t* L_0 = ___product0;
		__this->set_name_0(L_0);
		return;
	}
}
// System.Void System.Reflection.AssemblyTitleAttribute::.ctor(System.String)
extern "C"  void AssemblyTitleAttribute__ctor_m1696431446 (AssemblyTitleAttribute_t92945912 * __this, String_t* ___title0, const MethodInfo* method)
{
	{
		Attribute__ctor_m1730479323(__this, /*hidden argument*/NULL);
		String_t* L_0 = ___title0;
		__this->set_name_0(L_0);
		return;
	}
}
// System.Void System.Reflection.AssemblyTrademarkAttribute::.ctor(System.String)
extern "C"  void AssemblyTrademarkAttribute__ctor_m4184045333 (AssemblyTrademarkAttribute_t3740556705 * __this, String_t* ___trademark0, const MethodInfo* method)
{
	{
		Attribute__ctor_m1730479323(__this, /*hidden argument*/NULL);
		String_t* L_0 = ___trademark0;
		__this->set_name_0(L_0);
		return;
	}
}
// System.Void System.Reflection.Binder::.ctor()
extern "C"  void Binder__ctor_m1361613966 (Binder_t3404612058 * __this, const MethodInfo* method)
{
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Reflection.Binder::.cctor()
extern Il2CppClass* Default_t3956931304_il2cpp_TypeInfo_var;
extern Il2CppClass* Binder_t3404612058_il2cpp_TypeInfo_var;
extern const uint32_t Binder__cctor_m3736115807_MetadataUsageId;
extern "C"  void Binder__cctor_m3736115807 (Il2CppObject * __this /* static, unused */, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Binder__cctor_m3736115807_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Default_t3956931304 * L_0 = (Default_t3956931304 *)il2cpp_codegen_object_new(Default_t3956931304_il2cpp_TypeInfo_var);
		Default__ctor_m172834064(L_0, /*hidden argument*/NULL);
		((Binder_t3404612058_StaticFields*)Binder_t3404612058_il2cpp_TypeInfo_var->static_fields)->set_default_binder_0(L_0);
		return;
	}
}
// System.Reflection.Binder System.Reflection.Binder::get_DefaultBinder()
extern Il2CppClass* Binder_t3404612058_il2cpp_TypeInfo_var;
extern const uint32_t Binder_get_DefaultBinder_m965620943_MetadataUsageId;
extern "C"  Binder_t3404612058 * Binder_get_DefaultBinder_m965620943 (Il2CppObject * __this /* static, unused */, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Binder_get_DefaultBinder_m965620943_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(Binder_t3404612058_il2cpp_TypeInfo_var);
		Binder_t3404612058 * L_0 = ((Binder_t3404612058_StaticFields*)Binder_t3404612058_il2cpp_TypeInfo_var->static_fields)->get_default_binder_0();
		return L_0;
	}
}
// System.Boolean System.Reflection.Binder::ConvertArgs(System.Reflection.Binder,System.Object[],System.Reflection.ParameterInfo[],System.Globalization.CultureInfo)
extern Il2CppClass* TargetParameterCountException_t1554451430_il2cpp_TypeInfo_var;
extern const uint32_t Binder_ConvertArgs_m2999223281_MetadataUsageId;
extern "C"  bool Binder_ConvertArgs_m2999223281 (Il2CppObject * __this /* static, unused */, Binder_t3404612058 * ___binder0, ObjectU5BU5D_t3614634134* ___args1, ParameterInfoU5BU5D_t2275869610* ___pinfo2, CultureInfo_t3500843524 * ___culture3, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Binder_ConvertArgs_m2999223281_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	Il2CppObject * V_1 = NULL;
	{
		ObjectU5BU5D_t3614634134* L_0 = ___args1;
		if (L_0)
		{
			goto IL_0016;
		}
	}
	{
		ParameterInfoU5BU5D_t2275869610* L_1 = ___pinfo2;
		NullCheck(L_1);
		if ((((int32_t)((int32_t)(((Il2CppArray *)L_1)->max_length)))))
		{
			goto IL_0010;
		}
	}
	{
		return (bool)1;
	}

IL_0010:
	{
		TargetParameterCountException_t1554451430 * L_2 = (TargetParameterCountException_t1554451430 *)il2cpp_codegen_object_new(TargetParameterCountException_t1554451430_il2cpp_TypeInfo_var);
		TargetParameterCountException__ctor_m1256521036(L_2, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_2);
	}

IL_0016:
	{
		ParameterInfoU5BU5D_t2275869610* L_3 = ___pinfo2;
		NullCheck(L_3);
		ObjectU5BU5D_t3614634134* L_4 = ___args1;
		NullCheck(L_4);
		if ((((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_3)->max_length))))) == ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_4)->max_length)))))))
		{
			goto IL_0027;
		}
	}
	{
		TargetParameterCountException_t1554451430 * L_5 = (TargetParameterCountException_t1554451430 *)il2cpp_codegen_object_new(TargetParameterCountException_t1554451430_il2cpp_TypeInfo_var);
		TargetParameterCountException__ctor_m1256521036(L_5, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_5);
	}

IL_0027:
	{
		V_0 = 0;
		goto IL_0059;
	}

IL_002e:
	{
		Binder_t3404612058 * L_6 = ___binder0;
		ObjectU5BU5D_t3614634134* L_7 = ___args1;
		int32_t L_8 = V_0;
		NullCheck(L_7);
		int32_t L_9 = L_8;
		Il2CppObject * L_10 = (L_7)->GetAt(static_cast<il2cpp_array_size_t>(L_9));
		ParameterInfoU5BU5D_t2275869610* L_11 = ___pinfo2;
		int32_t L_12 = V_0;
		NullCheck(L_11);
		int32_t L_13 = L_12;
		ParameterInfo_t2249040075 * L_14 = (L_11)->GetAt(static_cast<il2cpp_array_size_t>(L_13));
		NullCheck(L_14);
		Type_t * L_15 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.ParameterInfo::get_ParameterType() */, L_14);
		CultureInfo_t3500843524 * L_16 = ___culture3;
		NullCheck(L_6);
		Il2CppObject * L_17 = VirtFuncInvoker3< Il2CppObject *, Il2CppObject *, Type_t *, CultureInfo_t3500843524 * >::Invoke(5 /* System.Object System.Reflection.Binder::ChangeType(System.Object,System.Type,System.Globalization.CultureInfo) */, L_6, L_10, L_15, L_16);
		V_1 = L_17;
		Il2CppObject * L_18 = V_1;
		if (L_18)
		{
			goto IL_0051;
		}
	}
	{
		ObjectU5BU5D_t3614634134* L_19 = ___args1;
		int32_t L_20 = V_0;
		NullCheck(L_19);
		int32_t L_21 = L_20;
		Il2CppObject * L_22 = (L_19)->GetAt(static_cast<il2cpp_array_size_t>(L_21));
		if (!L_22)
		{
			goto IL_0051;
		}
	}
	{
		return (bool)0;
	}

IL_0051:
	{
		ObjectU5BU5D_t3614634134* L_23 = ___args1;
		int32_t L_24 = V_0;
		Il2CppObject * L_25 = V_1;
		NullCheck(L_23);
		ArrayElementTypeCheck (L_23, L_25);
		(L_23)->SetAt(static_cast<il2cpp_array_size_t>(L_24), (Il2CppObject *)L_25);
		int32_t L_26 = V_0;
		V_0 = ((int32_t)((int32_t)L_26+(int32_t)1));
	}

IL_0059:
	{
		int32_t L_27 = V_0;
		ObjectU5BU5D_t3614634134* L_28 = ___args1;
		NullCheck(L_28);
		if ((((int32_t)L_27) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_28)->max_length)))))))
		{
			goto IL_002e;
		}
	}
	{
		return (bool)1;
	}
}
// System.Int32 System.Reflection.Binder::GetDerivedLevel(System.Type)
extern "C"  int32_t Binder_GetDerivedLevel_m1809808744 (Il2CppObject * __this /* static, unused */, Type_t * ___type0, const MethodInfo* method)
{
	Type_t * V_0 = NULL;
	int32_t V_1 = 0;
	{
		Type_t * L_0 = ___type0;
		V_0 = L_0;
		V_1 = 1;
		goto IL_0014;
	}

IL_0009:
	{
		int32_t L_1 = V_1;
		V_1 = ((int32_t)((int32_t)L_1+(int32_t)1));
		Type_t * L_2 = V_0;
		NullCheck(L_2);
		Type_t * L_3 = VirtFuncInvoker0< Type_t * >::Invoke(17 /* System.Type System.Type::get_BaseType() */, L_2);
		V_0 = L_3;
	}

IL_0014:
	{
		Type_t * L_4 = V_0;
		NullCheck(L_4);
		Type_t * L_5 = VirtFuncInvoker0< Type_t * >::Invoke(17 /* System.Type System.Type::get_BaseType() */, L_4);
		if (L_5)
		{
			goto IL_0009;
		}
	}
	{
		int32_t L_6 = V_1;
		return L_6;
	}
}
// System.Reflection.MethodBase System.Reflection.Binder::FindMostDerivedMatch(System.Reflection.MethodBase[])
extern Il2CppClass* Binder_t3404612058_il2cpp_TypeInfo_var;
extern Il2CppClass* AmbiguousMatchException_t1406414556_il2cpp_TypeInfo_var;
extern const uint32_t Binder_FindMostDerivedMatch_m2621831847_MetadataUsageId;
extern "C"  MethodBase_t904190842 * Binder_FindMostDerivedMatch_m2621831847 (Il2CppObject * __this /* static, unused */, MethodBaseU5BU5D_t2597254495* ___match0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Binder_FindMostDerivedMatch_m2621831847_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	int32_t V_3 = 0;
	MethodBase_t904190842 * V_4 = NULL;
	int32_t V_5 = 0;
	ParameterInfoU5BU5D_t2275869610* V_6 = NULL;
	ParameterInfoU5BU5D_t2275869610* V_7 = NULL;
	bool V_8 = false;
	int32_t V_9 = 0;
	{
		V_0 = 0;
		V_1 = (-1);
		MethodBaseU5BU5D_t2597254495* L_0 = ___match0;
		NullCheck(L_0);
		V_2 = (((int32_t)((int32_t)(((Il2CppArray *)L_0)->max_length))));
		V_3 = 0;
		goto IL_00ba;
	}

IL_000f:
	{
		MethodBaseU5BU5D_t2597254495* L_1 = ___match0;
		int32_t L_2 = V_3;
		NullCheck(L_1);
		int32_t L_3 = L_2;
		MethodBase_t904190842 * L_4 = (L_1)->GetAt(static_cast<il2cpp_array_size_t>(L_3));
		V_4 = L_4;
		MethodBase_t904190842 * L_5 = V_4;
		NullCheck(L_5);
		Type_t * L_6 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.MemberInfo::get_DeclaringType() */, L_5);
		IL2CPP_RUNTIME_CLASS_INIT(Binder_t3404612058_il2cpp_TypeInfo_var);
		int32_t L_7 = Binder_GetDerivedLevel_m1809808744(NULL /*static, unused*/, L_6, /*hidden argument*/NULL);
		V_5 = L_7;
		int32_t L_8 = V_5;
		int32_t L_9 = V_0;
		if ((!(((uint32_t)L_8) == ((uint32_t)L_9))))
		{
			goto IL_0030;
		}
	}
	{
		AmbiguousMatchException_t1406414556 * L_10 = (AmbiguousMatchException_t1406414556 *)il2cpp_codegen_object_new(AmbiguousMatchException_t1406414556_il2cpp_TypeInfo_var);
		AmbiguousMatchException__ctor_m2088048346(L_10, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_10);
	}

IL_0030:
	{
		int32_t L_11 = V_1;
		if ((((int32_t)L_11) < ((int32_t)0)))
		{
			goto IL_00a9;
		}
	}
	{
		MethodBase_t904190842 * L_12 = V_4;
		NullCheck(L_12);
		ParameterInfoU5BU5D_t2275869610* L_13 = VirtFuncInvoker0< ParameterInfoU5BU5D_t2275869610* >::Invoke(14 /* System.Reflection.ParameterInfo[] System.Reflection.MethodBase::GetParameters() */, L_12);
		V_6 = L_13;
		MethodBaseU5BU5D_t2597254495* L_14 = ___match0;
		int32_t L_15 = V_1;
		NullCheck(L_14);
		int32_t L_16 = L_15;
		MethodBase_t904190842 * L_17 = (L_14)->GetAt(static_cast<il2cpp_array_size_t>(L_16));
		NullCheck(L_17);
		ParameterInfoU5BU5D_t2275869610* L_18 = VirtFuncInvoker0< ParameterInfoU5BU5D_t2275869610* >::Invoke(14 /* System.Reflection.ParameterInfo[] System.Reflection.MethodBase::GetParameters() */, L_17);
		V_7 = L_18;
		V_8 = (bool)1;
		ParameterInfoU5BU5D_t2275869610* L_19 = V_6;
		NullCheck(L_19);
		ParameterInfoU5BU5D_t2275869610* L_20 = V_7;
		NullCheck(L_20);
		if ((((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_19)->max_length))))) == ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_20)->max_length)))))))
		{
			goto IL_0062;
		}
	}
	{
		V_8 = (bool)0;
		goto IL_009c;
	}

IL_0062:
	{
		V_9 = 0;
		goto IL_0091;
	}

IL_006a:
	{
		ParameterInfoU5BU5D_t2275869610* L_21 = V_6;
		int32_t L_22 = V_9;
		NullCheck(L_21);
		int32_t L_23 = L_22;
		ParameterInfo_t2249040075 * L_24 = (L_21)->GetAt(static_cast<il2cpp_array_size_t>(L_23));
		NullCheck(L_24);
		Type_t * L_25 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.ParameterInfo::get_ParameterType() */, L_24);
		ParameterInfoU5BU5D_t2275869610* L_26 = V_7;
		int32_t L_27 = V_9;
		NullCheck(L_26);
		int32_t L_28 = L_27;
		ParameterInfo_t2249040075 * L_29 = (L_26)->GetAt(static_cast<il2cpp_array_size_t>(L_28));
		NullCheck(L_29);
		Type_t * L_30 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.ParameterInfo::get_ParameterType() */, L_29);
		if ((((Il2CppObject*)(Type_t *)L_25) == ((Il2CppObject*)(Type_t *)L_30)))
		{
			goto IL_008b;
		}
	}
	{
		V_8 = (bool)0;
		goto IL_009c;
	}

IL_008b:
	{
		int32_t L_31 = V_9;
		V_9 = ((int32_t)((int32_t)L_31+(int32_t)1));
	}

IL_0091:
	{
		int32_t L_32 = V_9;
		ParameterInfoU5BU5D_t2275869610* L_33 = V_6;
		NullCheck(L_33);
		if ((((int32_t)L_32) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_33)->max_length)))))))
		{
			goto IL_006a;
		}
	}

IL_009c:
	{
		bool L_34 = V_8;
		if (L_34)
		{
			goto IL_00a9;
		}
	}
	{
		AmbiguousMatchException_t1406414556 * L_35 = (AmbiguousMatchException_t1406414556 *)il2cpp_codegen_object_new(AmbiguousMatchException_t1406414556_il2cpp_TypeInfo_var);
		AmbiguousMatchException__ctor_m2088048346(L_35, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_35);
	}

IL_00a9:
	{
		int32_t L_36 = V_5;
		int32_t L_37 = V_0;
		if ((((int32_t)L_36) <= ((int32_t)L_37)))
		{
			goto IL_00b6;
		}
	}
	{
		int32_t L_38 = V_5;
		V_0 = L_38;
		int32_t L_39 = V_3;
		V_1 = L_39;
	}

IL_00b6:
	{
		int32_t L_40 = V_3;
		V_3 = ((int32_t)((int32_t)L_40+(int32_t)1));
	}

IL_00ba:
	{
		int32_t L_41 = V_3;
		int32_t L_42 = V_2;
		if ((((int32_t)L_41) < ((int32_t)L_42)))
		{
			goto IL_000f;
		}
	}
	{
		MethodBaseU5BU5D_t2597254495* L_43 = ___match0;
		int32_t L_44 = V_1;
		NullCheck(L_43);
		int32_t L_45 = L_44;
		MethodBase_t904190842 * L_46 = (L_43)->GetAt(static_cast<il2cpp_array_size_t>(L_45));
		return L_46;
	}
}
// System.Void System.Reflection.Binder/Default::.ctor()
extern Il2CppClass* Binder_t3404612058_il2cpp_TypeInfo_var;
extern const uint32_t Default__ctor_m172834064_MetadataUsageId;
extern "C"  void Default__ctor_m172834064 (Default_t3956931304 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Default__ctor_m172834064_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(Binder_t3404612058_il2cpp_TypeInfo_var);
		Binder__ctor_m1361613966(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Reflection.MethodBase System.Reflection.Binder/Default::BindToMethod(System.Reflection.BindingFlags,System.Reflection.MethodBase[],System.Object[]&,System.Reflection.ParameterModifier[],System.Globalization.CultureInfo,System.String[],System.Object&)
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern Il2CppClass* TypeU5BU5D_t1664964607_il2cpp_TypeInfo_var;
extern const uint32_t Default_BindToMethod_m1132635736_MetadataUsageId;
extern "C"  MethodBase_t904190842 * Default_BindToMethod_m1132635736 (Default_t3956931304 * __this, int32_t ___bindingAttr0, MethodBaseU5BU5D_t2597254495* ___match1, ObjectU5BU5D_t3614634134** ___args2, ParameterModifierU5BU5D_t963192633* ___modifiers3, CultureInfo_t3500843524 * ___culture4, StringU5BU5D_t1642385972* ___names5, Il2CppObject ** ___state6, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Default_BindToMethod_m1132635736_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	TypeU5BU5D_t1664964607* V_0 = NULL;
	int32_t V_1 = 0;
	MethodBase_t904190842 * V_2 = NULL;
	{
		ObjectU5BU5D_t3614634134** L_0 = ___args2;
		if ((*((ObjectU5BU5D_t3614634134**)L_0)))
		{
			goto IL_0012;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		TypeU5BU5D_t1664964607* L_1 = ((Type_t_StaticFields*)Type_t_il2cpp_TypeInfo_var->static_fields)->get_EmptyTypes_3();
		V_0 = L_1;
		goto IL_0046;
	}

IL_0012:
	{
		ObjectU5BU5D_t3614634134** L_2 = ___args2;
		NullCheck((*((ObjectU5BU5D_t3614634134**)L_2)));
		V_0 = ((TypeU5BU5D_t1664964607*)SZArrayNew(TypeU5BU5D_t1664964607_il2cpp_TypeInfo_var, (uint32_t)(((int32_t)((int32_t)(((Il2CppArray *)(*((ObjectU5BU5D_t3614634134**)L_2)))->max_length))))));
		V_1 = 0;
		goto IL_003c;
	}

IL_0023:
	{
		ObjectU5BU5D_t3614634134** L_3 = ___args2;
		int32_t L_4 = V_1;
		NullCheck((*((ObjectU5BU5D_t3614634134**)L_3)));
		int32_t L_5 = L_4;
		Il2CppObject * L_6 = ((*((ObjectU5BU5D_t3614634134**)L_3)))->GetAt(static_cast<il2cpp_array_size_t>(L_5));
		if (!L_6)
		{
			goto IL_0038;
		}
	}
	{
		TypeU5BU5D_t1664964607* L_7 = V_0;
		int32_t L_8 = V_1;
		ObjectU5BU5D_t3614634134** L_9 = ___args2;
		int32_t L_10 = V_1;
		NullCheck((*((ObjectU5BU5D_t3614634134**)L_9)));
		int32_t L_11 = L_10;
		Il2CppObject * L_12 = ((*((ObjectU5BU5D_t3614634134**)L_9)))->GetAt(static_cast<il2cpp_array_size_t>(L_11));
		NullCheck(L_12);
		Type_t * L_13 = Object_GetType_m191970594(L_12, /*hidden argument*/NULL);
		NullCheck(L_7);
		ArrayElementTypeCheck (L_7, L_13);
		(L_7)->SetAt(static_cast<il2cpp_array_size_t>(L_8), (Type_t *)L_13);
	}

IL_0038:
	{
		int32_t L_14 = V_1;
		V_1 = ((int32_t)((int32_t)L_14+(int32_t)1));
	}

IL_003c:
	{
		int32_t L_15 = V_1;
		ObjectU5BU5D_t3614634134** L_16 = ___args2;
		NullCheck((*((ObjectU5BU5D_t3614634134**)L_16)));
		if ((((int32_t)L_15) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)(*((ObjectU5BU5D_t3614634134**)L_16)))->max_length)))))))
		{
			goto IL_0023;
		}
	}

IL_0046:
	{
		int32_t L_17 = ___bindingAttr0;
		MethodBaseU5BU5D_t2597254495* L_18 = ___match1;
		TypeU5BU5D_t1664964607* L_19 = V_0;
		ParameterModifierU5BU5D_t963192633* L_20 = ___modifiers3;
		MethodBase_t904190842 * L_21 = Default_SelectMethod_m3081239996(__this, L_17, L_18, L_19, L_20, (bool)1, /*hidden argument*/NULL);
		V_2 = L_21;
		Il2CppObject ** L_22 = ___state6;
		*((Il2CppObject **)(L_22)) = (Il2CppObject *)NULL;
		Il2CppCodeGenWriteBarrier((Il2CppObject **)(L_22), (Il2CppObject *)NULL);
		StringU5BU5D_t1642385972* L_23 = ___names5;
		if (!L_23)
		{
			goto IL_0068;
		}
	}
	{
		StringU5BU5D_t1642385972* L_24 = ___names5;
		ObjectU5BU5D_t3614634134** L_25 = ___args2;
		MethodBase_t904190842 * L_26 = V_2;
		Default_ReorderParameters_m1877749093(__this, L_24, L_25, L_26, /*hidden argument*/NULL);
	}

IL_0068:
	{
		MethodBase_t904190842 * L_27 = V_2;
		return L_27;
	}
}
// System.Void System.Reflection.Binder/Default::ReorderParameters(System.String[],System.Object[]&,System.Reflection.MethodBase)
extern Il2CppClass* ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern const uint32_t Default_ReorderParameters_m1877749093_MetadataUsageId;
extern "C"  void Default_ReorderParameters_m1877749093 (Default_t3956931304 * __this, StringU5BU5D_t1642385972* ___names0, ObjectU5BU5D_t3614634134** ___args1, MethodBase_t904190842 * ___selected2, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Default_ReorderParameters_m1877749093_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ObjectU5BU5D_t3614634134* V_0 = NULL;
	ParameterInfoU5BU5D_t2275869610* V_1 = NULL;
	int32_t V_2 = 0;
	int32_t V_3 = 0;
	{
		ObjectU5BU5D_t3614634134** L_0 = ___args1;
		NullCheck((*((ObjectU5BU5D_t3614634134**)L_0)));
		V_0 = ((ObjectU5BU5D_t3614634134*)SZArrayNew(ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var, (uint32_t)(((int32_t)((int32_t)(((Il2CppArray *)(*((ObjectU5BU5D_t3614634134**)L_0)))->max_length))))));
		ObjectU5BU5D_t3614634134** L_1 = ___args1;
		ObjectU5BU5D_t3614634134* L_2 = V_0;
		ObjectU5BU5D_t3614634134** L_3 = ___args1;
		NullCheck((*((ObjectU5BU5D_t3614634134**)L_3)));
		Array_Copy_m2363740072(NULL /*static, unused*/, (Il2CppArray *)(Il2CppArray *)(*((ObjectU5BU5D_t3614634134**)L_1)), (Il2CppArray *)(Il2CppArray *)L_2, (((int32_t)((int32_t)(((Il2CppArray *)(*((ObjectU5BU5D_t3614634134**)L_3)))->max_length)))), /*hidden argument*/NULL);
		MethodBase_t904190842 * L_4 = ___selected2;
		NullCheck(L_4);
		ParameterInfoU5BU5D_t2275869610* L_5 = VirtFuncInvoker0< ParameterInfoU5BU5D_t2275869610* >::Invoke(14 /* System.Reflection.ParameterInfo[] System.Reflection.MethodBase::GetParameters() */, L_4);
		V_1 = L_5;
		V_2 = 0;
		goto IL_005d;
	}

IL_0024:
	{
		V_3 = 0;
		goto IL_0050;
	}

IL_002b:
	{
		StringU5BU5D_t1642385972* L_6 = ___names0;
		int32_t L_7 = V_2;
		NullCheck(L_6);
		int32_t L_8 = L_7;
		String_t* L_9 = (L_6)->GetAt(static_cast<il2cpp_array_size_t>(L_8));
		ParameterInfoU5BU5D_t2275869610* L_10 = V_1;
		int32_t L_11 = V_3;
		NullCheck(L_10);
		int32_t L_12 = L_11;
		ParameterInfo_t2249040075 * L_13 = (L_10)->GetAt(static_cast<il2cpp_array_size_t>(L_12));
		NullCheck(L_13);
		String_t* L_14 = VirtFuncInvoker0< String_t* >::Invoke(9 /* System.String System.Reflection.ParameterInfo::get_Name() */, L_13);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_15 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_9, L_14, /*hidden argument*/NULL);
		if (!L_15)
		{
			goto IL_004c;
		}
	}
	{
		ObjectU5BU5D_t3614634134* L_16 = V_0;
		int32_t L_17 = V_3;
		ObjectU5BU5D_t3614634134** L_18 = ___args1;
		int32_t L_19 = V_2;
		NullCheck((*((ObjectU5BU5D_t3614634134**)L_18)));
		int32_t L_20 = L_19;
		Il2CppObject * L_21 = ((*((ObjectU5BU5D_t3614634134**)L_18)))->GetAt(static_cast<il2cpp_array_size_t>(L_20));
		NullCheck(L_16);
		ArrayElementTypeCheck (L_16, L_21);
		(L_16)->SetAt(static_cast<il2cpp_array_size_t>(L_17), (Il2CppObject *)L_21);
		goto IL_0059;
	}

IL_004c:
	{
		int32_t L_22 = V_3;
		V_3 = ((int32_t)((int32_t)L_22+(int32_t)1));
	}

IL_0050:
	{
		int32_t L_23 = V_3;
		ParameterInfoU5BU5D_t2275869610* L_24 = V_1;
		NullCheck(L_24);
		if ((((int32_t)L_23) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_24)->max_length)))))))
		{
			goto IL_002b;
		}
	}

IL_0059:
	{
		int32_t L_25 = V_2;
		V_2 = ((int32_t)((int32_t)L_25+(int32_t)1));
	}

IL_005d:
	{
		int32_t L_26 = V_2;
		StringU5BU5D_t1642385972* L_27 = ___names0;
		NullCheck(L_27);
		if ((((int32_t)L_26) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_27)->max_length)))))))
		{
			goto IL_0024;
		}
	}
	{
		ObjectU5BU5D_t3614634134* L_28 = V_0;
		ObjectU5BU5D_t3614634134** L_29 = ___args1;
		ObjectU5BU5D_t3614634134** L_30 = ___args1;
		NullCheck((*((ObjectU5BU5D_t3614634134**)L_30)));
		Array_Copy_m2363740072(NULL /*static, unused*/, (Il2CppArray *)(Il2CppArray *)L_28, (Il2CppArray *)(Il2CppArray *)(*((ObjectU5BU5D_t3614634134**)L_29)), (((int32_t)((int32_t)(((Il2CppArray *)(*((ObjectU5BU5D_t3614634134**)L_30)))->max_length)))), /*hidden argument*/NULL);
		return;
	}
}
// System.Boolean System.Reflection.Binder/Default::IsArrayAssignable(System.Type,System.Type)
extern "C"  bool Default_IsArrayAssignable_m3862319150 (Il2CppObject * __this /* static, unused */, Type_t * ___object_type0, Type_t * ___target_type1, const MethodInfo* method)
{
	{
		Type_t * L_0 = ___object_type0;
		NullCheck(L_0);
		bool L_1 = Type_get_IsArray_m811277129(L_0, /*hidden argument*/NULL);
		if (!L_1)
		{
			goto IL_0028;
		}
	}
	{
		Type_t * L_2 = ___target_type1;
		NullCheck(L_2);
		bool L_3 = Type_get_IsArray_m811277129(L_2, /*hidden argument*/NULL);
		if (!L_3)
		{
			goto IL_0028;
		}
	}
	{
		Type_t * L_4 = ___object_type0;
		NullCheck(L_4);
		Type_t * L_5 = VirtFuncInvoker0< Type_t * >::Invoke(42 /* System.Type System.Type::GetElementType() */, L_4);
		Type_t * L_6 = ___target_type1;
		NullCheck(L_6);
		Type_t * L_7 = VirtFuncInvoker0< Type_t * >::Invoke(42 /* System.Type System.Type::GetElementType() */, L_6);
		bool L_8 = Default_IsArrayAssignable_m3862319150(NULL /*static, unused*/, L_5, L_7, /*hidden argument*/NULL);
		return L_8;
	}

IL_0028:
	{
		Type_t * L_9 = ___target_type1;
		Type_t * L_10 = ___object_type0;
		NullCheck(L_9);
		bool L_11 = VirtFuncInvoker1< bool, Type_t * >::Invoke(40 /* System.Boolean System.Type::IsAssignableFrom(System.Type) */, L_9, L_10);
		if (!L_11)
		{
			goto IL_0036;
		}
	}
	{
		return (bool)1;
	}

IL_0036:
	{
		return (bool)0;
	}
}
// System.Object System.Reflection.Binder/Default::ChangeType(System.Object,System.Type,System.Globalization.CultureInfo)
extern const Il2CppType* Char_t3454481338_0_0_0_var;
extern const Il2CppType* Double_t4078015681_0_0_0_var;
extern const Il2CppType* Single_t2076509932_0_0_0_var;
extern const Il2CppType* IntPtr_t_0_0_0_var;
extern Il2CppClass* Enum_t2459695545_il2cpp_TypeInfo_var;
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern Il2CppClass* Char_t3454481338_il2cpp_TypeInfo_var;
extern Il2CppClass* Double_t4078015681_il2cpp_TypeInfo_var;
extern Il2CppClass* Single_t2076509932_il2cpp_TypeInfo_var;
extern Il2CppClass* Convert_t2607082565_il2cpp_TypeInfo_var;
extern const uint32_t Default_ChangeType_m3142518280_MetadataUsageId;
extern "C"  Il2CppObject * Default_ChangeType_m3142518280 (Default_t3956931304 * __this, Il2CppObject * ___value0, Type_t * ___type1, CultureInfo_t3500843524 * ___culture2, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Default_ChangeType_m3142518280_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Type_t * V_0 = NULL;
	{
		Il2CppObject * L_0 = ___value0;
		if (L_0)
		{
			goto IL_0008;
		}
	}
	{
		return NULL;
	}

IL_0008:
	{
		Il2CppObject * L_1 = ___value0;
		NullCheck(L_1);
		Type_t * L_2 = Object_GetType_m191970594(L_1, /*hidden argument*/NULL);
		V_0 = L_2;
		Type_t * L_3 = ___type1;
		NullCheck(L_3);
		bool L_4 = Type_get_IsByRef_m3523465500(L_3, /*hidden argument*/NULL);
		if (!L_4)
		{
			goto IL_0022;
		}
	}
	{
		Type_t * L_5 = ___type1;
		NullCheck(L_5);
		Type_t * L_6 = VirtFuncInvoker0< Type_t * >::Invoke(42 /* System.Type System.Type::GetElementType() */, L_5);
		___type1 = L_6;
	}

IL_0022:
	{
		Type_t * L_7 = V_0;
		Type_t * L_8 = ___type1;
		if ((((Il2CppObject*)(Type_t *)L_7) == ((Il2CppObject*)(Type_t *)L_8)))
		{
			goto IL_0035;
		}
	}
	{
		Type_t * L_9 = ___type1;
		Il2CppObject * L_10 = ___value0;
		NullCheck(L_9);
		bool L_11 = VirtFuncInvoker1< bool, Il2CppObject * >::Invoke(41 /* System.Boolean System.Type::IsInstanceOfType(System.Object) */, L_9, L_10);
		if (!L_11)
		{
			goto IL_0037;
		}
	}

IL_0035:
	{
		Il2CppObject * L_12 = ___value0;
		return L_12;
	}

IL_0037:
	{
		Type_t * L_13 = V_0;
		NullCheck(L_13);
		bool L_14 = Type_get_IsArray_m811277129(L_13, /*hidden argument*/NULL);
		if (!L_14)
		{
			goto IL_0065;
		}
	}
	{
		Type_t * L_15 = ___type1;
		NullCheck(L_15);
		bool L_16 = Type_get_IsArray_m811277129(L_15, /*hidden argument*/NULL);
		if (!L_16)
		{
			goto IL_0065;
		}
	}
	{
		Type_t * L_17 = V_0;
		NullCheck(L_17);
		Type_t * L_18 = VirtFuncInvoker0< Type_t * >::Invoke(42 /* System.Type System.Type::GetElementType() */, L_17);
		Type_t * L_19 = ___type1;
		NullCheck(L_19);
		Type_t * L_20 = VirtFuncInvoker0< Type_t * >::Invoke(42 /* System.Type System.Type::GetElementType() */, L_19);
		bool L_21 = Default_IsArrayAssignable_m3862319150(NULL /*static, unused*/, L_18, L_20, /*hidden argument*/NULL);
		if (!L_21)
		{
			goto IL_0065;
		}
	}
	{
		Il2CppObject * L_22 = ___value0;
		return L_22;
	}

IL_0065:
	{
		Type_t * L_23 = V_0;
		Type_t * L_24 = ___type1;
		bool L_25 = Default_check_type_m2363631305(NULL /*static, unused*/, L_23, L_24, /*hidden argument*/NULL);
		if (!L_25)
		{
			goto IL_00f3;
		}
	}
	{
		Type_t * L_26 = ___type1;
		NullCheck(L_26);
		bool L_27 = Type_get_IsEnum_m313908919(L_26, /*hidden argument*/NULL);
		if (!L_27)
		{
			goto IL_0084;
		}
	}
	{
		Type_t * L_28 = ___type1;
		Il2CppObject * L_29 = ___value0;
		IL2CPP_RUNTIME_CLASS_INIT(Enum_t2459695545_il2cpp_TypeInfo_var);
		Il2CppObject * L_30 = Enum_ToObject_m2460371738(NULL /*static, unused*/, L_28, L_29, /*hidden argument*/NULL);
		return L_30;
	}

IL_0084:
	{
		Type_t * L_31 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_32 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Char_t3454481338_0_0_0_var), /*hidden argument*/NULL);
		if ((!(((Il2CppObject*)(Type_t *)L_31) == ((Il2CppObject*)(Type_t *)L_32))))
		{
			goto IL_00ce;
		}
	}
	{
		Type_t * L_33 = ___type1;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_34 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Double_t4078015681_0_0_0_var), /*hidden argument*/NULL);
		if ((!(((Il2CppObject*)(Type_t *)L_33) == ((Il2CppObject*)(Type_t *)L_34))))
		{
			goto IL_00b1;
		}
	}
	{
		Il2CppObject * L_35 = ___value0;
		double L_36 = (((double)((double)((*(Il2CppChar*)((Il2CppChar*)UnBox (L_35, Char_t3454481338_il2cpp_TypeInfo_var)))))));
		Il2CppObject * L_37 = Box(Double_t4078015681_il2cpp_TypeInfo_var, &L_36);
		return L_37;
	}

IL_00b1:
	{
		Type_t * L_38 = ___type1;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_39 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Single_t2076509932_0_0_0_var), /*hidden argument*/NULL);
		if ((!(((Il2CppObject*)(Type_t *)L_38) == ((Il2CppObject*)(Type_t *)L_39))))
		{
			goto IL_00ce;
		}
	}
	{
		Il2CppObject * L_40 = ___value0;
		float L_41 = (((float)((float)((*(Il2CppChar*)((Il2CppChar*)UnBox (L_40, Char_t3454481338_il2cpp_TypeInfo_var)))))));
		Il2CppObject * L_42 = Box(Single_t2076509932_il2cpp_TypeInfo_var, &L_41);
		return L_42;
	}

IL_00ce:
	{
		Type_t * L_43 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_44 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(IntPtr_t_0_0_0_var), /*hidden argument*/NULL);
		if ((!(((Il2CppObject*)(Type_t *)L_43) == ((Il2CppObject*)(Type_t *)L_44))))
		{
			goto IL_00eb;
		}
	}
	{
		Type_t * L_45 = ___type1;
		NullCheck(L_45);
		bool L_46 = Type_get_IsPointer_m3832342327(L_45, /*hidden argument*/NULL);
		if (!L_46)
		{
			goto IL_00eb;
		}
	}
	{
		Il2CppObject * L_47 = ___value0;
		return L_47;
	}

IL_00eb:
	{
		Il2CppObject * L_48 = ___value0;
		Type_t * L_49 = ___type1;
		IL2CPP_RUNTIME_CLASS_INIT(Convert_t2607082565_il2cpp_TypeInfo_var);
		Il2CppObject * L_50 = Convert_ChangeType_m1630780412(NULL /*static, unused*/, L_48, L_49, /*hidden argument*/NULL);
		return L_50;
	}

IL_00f3:
	{
		return NULL;
	}
}
// System.Void System.Reflection.Binder/Default::ReorderArgumentArray(System.Object[]&,System.Object)
extern "C"  void Default_ReorderArgumentArray_m3980835731 (Default_t3956931304 * __this, ObjectU5BU5D_t3614634134** ___args0, Il2CppObject * ___state1, const MethodInfo* method)
{
	{
		return;
	}
}
// System.Boolean System.Reflection.Binder/Default::check_type(System.Type,System.Type)
extern const Il2CppType* Nullable_1_t1398937014_0_0_0_var;
extern const Il2CppType* Il2CppObject_0_0_0_var;
extern const Il2CppType* Enum_t2459695545_0_0_0_var;
extern const Il2CppType* IntPtr_t_0_0_0_var;
extern Il2CppClass* Enum_t2459695545_il2cpp_TypeInfo_var;
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern const uint32_t Default_check_type_m2363631305_MetadataUsageId;
extern "C"  bool Default_check_type_m2363631305 (Il2CppObject * __this /* static, unused */, Type_t * ___from0, Type_t * ___to1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Default_check_type_m2363631305_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	int32_t V_3 = 0;
	int32_t G_B28_0 = 0;
	int32_t G_B30_0 = 0;
	int32_t G_B38_0 = 0;
	int32_t G_B40_0 = 0;
	int32_t G_B48_0 = 0;
	int32_t G_B50_0 = 0;
	int32_t G_B58_0 = 0;
	int32_t G_B60_0 = 0;
	int32_t G_B68_0 = 0;
	int32_t G_B70_0 = 0;
	int32_t G_B78_0 = 0;
	int32_t G_B80_0 = 0;
	int32_t G_B89_0 = 0;
	int32_t G_B91_0 = 0;
	int32_t G_B95_0 = 0;
	{
		Type_t * L_0 = ___from0;
		Type_t * L_1 = ___to1;
		if ((!(((Il2CppObject*)(Type_t *)L_0) == ((Il2CppObject*)(Type_t *)L_1))))
		{
			goto IL_0009;
		}
	}
	{
		return (bool)1;
	}

IL_0009:
	{
		Type_t * L_2 = ___from0;
		if (L_2)
		{
			goto IL_0011;
		}
	}
	{
		return (bool)1;
	}

IL_0011:
	{
		Type_t * L_3 = ___to1;
		NullCheck(L_3);
		bool L_4 = Type_get_IsByRef_m3523465500(L_3, /*hidden argument*/NULL);
		Type_t * L_5 = ___from0;
		NullCheck(L_5);
		bool L_6 = Type_get_IsByRef_m3523465500(L_5, /*hidden argument*/NULL);
		if ((((int32_t)L_4) == ((int32_t)L_6)))
		{
			goto IL_0024;
		}
	}
	{
		return (bool)0;
	}

IL_0024:
	{
		Type_t * L_7 = ___to1;
		NullCheck(L_7);
		bool L_8 = Type_get_IsInterface_m3583817465(L_7, /*hidden argument*/NULL);
		if (!L_8)
		{
			goto IL_0037;
		}
	}
	{
		Type_t * L_9 = ___to1;
		Type_t * L_10 = ___from0;
		NullCheck(L_9);
		bool L_11 = VirtFuncInvoker1< bool, Type_t * >::Invoke(40 /* System.Boolean System.Type::IsAssignableFrom(System.Type) */, L_9, L_10);
		return L_11;
	}

IL_0037:
	{
		Type_t * L_12 = ___to1;
		NullCheck(L_12);
		bool L_13 = Type_get_IsEnum_m313908919(L_12, /*hidden argument*/NULL);
		if (!L_13)
		{
			goto IL_0053;
		}
	}
	{
		Type_t * L_14 = ___to1;
		IL2CPP_RUNTIME_CLASS_INIT(Enum_t2459695545_il2cpp_TypeInfo_var);
		Type_t * L_15 = Enum_GetUnderlyingType_m3513899012(NULL /*static, unused*/, L_14, /*hidden argument*/NULL);
		___to1 = L_15;
		Type_t * L_16 = ___from0;
		Type_t * L_17 = ___to1;
		if ((!(((Il2CppObject*)(Type_t *)L_16) == ((Il2CppObject*)(Type_t *)L_17))))
		{
			goto IL_0053;
		}
	}
	{
		return (bool)1;
	}

IL_0053:
	{
		Type_t * L_18 = ___to1;
		NullCheck(L_18);
		bool L_19 = VirtFuncInvoker0< bool >::Invoke(79 /* System.Boolean System.Type::get_IsGenericType() */, L_18);
		if (!L_19)
		{
			goto IL_0083;
		}
	}
	{
		Type_t * L_20 = ___to1;
		NullCheck(L_20);
		Type_t * L_21 = VirtFuncInvoker0< Type_t * >::Invoke(78 /* System.Type System.Type::GetGenericTypeDefinition() */, L_20);
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_22 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Nullable_1_t1398937014_0_0_0_var), /*hidden argument*/NULL);
		if ((!(((Il2CppObject*)(Type_t *)L_21) == ((Il2CppObject*)(Type_t *)L_22))))
		{
			goto IL_0083;
		}
	}
	{
		Type_t * L_23 = ___to1;
		NullCheck(L_23);
		TypeU5BU5D_t1664964607* L_24 = VirtFuncInvoker0< TypeU5BU5D_t1664964607* >::Invoke(75 /* System.Type[] System.Type::GetGenericArguments() */, L_23);
		NullCheck(L_24);
		int32_t L_25 = 0;
		Type_t * L_26 = (L_24)->GetAt(static_cast<il2cpp_array_size_t>(L_25));
		Type_t * L_27 = ___from0;
		if ((!(((Il2CppObject*)(Type_t *)L_26) == ((Il2CppObject*)(Type_t *)L_27))))
		{
			goto IL_0083;
		}
	}
	{
		return (bool)1;
	}

IL_0083:
	{
		Type_t * L_28 = ___from0;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		int32_t L_29 = Type_GetTypeCode_m1044483454(NULL /*static, unused*/, L_28, /*hidden argument*/NULL);
		V_0 = L_29;
		Type_t * L_30 = ___to1;
		int32_t L_31 = Type_GetTypeCode_m1044483454(NULL /*static, unused*/, L_30, /*hidden argument*/NULL);
		V_1 = L_31;
		int32_t L_32 = V_0;
		V_2 = L_32;
		int32_t L_33 = V_2;
		if (((int32_t)((int32_t)L_33-(int32_t)4)) == 0)
		{
			goto IL_00c8;
		}
		if (((int32_t)((int32_t)L_33-(int32_t)4)) == 1)
		{
			goto IL_016f;
		}
		if (((int32_t)((int32_t)L_33-(int32_t)4)) == 2)
		{
			goto IL_0103;
		}
		if (((int32_t)((int32_t)L_33-(int32_t)4)) == 3)
		{
			goto IL_0228;
		}
		if (((int32_t)((int32_t)L_33-(int32_t)4)) == 4)
		{
			goto IL_01cf;
		}
		if (((int32_t)((int32_t)L_33-(int32_t)4)) == 5)
		{
			goto IL_02d2;
		}
		if (((int32_t)((int32_t)L_33-(int32_t)4)) == 6)
		{
			goto IL_0281;
		}
		if (((int32_t)((int32_t)L_33-(int32_t)4)) == 7)
		{
			goto IL_0323;
		}
		if (((int32_t)((int32_t)L_33-(int32_t)4)) == 8)
		{
			goto IL_0323;
		}
		if (((int32_t)((int32_t)L_33-(int32_t)4)) == 9)
		{
			goto IL_036b;
		}
	}
	{
		goto IL_0384;
	}

IL_00c8:
	{
		int32_t L_34 = V_1;
		V_3 = L_34;
		int32_t L_35 = V_3;
		if (((int32_t)((int32_t)L_35-(int32_t)8)) == 0)
		{
			goto IL_00f3;
		}
		if (((int32_t)((int32_t)L_35-(int32_t)8)) == 1)
		{
			goto IL_00f3;
		}
		if (((int32_t)((int32_t)L_35-(int32_t)8)) == 2)
		{
			goto IL_00f3;
		}
		if (((int32_t)((int32_t)L_35-(int32_t)8)) == 3)
		{
			goto IL_00f3;
		}
		if (((int32_t)((int32_t)L_35-(int32_t)8)) == 4)
		{
			goto IL_00f3;
		}
		if (((int32_t)((int32_t)L_35-(int32_t)8)) == 5)
		{
			goto IL_00f3;
		}
		if (((int32_t)((int32_t)L_35-(int32_t)8)) == 6)
		{
			goto IL_00f3;
		}
	}
	{
		goto IL_00f5;
	}

IL_00f3:
	{
		return (bool)1;
	}

IL_00f5:
	{
		Type_t * L_36 = ___to1;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_37 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Il2CppObject_0_0_0_var), /*hidden argument*/NULL);
		return (bool)((((Il2CppObject*)(Type_t *)L_36) == ((Il2CppObject*)(Type_t *)L_37))? 1 : 0);
	}

IL_0103:
	{
		int32_t L_38 = V_1;
		V_3 = L_38;
		int32_t L_39 = V_3;
		if (((int32_t)((int32_t)L_39-(int32_t)4)) == 0)
		{
			goto IL_013e;
		}
		if (((int32_t)((int32_t)L_39-(int32_t)4)) == 1)
		{
			goto IL_0140;
		}
		if (((int32_t)((int32_t)L_39-(int32_t)4)) == 2)
		{
			goto IL_0140;
		}
		if (((int32_t)((int32_t)L_39-(int32_t)4)) == 3)
		{
			goto IL_013e;
		}
		if (((int32_t)((int32_t)L_39-(int32_t)4)) == 4)
		{
			goto IL_013e;
		}
		if (((int32_t)((int32_t)L_39-(int32_t)4)) == 5)
		{
			goto IL_013e;
		}
		if (((int32_t)((int32_t)L_39-(int32_t)4)) == 6)
		{
			goto IL_013e;
		}
		if (((int32_t)((int32_t)L_39-(int32_t)4)) == 7)
		{
			goto IL_013e;
		}
		if (((int32_t)((int32_t)L_39-(int32_t)4)) == 8)
		{
			goto IL_013e;
		}
		if (((int32_t)((int32_t)L_39-(int32_t)4)) == 9)
		{
			goto IL_013e;
		}
		if (((int32_t)((int32_t)L_39-(int32_t)4)) == 10)
		{
			goto IL_013e;
		}
	}
	{
		goto IL_0140;
	}

IL_013e:
	{
		return (bool)1;
	}

IL_0140:
	{
		Type_t * L_40 = ___to1;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_41 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Il2CppObject_0_0_0_var), /*hidden argument*/NULL);
		if ((((Il2CppObject*)(Type_t *)L_40) == ((Il2CppObject*)(Type_t *)L_41)))
		{
			goto IL_016d;
		}
	}
	{
		Type_t * L_42 = ___from0;
		NullCheck(L_42);
		bool L_43 = Type_get_IsEnum_m313908919(L_42, /*hidden argument*/NULL);
		if (!L_43)
		{
			goto IL_016a;
		}
	}
	{
		Type_t * L_44 = ___to1;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_45 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Enum_t2459695545_0_0_0_var), /*hidden argument*/NULL);
		G_B28_0 = ((((Il2CppObject*)(Type_t *)L_44) == ((Il2CppObject*)(Type_t *)L_45))? 1 : 0);
		goto IL_016b;
	}

IL_016a:
	{
		G_B28_0 = 0;
	}

IL_016b:
	{
		G_B30_0 = G_B28_0;
		goto IL_016e;
	}

IL_016d:
	{
		G_B30_0 = 1;
	}

IL_016e:
	{
		return (bool)G_B30_0;
	}

IL_016f:
	{
		int32_t L_46 = V_1;
		V_3 = L_46;
		int32_t L_47 = V_3;
		if (((int32_t)((int32_t)L_47-(int32_t)7)) == 0)
		{
			goto IL_019e;
		}
		if (((int32_t)((int32_t)L_47-(int32_t)7)) == 1)
		{
			goto IL_01a0;
		}
		if (((int32_t)((int32_t)L_47-(int32_t)7)) == 2)
		{
			goto IL_019e;
		}
		if (((int32_t)((int32_t)L_47-(int32_t)7)) == 3)
		{
			goto IL_01a0;
		}
		if (((int32_t)((int32_t)L_47-(int32_t)7)) == 4)
		{
			goto IL_019e;
		}
		if (((int32_t)((int32_t)L_47-(int32_t)7)) == 5)
		{
			goto IL_01a0;
		}
		if (((int32_t)((int32_t)L_47-(int32_t)7)) == 6)
		{
			goto IL_019e;
		}
		if (((int32_t)((int32_t)L_47-(int32_t)7)) == 7)
		{
			goto IL_019e;
		}
	}
	{
		goto IL_01a0;
	}

IL_019e:
	{
		return (bool)1;
	}

IL_01a0:
	{
		Type_t * L_48 = ___to1;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_49 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Il2CppObject_0_0_0_var), /*hidden argument*/NULL);
		if ((((Il2CppObject*)(Type_t *)L_48) == ((Il2CppObject*)(Type_t *)L_49)))
		{
			goto IL_01cd;
		}
	}
	{
		Type_t * L_50 = ___from0;
		NullCheck(L_50);
		bool L_51 = Type_get_IsEnum_m313908919(L_50, /*hidden argument*/NULL);
		if (!L_51)
		{
			goto IL_01ca;
		}
	}
	{
		Type_t * L_52 = ___to1;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_53 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Enum_t2459695545_0_0_0_var), /*hidden argument*/NULL);
		G_B38_0 = ((((Il2CppObject*)(Type_t *)L_52) == ((Il2CppObject*)(Type_t *)L_53))? 1 : 0);
		goto IL_01cb;
	}

IL_01ca:
	{
		G_B38_0 = 0;
	}

IL_01cb:
	{
		G_B40_0 = G_B38_0;
		goto IL_01ce;
	}

IL_01cd:
	{
		G_B40_0 = 1;
	}

IL_01ce:
	{
		return (bool)G_B40_0;
	}

IL_01cf:
	{
		int32_t L_54 = V_1;
		V_3 = L_54;
		int32_t L_55 = V_3;
		if (((int32_t)((int32_t)L_55-(int32_t)((int32_t)9))) == 0)
		{
			goto IL_01f7;
		}
		if (((int32_t)((int32_t)L_55-(int32_t)((int32_t)9))) == 1)
		{
			goto IL_01f7;
		}
		if (((int32_t)((int32_t)L_55-(int32_t)((int32_t)9))) == 2)
		{
			goto IL_01f7;
		}
		if (((int32_t)((int32_t)L_55-(int32_t)((int32_t)9))) == 3)
		{
			goto IL_01f7;
		}
		if (((int32_t)((int32_t)L_55-(int32_t)((int32_t)9))) == 4)
		{
			goto IL_01f7;
		}
		if (((int32_t)((int32_t)L_55-(int32_t)((int32_t)9))) == 5)
		{
			goto IL_01f7;
		}
	}
	{
		goto IL_01f9;
	}

IL_01f7:
	{
		return (bool)1;
	}

IL_01f9:
	{
		Type_t * L_56 = ___to1;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_57 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Il2CppObject_0_0_0_var), /*hidden argument*/NULL);
		if ((((Il2CppObject*)(Type_t *)L_56) == ((Il2CppObject*)(Type_t *)L_57)))
		{
			goto IL_0226;
		}
	}
	{
		Type_t * L_58 = ___from0;
		NullCheck(L_58);
		bool L_59 = Type_get_IsEnum_m313908919(L_58, /*hidden argument*/NULL);
		if (!L_59)
		{
			goto IL_0223;
		}
	}
	{
		Type_t * L_60 = ___to1;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_61 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Enum_t2459695545_0_0_0_var), /*hidden argument*/NULL);
		G_B48_0 = ((((Il2CppObject*)(Type_t *)L_60) == ((Il2CppObject*)(Type_t *)L_61))? 1 : 0);
		goto IL_0224;
	}

IL_0223:
	{
		G_B48_0 = 0;
	}

IL_0224:
	{
		G_B50_0 = G_B48_0;
		goto IL_0227;
	}

IL_0226:
	{
		G_B50_0 = 1;
	}

IL_0227:
	{
		return (bool)G_B50_0;
	}

IL_0228:
	{
		int32_t L_62 = V_1;
		V_3 = L_62;
		int32_t L_63 = V_3;
		if (((int32_t)((int32_t)L_63-(int32_t)((int32_t)9))) == 0)
		{
			goto IL_0250;
		}
		if (((int32_t)((int32_t)L_63-(int32_t)((int32_t)9))) == 1)
		{
			goto IL_0252;
		}
		if (((int32_t)((int32_t)L_63-(int32_t)((int32_t)9))) == 2)
		{
			goto IL_0250;
		}
		if (((int32_t)((int32_t)L_63-(int32_t)((int32_t)9))) == 3)
		{
			goto IL_0252;
		}
		if (((int32_t)((int32_t)L_63-(int32_t)((int32_t)9))) == 4)
		{
			goto IL_0250;
		}
		if (((int32_t)((int32_t)L_63-(int32_t)((int32_t)9))) == 5)
		{
			goto IL_0250;
		}
	}
	{
		goto IL_0252;
	}

IL_0250:
	{
		return (bool)1;
	}

IL_0252:
	{
		Type_t * L_64 = ___to1;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_65 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Il2CppObject_0_0_0_var), /*hidden argument*/NULL);
		if ((((Il2CppObject*)(Type_t *)L_64) == ((Il2CppObject*)(Type_t *)L_65)))
		{
			goto IL_027f;
		}
	}
	{
		Type_t * L_66 = ___from0;
		NullCheck(L_66);
		bool L_67 = Type_get_IsEnum_m313908919(L_66, /*hidden argument*/NULL);
		if (!L_67)
		{
			goto IL_027c;
		}
	}
	{
		Type_t * L_68 = ___to1;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_69 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Enum_t2459695545_0_0_0_var), /*hidden argument*/NULL);
		G_B58_0 = ((((Il2CppObject*)(Type_t *)L_68) == ((Il2CppObject*)(Type_t *)L_69))? 1 : 0);
		goto IL_027d;
	}

IL_027c:
	{
		G_B58_0 = 0;
	}

IL_027d:
	{
		G_B60_0 = G_B58_0;
		goto IL_0280;
	}

IL_027f:
	{
		G_B60_0 = 1;
	}

IL_0280:
	{
		return (bool)G_B60_0;
	}

IL_0281:
	{
		int32_t L_70 = V_1;
		V_3 = L_70;
		int32_t L_71 = V_3;
		if (((int32_t)((int32_t)L_71-(int32_t)((int32_t)11))) == 0)
		{
			goto IL_02a1;
		}
		if (((int32_t)((int32_t)L_71-(int32_t)((int32_t)11))) == 1)
		{
			goto IL_02a1;
		}
		if (((int32_t)((int32_t)L_71-(int32_t)((int32_t)11))) == 2)
		{
			goto IL_02a1;
		}
		if (((int32_t)((int32_t)L_71-(int32_t)((int32_t)11))) == 3)
		{
			goto IL_02a1;
		}
	}
	{
		goto IL_02a3;
	}

IL_02a1:
	{
		return (bool)1;
	}

IL_02a3:
	{
		Type_t * L_72 = ___to1;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_73 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Il2CppObject_0_0_0_var), /*hidden argument*/NULL);
		if ((((Il2CppObject*)(Type_t *)L_72) == ((Il2CppObject*)(Type_t *)L_73)))
		{
			goto IL_02d0;
		}
	}
	{
		Type_t * L_74 = ___from0;
		NullCheck(L_74);
		bool L_75 = Type_get_IsEnum_m313908919(L_74, /*hidden argument*/NULL);
		if (!L_75)
		{
			goto IL_02cd;
		}
	}
	{
		Type_t * L_76 = ___to1;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_77 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Enum_t2459695545_0_0_0_var), /*hidden argument*/NULL);
		G_B68_0 = ((((Il2CppObject*)(Type_t *)L_76) == ((Il2CppObject*)(Type_t *)L_77))? 1 : 0);
		goto IL_02ce;
	}

IL_02cd:
	{
		G_B68_0 = 0;
	}

IL_02ce:
	{
		G_B70_0 = G_B68_0;
		goto IL_02d1;
	}

IL_02d0:
	{
		G_B70_0 = 1;
	}

IL_02d1:
	{
		return (bool)G_B70_0;
	}

IL_02d2:
	{
		int32_t L_78 = V_1;
		V_3 = L_78;
		int32_t L_79 = V_3;
		if (((int32_t)((int32_t)L_79-(int32_t)((int32_t)11))) == 0)
		{
			goto IL_02f2;
		}
		if (((int32_t)((int32_t)L_79-(int32_t)((int32_t)11))) == 1)
		{
			goto IL_02f4;
		}
		if (((int32_t)((int32_t)L_79-(int32_t)((int32_t)11))) == 2)
		{
			goto IL_02f2;
		}
		if (((int32_t)((int32_t)L_79-(int32_t)((int32_t)11))) == 3)
		{
			goto IL_02f2;
		}
	}
	{
		goto IL_02f4;
	}

IL_02f2:
	{
		return (bool)1;
	}

IL_02f4:
	{
		Type_t * L_80 = ___to1;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_81 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Il2CppObject_0_0_0_var), /*hidden argument*/NULL);
		if ((((Il2CppObject*)(Type_t *)L_80) == ((Il2CppObject*)(Type_t *)L_81)))
		{
			goto IL_0321;
		}
	}
	{
		Type_t * L_82 = ___from0;
		NullCheck(L_82);
		bool L_83 = Type_get_IsEnum_m313908919(L_82, /*hidden argument*/NULL);
		if (!L_83)
		{
			goto IL_031e;
		}
	}
	{
		Type_t * L_84 = ___to1;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_85 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Enum_t2459695545_0_0_0_var), /*hidden argument*/NULL);
		G_B78_0 = ((((Il2CppObject*)(Type_t *)L_84) == ((Il2CppObject*)(Type_t *)L_85))? 1 : 0);
		goto IL_031f;
	}

IL_031e:
	{
		G_B78_0 = 0;
	}

IL_031f:
	{
		G_B80_0 = G_B78_0;
		goto IL_0322;
	}

IL_0321:
	{
		G_B80_0 = 1;
	}

IL_0322:
	{
		return (bool)G_B80_0;
	}

IL_0323:
	{
		int32_t L_86 = V_1;
		V_3 = L_86;
		int32_t L_87 = V_3;
		if ((((int32_t)L_87) == ((int32_t)((int32_t)13))))
		{
			goto IL_033a;
		}
	}
	{
		int32_t L_88 = V_3;
		if ((((int32_t)L_88) == ((int32_t)((int32_t)14))))
		{
			goto IL_033a;
		}
	}
	{
		goto IL_033c;
	}

IL_033a:
	{
		return (bool)1;
	}

IL_033c:
	{
		Type_t * L_89 = ___to1;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_90 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Il2CppObject_0_0_0_var), /*hidden argument*/NULL);
		if ((((Il2CppObject*)(Type_t *)L_89) == ((Il2CppObject*)(Type_t *)L_90)))
		{
			goto IL_0369;
		}
	}
	{
		Type_t * L_91 = ___from0;
		NullCheck(L_91);
		bool L_92 = Type_get_IsEnum_m313908919(L_91, /*hidden argument*/NULL);
		if (!L_92)
		{
			goto IL_0366;
		}
	}
	{
		Type_t * L_93 = ___to1;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_94 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Enum_t2459695545_0_0_0_var), /*hidden argument*/NULL);
		G_B89_0 = ((((Il2CppObject*)(Type_t *)L_93) == ((Il2CppObject*)(Type_t *)L_94))? 1 : 0);
		goto IL_0367;
	}

IL_0366:
	{
		G_B89_0 = 0;
	}

IL_0367:
	{
		G_B91_0 = G_B89_0;
		goto IL_036a;
	}

IL_0369:
	{
		G_B91_0 = 1;
	}

IL_036a:
	{
		return (bool)G_B91_0;
	}

IL_036b:
	{
		int32_t L_95 = V_1;
		if ((((int32_t)L_95) == ((int32_t)((int32_t)14))))
		{
			goto IL_0382;
		}
	}
	{
		Type_t * L_96 = ___to1;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_97 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Il2CppObject_0_0_0_var), /*hidden argument*/NULL);
		G_B95_0 = ((((Il2CppObject*)(Type_t *)L_96) == ((Il2CppObject*)(Type_t *)L_97))? 1 : 0);
		goto IL_0383;
	}

IL_0382:
	{
		G_B95_0 = 1;
	}

IL_0383:
	{
		return (bool)G_B95_0;
	}

IL_0384:
	{
		Type_t * L_98 = ___to1;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_99 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Il2CppObject_0_0_0_var), /*hidden argument*/NULL);
		if ((!(((Il2CppObject*)(Type_t *)L_98) == ((Il2CppObject*)(Type_t *)L_99))))
		{
			goto IL_03a1;
		}
	}
	{
		Type_t * L_100 = ___from0;
		NullCheck(L_100);
		bool L_101 = Type_get_IsValueType_m1733572463(L_100, /*hidden argument*/NULL);
		if (!L_101)
		{
			goto IL_03a1;
		}
	}
	{
		return (bool)1;
	}

IL_03a1:
	{
		Type_t * L_102 = ___to1;
		NullCheck(L_102);
		bool L_103 = Type_get_IsPointer_m3832342327(L_102, /*hidden argument*/NULL);
		if (!L_103)
		{
			goto IL_03be;
		}
	}
	{
		Type_t * L_104 = ___from0;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_105 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(IntPtr_t_0_0_0_var), /*hidden argument*/NULL);
		if ((!(((Il2CppObject*)(Type_t *)L_104) == ((Il2CppObject*)(Type_t *)L_105))))
		{
			goto IL_03be;
		}
	}
	{
		return (bool)1;
	}

IL_03be:
	{
		Type_t * L_106 = ___to1;
		Type_t * L_107 = ___from0;
		NullCheck(L_106);
		bool L_108 = VirtFuncInvoker1< bool, Type_t * >::Invoke(40 /* System.Boolean System.Type::IsAssignableFrom(System.Type) */, L_106, L_107);
		return L_108;
	}
}
// System.Boolean System.Reflection.Binder/Default::check_arguments(System.Type[],System.Reflection.ParameterInfo[],System.Boolean)
extern "C"  bool Default_check_arguments_m3406020270 (Il2CppObject * __this /* static, unused */, TypeU5BU5D_t1664964607* ___types0, ParameterInfoU5BU5D_t2275869610* ___args1, bool ___allowByRefMatch2, const MethodInfo* method)
{
	int32_t V_0 = 0;
	bool V_1 = false;
	Type_t * V_2 = NULL;
	{
		V_0 = 0;
		goto IL_0053;
	}

IL_0007:
	{
		TypeU5BU5D_t1664964607* L_0 = ___types0;
		int32_t L_1 = V_0;
		NullCheck(L_0);
		int32_t L_2 = L_1;
		Type_t * L_3 = (L_0)->GetAt(static_cast<il2cpp_array_size_t>(L_2));
		ParameterInfoU5BU5D_t2275869610* L_4 = ___args1;
		int32_t L_5 = V_0;
		NullCheck(L_4);
		int32_t L_6 = L_5;
		ParameterInfo_t2249040075 * L_7 = (L_4)->GetAt(static_cast<il2cpp_array_size_t>(L_6));
		NullCheck(L_7);
		Type_t * L_8 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.ParameterInfo::get_ParameterType() */, L_7);
		bool L_9 = Default_check_type_m2363631305(NULL /*static, unused*/, L_3, L_8, /*hidden argument*/NULL);
		V_1 = L_9;
		bool L_10 = V_1;
		if (L_10)
		{
			goto IL_0047;
		}
	}
	{
		bool L_11 = ___allowByRefMatch2;
		if (!L_11)
		{
			goto IL_0047;
		}
	}
	{
		ParameterInfoU5BU5D_t2275869610* L_12 = ___args1;
		int32_t L_13 = V_0;
		NullCheck(L_12);
		int32_t L_14 = L_13;
		ParameterInfo_t2249040075 * L_15 = (L_12)->GetAt(static_cast<il2cpp_array_size_t>(L_14));
		NullCheck(L_15);
		Type_t * L_16 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.ParameterInfo::get_ParameterType() */, L_15);
		V_2 = L_16;
		Type_t * L_17 = V_2;
		NullCheck(L_17);
		bool L_18 = Type_get_IsByRef_m3523465500(L_17, /*hidden argument*/NULL);
		if (!L_18)
		{
			goto IL_0047;
		}
	}
	{
		TypeU5BU5D_t1664964607* L_19 = ___types0;
		int32_t L_20 = V_0;
		NullCheck(L_19);
		int32_t L_21 = L_20;
		Type_t * L_22 = (L_19)->GetAt(static_cast<il2cpp_array_size_t>(L_21));
		Type_t * L_23 = V_2;
		NullCheck(L_23);
		Type_t * L_24 = VirtFuncInvoker0< Type_t * >::Invoke(42 /* System.Type System.Type::GetElementType() */, L_23);
		bool L_25 = Default_check_type_m2363631305(NULL /*static, unused*/, L_22, L_24, /*hidden argument*/NULL);
		V_1 = L_25;
	}

IL_0047:
	{
		bool L_26 = V_1;
		if (L_26)
		{
			goto IL_004f;
		}
	}
	{
		return (bool)0;
	}

IL_004f:
	{
		int32_t L_27 = V_0;
		V_0 = ((int32_t)((int32_t)L_27+(int32_t)1));
	}

IL_0053:
	{
		int32_t L_28 = V_0;
		TypeU5BU5D_t1664964607* L_29 = ___types0;
		NullCheck(L_29);
		if ((((int32_t)L_28) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_29)->max_length)))))))
		{
			goto IL_0007;
		}
	}
	{
		return (bool)1;
	}
}
// System.Reflection.MethodBase System.Reflection.Binder/Default::SelectMethod(System.Reflection.BindingFlags,System.Reflection.MethodBase[],System.Type[],System.Reflection.ParameterModifier[])
extern "C"  MethodBase_t904190842 * Default_SelectMethod_m622251293 (Default_t3956931304 * __this, int32_t ___bindingAttr0, MethodBaseU5BU5D_t2597254495* ___match1, TypeU5BU5D_t1664964607* ___types2, ParameterModifierU5BU5D_t963192633* ___modifiers3, const MethodInfo* method)
{
	{
		int32_t L_0 = ___bindingAttr0;
		MethodBaseU5BU5D_t2597254495* L_1 = ___match1;
		TypeU5BU5D_t1664964607* L_2 = ___types2;
		ParameterModifierU5BU5D_t963192633* L_3 = ___modifiers3;
		MethodBase_t904190842 * L_4 = Default_SelectMethod_m3081239996(__this, L_0, L_1, L_2, L_3, (bool)0, /*hidden argument*/NULL);
		return L_4;
	}
}
// System.Reflection.MethodBase System.Reflection.Binder/Default::SelectMethod(System.Reflection.BindingFlags,System.Reflection.MethodBase[],System.Type[],System.Reflection.ParameterModifier[],System.Boolean)
extern const Il2CppType* ParamArrayAttribute_t2144993728_0_0_0_var;
extern Il2CppClass* ArgumentNullException_t628810857_il2cpp_TypeInfo_var;
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral3322341559;
extern const uint32_t Default_SelectMethod_m3081239996_MetadataUsageId;
extern "C"  MethodBase_t904190842 * Default_SelectMethod_m3081239996 (Default_t3956931304 * __this, int32_t ___bindingAttr0, MethodBaseU5BU5D_t2597254495* ___match1, TypeU5BU5D_t1664964607* ___types2, ParameterModifierU5BU5D_t963192633* ___modifiers3, bool ___allowByRefMatch4, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Default_SelectMethod_m3081239996_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	MethodBase_t904190842 * V_0 = NULL;
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	ParameterInfoU5BU5D_t2275869610* V_3 = NULL;
	bool V_4 = false;
	Type_t * V_5 = NULL;
	ParameterInfoU5BU5D_t2275869610* V_6 = NULL;
	MethodBase_t904190842 * V_7 = NULL;
	ParameterInfoU5BU5D_t2275869610* V_8 = NULL;
	{
		MethodBaseU5BU5D_t2597254495* L_0 = ___match1;
		if (L_0)
		{
			goto IL_0011;
		}
	}
	{
		ArgumentNullException_t628810857 * L_1 = (ArgumentNullException_t628810857 *)il2cpp_codegen_object_new(ArgumentNullException_t628810857_il2cpp_TypeInfo_var);
		ArgumentNullException__ctor_m3380712306(L_1, _stringLiteral3322341559, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_1);
	}

IL_0011:
	{
		V_1 = 0;
		goto IL_006b;
	}

IL_0018:
	{
		MethodBaseU5BU5D_t2597254495* L_2 = ___match1;
		int32_t L_3 = V_1;
		NullCheck(L_2);
		int32_t L_4 = L_3;
		MethodBase_t904190842 * L_5 = (L_2)->GetAt(static_cast<il2cpp_array_size_t>(L_4));
		V_0 = L_5;
		MethodBase_t904190842 * L_6 = V_0;
		NullCheck(L_6);
		ParameterInfoU5BU5D_t2275869610* L_7 = VirtFuncInvoker0< ParameterInfoU5BU5D_t2275869610* >::Invoke(14 /* System.Reflection.ParameterInfo[] System.Reflection.MethodBase::GetParameters() */, L_6);
		V_3 = L_7;
		ParameterInfoU5BU5D_t2275869610* L_8 = V_3;
		NullCheck(L_8);
		TypeU5BU5D_t1664964607* L_9 = ___types2;
		NullCheck(L_9);
		if ((((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_8)->max_length))))) == ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_9)->max_length)))))))
		{
			goto IL_0033;
		}
	}
	{
		goto IL_0067;
	}

IL_0033:
	{
		V_2 = 0;
		goto IL_0053;
	}

IL_003a:
	{
		TypeU5BU5D_t1664964607* L_10 = ___types2;
		int32_t L_11 = V_2;
		NullCheck(L_10);
		int32_t L_12 = L_11;
		Type_t * L_13 = (L_10)->GetAt(static_cast<il2cpp_array_size_t>(L_12));
		ParameterInfoU5BU5D_t2275869610* L_14 = V_3;
		int32_t L_15 = V_2;
		NullCheck(L_14);
		int32_t L_16 = L_15;
		ParameterInfo_t2249040075 * L_17 = (L_14)->GetAt(static_cast<il2cpp_array_size_t>(L_16));
		NullCheck(L_17);
		Type_t * L_18 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.ParameterInfo::get_ParameterType() */, L_17);
		if ((((Il2CppObject*)(Type_t *)L_13) == ((Il2CppObject*)(Type_t *)L_18)))
		{
			goto IL_004f;
		}
	}
	{
		goto IL_005c;
	}

IL_004f:
	{
		int32_t L_19 = V_2;
		V_2 = ((int32_t)((int32_t)L_19+(int32_t)1));
	}

IL_0053:
	{
		int32_t L_20 = V_2;
		TypeU5BU5D_t1664964607* L_21 = ___types2;
		NullCheck(L_21);
		if ((((int32_t)L_20) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_21)->max_length)))))))
		{
			goto IL_003a;
		}
	}

IL_005c:
	{
		int32_t L_22 = V_2;
		TypeU5BU5D_t1664964607* L_23 = ___types2;
		NullCheck(L_23);
		if ((!(((uint32_t)L_22) == ((uint32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_23)->max_length))))))))
		{
			goto IL_0067;
		}
	}
	{
		MethodBase_t904190842 * L_24 = V_0;
		return L_24;
	}

IL_0067:
	{
		int32_t L_25 = V_1;
		V_1 = ((int32_t)((int32_t)L_25+(int32_t)1));
	}

IL_006b:
	{
		int32_t L_26 = V_1;
		MethodBaseU5BU5D_t2597254495* L_27 = ___match1;
		NullCheck(L_27);
		if ((((int32_t)L_26) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_27)->max_length)))))))
		{
			goto IL_0018;
		}
	}
	{
		V_4 = (bool)0;
		V_5 = (Type_t *)NULL;
		V_1 = 0;
		goto IL_0147;
	}

IL_0081:
	{
		MethodBaseU5BU5D_t2597254495* L_28 = ___match1;
		int32_t L_29 = V_1;
		NullCheck(L_28);
		int32_t L_30 = L_29;
		MethodBase_t904190842 * L_31 = (L_28)->GetAt(static_cast<il2cpp_array_size_t>(L_30));
		V_0 = L_31;
		MethodBase_t904190842 * L_32 = V_0;
		NullCheck(L_32);
		ParameterInfoU5BU5D_t2275869610* L_33 = VirtFuncInvoker0< ParameterInfoU5BU5D_t2275869610* >::Invoke(14 /* System.Reflection.ParameterInfo[] System.Reflection.MethodBase::GetParameters() */, L_32);
		V_6 = L_33;
		ParameterInfoU5BU5D_t2275869610* L_34 = V_6;
		NullCheck(L_34);
		TypeU5BU5D_t1664964607* L_35 = ___types2;
		NullCheck(L_35);
		if ((((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_34)->max_length))))) <= ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_35)->max_length)))))))
		{
			goto IL_009e;
		}
	}
	{
		goto IL_0143;
	}

IL_009e:
	{
		ParameterInfoU5BU5D_t2275869610* L_36 = V_6;
		NullCheck(L_36);
		if ((((int32_t)((int32_t)(((Il2CppArray *)L_36)->max_length)))))
		{
			goto IL_00ac;
		}
	}
	{
		goto IL_0143;
	}

IL_00ac:
	{
		ParameterInfoU5BU5D_t2275869610* L_37 = V_6;
		ParameterInfoU5BU5D_t2275869610* L_38 = V_6;
		NullCheck(L_38);
		NullCheck(L_37);
		int32_t L_39 = ((int32_t)((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_38)->max_length))))-(int32_t)1));
		ParameterInfo_t2249040075 * L_40 = (L_37)->GetAt(static_cast<il2cpp_array_size_t>(L_39));
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_41 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(ParamArrayAttribute_t2144993728_0_0_0_var), /*hidden argument*/NULL);
		bool L_42 = Attribute_IsDefined_m2186700650(NULL /*static, unused*/, L_40, L_41, /*hidden argument*/NULL);
		V_4 = L_42;
		bool L_43 = V_4;
		if (L_43)
		{
			goto IL_00d2;
		}
	}
	{
		goto IL_0143;
	}

IL_00d2:
	{
		ParameterInfoU5BU5D_t2275869610* L_44 = V_6;
		ParameterInfoU5BU5D_t2275869610* L_45 = V_6;
		NullCheck(L_45);
		NullCheck(L_44);
		int32_t L_46 = ((int32_t)((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_45)->max_length))))-(int32_t)1));
		ParameterInfo_t2249040075 * L_47 = (L_44)->GetAt(static_cast<il2cpp_array_size_t>(L_46));
		NullCheck(L_47);
		Type_t * L_48 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.ParameterInfo::get_ParameterType() */, L_47);
		NullCheck(L_48);
		Type_t * L_49 = VirtFuncInvoker0< Type_t * >::Invoke(42 /* System.Type System.Type::GetElementType() */, L_48);
		V_5 = L_49;
		V_2 = 0;
		goto IL_012f;
	}

IL_00ee:
	{
		int32_t L_50 = V_2;
		ParameterInfoU5BU5D_t2275869610* L_51 = V_6;
		NullCheck(L_51);
		if ((((int32_t)L_50) >= ((int32_t)((int32_t)((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_51)->max_length))))-(int32_t)1)))))
		{
			goto IL_0110;
		}
	}
	{
		TypeU5BU5D_t1664964607* L_52 = ___types2;
		int32_t L_53 = V_2;
		NullCheck(L_52);
		int32_t L_54 = L_53;
		Type_t * L_55 = (L_52)->GetAt(static_cast<il2cpp_array_size_t>(L_54));
		ParameterInfoU5BU5D_t2275869610* L_56 = V_6;
		int32_t L_57 = V_2;
		NullCheck(L_56);
		int32_t L_58 = L_57;
		ParameterInfo_t2249040075 * L_59 = (L_56)->GetAt(static_cast<il2cpp_array_size_t>(L_58));
		NullCheck(L_59);
		Type_t * L_60 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.ParameterInfo::get_ParameterType() */, L_59);
		if ((((Il2CppObject*)(Type_t *)L_55) == ((Il2CppObject*)(Type_t *)L_60)))
		{
			goto IL_0110;
		}
	}
	{
		goto IL_0138;
	}

IL_0110:
	{
		int32_t L_61 = V_2;
		ParameterInfoU5BU5D_t2275869610* L_62 = V_6;
		NullCheck(L_62);
		if ((((int32_t)L_61) < ((int32_t)((int32_t)((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_62)->max_length))))-(int32_t)1)))))
		{
			goto IL_012b;
		}
	}
	{
		TypeU5BU5D_t1664964607* L_63 = ___types2;
		int32_t L_64 = V_2;
		NullCheck(L_63);
		int32_t L_65 = L_64;
		Type_t * L_66 = (L_63)->GetAt(static_cast<il2cpp_array_size_t>(L_65));
		Type_t * L_67 = V_5;
		if ((((Il2CppObject*)(Type_t *)L_66) == ((Il2CppObject*)(Type_t *)L_67)))
		{
			goto IL_012b;
		}
	}
	{
		goto IL_0138;
	}

IL_012b:
	{
		int32_t L_68 = V_2;
		V_2 = ((int32_t)((int32_t)L_68+(int32_t)1));
	}

IL_012f:
	{
		int32_t L_69 = V_2;
		TypeU5BU5D_t1664964607* L_70 = ___types2;
		NullCheck(L_70);
		if ((((int32_t)L_69) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_70)->max_length)))))))
		{
			goto IL_00ee;
		}
	}

IL_0138:
	{
		int32_t L_71 = V_2;
		TypeU5BU5D_t1664964607* L_72 = ___types2;
		NullCheck(L_72);
		if ((!(((uint32_t)L_71) == ((uint32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_72)->max_length))))))))
		{
			goto IL_0143;
		}
	}
	{
		MethodBase_t904190842 * L_73 = V_0;
		return L_73;
	}

IL_0143:
	{
		int32_t L_74 = V_1;
		V_1 = ((int32_t)((int32_t)L_74+(int32_t)1));
	}

IL_0147:
	{
		int32_t L_75 = V_1;
		MethodBaseU5BU5D_t2597254495* L_76 = ___match1;
		NullCheck(L_76);
		if ((((int32_t)L_75) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_76)->max_length)))))))
		{
			goto IL_0081;
		}
	}
	{
		int32_t L_77 = ___bindingAttr0;
		if (!((int32_t)((int32_t)L_77&(int32_t)((int32_t)65536))))
		{
			goto IL_015e;
		}
	}
	{
		return (MethodBase_t904190842 *)NULL;
	}

IL_015e:
	{
		V_7 = (MethodBase_t904190842 *)NULL;
		V_1 = 0;
		goto IL_01b8;
	}

IL_0168:
	{
		MethodBaseU5BU5D_t2597254495* L_78 = ___match1;
		int32_t L_79 = V_1;
		NullCheck(L_78);
		int32_t L_80 = L_79;
		MethodBase_t904190842 * L_81 = (L_78)->GetAt(static_cast<il2cpp_array_size_t>(L_80));
		V_0 = L_81;
		MethodBase_t904190842 * L_82 = V_0;
		NullCheck(L_82);
		ParameterInfoU5BU5D_t2275869610* L_83 = VirtFuncInvoker0< ParameterInfoU5BU5D_t2275869610* >::Invoke(14 /* System.Reflection.ParameterInfo[] System.Reflection.MethodBase::GetParameters() */, L_82);
		V_8 = L_83;
		ParameterInfoU5BU5D_t2275869610* L_84 = V_8;
		NullCheck(L_84);
		TypeU5BU5D_t1664964607* L_85 = ___types2;
		NullCheck(L_85);
		if ((((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_84)->max_length))))) == ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_85)->max_length)))))))
		{
			goto IL_0185;
		}
	}
	{
		goto IL_01b4;
	}

IL_0185:
	{
		TypeU5BU5D_t1664964607* L_86 = ___types2;
		ParameterInfoU5BU5D_t2275869610* L_87 = V_8;
		bool L_88 = ___allowByRefMatch4;
		bool L_89 = Default_check_arguments_m3406020270(NULL /*static, unused*/, L_86, L_87, L_88, /*hidden argument*/NULL);
		if (L_89)
		{
			goto IL_0199;
		}
	}
	{
		goto IL_01b4;
	}

IL_0199:
	{
		MethodBase_t904190842 * L_90 = V_7;
		if (!L_90)
		{
			goto IL_01b1;
		}
	}
	{
		MethodBase_t904190842 * L_91 = V_7;
		MethodBase_t904190842 * L_92 = V_0;
		TypeU5BU5D_t1664964607* L_93 = ___types2;
		MethodBase_t904190842 * L_94 = Default_GetBetterMethod_m4255740863(__this, L_91, L_92, L_93, /*hidden argument*/NULL);
		V_7 = L_94;
		goto IL_01b4;
	}

IL_01b1:
	{
		MethodBase_t904190842 * L_95 = V_0;
		V_7 = L_95;
	}

IL_01b4:
	{
		int32_t L_96 = V_1;
		V_1 = ((int32_t)((int32_t)L_96+(int32_t)1));
	}

IL_01b8:
	{
		int32_t L_97 = V_1;
		MethodBaseU5BU5D_t2597254495* L_98 = ___match1;
		NullCheck(L_98);
		if ((((int32_t)L_97) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_98)->max_length)))))))
		{
			goto IL_0168;
		}
	}
	{
		MethodBase_t904190842 * L_99 = V_7;
		return L_99;
	}
}
// System.Reflection.MethodBase System.Reflection.Binder/Default::GetBetterMethod(System.Reflection.MethodBase,System.Reflection.MethodBase,System.Type[])
extern Il2CppClass* AmbiguousMatchException_t1406414556_il2cpp_TypeInfo_var;
extern const uint32_t Default_GetBetterMethod_m4255740863_MetadataUsageId;
extern "C"  MethodBase_t904190842 * Default_GetBetterMethod_m4255740863 (Default_t3956931304 * __this, MethodBase_t904190842 * ___m10, MethodBase_t904190842 * ___m21, TypeU5BU5D_t1664964607* ___types2, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Default_GetBetterMethod_m4255740863_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ParameterInfoU5BU5D_t2275869610* V_0 = NULL;
	ParameterInfoU5BU5D_t2275869610* V_1 = NULL;
	int32_t V_2 = 0;
	int32_t V_3 = 0;
	int32_t V_4 = 0;
	Type_t * V_5 = NULL;
	Type_t * V_6 = NULL;
	bool V_7 = false;
	bool V_8 = false;
	MethodBase_t904190842 * G_B19_0 = NULL;
	{
		MethodBase_t904190842 * L_0 = ___m10;
		NullCheck(L_0);
		bool L_1 = VirtFuncInvoker0< bool >::Invoke(28 /* System.Boolean System.Reflection.MethodBase::get_IsGenericMethodDefinition() */, L_0);
		if (!L_1)
		{
			goto IL_0018;
		}
	}
	{
		MethodBase_t904190842 * L_2 = ___m21;
		NullCheck(L_2);
		bool L_3 = VirtFuncInvoker0< bool >::Invoke(28 /* System.Boolean System.Reflection.MethodBase::get_IsGenericMethodDefinition() */, L_2);
		if (L_3)
		{
			goto IL_0018;
		}
	}
	{
		MethodBase_t904190842 * L_4 = ___m21;
		return L_4;
	}

IL_0018:
	{
		MethodBase_t904190842 * L_5 = ___m21;
		NullCheck(L_5);
		bool L_6 = VirtFuncInvoker0< bool >::Invoke(28 /* System.Boolean System.Reflection.MethodBase::get_IsGenericMethodDefinition() */, L_5);
		if (!L_6)
		{
			goto IL_0030;
		}
	}
	{
		MethodBase_t904190842 * L_7 = ___m10;
		NullCheck(L_7);
		bool L_8 = VirtFuncInvoker0< bool >::Invoke(28 /* System.Boolean System.Reflection.MethodBase::get_IsGenericMethodDefinition() */, L_7);
		if (L_8)
		{
			goto IL_0030;
		}
	}
	{
		MethodBase_t904190842 * L_9 = ___m10;
		return L_9;
	}

IL_0030:
	{
		MethodBase_t904190842 * L_10 = ___m10;
		NullCheck(L_10);
		ParameterInfoU5BU5D_t2275869610* L_11 = VirtFuncInvoker0< ParameterInfoU5BU5D_t2275869610* >::Invoke(14 /* System.Reflection.ParameterInfo[] System.Reflection.MethodBase::GetParameters() */, L_10);
		V_0 = L_11;
		MethodBase_t904190842 * L_12 = ___m21;
		NullCheck(L_12);
		ParameterInfoU5BU5D_t2275869610* L_13 = VirtFuncInvoker0< ParameterInfoU5BU5D_t2275869610* >::Invoke(14 /* System.Reflection.ParameterInfo[] System.Reflection.MethodBase::GetParameters() */, L_12);
		V_1 = L_13;
		V_2 = 0;
		V_3 = 0;
		goto IL_0088;
	}

IL_0047:
	{
		ParameterInfoU5BU5D_t2275869610* L_14 = V_0;
		int32_t L_15 = V_3;
		NullCheck(L_14);
		int32_t L_16 = L_15;
		ParameterInfo_t2249040075 * L_17 = (L_14)->GetAt(static_cast<il2cpp_array_size_t>(L_16));
		NullCheck(L_17);
		Type_t * L_18 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.ParameterInfo::get_ParameterType() */, L_17);
		ParameterInfoU5BU5D_t2275869610* L_19 = V_1;
		int32_t L_20 = V_3;
		NullCheck(L_19);
		int32_t L_21 = L_20;
		ParameterInfo_t2249040075 * L_22 = (L_19)->GetAt(static_cast<il2cpp_array_size_t>(L_21));
		NullCheck(L_22);
		Type_t * L_23 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.ParameterInfo::get_ParameterType() */, L_22);
		int32_t L_24 = Default_CompareCloserType_m1367126249(__this, L_18, L_23, /*hidden argument*/NULL);
		V_4 = L_24;
		int32_t L_25 = V_4;
		if (!L_25)
		{
			goto IL_007a;
		}
	}
	{
		int32_t L_26 = V_2;
		if (!L_26)
		{
			goto IL_007a;
		}
	}
	{
		int32_t L_27 = V_2;
		int32_t L_28 = V_4;
		if ((((int32_t)L_27) == ((int32_t)L_28)))
		{
			goto IL_007a;
		}
	}
	{
		AmbiguousMatchException_t1406414556 * L_29 = (AmbiguousMatchException_t1406414556 *)il2cpp_codegen_object_new(AmbiguousMatchException_t1406414556_il2cpp_TypeInfo_var);
		AmbiguousMatchException__ctor_m2088048346(L_29, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_29);
	}

IL_007a:
	{
		int32_t L_30 = V_4;
		if (!L_30)
		{
			goto IL_0084;
		}
	}
	{
		int32_t L_31 = V_4;
		V_2 = L_31;
	}

IL_0084:
	{
		int32_t L_32 = V_3;
		V_3 = ((int32_t)((int32_t)L_32+(int32_t)1));
	}

IL_0088:
	{
		int32_t L_33 = V_3;
		ParameterInfoU5BU5D_t2275869610* L_34 = V_0;
		NullCheck(L_34);
		if ((((int32_t)L_33) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_34)->max_length)))))))
		{
			goto IL_0047;
		}
	}
	{
		int32_t L_35 = V_2;
		if (!L_35)
		{
			goto IL_00a6;
		}
	}
	{
		int32_t L_36 = V_2;
		if ((((int32_t)L_36) <= ((int32_t)0)))
		{
			goto IL_00a4;
		}
	}
	{
		MethodBase_t904190842 * L_37 = ___m21;
		G_B19_0 = L_37;
		goto IL_00a5;
	}

IL_00a4:
	{
		MethodBase_t904190842 * L_38 = ___m10;
		G_B19_0 = L_38;
	}

IL_00a5:
	{
		return G_B19_0;
	}

IL_00a6:
	{
		MethodBase_t904190842 * L_39 = ___m10;
		NullCheck(L_39);
		Type_t * L_40 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.MemberInfo::get_DeclaringType() */, L_39);
		V_5 = L_40;
		MethodBase_t904190842 * L_41 = ___m21;
		NullCheck(L_41);
		Type_t * L_42 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.MemberInfo::get_DeclaringType() */, L_41);
		V_6 = L_42;
		Type_t * L_43 = V_5;
		Type_t * L_44 = V_6;
		if ((((Il2CppObject*)(Type_t *)L_43) == ((Il2CppObject*)(Type_t *)L_44)))
		{
			goto IL_00df;
		}
	}
	{
		Type_t * L_45 = V_5;
		Type_t * L_46 = V_6;
		NullCheck(L_45);
		bool L_47 = VirtFuncInvoker1< bool, Type_t * >::Invoke(38 /* System.Boolean System.Type::IsSubclassOf(System.Type) */, L_45, L_46);
		if (!L_47)
		{
			goto IL_00cf;
		}
	}
	{
		MethodBase_t904190842 * L_48 = ___m10;
		return L_48;
	}

IL_00cf:
	{
		Type_t * L_49 = V_6;
		Type_t * L_50 = V_5;
		NullCheck(L_49);
		bool L_51 = VirtFuncInvoker1< bool, Type_t * >::Invoke(38 /* System.Boolean System.Type::IsSubclassOf(System.Type) */, L_49, L_50);
		if (!L_51)
		{
			goto IL_00df;
		}
	}
	{
		MethodBase_t904190842 * L_52 = ___m21;
		return L_52;
	}

IL_00df:
	{
		MethodBase_t904190842 * L_53 = ___m10;
		NullCheck(L_53);
		int32_t L_54 = VirtFuncInvoker0< int32_t >::Invoke(20 /* System.Reflection.CallingConventions System.Reflection.MethodBase::get_CallingConvention() */, L_53);
		V_7 = (bool)((((int32_t)((((int32_t)((int32_t)((int32_t)L_54&(int32_t)2))) == ((int32_t)0))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		MethodBase_t904190842 * L_55 = ___m21;
		NullCheck(L_55);
		int32_t L_56 = VirtFuncInvoker0< int32_t >::Invoke(20 /* System.Reflection.CallingConventions System.Reflection.MethodBase::get_CallingConvention() */, L_55);
		V_8 = (bool)((((int32_t)((((int32_t)((int32_t)((int32_t)L_56&(int32_t)2))) == ((int32_t)0))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		bool L_57 = V_7;
		if (!L_57)
		{
			goto IL_010f;
		}
	}
	{
		bool L_58 = V_8;
		if (L_58)
		{
			goto IL_010f;
		}
	}
	{
		MethodBase_t904190842 * L_59 = ___m21;
		return L_59;
	}

IL_010f:
	{
		bool L_60 = V_8;
		if (!L_60)
		{
			goto IL_011f;
		}
	}
	{
		bool L_61 = V_7;
		if (L_61)
		{
			goto IL_011f;
		}
	}
	{
		MethodBase_t904190842 * L_62 = ___m10;
		return L_62;
	}

IL_011f:
	{
		AmbiguousMatchException_t1406414556 * L_63 = (AmbiguousMatchException_t1406414556 *)il2cpp_codegen_object_new(AmbiguousMatchException_t1406414556_il2cpp_TypeInfo_var);
		AmbiguousMatchException__ctor_m2088048346(L_63, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_63);
	}
}
// System.Int32 System.Reflection.Binder/Default::CompareCloserType(System.Type,System.Type)
extern const MethodInfo* Array_IndexOf_TisType_t_m4216821136_MethodInfo_var;
extern const uint32_t Default_CompareCloserType_m1367126249_MetadataUsageId;
extern "C"  int32_t Default_CompareCloserType_m1367126249 (Default_t3956931304 * __this, Type_t * ___t10, Type_t * ___t21, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Default_CompareCloserType_m1367126249_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Type_t * L_0 = ___t10;
		Type_t * L_1 = ___t21;
		if ((!(((Il2CppObject*)(Type_t *)L_0) == ((Il2CppObject*)(Type_t *)L_1))))
		{
			goto IL_0009;
		}
	}
	{
		return 0;
	}

IL_0009:
	{
		Type_t * L_2 = ___t10;
		NullCheck(L_2);
		bool L_3 = VirtFuncInvoker0< bool >::Invoke(81 /* System.Boolean System.Type::get_IsGenericParameter() */, L_2);
		if (!L_3)
		{
			goto IL_0021;
		}
	}
	{
		Type_t * L_4 = ___t21;
		NullCheck(L_4);
		bool L_5 = VirtFuncInvoker0< bool >::Invoke(81 /* System.Boolean System.Type::get_IsGenericParameter() */, L_4);
		if (L_5)
		{
			goto IL_0021;
		}
	}
	{
		return 1;
	}

IL_0021:
	{
		Type_t * L_6 = ___t10;
		NullCheck(L_6);
		bool L_7 = VirtFuncInvoker0< bool >::Invoke(81 /* System.Boolean System.Type::get_IsGenericParameter() */, L_6);
		if (L_7)
		{
			goto IL_0039;
		}
	}
	{
		Type_t * L_8 = ___t21;
		NullCheck(L_8);
		bool L_9 = VirtFuncInvoker0< bool >::Invoke(81 /* System.Boolean System.Type::get_IsGenericParameter() */, L_8);
		if (!L_9)
		{
			goto IL_0039;
		}
	}
	{
		return (-1);
	}

IL_0039:
	{
		Type_t * L_10 = ___t10;
		NullCheck(L_10);
		bool L_11 = Type_get_HasElementType_m3319917896(L_10, /*hidden argument*/NULL);
		if (!L_11)
		{
			goto IL_0062;
		}
	}
	{
		Type_t * L_12 = ___t21;
		NullCheck(L_12);
		bool L_13 = Type_get_HasElementType_m3319917896(L_12, /*hidden argument*/NULL);
		if (!L_13)
		{
			goto IL_0062;
		}
	}
	{
		Type_t * L_14 = ___t10;
		NullCheck(L_14);
		Type_t * L_15 = VirtFuncInvoker0< Type_t * >::Invoke(42 /* System.Type System.Type::GetElementType() */, L_14);
		Type_t * L_16 = ___t21;
		NullCheck(L_16);
		Type_t * L_17 = VirtFuncInvoker0< Type_t * >::Invoke(42 /* System.Type System.Type::GetElementType() */, L_16);
		int32_t L_18 = Default_CompareCloserType_m1367126249(__this, L_15, L_17, /*hidden argument*/NULL);
		return L_18;
	}

IL_0062:
	{
		Type_t * L_19 = ___t10;
		Type_t * L_20 = ___t21;
		NullCheck(L_19);
		bool L_21 = VirtFuncInvoker1< bool, Type_t * >::Invoke(38 /* System.Boolean System.Type::IsSubclassOf(System.Type) */, L_19, L_20);
		if (!L_21)
		{
			goto IL_0070;
		}
	}
	{
		return (-1);
	}

IL_0070:
	{
		Type_t * L_22 = ___t21;
		Type_t * L_23 = ___t10;
		NullCheck(L_22);
		bool L_24 = VirtFuncInvoker1< bool, Type_t * >::Invoke(38 /* System.Boolean System.Type::IsSubclassOf(System.Type) */, L_22, L_23);
		if (!L_24)
		{
			goto IL_007e;
		}
	}
	{
		return 1;
	}

IL_007e:
	{
		Type_t * L_25 = ___t10;
		NullCheck(L_25);
		bool L_26 = Type_get_IsInterface_m3583817465(L_25, /*hidden argument*/NULL);
		if (!L_26)
		{
			goto IL_009d;
		}
	}
	{
		Type_t * L_27 = ___t21;
		NullCheck(L_27);
		TypeU5BU5D_t1664964607* L_28 = VirtFuncInvoker0< TypeU5BU5D_t1664964607* >::Invoke(39 /* System.Type[] System.Type::GetInterfaces() */, L_27);
		Type_t * L_29 = ___t10;
		int32_t L_30 = Array_IndexOf_TisType_t_m4216821136(NULL /*static, unused*/, L_28, L_29, /*hidden argument*/Array_IndexOf_TisType_t_m4216821136_MethodInfo_var);
		if ((((int32_t)L_30) < ((int32_t)0)))
		{
			goto IL_009d;
		}
	}
	{
		return 1;
	}

IL_009d:
	{
		Type_t * L_31 = ___t21;
		NullCheck(L_31);
		bool L_32 = Type_get_IsInterface_m3583817465(L_31, /*hidden argument*/NULL);
		if (!L_32)
		{
			goto IL_00bc;
		}
	}
	{
		Type_t * L_33 = ___t10;
		NullCheck(L_33);
		TypeU5BU5D_t1664964607* L_34 = VirtFuncInvoker0< TypeU5BU5D_t1664964607* >::Invoke(39 /* System.Type[] System.Type::GetInterfaces() */, L_33);
		Type_t * L_35 = ___t21;
		int32_t L_36 = Array_IndexOf_TisType_t_m4216821136(NULL /*static, unused*/, L_34, L_35, /*hidden argument*/Array_IndexOf_TisType_t_m4216821136_MethodInfo_var);
		if ((((int32_t)L_36) < ((int32_t)0)))
		{
			goto IL_00bc;
		}
	}
	{
		return (-1);
	}

IL_00bc:
	{
		return 0;
	}
}
// System.Reflection.PropertyInfo System.Reflection.Binder/Default::SelectProperty(System.Reflection.BindingFlags,System.Reflection.PropertyInfo[],System.Type,System.Type[],System.Reflection.ParameterModifier[])
extern Il2CppClass* ArgumentException_t3259014390_il2cpp_TypeInfo_var;
extern Il2CppClass* Binder_t3404612058_il2cpp_TypeInfo_var;
extern Il2CppClass* AmbiguousMatchException_t1406414556_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral2103942763;
extern Il2CppCodeGenString* _stringLiteral3322341559;
extern const uint32_t Default_SelectProperty_m4154143536_MetadataUsageId;
extern "C"  PropertyInfo_t * Default_SelectProperty_m4154143536 (Default_t3956931304 * __this, int32_t ___bindingAttr0, PropertyInfoU5BU5D_t1736152084* ___match1, Type_t * ___returnType2, TypeU5BU5D_t1664964607* ___indexes3, ParameterModifierU5BU5D_t963192633* ___modifiers4, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Default_SelectProperty_m4154143536_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	bool V_0 = false;
	int32_t V_1 = 0;
	PropertyInfo_t * V_2 = NULL;
	int32_t V_3 = 0;
	int32_t V_4 = 0;
	int32_t V_5 = 0;
	int32_t V_6 = 0;
	PropertyInfo_t * V_7 = NULL;
	ParameterInfoU5BU5D_t2275869610* V_8 = NULL;
	int32_t V_9 = 0;
	int32_t V_10 = 0;
	int32_t G_B6_0 = 0;
	{
		PropertyInfoU5BU5D_t1736152084* L_0 = ___match1;
		if (!L_0)
		{
			goto IL_000e;
		}
	}
	{
		PropertyInfoU5BU5D_t1736152084* L_1 = ___match1;
		NullCheck(L_1);
		if ((((int32_t)((int32_t)(((Il2CppArray *)L_1)->max_length)))))
		{
			goto IL_001e;
		}
	}

IL_000e:
	{
		ArgumentException_t3259014390 * L_2 = (ArgumentException_t3259014390 *)il2cpp_codegen_object_new(ArgumentException_t3259014390_il2cpp_TypeInfo_var);
		ArgumentException__ctor_m544251339(L_2, _stringLiteral2103942763, _stringLiteral3322341559, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_2);
	}

IL_001e:
	{
		Type_t * L_3 = ___returnType2;
		V_0 = (bool)((((int32_t)((((Il2CppObject*)(Type_t *)L_3) == ((Il2CppObject*)(Il2CppObject *)NULL))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		TypeU5BU5D_t1664964607* L_4 = ___indexes3;
		if (!L_4)
		{
			goto IL_0036;
		}
	}
	{
		TypeU5BU5D_t1664964607* L_5 = ___indexes3;
		NullCheck(L_5);
		G_B6_0 = (((int32_t)((int32_t)(((Il2CppArray *)L_5)->max_length))));
		goto IL_0037;
	}

IL_0036:
	{
		G_B6_0 = (-1);
	}

IL_0037:
	{
		V_1 = G_B6_0;
		V_2 = (PropertyInfo_t *)NULL;
		V_4 = ((int32_t)2147483646);
		V_5 = ((int32_t)2147483647LL);
		V_6 = 0;
		PropertyInfoU5BU5D_t1736152084* L_6 = ___match1;
		NullCheck(L_6);
		V_3 = ((int32_t)((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_6)->max_length))))-(int32_t)1));
		goto IL_0112;
	}

IL_0056:
	{
		PropertyInfoU5BU5D_t1736152084* L_7 = ___match1;
		int32_t L_8 = V_3;
		NullCheck(L_7);
		int32_t L_9 = L_8;
		PropertyInfo_t * L_10 = (L_7)->GetAt(static_cast<il2cpp_array_size_t>(L_9));
		V_7 = L_10;
		PropertyInfo_t * L_11 = V_7;
		NullCheck(L_11);
		ParameterInfoU5BU5D_t2275869610* L_12 = VirtFuncInvoker0< ParameterInfoU5BU5D_t2275869610* >::Invoke(20 /* System.Reflection.ParameterInfo[] System.Reflection.PropertyInfo::GetIndexParameters() */, L_11);
		V_8 = L_12;
		int32_t L_13 = V_1;
		if ((((int32_t)L_13) < ((int32_t)0)))
		{
			goto IL_007a;
		}
	}
	{
		int32_t L_14 = V_1;
		ParameterInfoU5BU5D_t2275869610* L_15 = V_8;
		NullCheck(L_15);
		if ((((int32_t)L_14) == ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_15)->max_length)))))))
		{
			goto IL_007a;
		}
	}
	{
		goto IL_010e;
	}

IL_007a:
	{
		bool L_16 = V_0;
		if (!L_16)
		{
			goto IL_0092;
		}
	}
	{
		PropertyInfo_t * L_17 = V_7;
		NullCheck(L_17);
		Type_t * L_18 = VirtFuncInvoker0< Type_t * >::Invoke(17 /* System.Type System.Reflection.PropertyInfo::get_PropertyType() */, L_17);
		Type_t * L_19 = ___returnType2;
		if ((((Il2CppObject*)(Type_t *)L_18) == ((Il2CppObject*)(Type_t *)L_19)))
		{
			goto IL_0092;
		}
	}
	{
		goto IL_010e;
	}

IL_0092:
	{
		V_9 = ((int32_t)2147483646);
		int32_t L_20 = V_1;
		if ((((int32_t)L_20) <= ((int32_t)0)))
		{
			goto IL_00b8;
		}
	}
	{
		TypeU5BU5D_t1664964607* L_21 = ___indexes3;
		ParameterInfoU5BU5D_t2275869610* L_22 = V_8;
		int32_t L_23 = Default_check_arguments_with_score_m1714931543(NULL /*static, unused*/, L_21, L_22, /*hidden argument*/NULL);
		V_9 = L_23;
		int32_t L_24 = V_9;
		if ((!(((uint32_t)L_24) == ((uint32_t)(-1)))))
		{
			goto IL_00b8;
		}
	}
	{
		goto IL_010e;
	}

IL_00b8:
	{
		PropertyInfo_t * L_25 = V_7;
		NullCheck(L_25);
		Type_t * L_26 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.MemberInfo::get_DeclaringType() */, L_25);
		IL2CPP_RUNTIME_CLASS_INIT(Binder_t3404612058_il2cpp_TypeInfo_var);
		int32_t L_27 = Binder_GetDerivedLevel_m1809808744(NULL /*static, unused*/, L_26, /*hidden argument*/NULL);
		V_10 = L_27;
		PropertyInfo_t * L_28 = V_2;
		if (!L_28)
		{
			goto IL_0103;
		}
	}
	{
		int32_t L_29 = V_4;
		int32_t L_30 = V_9;
		if ((((int32_t)L_29) >= ((int32_t)L_30)))
		{
			goto IL_00da;
		}
	}
	{
		goto IL_010e;
	}

IL_00da:
	{
		int32_t L_31 = V_4;
		int32_t L_32 = V_9;
		if ((!(((uint32_t)L_31) == ((uint32_t)L_32))))
		{
			goto IL_0103;
		}
	}
	{
		int32_t L_33 = V_6;
		int32_t L_34 = V_10;
		if ((!(((uint32_t)L_33) == ((uint32_t)L_34))))
		{
			goto IL_00f5;
		}
	}
	{
		int32_t L_35 = V_9;
		V_5 = L_35;
		goto IL_010e;
	}

IL_00f5:
	{
		int32_t L_36 = V_6;
		int32_t L_37 = V_10;
		if ((((int32_t)L_36) <= ((int32_t)L_37)))
		{
			goto IL_0103;
		}
	}
	{
		goto IL_010e;
	}

IL_0103:
	{
		PropertyInfo_t * L_38 = V_7;
		V_2 = L_38;
		int32_t L_39 = V_9;
		V_4 = L_39;
		int32_t L_40 = V_10;
		V_6 = L_40;
	}

IL_010e:
	{
		int32_t L_41 = V_3;
		V_3 = ((int32_t)((int32_t)L_41-(int32_t)1));
	}

IL_0112:
	{
		int32_t L_42 = V_3;
		if ((((int32_t)L_42) >= ((int32_t)0)))
		{
			goto IL_0056;
		}
	}
	{
		int32_t L_43 = V_5;
		int32_t L_44 = V_4;
		if ((((int32_t)L_43) > ((int32_t)L_44)))
		{
			goto IL_0128;
		}
	}
	{
		AmbiguousMatchException_t1406414556 * L_45 = (AmbiguousMatchException_t1406414556 *)il2cpp_codegen_object_new(AmbiguousMatchException_t1406414556_il2cpp_TypeInfo_var);
		AmbiguousMatchException__ctor_m2088048346(L_45, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_45);
	}

IL_0128:
	{
		PropertyInfo_t * L_46 = V_2;
		return L_46;
	}
}
// System.Int32 System.Reflection.Binder/Default::check_arguments_with_score(System.Type[],System.Reflection.ParameterInfo[])
extern "C"  int32_t Default_check_arguments_with_score_m1714931543 (Il2CppObject * __this /* static, unused */, TypeU5BU5D_t1664964607* ___types0, ParameterInfoU5BU5D_t2275869610* ___args1, const MethodInfo* method)
{
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	{
		V_0 = (-1);
		V_1 = 0;
		goto IL_0030;
	}

IL_0009:
	{
		TypeU5BU5D_t1664964607* L_0 = ___types0;
		int32_t L_1 = V_1;
		NullCheck(L_0);
		int32_t L_2 = L_1;
		Type_t * L_3 = (L_0)->GetAt(static_cast<il2cpp_array_size_t>(L_2));
		ParameterInfoU5BU5D_t2275869610* L_4 = ___args1;
		int32_t L_5 = V_1;
		NullCheck(L_4);
		int32_t L_6 = L_5;
		ParameterInfo_t2249040075 * L_7 = (L_4)->GetAt(static_cast<il2cpp_array_size_t>(L_6));
		NullCheck(L_7);
		Type_t * L_8 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.ParameterInfo::get_ParameterType() */, L_7);
		int32_t L_9 = Default_check_type_with_score_m58148013(NULL /*static, unused*/, L_3, L_8, /*hidden argument*/NULL);
		V_2 = L_9;
		int32_t L_10 = V_2;
		if ((!(((uint32_t)L_10) == ((uint32_t)(-1)))))
		{
			goto IL_0023;
		}
	}
	{
		return (-1);
	}

IL_0023:
	{
		int32_t L_11 = V_0;
		int32_t L_12 = V_2;
		if ((((int32_t)L_11) >= ((int32_t)L_12)))
		{
			goto IL_002c;
		}
	}
	{
		int32_t L_13 = V_2;
		V_0 = L_13;
	}

IL_002c:
	{
		int32_t L_14 = V_1;
		V_1 = ((int32_t)((int32_t)L_14+(int32_t)1));
	}

IL_0030:
	{
		int32_t L_15 = V_1;
		TypeU5BU5D_t1664964607* L_16 = ___types0;
		NullCheck(L_16);
		if ((((int32_t)L_15) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_16)->max_length)))))))
		{
			goto IL_0009;
		}
	}
	{
		int32_t L_17 = V_0;
		return L_17;
	}
}
// System.Int32 System.Reflection.Binder/Default::check_type_with_score(System.Type,System.Type)
extern const Il2CppType* Il2CppObject_0_0_0_var;
extern const Il2CppType* Enum_t2459695545_0_0_0_var;
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern const uint32_t Default_check_type_with_score_m58148013_MetadataUsageId;
extern "C"  int32_t Default_check_type_with_score_m58148013 (Il2CppObject * __this /* static, unused */, Type_t * ___from0, Type_t * ___to1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Default_check_type_with_score_m58148013_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	int32_t V_3 = 0;
	int32_t G_B4_0 = 0;
	int32_t G_B23_0 = 0;
	int32_t G_B31_0 = 0;
	int32_t G_B39_0 = 0;
	int32_t G_B47_0 = 0;
	int32_t G_B55_0 = 0;
	int32_t G_B63_0 = 0;
	int32_t G_B72_0 = 0;
	int32_t G_B76_0 = 0;
	int32_t G_B80_0 = 0;
	{
		Type_t * L_0 = ___from0;
		if (L_0)
		{
			goto IL_0019;
		}
	}
	{
		Type_t * L_1 = ___to1;
		NullCheck(L_1);
		bool L_2 = Type_get_IsValueType_m1733572463(L_1, /*hidden argument*/NULL);
		if (!L_2)
		{
			goto IL_0017;
		}
	}
	{
		G_B4_0 = (-1);
		goto IL_0018;
	}

IL_0017:
	{
		G_B4_0 = 0;
	}

IL_0018:
	{
		return G_B4_0;
	}

IL_0019:
	{
		Type_t * L_3 = ___from0;
		Type_t * L_4 = ___to1;
		if ((!(((Il2CppObject*)(Type_t *)L_3) == ((Il2CppObject*)(Type_t *)L_4))))
		{
			goto IL_0022;
		}
	}
	{
		return 0;
	}

IL_0022:
	{
		Type_t * L_5 = ___to1;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_6 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Il2CppObject_0_0_0_var), /*hidden argument*/NULL);
		if ((!(((Il2CppObject*)(Type_t *)L_5) == ((Il2CppObject*)(Type_t *)L_6))))
		{
			goto IL_0034;
		}
	}
	{
		return 4;
	}

IL_0034:
	{
		Type_t * L_7 = ___from0;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		int32_t L_8 = Type_GetTypeCode_m1044483454(NULL /*static, unused*/, L_7, /*hidden argument*/NULL);
		V_0 = L_8;
		Type_t * L_9 = ___to1;
		int32_t L_10 = Type_GetTypeCode_m1044483454(NULL /*static, unused*/, L_9, /*hidden argument*/NULL);
		V_1 = L_10;
		int32_t L_11 = V_0;
		V_2 = L_11;
		int32_t L_12 = V_2;
		if (((int32_t)((int32_t)L_12-(int32_t)4)) == 0)
		{
			goto IL_0079;
		}
		if (((int32_t)((int32_t)L_12-(int32_t)4)) == 1)
		{
			goto IL_010a;
		}
		if (((int32_t)((int32_t)L_12-(int32_t)4)) == 2)
		{
			goto IL_00aa;
		}
		if (((int32_t)((int32_t)L_12-(int32_t)4)) == 3)
		{
			goto IL_01ab;
		}
		if (((int32_t)((int32_t)L_12-(int32_t)4)) == 4)
		{
			goto IL_015e;
		}
		if (((int32_t)((int32_t)L_12-(int32_t)4)) == 5)
		{
			goto IL_023d;
		}
		if (((int32_t)((int32_t)L_12-(int32_t)4)) == 6)
		{
			goto IL_01f8;
		}
		if (((int32_t)((int32_t)L_12-(int32_t)4)) == 7)
		{
			goto IL_0282;
		}
		if (((int32_t)((int32_t)L_12-(int32_t)4)) == 8)
		{
			goto IL_0282;
		}
		if (((int32_t)((int32_t)L_12-(int32_t)4)) == 9)
		{
			goto IL_02be;
		}
	}
	{
		goto IL_02ce;
	}

IL_0079:
	{
		int32_t L_13 = V_1;
		V_3 = L_13;
		int32_t L_14 = V_3;
		if (((int32_t)((int32_t)L_14-(int32_t)8)) == 0)
		{
			goto IL_00a4;
		}
		if (((int32_t)((int32_t)L_14-(int32_t)8)) == 1)
		{
			goto IL_00a6;
		}
		if (((int32_t)((int32_t)L_14-(int32_t)8)) == 2)
		{
			goto IL_00a6;
		}
		if (((int32_t)((int32_t)L_14-(int32_t)8)) == 3)
		{
			goto IL_00a6;
		}
		if (((int32_t)((int32_t)L_14-(int32_t)8)) == 4)
		{
			goto IL_00a6;
		}
		if (((int32_t)((int32_t)L_14-(int32_t)8)) == 5)
		{
			goto IL_00a6;
		}
		if (((int32_t)((int32_t)L_14-(int32_t)8)) == 6)
		{
			goto IL_00a6;
		}
	}
	{
		goto IL_00a8;
	}

IL_00a4:
	{
		return 0;
	}

IL_00a6:
	{
		return 2;
	}

IL_00a8:
	{
		return (-1);
	}

IL_00aa:
	{
		int32_t L_15 = V_1;
		V_3 = L_15;
		int32_t L_16 = V_3;
		if (((int32_t)((int32_t)L_16-(int32_t)4)) == 0)
		{
			goto IL_00e5;
		}
		if (((int32_t)((int32_t)L_16-(int32_t)4)) == 1)
		{
			goto IL_00e7;
		}
		if (((int32_t)((int32_t)L_16-(int32_t)4)) == 2)
		{
			goto IL_00e7;
		}
		if (((int32_t)((int32_t)L_16-(int32_t)4)) == 3)
		{
			goto IL_00e5;
		}
		if (((int32_t)((int32_t)L_16-(int32_t)4)) == 4)
		{
			goto IL_00e5;
		}
		if (((int32_t)((int32_t)L_16-(int32_t)4)) == 5)
		{
			goto IL_00e5;
		}
		if (((int32_t)((int32_t)L_16-(int32_t)4)) == 6)
		{
			goto IL_00e5;
		}
		if (((int32_t)((int32_t)L_16-(int32_t)4)) == 7)
		{
			goto IL_00e5;
		}
		if (((int32_t)((int32_t)L_16-(int32_t)4)) == 8)
		{
			goto IL_00e5;
		}
		if (((int32_t)((int32_t)L_16-(int32_t)4)) == 9)
		{
			goto IL_00e5;
		}
		if (((int32_t)((int32_t)L_16-(int32_t)4)) == 10)
		{
			goto IL_00e5;
		}
	}
	{
		goto IL_00e7;
	}

IL_00e5:
	{
		return 2;
	}

IL_00e7:
	{
		Type_t * L_17 = ___from0;
		NullCheck(L_17);
		bool L_18 = Type_get_IsEnum_m313908919(L_17, /*hidden argument*/NULL);
		if (!L_18)
		{
			goto IL_0108;
		}
	}
	{
		Type_t * L_19 = ___to1;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_20 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Enum_t2459695545_0_0_0_var), /*hidden argument*/NULL);
		if ((!(((Il2CppObject*)(Type_t *)L_19) == ((Il2CppObject*)(Type_t *)L_20))))
		{
			goto IL_0108;
		}
	}
	{
		G_B23_0 = 1;
		goto IL_0109;
	}

IL_0108:
	{
		G_B23_0 = (-1);
	}

IL_0109:
	{
		return G_B23_0;
	}

IL_010a:
	{
		int32_t L_21 = V_1;
		V_3 = L_21;
		int32_t L_22 = V_3;
		if (((int32_t)((int32_t)L_22-(int32_t)7)) == 0)
		{
			goto IL_0139;
		}
		if (((int32_t)((int32_t)L_22-(int32_t)7)) == 1)
		{
			goto IL_013b;
		}
		if (((int32_t)((int32_t)L_22-(int32_t)7)) == 2)
		{
			goto IL_0139;
		}
		if (((int32_t)((int32_t)L_22-(int32_t)7)) == 3)
		{
			goto IL_013b;
		}
		if (((int32_t)((int32_t)L_22-(int32_t)7)) == 4)
		{
			goto IL_0139;
		}
		if (((int32_t)((int32_t)L_22-(int32_t)7)) == 5)
		{
			goto IL_013b;
		}
		if (((int32_t)((int32_t)L_22-(int32_t)7)) == 6)
		{
			goto IL_0139;
		}
		if (((int32_t)((int32_t)L_22-(int32_t)7)) == 7)
		{
			goto IL_0139;
		}
	}
	{
		goto IL_013b;
	}

IL_0139:
	{
		return 2;
	}

IL_013b:
	{
		Type_t * L_23 = ___from0;
		NullCheck(L_23);
		bool L_24 = Type_get_IsEnum_m313908919(L_23, /*hidden argument*/NULL);
		if (!L_24)
		{
			goto IL_015c;
		}
	}
	{
		Type_t * L_25 = ___to1;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_26 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Enum_t2459695545_0_0_0_var), /*hidden argument*/NULL);
		if ((!(((Il2CppObject*)(Type_t *)L_25) == ((Il2CppObject*)(Type_t *)L_26))))
		{
			goto IL_015c;
		}
	}
	{
		G_B31_0 = 1;
		goto IL_015d;
	}

IL_015c:
	{
		G_B31_0 = (-1);
	}

IL_015d:
	{
		return G_B31_0;
	}

IL_015e:
	{
		int32_t L_27 = V_1;
		V_3 = L_27;
		int32_t L_28 = V_3;
		if (((int32_t)((int32_t)L_28-(int32_t)((int32_t)9))) == 0)
		{
			goto IL_0186;
		}
		if (((int32_t)((int32_t)L_28-(int32_t)((int32_t)9))) == 1)
		{
			goto IL_0186;
		}
		if (((int32_t)((int32_t)L_28-(int32_t)((int32_t)9))) == 2)
		{
			goto IL_0186;
		}
		if (((int32_t)((int32_t)L_28-(int32_t)((int32_t)9))) == 3)
		{
			goto IL_0186;
		}
		if (((int32_t)((int32_t)L_28-(int32_t)((int32_t)9))) == 4)
		{
			goto IL_0186;
		}
		if (((int32_t)((int32_t)L_28-(int32_t)((int32_t)9))) == 5)
		{
			goto IL_0186;
		}
	}
	{
		goto IL_0188;
	}

IL_0186:
	{
		return 2;
	}

IL_0188:
	{
		Type_t * L_29 = ___from0;
		NullCheck(L_29);
		bool L_30 = Type_get_IsEnum_m313908919(L_29, /*hidden argument*/NULL);
		if (!L_30)
		{
			goto IL_01a9;
		}
	}
	{
		Type_t * L_31 = ___to1;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_32 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Enum_t2459695545_0_0_0_var), /*hidden argument*/NULL);
		if ((!(((Il2CppObject*)(Type_t *)L_31) == ((Il2CppObject*)(Type_t *)L_32))))
		{
			goto IL_01a9;
		}
	}
	{
		G_B39_0 = 1;
		goto IL_01aa;
	}

IL_01a9:
	{
		G_B39_0 = (-1);
	}

IL_01aa:
	{
		return G_B39_0;
	}

IL_01ab:
	{
		int32_t L_33 = V_1;
		V_3 = L_33;
		int32_t L_34 = V_3;
		if (((int32_t)((int32_t)L_34-(int32_t)((int32_t)9))) == 0)
		{
			goto IL_01d3;
		}
		if (((int32_t)((int32_t)L_34-(int32_t)((int32_t)9))) == 1)
		{
			goto IL_01d5;
		}
		if (((int32_t)((int32_t)L_34-(int32_t)((int32_t)9))) == 2)
		{
			goto IL_01d3;
		}
		if (((int32_t)((int32_t)L_34-(int32_t)((int32_t)9))) == 3)
		{
			goto IL_01d5;
		}
		if (((int32_t)((int32_t)L_34-(int32_t)((int32_t)9))) == 4)
		{
			goto IL_01d3;
		}
		if (((int32_t)((int32_t)L_34-(int32_t)((int32_t)9))) == 5)
		{
			goto IL_01d3;
		}
	}
	{
		goto IL_01d5;
	}

IL_01d3:
	{
		return 2;
	}

IL_01d5:
	{
		Type_t * L_35 = ___from0;
		NullCheck(L_35);
		bool L_36 = Type_get_IsEnum_m313908919(L_35, /*hidden argument*/NULL);
		if (!L_36)
		{
			goto IL_01f6;
		}
	}
	{
		Type_t * L_37 = ___to1;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_38 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Enum_t2459695545_0_0_0_var), /*hidden argument*/NULL);
		if ((!(((Il2CppObject*)(Type_t *)L_37) == ((Il2CppObject*)(Type_t *)L_38))))
		{
			goto IL_01f6;
		}
	}
	{
		G_B47_0 = 1;
		goto IL_01f7;
	}

IL_01f6:
	{
		G_B47_0 = (-1);
	}

IL_01f7:
	{
		return G_B47_0;
	}

IL_01f8:
	{
		int32_t L_39 = V_1;
		V_3 = L_39;
		int32_t L_40 = V_3;
		if (((int32_t)((int32_t)L_40-(int32_t)((int32_t)11))) == 0)
		{
			goto IL_0218;
		}
		if (((int32_t)((int32_t)L_40-(int32_t)((int32_t)11))) == 1)
		{
			goto IL_0218;
		}
		if (((int32_t)((int32_t)L_40-(int32_t)((int32_t)11))) == 2)
		{
			goto IL_0218;
		}
		if (((int32_t)((int32_t)L_40-(int32_t)((int32_t)11))) == 3)
		{
			goto IL_0218;
		}
	}
	{
		goto IL_021a;
	}

IL_0218:
	{
		return 2;
	}

IL_021a:
	{
		Type_t * L_41 = ___from0;
		NullCheck(L_41);
		bool L_42 = Type_get_IsEnum_m313908919(L_41, /*hidden argument*/NULL);
		if (!L_42)
		{
			goto IL_023b;
		}
	}
	{
		Type_t * L_43 = ___to1;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_44 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Enum_t2459695545_0_0_0_var), /*hidden argument*/NULL);
		if ((!(((Il2CppObject*)(Type_t *)L_43) == ((Il2CppObject*)(Type_t *)L_44))))
		{
			goto IL_023b;
		}
	}
	{
		G_B55_0 = 1;
		goto IL_023c;
	}

IL_023b:
	{
		G_B55_0 = (-1);
	}

IL_023c:
	{
		return G_B55_0;
	}

IL_023d:
	{
		int32_t L_45 = V_1;
		V_3 = L_45;
		int32_t L_46 = V_3;
		if (((int32_t)((int32_t)L_46-(int32_t)((int32_t)11))) == 0)
		{
			goto IL_025d;
		}
		if (((int32_t)((int32_t)L_46-(int32_t)((int32_t)11))) == 1)
		{
			goto IL_025f;
		}
		if (((int32_t)((int32_t)L_46-(int32_t)((int32_t)11))) == 2)
		{
			goto IL_025d;
		}
		if (((int32_t)((int32_t)L_46-(int32_t)((int32_t)11))) == 3)
		{
			goto IL_025d;
		}
	}
	{
		goto IL_025f;
	}

IL_025d:
	{
		return 2;
	}

IL_025f:
	{
		Type_t * L_47 = ___from0;
		NullCheck(L_47);
		bool L_48 = Type_get_IsEnum_m313908919(L_47, /*hidden argument*/NULL);
		if (!L_48)
		{
			goto IL_0280;
		}
	}
	{
		Type_t * L_49 = ___to1;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_50 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Enum_t2459695545_0_0_0_var), /*hidden argument*/NULL);
		if ((!(((Il2CppObject*)(Type_t *)L_49) == ((Il2CppObject*)(Type_t *)L_50))))
		{
			goto IL_0280;
		}
	}
	{
		G_B63_0 = 1;
		goto IL_0281;
	}

IL_0280:
	{
		G_B63_0 = (-1);
	}

IL_0281:
	{
		return G_B63_0;
	}

IL_0282:
	{
		int32_t L_51 = V_1;
		V_3 = L_51;
		int32_t L_52 = V_3;
		if ((((int32_t)L_52) == ((int32_t)((int32_t)13))))
		{
			goto IL_0299;
		}
	}
	{
		int32_t L_53 = V_3;
		if ((((int32_t)L_53) == ((int32_t)((int32_t)14))))
		{
			goto IL_0299;
		}
	}
	{
		goto IL_029b;
	}

IL_0299:
	{
		return 2;
	}

IL_029b:
	{
		Type_t * L_54 = ___from0;
		NullCheck(L_54);
		bool L_55 = Type_get_IsEnum_m313908919(L_54, /*hidden argument*/NULL);
		if (!L_55)
		{
			goto IL_02bc;
		}
	}
	{
		Type_t * L_56 = ___to1;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_57 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Enum_t2459695545_0_0_0_var), /*hidden argument*/NULL);
		if ((!(((Il2CppObject*)(Type_t *)L_56) == ((Il2CppObject*)(Type_t *)L_57))))
		{
			goto IL_02bc;
		}
	}
	{
		G_B72_0 = 1;
		goto IL_02bd;
	}

IL_02bc:
	{
		G_B72_0 = (-1);
	}

IL_02bd:
	{
		return G_B72_0;
	}

IL_02be:
	{
		int32_t L_58 = V_1;
		if ((!(((uint32_t)L_58) == ((uint32_t)((int32_t)14)))))
		{
			goto IL_02cc;
		}
	}
	{
		G_B76_0 = 2;
		goto IL_02cd;
	}

IL_02cc:
	{
		G_B76_0 = (-1);
	}

IL_02cd:
	{
		return G_B76_0;
	}

IL_02ce:
	{
		Type_t * L_59 = ___to1;
		Type_t * L_60 = ___from0;
		NullCheck(L_59);
		bool L_61 = VirtFuncInvoker1< bool, Type_t * >::Invoke(40 /* System.Boolean System.Type::IsAssignableFrom(System.Type) */, L_59, L_60);
		if (!L_61)
		{
			goto IL_02e0;
		}
	}
	{
		G_B80_0 = 3;
		goto IL_02e1;
	}

IL_02e0:
	{
		G_B80_0 = (-1);
	}

IL_02e1:
	{
		return G_B80_0;
	}
}
// System.Void System.Reflection.ConstructorInfo::.ctor()
extern "C"  void ConstructorInfo__ctor_m3847352284 (ConstructorInfo_t2851816542 * __this, const MethodInfo* method)
{
	{
		MethodBase__ctor_m3951051358(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Reflection.ConstructorInfo::.cctor()
extern Il2CppClass* ConstructorInfo_t2851816542_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral2199879418;
extern Il2CppCodeGenString* _stringLiteral3705238055;
extern const uint32_t ConstructorInfo__cctor_m2897369343_MetadataUsageId;
extern "C"  void ConstructorInfo__cctor_m2897369343 (Il2CppObject * __this /* static, unused */, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ConstructorInfo__cctor_m2897369343_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		((ConstructorInfo_t2851816542_StaticFields*)ConstructorInfo_t2851816542_il2cpp_TypeInfo_var->static_fields)->set_ConstructorName_0(_stringLiteral2199879418);
		((ConstructorInfo_t2851816542_StaticFields*)ConstructorInfo_t2851816542_il2cpp_TypeInfo_var->static_fields)->set_TypeConstructorName_1(_stringLiteral3705238055);
		return;
	}
}
// System.Reflection.MemberTypes System.Reflection.ConstructorInfo::get_MemberType()
extern "C"  int32_t ConstructorInfo_get_MemberType_m1879090087 (ConstructorInfo_t2851816542 * __this, const MethodInfo* method)
{
	{
		return (int32_t)(1);
	}
}
// System.Object System.Reflection.ConstructorInfo::Invoke(System.Object[])
extern Il2CppClass* ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var;
extern const uint32_t ConstructorInfo_Invoke_m2144827141_MetadataUsageId;
extern "C"  Il2CppObject * ConstructorInfo_Invoke_m2144827141 (ConstructorInfo_t2851816542 * __this, ObjectU5BU5D_t3614634134* ___parameters0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ConstructorInfo_Invoke_m2144827141_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ObjectU5BU5D_t3614634134* L_0 = ___parameters0;
		if (L_0)
		{
			goto IL_000e;
		}
	}
	{
		___parameters0 = ((ObjectU5BU5D_t3614634134*)SZArrayNew(ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var, (uint32_t)0));
	}

IL_000e:
	{
		ObjectU5BU5D_t3614634134* L_1 = ___parameters0;
		Il2CppObject * L_2 = VirtFuncInvoker4< Il2CppObject *, int32_t, Binder_t3404612058 *, ObjectU5BU5D_t3614634134*, CultureInfo_t3500843524 * >::Invoke(30 /* System.Object System.Reflection.ConstructorInfo::Invoke(System.Reflection.BindingFlags,System.Reflection.Binder,System.Object[],System.Globalization.CultureInfo) */, __this, ((int32_t)512), (Binder_t3404612058 *)NULL, L_1, (CultureInfo_t3500843524 *)NULL);
		return L_2;
	}
}
// System.Void System.Reflection.CustomAttributeData::.ctor(System.Reflection.ConstructorInfo,System.Object[],System.Object[])
extern Il2CppClass* CustomAttributeTypedArgumentU5BU5D_t1075686591_il2cpp_TypeInfo_var;
extern Il2CppClass* CustomAttributeNamedArgumentU5BU5D_t3304067486_il2cpp_TypeInfo_var;
extern const MethodInfo* CustomAttributeData_UnboxValues_TisCustomAttributeTypedArgument_t1498197914_m2561215702_MethodInfo_var;
extern const MethodInfo* Array_AsReadOnly_TisCustomAttributeTypedArgument_t1498197914_m2855930084_MethodInfo_var;
extern const MethodInfo* CustomAttributeData_UnboxValues_TisCustomAttributeNamedArgument_t94157543_m2789115353_MethodInfo_var;
extern const MethodInfo* Array_AsReadOnly_TisCustomAttributeNamedArgument_t94157543_m2935638619_MethodInfo_var;
extern const uint32_t CustomAttributeData__ctor_m1358286409_MetadataUsageId;
extern "C"  void CustomAttributeData__ctor_m1358286409 (CustomAttributeData_t3093286891 * __this, ConstructorInfo_t2851816542 * ___ctorInfo0, ObjectU5BU5D_t3614634134* ___ctorArgs1, ObjectU5BU5D_t3614634134* ___namedArgs2, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (CustomAttributeData__ctor_m1358286409_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	CustomAttributeData_t3093286891 * G_B2_0 = NULL;
	CustomAttributeData_t3093286891 * G_B1_0 = NULL;
	CustomAttributeTypedArgumentU5BU5D_t1075686591* G_B3_0 = NULL;
	CustomAttributeData_t3093286891 * G_B3_1 = NULL;
	CustomAttributeData_t3093286891 * G_B5_0 = NULL;
	CustomAttributeData_t3093286891 * G_B4_0 = NULL;
	CustomAttributeNamedArgumentU5BU5D_t3304067486* G_B6_0 = NULL;
	CustomAttributeData_t3093286891 * G_B6_1 = NULL;
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		ConstructorInfo_t2851816542 * L_0 = ___ctorInfo0;
		__this->set_ctorInfo_0(L_0);
		ObjectU5BU5D_t3614634134* L_1 = ___ctorArgs1;
		G_B1_0 = __this;
		if (!L_1)
		{
			G_B2_0 = __this;
			goto IL_001f;
		}
	}
	{
		ObjectU5BU5D_t3614634134* L_2 = ___ctorArgs1;
		CustomAttributeTypedArgumentU5BU5D_t1075686591* L_3 = CustomAttributeData_UnboxValues_TisCustomAttributeTypedArgument_t1498197914_m2561215702(NULL /*static, unused*/, L_2, /*hidden argument*/CustomAttributeData_UnboxValues_TisCustomAttributeTypedArgument_t1498197914_m2561215702_MethodInfo_var);
		G_B3_0 = L_3;
		G_B3_1 = G_B1_0;
		goto IL_0025;
	}

IL_001f:
	{
		G_B3_0 = ((CustomAttributeTypedArgumentU5BU5D_t1075686591*)SZArrayNew(CustomAttributeTypedArgumentU5BU5D_t1075686591_il2cpp_TypeInfo_var, (uint32_t)0));
		G_B3_1 = G_B2_0;
	}

IL_0025:
	{
		ReadOnlyCollection_1_t1683983606 * L_4 = Array_AsReadOnly_TisCustomAttributeTypedArgument_t1498197914_m2855930084(NULL /*static, unused*/, G_B3_0, /*hidden argument*/Array_AsReadOnly_TisCustomAttributeTypedArgument_t1498197914_m2855930084_MethodInfo_var);
		NullCheck(G_B3_1);
		G_B3_1->set_ctorArgs_1(L_4);
		ObjectU5BU5D_t3614634134* L_5 = ___namedArgs2;
		G_B4_0 = __this;
		if (!L_5)
		{
			G_B5_0 = __this;
			goto IL_0041;
		}
	}
	{
		ObjectU5BU5D_t3614634134* L_6 = ___namedArgs2;
		CustomAttributeNamedArgumentU5BU5D_t3304067486* L_7 = CustomAttributeData_UnboxValues_TisCustomAttributeNamedArgument_t94157543_m2789115353(NULL /*static, unused*/, L_6, /*hidden argument*/CustomAttributeData_UnboxValues_TisCustomAttributeNamedArgument_t94157543_m2789115353_MethodInfo_var);
		G_B6_0 = L_7;
		G_B6_1 = G_B4_0;
		goto IL_0047;
	}

IL_0041:
	{
		G_B6_0 = ((CustomAttributeNamedArgumentU5BU5D_t3304067486*)SZArrayNew(CustomAttributeNamedArgumentU5BU5D_t3304067486_il2cpp_TypeInfo_var, (uint32_t)0));
		G_B6_1 = G_B5_0;
	}

IL_0047:
	{
		ReadOnlyCollection_1_t279943235 * L_8 = Array_AsReadOnly_TisCustomAttributeNamedArgument_t94157543_m2935638619(NULL /*static, unused*/, G_B6_0, /*hidden argument*/Array_AsReadOnly_TisCustomAttributeNamedArgument_t94157543_m2935638619_MethodInfo_var);
		NullCheck(G_B6_1);
		G_B6_1->set_namedArgs_2(L_8);
		return;
	}
}
// System.Reflection.ConstructorInfo System.Reflection.CustomAttributeData::get_Constructor()
extern "C"  ConstructorInfo_t2851816542 * CustomAttributeData_get_Constructor_m2529070599 (CustomAttributeData_t3093286891 * __this, const MethodInfo* method)
{
	{
		ConstructorInfo_t2851816542 * L_0 = __this->get_ctorInfo_0();
		return L_0;
	}
}
// System.Collections.Generic.IList`1<System.Reflection.CustomAttributeTypedArgument> System.Reflection.CustomAttributeData::get_ConstructorArguments()
extern "C"  Il2CppObject* CustomAttributeData_get_ConstructorArguments_m1625171154 (CustomAttributeData_t3093286891 * __this, const MethodInfo* method)
{
	{
		Il2CppObject* L_0 = __this->get_ctorArgs_1();
		return L_0;
	}
}
// System.Collections.Generic.IList`1<System.Reflection.CustomAttributeNamedArgument> System.Reflection.CustomAttributeData::get_NamedArguments()
extern "C"  Il2CppObject* CustomAttributeData_get_NamedArguments_m708818174 (CustomAttributeData_t3093286891 * __this, const MethodInfo* method)
{
	{
		Il2CppObject* L_0 = __this->get_namedArgs_2();
		return L_0;
	}
}
// System.Collections.Generic.IList`1<System.Reflection.CustomAttributeData> System.Reflection.CustomAttributeData::GetCustomAttributes(System.Reflection.Assembly)
extern Il2CppClass* MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var;
extern const uint32_t CustomAttributeData_GetCustomAttributes_m4124612360_MetadataUsageId;
extern "C"  Il2CppObject* CustomAttributeData_GetCustomAttributes_m4124612360 (Il2CppObject * __this /* static, unused */, Assembly_t4268412390 * ___target0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (CustomAttributeData_GetCustomAttributes_m4124612360_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Assembly_t4268412390 * L_0 = ___target0;
		IL2CPP_RUNTIME_CLASS_INIT(MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var);
		Il2CppObject* L_1 = MonoCustomAttrs_GetCustomAttributesData_m550893105(NULL /*static, unused*/, L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Collections.Generic.IList`1<System.Reflection.CustomAttributeData> System.Reflection.CustomAttributeData::GetCustomAttributes(System.Reflection.MemberInfo)
extern Il2CppClass* MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var;
extern const uint32_t CustomAttributeData_GetCustomAttributes_m2421330738_MetadataUsageId;
extern "C"  Il2CppObject* CustomAttributeData_GetCustomAttributes_m2421330738 (Il2CppObject * __this /* static, unused */, MemberInfo_t * ___target0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (CustomAttributeData_GetCustomAttributes_m2421330738_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		MemberInfo_t * L_0 = ___target0;
		IL2CPP_RUNTIME_CLASS_INIT(MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var);
		Il2CppObject* L_1 = MonoCustomAttrs_GetCustomAttributesData_m550893105(NULL /*static, unused*/, L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Collections.Generic.IList`1<System.Reflection.CustomAttributeData> System.Reflection.CustomAttributeData::GetCustomAttributes(System.Reflection.Module)
extern Il2CppClass* MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var;
extern const uint32_t CustomAttributeData_GetCustomAttributes_m119332220_MetadataUsageId;
extern "C"  Il2CppObject* CustomAttributeData_GetCustomAttributes_m119332220 (Il2CppObject * __this /* static, unused */, Module_t4282841206 * ___target0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (CustomAttributeData_GetCustomAttributes_m119332220_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Module_t4282841206 * L_0 = ___target0;
		IL2CPP_RUNTIME_CLASS_INIT(MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var);
		Il2CppObject* L_1 = MonoCustomAttrs_GetCustomAttributesData_m550893105(NULL /*static, unused*/, L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Collections.Generic.IList`1<System.Reflection.CustomAttributeData> System.Reflection.CustomAttributeData::GetCustomAttributes(System.Reflection.ParameterInfo)
extern Il2CppClass* MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var;
extern const uint32_t CustomAttributeData_GetCustomAttributes_m3258419955_MetadataUsageId;
extern "C"  Il2CppObject* CustomAttributeData_GetCustomAttributes_m3258419955 (Il2CppObject * __this /* static, unused */, ParameterInfo_t2249040075 * ___target0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (CustomAttributeData_GetCustomAttributes_m3258419955_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ParameterInfo_t2249040075 * L_0 = ___target0;
		IL2CPP_RUNTIME_CLASS_INIT(MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var);
		Il2CppObject* L_1 = MonoCustomAttrs_GetCustomAttributesData_m550893105(NULL /*static, unused*/, L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.String System.Reflection.CustomAttributeData::ToString()
extern Il2CppClass* StringBuilder_t1221177846_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* IList_1_t2039138515_il2cpp_TypeInfo_var;
extern Il2CppClass* ICollection_1_t2450273219_il2cpp_TypeInfo_var;
extern Il2CppClass* ICollection_1_t1046232848_il2cpp_TypeInfo_var;
extern Il2CppClass* IList_1_t635098144_il2cpp_TypeInfo_var;
extern Il2CppClass* ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral372029431;
extern Il2CppCodeGenString* _stringLiteral372029318;
extern Il2CppCodeGenString* _stringLiteral811305474;
extern Il2CppCodeGenString* _stringLiteral522332260;
extern const uint32_t CustomAttributeData_ToString_m1673522836_MetadataUsageId;
extern "C"  String_t* CustomAttributeData_ToString_m1673522836 (CustomAttributeData_t3093286891 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (CustomAttributeData_ToString_m1673522836_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	StringBuilder_t1221177846 * V_0 = NULL;
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	CustomAttributeTypedArgument_t1498197914  V_3;
	memset(&V_3, 0, sizeof(V_3));
	CustomAttributeNamedArgument_t94157543  V_4;
	memset(&V_4, 0, sizeof(V_4));
	{
		StringBuilder_t1221177846 * L_0 = (StringBuilder_t1221177846 *)il2cpp_codegen_object_new(StringBuilder_t1221177846_il2cpp_TypeInfo_var);
		StringBuilder__ctor_m3946851802(L_0, /*hidden argument*/NULL);
		V_0 = L_0;
		StringBuilder_t1221177846 * L_1 = V_0;
		ConstructorInfo_t2851816542 * L_2 = __this->get_ctorInfo_0();
		NullCheck(L_2);
		Type_t * L_3 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.MemberInfo::get_DeclaringType() */, L_2);
		NullCheck(L_3);
		String_t* L_4 = VirtFuncInvoker0< String_t* >::Invoke(18 /* System.String System.Type::get_FullName() */, L_3);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_5 = String_Concat_m612901809(NULL /*static, unused*/, _stringLiteral372029431, L_4, _stringLiteral372029318, /*hidden argument*/NULL);
		NullCheck(L_1);
		StringBuilder_Append_m3636508479(L_1, L_5, /*hidden argument*/NULL);
		V_1 = 0;
		goto IL_0071;
	}

IL_0033:
	{
		StringBuilder_t1221177846 * L_6 = V_0;
		Il2CppObject* L_7 = __this->get_ctorArgs_1();
		int32_t L_8 = V_1;
		NullCheck(L_7);
		CustomAttributeTypedArgument_t1498197914  L_9 = InterfaceFuncInvoker1< CustomAttributeTypedArgument_t1498197914 , int32_t >::Invoke(3 /* T System.Collections.Generic.IList`1<System.Reflection.CustomAttributeTypedArgument>::get_Item(System.Int32) */, IList_1_t2039138515_il2cpp_TypeInfo_var, L_7, L_8);
		V_3 = L_9;
		String_t* L_10 = CustomAttributeTypedArgument_ToString_m1091739553((&V_3), /*hidden argument*/NULL);
		NullCheck(L_6);
		StringBuilder_Append_m3636508479(L_6, L_10, /*hidden argument*/NULL);
		int32_t L_11 = V_1;
		Il2CppObject* L_12 = __this->get_ctorArgs_1();
		NullCheck(L_12);
		int32_t L_13 = InterfaceFuncInvoker0< int32_t >::Invoke(0 /* System.Int32 System.Collections.Generic.ICollection`1<System.Reflection.CustomAttributeTypedArgument>::get_Count() */, ICollection_1_t2450273219_il2cpp_TypeInfo_var, L_12);
		if ((((int32_t)((int32_t)((int32_t)L_11+(int32_t)1))) >= ((int32_t)L_13)))
		{
			goto IL_006d;
		}
	}
	{
		StringBuilder_t1221177846 * L_14 = V_0;
		NullCheck(L_14);
		StringBuilder_Append_m3636508479(L_14, _stringLiteral811305474, /*hidden argument*/NULL);
	}

IL_006d:
	{
		int32_t L_15 = V_1;
		V_1 = ((int32_t)((int32_t)L_15+(int32_t)1));
	}

IL_0071:
	{
		int32_t L_16 = V_1;
		Il2CppObject* L_17 = __this->get_ctorArgs_1();
		NullCheck(L_17);
		int32_t L_18 = InterfaceFuncInvoker0< int32_t >::Invoke(0 /* System.Int32 System.Collections.Generic.ICollection`1<System.Reflection.CustomAttributeTypedArgument>::get_Count() */, ICollection_1_t2450273219_il2cpp_TypeInfo_var, L_17);
		if ((((int32_t)L_16) < ((int32_t)L_18)))
		{
			goto IL_0033;
		}
	}
	{
		Il2CppObject* L_19 = __this->get_namedArgs_2();
		NullCheck(L_19);
		int32_t L_20 = InterfaceFuncInvoker0< int32_t >::Invoke(0 /* System.Int32 System.Collections.Generic.ICollection`1<System.Reflection.CustomAttributeNamedArgument>::get_Count() */, ICollection_1_t1046232848_il2cpp_TypeInfo_var, L_19);
		if ((((int32_t)L_20) <= ((int32_t)0)))
		{
			goto IL_009f;
		}
	}
	{
		StringBuilder_t1221177846 * L_21 = V_0;
		NullCheck(L_21);
		StringBuilder_Append_m3636508479(L_21, _stringLiteral811305474, /*hidden argument*/NULL);
	}

IL_009f:
	{
		V_2 = 0;
		goto IL_00e5;
	}

IL_00a6:
	{
		StringBuilder_t1221177846 * L_22 = V_0;
		Il2CppObject* L_23 = __this->get_namedArgs_2();
		int32_t L_24 = V_2;
		NullCheck(L_23);
		CustomAttributeNamedArgument_t94157543  L_25 = InterfaceFuncInvoker1< CustomAttributeNamedArgument_t94157543 , int32_t >::Invoke(3 /* T System.Collections.Generic.IList`1<System.Reflection.CustomAttributeNamedArgument>::get_Item(System.Int32) */, IList_1_t635098144_il2cpp_TypeInfo_var, L_23, L_24);
		V_4 = L_25;
		String_t* L_26 = CustomAttributeNamedArgument_ToString_m804774956((&V_4), /*hidden argument*/NULL);
		NullCheck(L_22);
		StringBuilder_Append_m3636508479(L_22, L_26, /*hidden argument*/NULL);
		int32_t L_27 = V_2;
		Il2CppObject* L_28 = __this->get_namedArgs_2();
		NullCheck(L_28);
		int32_t L_29 = InterfaceFuncInvoker0< int32_t >::Invoke(0 /* System.Int32 System.Collections.Generic.ICollection`1<System.Reflection.CustomAttributeNamedArgument>::get_Count() */, ICollection_1_t1046232848_il2cpp_TypeInfo_var, L_28);
		if ((((int32_t)((int32_t)((int32_t)L_27+(int32_t)1))) >= ((int32_t)L_29)))
		{
			goto IL_00e1;
		}
	}
	{
		StringBuilder_t1221177846 * L_30 = V_0;
		NullCheck(L_30);
		StringBuilder_Append_m3636508479(L_30, _stringLiteral811305474, /*hidden argument*/NULL);
	}

IL_00e1:
	{
		int32_t L_31 = V_2;
		V_2 = ((int32_t)((int32_t)L_31+(int32_t)1));
	}

IL_00e5:
	{
		int32_t L_32 = V_2;
		Il2CppObject* L_33 = __this->get_namedArgs_2();
		NullCheck(L_33);
		int32_t L_34 = InterfaceFuncInvoker0< int32_t >::Invoke(0 /* System.Int32 System.Collections.Generic.ICollection`1<System.Reflection.CustomAttributeNamedArgument>::get_Count() */, ICollection_1_t1046232848_il2cpp_TypeInfo_var, L_33);
		if ((((int32_t)L_32) < ((int32_t)L_34)))
		{
			goto IL_00a6;
		}
	}
	{
		StringBuilder_t1221177846 * L_35 = V_0;
		NullCheck(L_35);
		StringBuilder_AppendFormat_m1879616656(L_35, _stringLiteral522332260, ((ObjectU5BU5D_t3614634134*)SZArrayNew(ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var, (uint32_t)0)), /*hidden argument*/NULL);
		StringBuilder_t1221177846 * L_36 = V_0;
		NullCheck(L_36);
		String_t* L_37 = StringBuilder_ToString_m1507807375(L_36, /*hidden argument*/NULL);
		return L_37;
	}
}
// System.Boolean System.Reflection.CustomAttributeData::Equals(System.Object)
extern Il2CppClass* CustomAttributeData_t3093286891_il2cpp_TypeInfo_var;
extern Il2CppClass* ICollection_1_t2450273219_il2cpp_TypeInfo_var;
extern Il2CppClass* ICollection_1_t1046232848_il2cpp_TypeInfo_var;
extern Il2CppClass* IList_1_t2039138515_il2cpp_TypeInfo_var;
extern Il2CppClass* CustomAttributeTypedArgument_t1498197914_il2cpp_TypeInfo_var;
extern Il2CppClass* IList_1_t635098144_il2cpp_TypeInfo_var;
extern Il2CppClass* CustomAttributeNamedArgument_t94157543_il2cpp_TypeInfo_var;
extern const uint32_t CustomAttributeData_Equals_m909425978_MetadataUsageId;
extern "C"  bool CustomAttributeData_Equals_m909425978 (CustomAttributeData_t3093286891 * __this, Il2CppObject * ___obj0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (CustomAttributeData_Equals_m909425978_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	CustomAttributeData_t3093286891 * V_0 = NULL;
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	bool V_3 = false;
	int32_t V_4 = 0;
	CustomAttributeTypedArgument_t1498197914  V_5;
	memset(&V_5, 0, sizeof(V_5));
	CustomAttributeNamedArgument_t94157543  V_6;
	memset(&V_6, 0, sizeof(V_6));
	{
		Il2CppObject * L_0 = ___obj0;
		V_0 = ((CustomAttributeData_t3093286891 *)IsInstSealed(L_0, CustomAttributeData_t3093286891_il2cpp_TypeInfo_var));
		CustomAttributeData_t3093286891 * L_1 = V_0;
		if (!L_1)
		{
			goto IL_0054;
		}
	}
	{
		CustomAttributeData_t3093286891 * L_2 = V_0;
		NullCheck(L_2);
		ConstructorInfo_t2851816542 * L_3 = L_2->get_ctorInfo_0();
		ConstructorInfo_t2851816542 * L_4 = __this->get_ctorInfo_0();
		if ((!(((Il2CppObject*)(ConstructorInfo_t2851816542 *)L_3) == ((Il2CppObject*)(ConstructorInfo_t2851816542 *)L_4))))
		{
			goto IL_0054;
		}
	}
	{
		CustomAttributeData_t3093286891 * L_5 = V_0;
		NullCheck(L_5);
		Il2CppObject* L_6 = L_5->get_ctorArgs_1();
		NullCheck(L_6);
		int32_t L_7 = InterfaceFuncInvoker0< int32_t >::Invoke(0 /* System.Int32 System.Collections.Generic.ICollection`1<System.Reflection.CustomAttributeTypedArgument>::get_Count() */, ICollection_1_t2450273219_il2cpp_TypeInfo_var, L_6);
		Il2CppObject* L_8 = __this->get_ctorArgs_1();
		NullCheck(L_8);
		int32_t L_9 = InterfaceFuncInvoker0< int32_t >::Invoke(0 /* System.Int32 System.Collections.Generic.ICollection`1<System.Reflection.CustomAttributeTypedArgument>::get_Count() */, ICollection_1_t2450273219_il2cpp_TypeInfo_var, L_8);
		if ((!(((uint32_t)L_7) == ((uint32_t)L_9))))
		{
			goto IL_0054;
		}
	}
	{
		CustomAttributeData_t3093286891 * L_10 = V_0;
		NullCheck(L_10);
		Il2CppObject* L_11 = L_10->get_namedArgs_2();
		NullCheck(L_11);
		int32_t L_12 = InterfaceFuncInvoker0< int32_t >::Invoke(0 /* System.Int32 System.Collections.Generic.ICollection`1<System.Reflection.CustomAttributeNamedArgument>::get_Count() */, ICollection_1_t1046232848_il2cpp_TypeInfo_var, L_11);
		Il2CppObject* L_13 = __this->get_namedArgs_2();
		NullCheck(L_13);
		int32_t L_14 = InterfaceFuncInvoker0< int32_t >::Invoke(0 /* System.Int32 System.Collections.Generic.ICollection`1<System.Reflection.CustomAttributeNamedArgument>::get_Count() */, ICollection_1_t1046232848_il2cpp_TypeInfo_var, L_13);
		if ((((int32_t)L_12) == ((int32_t)L_14)))
		{
			goto IL_0056;
		}
	}

IL_0054:
	{
		return (bool)0;
	}

IL_0056:
	{
		V_1 = 0;
		goto IL_008e;
	}

IL_005d:
	{
		Il2CppObject* L_15 = __this->get_ctorArgs_1();
		int32_t L_16 = V_1;
		NullCheck(L_15);
		CustomAttributeTypedArgument_t1498197914  L_17 = InterfaceFuncInvoker1< CustomAttributeTypedArgument_t1498197914 , int32_t >::Invoke(3 /* T System.Collections.Generic.IList`1<System.Reflection.CustomAttributeTypedArgument>::get_Item(System.Int32) */, IList_1_t2039138515_il2cpp_TypeInfo_var, L_15, L_16);
		V_5 = L_17;
		CustomAttributeData_t3093286891 * L_18 = V_0;
		NullCheck(L_18);
		Il2CppObject* L_19 = L_18->get_ctorArgs_1();
		int32_t L_20 = V_1;
		NullCheck(L_19);
		CustomAttributeTypedArgument_t1498197914  L_21 = InterfaceFuncInvoker1< CustomAttributeTypedArgument_t1498197914 , int32_t >::Invoke(3 /* T System.Collections.Generic.IList`1<System.Reflection.CustomAttributeTypedArgument>::get_Item(System.Int32) */, IList_1_t2039138515_il2cpp_TypeInfo_var, L_19, L_20);
		CustomAttributeTypedArgument_t1498197914  L_22 = L_21;
		Il2CppObject * L_23 = Box(CustomAttributeTypedArgument_t1498197914_il2cpp_TypeInfo_var, &L_22);
		bool L_24 = CustomAttributeTypedArgument_Equals_m1555989603((&V_5), L_23, /*hidden argument*/NULL);
		if (!L_24)
		{
			goto IL_008a;
		}
	}
	{
		return (bool)0;
	}

IL_008a:
	{
		int32_t L_25 = V_1;
		V_1 = ((int32_t)((int32_t)L_25+(int32_t)1));
	}

IL_008e:
	{
		int32_t L_26 = V_1;
		Il2CppObject* L_27 = __this->get_ctorArgs_1();
		NullCheck(L_27);
		int32_t L_28 = InterfaceFuncInvoker0< int32_t >::Invoke(0 /* System.Int32 System.Collections.Generic.ICollection`1<System.Reflection.CustomAttributeTypedArgument>::get_Count() */, ICollection_1_t2450273219_il2cpp_TypeInfo_var, L_27);
		if ((((int32_t)L_26) < ((int32_t)L_28)))
		{
			goto IL_005d;
		}
	}
	{
		V_2 = 0;
		goto IL_0107;
	}

IL_00a6:
	{
		V_3 = (bool)0;
		V_4 = 0;
		goto IL_00e9;
	}

IL_00b0:
	{
		Il2CppObject* L_29 = __this->get_namedArgs_2();
		int32_t L_30 = V_2;
		NullCheck(L_29);
		CustomAttributeNamedArgument_t94157543  L_31 = InterfaceFuncInvoker1< CustomAttributeNamedArgument_t94157543 , int32_t >::Invoke(3 /* T System.Collections.Generic.IList`1<System.Reflection.CustomAttributeNamedArgument>::get_Item(System.Int32) */, IList_1_t635098144_il2cpp_TypeInfo_var, L_29, L_30);
		V_6 = L_31;
		CustomAttributeData_t3093286891 * L_32 = V_0;
		NullCheck(L_32);
		Il2CppObject* L_33 = L_32->get_namedArgs_2();
		int32_t L_34 = V_4;
		NullCheck(L_33);
		CustomAttributeNamedArgument_t94157543  L_35 = InterfaceFuncInvoker1< CustomAttributeNamedArgument_t94157543 , int32_t >::Invoke(3 /* T System.Collections.Generic.IList`1<System.Reflection.CustomAttributeNamedArgument>::get_Item(System.Int32) */, IList_1_t635098144_il2cpp_TypeInfo_var, L_33, L_34);
		CustomAttributeNamedArgument_t94157543  L_36 = L_35;
		Il2CppObject * L_37 = Box(CustomAttributeNamedArgument_t94157543_il2cpp_TypeInfo_var, &L_36);
		bool L_38 = CustomAttributeNamedArgument_Equals_m2691468532((&V_6), L_37, /*hidden argument*/NULL);
		if (!L_38)
		{
			goto IL_00e3;
		}
	}
	{
		V_3 = (bool)1;
		goto IL_00fb;
	}

IL_00e3:
	{
		int32_t L_39 = V_4;
		V_4 = ((int32_t)((int32_t)L_39+(int32_t)1));
	}

IL_00e9:
	{
		int32_t L_40 = V_4;
		CustomAttributeData_t3093286891 * L_41 = V_0;
		NullCheck(L_41);
		Il2CppObject* L_42 = L_41->get_namedArgs_2();
		NullCheck(L_42);
		int32_t L_43 = InterfaceFuncInvoker0< int32_t >::Invoke(0 /* System.Int32 System.Collections.Generic.ICollection`1<System.Reflection.CustomAttributeNamedArgument>::get_Count() */, ICollection_1_t1046232848_il2cpp_TypeInfo_var, L_42);
		if ((((int32_t)L_40) < ((int32_t)L_43)))
		{
			goto IL_00b0;
		}
	}

IL_00fb:
	{
		bool L_44 = V_3;
		if (L_44)
		{
			goto IL_0103;
		}
	}
	{
		return (bool)0;
	}

IL_0103:
	{
		int32_t L_45 = V_2;
		V_2 = ((int32_t)((int32_t)L_45+(int32_t)1));
	}

IL_0107:
	{
		int32_t L_46 = V_2;
		Il2CppObject* L_47 = __this->get_namedArgs_2();
		NullCheck(L_47);
		int32_t L_48 = InterfaceFuncInvoker0< int32_t >::Invoke(0 /* System.Int32 System.Collections.Generic.ICollection`1<System.Reflection.CustomAttributeNamedArgument>::get_Count() */, ICollection_1_t1046232848_il2cpp_TypeInfo_var, L_47);
		if ((((int32_t)L_46) < ((int32_t)L_48)))
		{
			goto IL_00a6;
		}
	}
	{
		return (bool)1;
	}
}
// System.Int32 System.Reflection.CustomAttributeData::GetHashCode()
extern Il2CppClass* IList_1_t2039138515_il2cpp_TypeInfo_var;
extern Il2CppClass* ICollection_1_t2450273219_il2cpp_TypeInfo_var;
extern Il2CppClass* IList_1_t635098144_il2cpp_TypeInfo_var;
extern Il2CppClass* ICollection_1_t1046232848_il2cpp_TypeInfo_var;
extern const uint32_t CustomAttributeData_GetHashCode_m3989739430_MetadataUsageId;
extern "C"  int32_t CustomAttributeData_GetHashCode_m3989739430 (CustomAttributeData_t3093286891 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (CustomAttributeData_GetHashCode_m3989739430_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	CustomAttributeTypedArgument_t1498197914  V_3;
	memset(&V_3, 0, sizeof(V_3));
	CustomAttributeNamedArgument_t94157543  V_4;
	memset(&V_4, 0, sizeof(V_4));
	{
		ConstructorInfo_t2851816542 * L_0 = __this->get_ctorInfo_0();
		NullCheck(L_0);
		int32_t L_1 = VirtFuncInvoker0< int32_t >::Invoke(2 /* System.Int32 System.Object::GetHashCode() */, L_0);
		V_0 = ((int32_t)((int32_t)L_1<<(int32_t)((int32_t)16)));
		V_1 = 0;
		goto IL_003f;
	}

IL_0016:
	{
		int32_t L_2 = V_0;
		int32_t L_3 = V_0;
		Il2CppObject* L_4 = __this->get_ctorArgs_1();
		int32_t L_5 = V_1;
		NullCheck(L_4);
		CustomAttributeTypedArgument_t1498197914  L_6 = InterfaceFuncInvoker1< CustomAttributeTypedArgument_t1498197914 , int32_t >::Invoke(3 /* T System.Collections.Generic.IList`1<System.Reflection.CustomAttributeTypedArgument>::get_Item(System.Int32) */, IList_1_t2039138515_il2cpp_TypeInfo_var, L_4, L_5);
		V_3 = L_6;
		int32_t L_7 = CustomAttributeTypedArgument_GetHashCode_m999147081((&V_3), /*hidden argument*/NULL);
		int32_t L_8 = V_1;
		V_0 = ((int32_t)((int32_t)L_2+(int32_t)((int32_t)((int32_t)L_3^(int32_t)((int32_t)((int32_t)((int32_t)((int32_t)7+(int32_t)L_7))<<(int32_t)((int32_t)((int32_t)((int32_t)((int32_t)((int32_t)((int32_t)L_8*(int32_t)4))&(int32_t)((int32_t)31)))&(int32_t)((int32_t)31)))))))));
		int32_t L_9 = V_1;
		V_1 = ((int32_t)((int32_t)L_9+(int32_t)1));
	}

IL_003f:
	{
		int32_t L_10 = V_1;
		Il2CppObject* L_11 = __this->get_ctorArgs_1();
		NullCheck(L_11);
		int32_t L_12 = InterfaceFuncInvoker0< int32_t >::Invoke(0 /* System.Int32 System.Collections.Generic.ICollection`1<System.Reflection.CustomAttributeTypedArgument>::get_Count() */, ICollection_1_t2450273219_il2cpp_TypeInfo_var, L_11);
		if ((((int32_t)L_10) < ((int32_t)L_12)))
		{
			goto IL_0016;
		}
	}
	{
		V_2 = 0;
		goto IL_0075;
	}

IL_0057:
	{
		int32_t L_13 = V_0;
		Il2CppObject* L_14 = __this->get_namedArgs_2();
		int32_t L_15 = V_2;
		NullCheck(L_14);
		CustomAttributeNamedArgument_t94157543  L_16 = InterfaceFuncInvoker1< CustomAttributeNamedArgument_t94157543 , int32_t >::Invoke(3 /* T System.Collections.Generic.IList`1<System.Reflection.CustomAttributeNamedArgument>::get_Item(System.Int32) */, IList_1_t635098144_il2cpp_TypeInfo_var, L_14, L_15);
		V_4 = L_16;
		int32_t L_17 = CustomAttributeNamedArgument_GetHashCode_m3715408876((&V_4), /*hidden argument*/NULL);
		V_0 = ((int32_t)((int32_t)L_13+(int32_t)((int32_t)((int32_t)L_17<<(int32_t)5))));
		int32_t L_18 = V_2;
		V_2 = ((int32_t)((int32_t)L_18+(int32_t)1));
	}

IL_0075:
	{
		int32_t L_19 = V_2;
		Il2CppObject* L_20 = __this->get_namedArgs_2();
		NullCheck(L_20);
		int32_t L_21 = InterfaceFuncInvoker0< int32_t >::Invoke(0 /* System.Int32 System.Collections.Generic.ICollection`1<System.Reflection.CustomAttributeNamedArgument>::get_Count() */, ICollection_1_t1046232848_il2cpp_TypeInfo_var, L_20);
		if ((((int32_t)L_19) < ((int32_t)L_21)))
		{
			goto IL_0057;
		}
	}
	{
		int32_t L_22 = V_0;
		return L_22;
	}
}
// System.String System.Reflection.CustomAttributeNamedArgument::ToString()
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral507810557;
extern const uint32_t CustomAttributeNamedArgument_ToString_m804774956_MetadataUsageId;
extern "C"  String_t* CustomAttributeNamedArgument_ToString_m804774956 (CustomAttributeNamedArgument_t94157543 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (CustomAttributeNamedArgument_ToString_m804774956_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		MemberInfo_t * L_0 = __this->get_memberInfo_1();
		NullCheck(L_0);
		String_t* L_1 = VirtFuncInvoker0< String_t* >::Invoke(8 /* System.String System.Reflection.MemberInfo::get_Name() */, L_0);
		CustomAttributeTypedArgument_t1498197914 * L_2 = __this->get_address_of_typedArgument_0();
		String_t* L_3 = CustomAttributeTypedArgument_ToString_m1091739553(L_2, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_4 = String_Concat_m612901809(NULL /*static, unused*/, L_1, _stringLiteral507810557, L_3, /*hidden argument*/NULL);
		return L_4;
	}
}
extern "C"  String_t* CustomAttributeNamedArgument_ToString_m804774956_AdjustorThunk (Il2CppObject * __this, const MethodInfo* method)
{
	CustomAttributeNamedArgument_t94157543 * _thisAdjusted = reinterpret_cast<CustomAttributeNamedArgument_t94157543 *>(__this + 1);
	return CustomAttributeNamedArgument_ToString_m804774956(_thisAdjusted, method);
}
// System.Boolean System.Reflection.CustomAttributeNamedArgument::Equals(System.Object)
extern Il2CppClass* CustomAttributeNamedArgument_t94157543_il2cpp_TypeInfo_var;
extern Il2CppClass* CustomAttributeTypedArgument_t1498197914_il2cpp_TypeInfo_var;
extern const uint32_t CustomAttributeNamedArgument_Equals_m2691468532_MetadataUsageId;
extern "C"  bool CustomAttributeNamedArgument_Equals_m2691468532 (CustomAttributeNamedArgument_t94157543 * __this, Il2CppObject * ___obj0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (CustomAttributeNamedArgument_Equals_m2691468532_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	CustomAttributeNamedArgument_t94157543  V_0;
	memset(&V_0, 0, sizeof(V_0));
	int32_t G_B5_0 = 0;
	{
		Il2CppObject * L_0 = ___obj0;
		if (((Il2CppObject *)IsInstSealed(L_0, CustomAttributeNamedArgument_t94157543_il2cpp_TypeInfo_var)))
		{
			goto IL_000d;
		}
	}
	{
		return (bool)0;
	}

IL_000d:
	{
		Il2CppObject * L_1 = ___obj0;
		V_0 = ((*(CustomAttributeNamedArgument_t94157543 *)((CustomAttributeNamedArgument_t94157543 *)UnBox (L_1, CustomAttributeNamedArgument_t94157543_il2cpp_TypeInfo_var))));
		MemberInfo_t * L_2 = (&V_0)->get_memberInfo_1();
		MemberInfo_t * L_3 = __this->get_memberInfo_1();
		if ((!(((Il2CppObject*)(MemberInfo_t *)L_2) == ((Il2CppObject*)(MemberInfo_t *)L_3))))
		{
			goto IL_003f;
		}
	}
	{
		CustomAttributeTypedArgument_t1498197914 * L_4 = __this->get_address_of_typedArgument_0();
		CustomAttributeTypedArgument_t1498197914  L_5 = (&V_0)->get_typedArgument_0();
		CustomAttributeTypedArgument_t1498197914  L_6 = L_5;
		Il2CppObject * L_7 = Box(CustomAttributeTypedArgument_t1498197914_il2cpp_TypeInfo_var, &L_6);
		bool L_8 = CustomAttributeTypedArgument_Equals_m1555989603(L_4, L_7, /*hidden argument*/NULL);
		G_B5_0 = ((int32_t)(L_8));
		goto IL_0040;
	}

IL_003f:
	{
		G_B5_0 = 0;
	}

IL_0040:
	{
		return (bool)G_B5_0;
	}
}
extern "C"  bool CustomAttributeNamedArgument_Equals_m2691468532_AdjustorThunk (Il2CppObject * __this, Il2CppObject * ___obj0, const MethodInfo* method)
{
	CustomAttributeNamedArgument_t94157543 * _thisAdjusted = reinterpret_cast<CustomAttributeNamedArgument_t94157543 *>(__this + 1);
	return CustomAttributeNamedArgument_Equals_m2691468532(_thisAdjusted, ___obj0, method);
}
// System.Int32 System.Reflection.CustomAttributeNamedArgument::GetHashCode()
extern "C"  int32_t CustomAttributeNamedArgument_GetHashCode_m3715408876 (CustomAttributeNamedArgument_t94157543 * __this, const MethodInfo* method)
{
	{
		MemberInfo_t * L_0 = __this->get_memberInfo_1();
		NullCheck(L_0);
		int32_t L_1 = VirtFuncInvoker0< int32_t >::Invoke(2 /* System.Int32 System.Object::GetHashCode() */, L_0);
		CustomAttributeTypedArgument_t1498197914 * L_2 = __this->get_address_of_typedArgument_0();
		int32_t L_3 = CustomAttributeTypedArgument_GetHashCode_m999147081(L_2, /*hidden argument*/NULL);
		return ((int32_t)((int32_t)((int32_t)((int32_t)L_1<<(int32_t)((int32_t)16)))+(int32_t)L_3));
	}
}
extern "C"  int32_t CustomAttributeNamedArgument_GetHashCode_m3715408876_AdjustorThunk (Il2CppObject * __this, const MethodInfo* method)
{
	CustomAttributeNamedArgument_t94157543 * _thisAdjusted = reinterpret_cast<CustomAttributeNamedArgument_t94157543 *>(__this + 1);
	return CustomAttributeNamedArgument_GetHashCode_m3715408876(_thisAdjusted, method);
}
// Conversion methods for marshalling of: System.Reflection.CustomAttributeNamedArgument
extern "C" void CustomAttributeNamedArgument_t94157543_marshal_pinvoke(const CustomAttributeNamedArgument_t94157543& unmarshaled, CustomAttributeNamedArgument_t94157543_marshaled_pinvoke& marshaled)
{
	Il2CppCodeGenException* ___typedArgument_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'typedArgument' of type 'CustomAttributeNamedArgument'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___typedArgument_0Exception);
}
extern "C" void CustomAttributeNamedArgument_t94157543_marshal_pinvoke_back(const CustomAttributeNamedArgument_t94157543_marshaled_pinvoke& marshaled, CustomAttributeNamedArgument_t94157543& unmarshaled)
{
	Il2CppCodeGenException* ___typedArgument_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'typedArgument' of type 'CustomAttributeNamedArgument'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___typedArgument_0Exception);
}
// Conversion method for clean up from marshalling of: System.Reflection.CustomAttributeNamedArgument
extern "C" void CustomAttributeNamedArgument_t94157543_marshal_pinvoke_cleanup(CustomAttributeNamedArgument_t94157543_marshaled_pinvoke& marshaled)
{
}
// Conversion methods for marshalling of: System.Reflection.CustomAttributeNamedArgument
extern "C" void CustomAttributeNamedArgument_t94157543_marshal_com(const CustomAttributeNamedArgument_t94157543& unmarshaled, CustomAttributeNamedArgument_t94157543_marshaled_com& marshaled)
{
	Il2CppCodeGenException* ___typedArgument_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'typedArgument' of type 'CustomAttributeNamedArgument'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___typedArgument_0Exception);
}
extern "C" void CustomAttributeNamedArgument_t94157543_marshal_com_back(const CustomAttributeNamedArgument_t94157543_marshaled_com& marshaled, CustomAttributeNamedArgument_t94157543& unmarshaled)
{
	Il2CppCodeGenException* ___typedArgument_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'typedArgument' of type 'CustomAttributeNamedArgument'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___typedArgument_0Exception);
}
// Conversion method for clean up from marshalling of: System.Reflection.CustomAttributeNamedArgument
extern "C" void CustomAttributeNamedArgument_t94157543_marshal_com_cleanup(CustomAttributeNamedArgument_t94157543_marshaled_com& marshaled)
{
}
// System.String System.Reflection.CustomAttributeTypedArgument::ToString()
extern const Il2CppType* String_t_0_0_0_var;
extern const Il2CppType* Type_t_0_0_0_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral372029312;
extern Il2CppCodeGenString* _stringLiteral1002073185;
extern Il2CppCodeGenString* _stringLiteral372029317;
extern Il2CppCodeGenString* _stringLiteral372029318;
extern const uint32_t CustomAttributeTypedArgument_ToString_m1091739553_MetadataUsageId;
extern "C"  String_t* CustomAttributeTypedArgument_ToString_m1091739553 (CustomAttributeTypedArgument_t1498197914 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (CustomAttributeTypedArgument_ToString_m1091739553_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	String_t* V_0 = NULL;
	String_t* G_B3_0 = NULL;
	{
		Il2CppObject * L_0 = __this->get_value_1();
		if (!L_0)
		{
			goto IL_001b;
		}
	}
	{
		Il2CppObject * L_1 = __this->get_value_1();
		NullCheck(L_1);
		String_t* L_2 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Object::ToString() */, L_1);
		G_B3_0 = L_2;
		goto IL_0020;
	}

IL_001b:
	{
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_3 = ((String_t_StaticFields*)String_t_il2cpp_TypeInfo_var->static_fields)->get_Empty_2();
		G_B3_0 = L_3;
	}

IL_0020:
	{
		V_0 = G_B3_0;
		Type_t * L_4 = __this->get_argumentType_0();
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_5 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(String_t_0_0_0_var), /*hidden argument*/NULL);
		if ((!(((Il2CppObject*)(Type_t *)L_4) == ((Il2CppObject*)(Type_t *)L_5))))
		{
			goto IL_0047;
		}
	}
	{
		String_t* L_6 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_7 = String_Concat_m612901809(NULL /*static, unused*/, _stringLiteral372029312, L_6, _stringLiteral372029312, /*hidden argument*/NULL);
		return L_7;
	}

IL_0047:
	{
		Type_t * L_8 = __this->get_argumentType_0();
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_9 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Type_t_0_0_0_var), /*hidden argument*/NULL);
		if ((!(((Il2CppObject*)(Type_t *)L_8) == ((Il2CppObject*)(Type_t *)L_9))))
		{
			goto IL_006d;
		}
	}
	{
		String_t* L_10 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_11 = String_Concat_m612901809(NULL /*static, unused*/, _stringLiteral1002073185, L_10, _stringLiteral372029317, /*hidden argument*/NULL);
		return L_11;
	}

IL_006d:
	{
		Type_t * L_12 = __this->get_argumentType_0();
		NullCheck(L_12);
		bool L_13 = Type_get_IsEnum_m313908919(L_12, /*hidden argument*/NULL);
		if (!L_13)
		{
			goto IL_0099;
		}
	}
	{
		Type_t * L_14 = __this->get_argumentType_0();
		NullCheck(L_14);
		String_t* L_15 = VirtFuncInvoker0< String_t* >::Invoke(8 /* System.String System.Reflection.MemberInfo::get_Name() */, L_14);
		String_t* L_16 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_17 = String_Concat_m1561703559(NULL /*static, unused*/, _stringLiteral372029318, L_15, _stringLiteral372029317, L_16, /*hidden argument*/NULL);
		return L_17;
	}

IL_0099:
	{
		String_t* L_18 = V_0;
		return L_18;
	}
}
extern "C"  String_t* CustomAttributeTypedArgument_ToString_m1091739553_AdjustorThunk (Il2CppObject * __this, const MethodInfo* method)
{
	CustomAttributeTypedArgument_t1498197914 * _thisAdjusted = reinterpret_cast<CustomAttributeTypedArgument_t1498197914 *>(__this + 1);
	return CustomAttributeTypedArgument_ToString_m1091739553(_thisAdjusted, method);
}
// System.Boolean System.Reflection.CustomAttributeTypedArgument::Equals(System.Object)
extern Il2CppClass* CustomAttributeTypedArgument_t1498197914_il2cpp_TypeInfo_var;
extern const uint32_t CustomAttributeTypedArgument_Equals_m1555989603_MetadataUsageId;
extern "C"  bool CustomAttributeTypedArgument_Equals_m1555989603 (CustomAttributeTypedArgument_t1498197914 * __this, Il2CppObject * ___obj0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (CustomAttributeTypedArgument_Equals_m1555989603_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	CustomAttributeTypedArgument_t1498197914  V_0;
	memset(&V_0, 0, sizeof(V_0));
	int32_t G_B6_0 = 0;
	{
		Il2CppObject * L_0 = ___obj0;
		if (((Il2CppObject *)IsInstSealed(L_0, CustomAttributeTypedArgument_t1498197914_il2cpp_TypeInfo_var)))
		{
			goto IL_000d;
		}
	}
	{
		return (bool)0;
	}

IL_000d:
	{
		Il2CppObject * L_1 = ___obj0;
		V_0 = ((*(CustomAttributeTypedArgument_t1498197914 *)((CustomAttributeTypedArgument_t1498197914 *)UnBox (L_1, CustomAttributeTypedArgument_t1498197914_il2cpp_TypeInfo_var))));
		Type_t * L_2 = (&V_0)->get_argumentType_0();
		Type_t * L_3 = __this->get_argumentType_0();
		if ((!(((Il2CppObject*)(Type_t *)L_2) == ((Il2CppObject*)(Type_t *)L_3))))
		{
			goto IL_0048;
		}
	}
	{
		Il2CppObject * L_4 = __this->get_value_1();
		if (!L_4)
		{
			goto IL_0048;
		}
	}
	{
		Il2CppObject * L_5 = __this->get_value_1();
		Il2CppObject * L_6 = (&V_0)->get_value_1();
		NullCheck(L_5);
		bool L_7 = VirtFuncInvoker1< bool, Il2CppObject * >::Invoke(0 /* System.Boolean System.Object::Equals(System.Object) */, L_5, L_6);
		G_B6_0 = ((int32_t)(L_7));
		goto IL_0052;
	}

IL_0048:
	{
		Il2CppObject * L_8 = (&V_0)->get_value_1();
		G_B6_0 = ((((Il2CppObject*)(Il2CppObject *)L_8) == ((Il2CppObject*)(Il2CppObject *)NULL))? 1 : 0);
	}

IL_0052:
	{
		return (bool)G_B6_0;
	}
}
extern "C"  bool CustomAttributeTypedArgument_Equals_m1555989603_AdjustorThunk (Il2CppObject * __this, Il2CppObject * ___obj0, const MethodInfo* method)
{
	CustomAttributeTypedArgument_t1498197914 * _thisAdjusted = reinterpret_cast<CustomAttributeTypedArgument_t1498197914 *>(__this + 1);
	return CustomAttributeTypedArgument_Equals_m1555989603(_thisAdjusted, ___obj0, method);
}
// System.Int32 System.Reflection.CustomAttributeTypedArgument::GetHashCode()
extern "C"  int32_t CustomAttributeTypedArgument_GetHashCode_m999147081 (CustomAttributeTypedArgument_t1498197914 * __this, const MethodInfo* method)
{
	int32_t G_B2_0 = 0;
	int32_t G_B1_0 = 0;
	int32_t G_B3_0 = 0;
	int32_t G_B3_1 = 0;
	{
		Type_t * L_0 = __this->get_argumentType_0();
		NullCheck(L_0);
		int32_t L_1 = VirtFuncInvoker0< int32_t >::Invoke(2 /* System.Int32 System.Type::GetHashCode() */, L_0);
		Il2CppObject * L_2 = __this->get_value_1();
		G_B1_0 = ((int32_t)((int32_t)L_1<<(int32_t)((int32_t)16)));
		if (!L_2)
		{
			G_B2_0 = ((int32_t)((int32_t)L_1<<(int32_t)((int32_t)16)));
			goto IL_0029;
		}
	}
	{
		Il2CppObject * L_3 = __this->get_value_1();
		NullCheck(L_3);
		int32_t L_4 = VirtFuncInvoker0< int32_t >::Invoke(2 /* System.Int32 System.Object::GetHashCode() */, L_3);
		G_B3_0 = L_4;
		G_B3_1 = G_B1_0;
		goto IL_002a;
	}

IL_0029:
	{
		G_B3_0 = 0;
		G_B3_1 = G_B2_0;
	}

IL_002a:
	{
		return ((int32_t)((int32_t)G_B3_1+(int32_t)G_B3_0));
	}
}
extern "C"  int32_t CustomAttributeTypedArgument_GetHashCode_m999147081_AdjustorThunk (Il2CppObject * __this, const MethodInfo* method)
{
	CustomAttributeTypedArgument_t1498197914 * _thisAdjusted = reinterpret_cast<CustomAttributeTypedArgument_t1498197914 *>(__this + 1);
	return CustomAttributeTypedArgument_GetHashCode_m999147081(_thisAdjusted, method);
}
// Conversion methods for marshalling of: System.Reflection.CustomAttributeTypedArgument
extern "C" void CustomAttributeTypedArgument_t1498197914_marshal_pinvoke(const CustomAttributeTypedArgument_t1498197914& unmarshaled, CustomAttributeTypedArgument_t1498197914_marshaled_pinvoke& marshaled)
{
	Il2CppCodeGenException* ___argumentType_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'argumentType' of type 'CustomAttributeTypedArgument': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___argumentType_0Exception);
}
extern "C" void CustomAttributeTypedArgument_t1498197914_marshal_pinvoke_back(const CustomAttributeTypedArgument_t1498197914_marshaled_pinvoke& marshaled, CustomAttributeTypedArgument_t1498197914& unmarshaled)
{
	Il2CppCodeGenException* ___argumentType_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'argumentType' of type 'CustomAttributeTypedArgument': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___argumentType_0Exception);
}
// Conversion method for clean up from marshalling of: System.Reflection.CustomAttributeTypedArgument
extern "C" void CustomAttributeTypedArgument_t1498197914_marshal_pinvoke_cleanup(CustomAttributeTypedArgument_t1498197914_marshaled_pinvoke& marshaled)
{
}
// Conversion methods for marshalling of: System.Reflection.CustomAttributeTypedArgument
extern "C" void CustomAttributeTypedArgument_t1498197914_marshal_com(const CustomAttributeTypedArgument_t1498197914& unmarshaled, CustomAttributeTypedArgument_t1498197914_marshaled_com& marshaled)
{
	Il2CppCodeGenException* ___argumentType_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'argumentType' of type 'CustomAttributeTypedArgument': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___argumentType_0Exception);
}
extern "C" void CustomAttributeTypedArgument_t1498197914_marshal_com_back(const CustomAttributeTypedArgument_t1498197914_marshaled_com& marshaled, CustomAttributeTypedArgument_t1498197914& unmarshaled)
{
	Il2CppCodeGenException* ___argumentType_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'argumentType' of type 'CustomAttributeTypedArgument': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___argumentType_0Exception);
}
// Conversion method for clean up from marshalling of: System.Reflection.CustomAttributeTypedArgument
extern "C" void CustomAttributeTypedArgument_t1498197914_marshal_com_cleanup(CustomAttributeTypedArgument_t1498197914_marshaled_com& marshaled)
{
}
// System.Void System.Reflection.DefaultMemberAttribute::.ctor(System.String)
extern "C"  void DefaultMemberAttribute__ctor_m2234856827 (DefaultMemberAttribute_t889804479 * __this, String_t* ___memberName0, const MethodInfo* method)
{
	{
		Attribute__ctor_m1730479323(__this, /*hidden argument*/NULL);
		String_t* L_0 = ___memberName0;
		__this->set_member_name_0(L_0);
		return;
	}
}
// System.String System.Reflection.DefaultMemberAttribute::get_MemberName()
extern "C"  String_t* DefaultMemberAttribute_get_MemberName_m1393933516 (DefaultMemberAttribute_t889804479 * __this, const MethodInfo* method)
{
	{
		String_t* L_0 = __this->get_member_name_0();
		return L_0;
	}
}
// System.String System.Reflection.Emit.AssemblyBuilder::get_Location()
extern "C"  String_t* AssemblyBuilder_get_Location_m554656855 (AssemblyBuilder_t1646117627 * __this, const MethodInfo* method)
{
	{
		Exception_t1927440687 * L_0 = AssemblyBuilder_not_supported_m383946865(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Reflection.Module[] System.Reflection.Emit.AssemblyBuilder::GetModulesInternal()
extern Il2CppClass* ModuleU5BU5D_t3593287923_il2cpp_TypeInfo_var;
extern const uint32_t AssemblyBuilder_GetModulesInternal_m3379844831_MetadataUsageId;
extern "C"  ModuleU5BU5D_t3593287923* AssemblyBuilder_GetModulesInternal_m3379844831 (AssemblyBuilder_t1646117627 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AssemblyBuilder_GetModulesInternal_m3379844831_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ModuleBuilderU5BU5D_t3642333382* L_0 = __this->get_modules_10();
		if (L_0)
		{
			goto IL_0012;
		}
	}
	{
		return ((ModuleU5BU5D_t3593287923*)SZArrayNew(ModuleU5BU5D_t3593287923_il2cpp_TypeInfo_var, (uint32_t)0));
	}

IL_0012:
	{
		ModuleBuilderU5BU5D_t3642333382* L_1 = __this->get_modules_10();
		NullCheck((Il2CppArray *)(Il2CppArray *)L_1);
		Il2CppObject * L_2 = Array_Clone_m768574314((Il2CppArray *)(Il2CppArray *)L_1, /*hidden argument*/NULL);
		return ((ModuleU5BU5D_t3593287923*)Castclass(L_2, ModuleU5BU5D_t3593287923_il2cpp_TypeInfo_var));
	}
}
// System.Type[] System.Reflection.Emit.AssemblyBuilder::GetTypes(System.Boolean)
extern Il2CppClass* TypeU5BU5D_t1664964607_il2cpp_TypeInfo_var;
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern const uint32_t AssemblyBuilder_GetTypes_m2527954992_MetadataUsageId;
extern "C"  TypeU5BU5D_t1664964607* AssemblyBuilder_GetTypes_m2527954992 (AssemblyBuilder_t1646117627 * __this, bool ___exportedOnly0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AssemblyBuilder_GetTypes_m2527954992_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	TypeU5BU5D_t1664964607* V_0 = NULL;
	int32_t V_1 = 0;
	TypeU5BU5D_t1664964607* V_2 = NULL;
	TypeU5BU5D_t1664964607* V_3 = NULL;
	int32_t V_4 = 0;
	TypeU5BU5D_t1664964607* V_5 = NULL;
	TypeU5BU5D_t1664964607* V_6 = NULL;
	TypeU5BU5D_t1664964607* G_B17_0 = NULL;
	{
		V_0 = (TypeU5BU5D_t1664964607*)NULL;
		ModuleBuilderU5BU5D_t3642333382* L_0 = __this->get_modules_10();
		if (!L_0)
		{
			goto IL_0068;
		}
	}
	{
		V_1 = 0;
		goto IL_005a;
	}

IL_0014:
	{
		ModuleBuilderU5BU5D_t3642333382* L_1 = __this->get_modules_10();
		int32_t L_2 = V_1;
		NullCheck(L_1);
		int32_t L_3 = L_2;
		ModuleBuilder_t4156028127 * L_4 = (L_1)->GetAt(static_cast<il2cpp_array_size_t>(L_3));
		NullCheck(L_4);
		TypeU5BU5D_t1664964607* L_5 = VirtFuncInvoker0< TypeU5BU5D_t1664964607* >::Invoke(9 /* System.Type[] System.Reflection.Emit.ModuleBuilder::GetTypes() */, L_4);
		V_2 = L_5;
		TypeU5BU5D_t1664964607* L_6 = V_0;
		if (L_6)
		{
			goto IL_002f;
		}
	}
	{
		TypeU5BU5D_t1664964607* L_7 = V_2;
		V_0 = L_7;
		goto IL_0056;
	}

IL_002f:
	{
		TypeU5BU5D_t1664964607* L_8 = V_0;
		NullCheck(L_8);
		TypeU5BU5D_t1664964607* L_9 = V_2;
		NullCheck(L_9);
		V_3 = ((TypeU5BU5D_t1664964607*)SZArrayNew(TypeU5BU5D_t1664964607_il2cpp_TypeInfo_var, (uint32_t)((int32_t)((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_8)->max_length))))+(int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_9)->max_length))))))));
		TypeU5BU5D_t1664964607* L_10 = V_0;
		TypeU5BU5D_t1664964607* L_11 = V_3;
		TypeU5BU5D_t1664964607* L_12 = V_0;
		NullCheck(L_12);
		Array_Copy_m3808317496(NULL /*static, unused*/, (Il2CppArray *)(Il2CppArray *)L_10, 0, (Il2CppArray *)(Il2CppArray *)L_11, 0, (((int32_t)((int32_t)(((Il2CppArray *)L_12)->max_length)))), /*hidden argument*/NULL);
		TypeU5BU5D_t1664964607* L_13 = V_2;
		TypeU5BU5D_t1664964607* L_14 = V_3;
		TypeU5BU5D_t1664964607* L_15 = V_0;
		NullCheck(L_15);
		TypeU5BU5D_t1664964607* L_16 = V_2;
		NullCheck(L_16);
		Array_Copy_m3808317496(NULL /*static, unused*/, (Il2CppArray *)(Il2CppArray *)L_13, 0, (Il2CppArray *)(Il2CppArray *)L_14, (((int32_t)((int32_t)(((Il2CppArray *)L_15)->max_length)))), (((int32_t)((int32_t)(((Il2CppArray *)L_16)->max_length)))), /*hidden argument*/NULL);
	}

IL_0056:
	{
		int32_t L_17 = V_1;
		V_1 = ((int32_t)((int32_t)L_17+(int32_t)1));
	}

IL_005a:
	{
		int32_t L_18 = V_1;
		ModuleBuilderU5BU5D_t3642333382* L_19 = __this->get_modules_10();
		NullCheck(L_19);
		if ((((int32_t)L_18) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_19)->max_length)))))))
		{
			goto IL_0014;
		}
	}

IL_0068:
	{
		ModuleU5BU5D_t3593287923* L_20 = __this->get_loaded_modules_11();
		if (!L_20)
		{
			goto IL_00db;
		}
	}
	{
		V_4 = 0;
		goto IL_00cc;
	}

IL_007b:
	{
		ModuleU5BU5D_t3593287923* L_21 = __this->get_loaded_modules_11();
		int32_t L_22 = V_4;
		NullCheck(L_21);
		int32_t L_23 = L_22;
		Module_t4282841206 * L_24 = (L_21)->GetAt(static_cast<il2cpp_array_size_t>(L_23));
		NullCheck(L_24);
		TypeU5BU5D_t1664964607* L_25 = VirtFuncInvoker0< TypeU5BU5D_t1664964607* >::Invoke(9 /* System.Type[] System.Reflection.Module::GetTypes() */, L_24);
		V_5 = L_25;
		TypeU5BU5D_t1664964607* L_26 = V_0;
		if (L_26)
		{
			goto IL_0099;
		}
	}
	{
		TypeU5BU5D_t1664964607* L_27 = V_5;
		V_0 = L_27;
		goto IL_00c6;
	}

IL_0099:
	{
		TypeU5BU5D_t1664964607* L_28 = V_0;
		NullCheck(L_28);
		TypeU5BU5D_t1664964607* L_29 = V_5;
		NullCheck(L_29);
		V_6 = ((TypeU5BU5D_t1664964607*)SZArrayNew(TypeU5BU5D_t1664964607_il2cpp_TypeInfo_var, (uint32_t)((int32_t)((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_28)->max_length))))+(int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_29)->max_length))))))));
		TypeU5BU5D_t1664964607* L_30 = V_0;
		TypeU5BU5D_t1664964607* L_31 = V_6;
		TypeU5BU5D_t1664964607* L_32 = V_0;
		NullCheck(L_32);
		Array_Copy_m3808317496(NULL /*static, unused*/, (Il2CppArray *)(Il2CppArray *)L_30, 0, (Il2CppArray *)(Il2CppArray *)L_31, 0, (((int32_t)((int32_t)(((Il2CppArray *)L_32)->max_length)))), /*hidden argument*/NULL);
		TypeU5BU5D_t1664964607* L_33 = V_5;
		TypeU5BU5D_t1664964607* L_34 = V_6;
		TypeU5BU5D_t1664964607* L_35 = V_0;
		NullCheck(L_35);
		TypeU5BU5D_t1664964607* L_36 = V_5;
		NullCheck(L_36);
		Array_Copy_m3808317496(NULL /*static, unused*/, (Il2CppArray *)(Il2CppArray *)L_33, 0, (Il2CppArray *)(Il2CppArray *)L_34, (((int32_t)((int32_t)(((Il2CppArray *)L_35)->max_length)))), (((int32_t)((int32_t)(((Il2CppArray *)L_36)->max_length)))), /*hidden argument*/NULL);
	}

IL_00c6:
	{
		int32_t L_37 = V_4;
		V_4 = ((int32_t)((int32_t)L_37+(int32_t)1));
	}

IL_00cc:
	{
		int32_t L_38 = V_4;
		ModuleU5BU5D_t3593287923* L_39 = __this->get_loaded_modules_11();
		NullCheck(L_39);
		if ((((int32_t)L_38) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_39)->max_length)))))))
		{
			goto IL_007b;
		}
	}

IL_00db:
	{
		TypeU5BU5D_t1664964607* L_40 = V_0;
		if (L_40)
		{
			goto IL_00eb;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		TypeU5BU5D_t1664964607* L_41 = ((Type_t_StaticFields*)Type_t_il2cpp_TypeInfo_var->static_fields)->get_EmptyTypes_3();
		G_B17_0 = L_41;
		goto IL_00ec;
	}

IL_00eb:
	{
		TypeU5BU5D_t1664964607* L_42 = V_0;
		G_B17_0 = L_42;
	}

IL_00ec:
	{
		return G_B17_0;
	}
}
// System.Boolean System.Reflection.Emit.AssemblyBuilder::get_IsCompilerContext()
extern "C"  bool AssemblyBuilder_get_IsCompilerContext_m2864230005 (AssemblyBuilder_t1646117627 * __this, const MethodInfo* method)
{
	{
		bool L_0 = __this->get_is_compiler_context_16();
		return L_0;
	}
}
// System.Exception System.Reflection.Emit.AssemblyBuilder::not_supported()
extern Il2CppClass* NotSupportedException_t1793819818_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral4087454587;
extern const uint32_t AssemblyBuilder_not_supported_m383946865_MetadataUsageId;
extern "C"  Exception_t1927440687 * AssemblyBuilder_not_supported_m383946865 (AssemblyBuilder_t1646117627 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AssemblyBuilder_not_supported_m383946865_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		NotSupportedException_t1793819818 * L_0 = (NotSupportedException_t1793819818 *)il2cpp_codegen_object_new(NotSupportedException_t1793819818_il2cpp_TypeInfo_var);
		NotSupportedException__ctor_m836173213(L_0, _stringLiteral4087454587, /*hidden argument*/NULL);
		return L_0;
	}
}
// System.Reflection.AssemblyName System.Reflection.Emit.AssemblyBuilder::UnprotectedGetName()
extern "C"  AssemblyName_t894705941 * AssemblyBuilder_UnprotectedGetName_m2328641134 (AssemblyBuilder_t1646117627 * __this, const MethodInfo* method)
{
	AssemblyName_t894705941 * V_0 = NULL;
	{
		AssemblyName_t894705941 * L_0 = Assembly_UnprotectedGetName_m3014607408(__this, /*hidden argument*/NULL);
		V_0 = L_0;
		StrongName_t117835354 * L_1 = __this->get_sn_15();
		if (!L_1)
		{
			goto IL_0034;
		}
	}
	{
		AssemblyName_t894705941 * L_2 = V_0;
		StrongName_t117835354 * L_3 = __this->get_sn_15();
		NullCheck(L_3);
		ByteU5BU5D_t3397334013* L_4 = StrongName_get_PublicKey_m3777577320(L_3, /*hidden argument*/NULL);
		NullCheck(L_2);
		AssemblyName_SetPublicKey_m1491402438(L_2, L_4, /*hidden argument*/NULL);
		AssemblyName_t894705941 * L_5 = V_0;
		StrongName_t117835354 * L_6 = __this->get_sn_15();
		NullCheck(L_6);
		ByteU5BU5D_t3397334013* L_7 = StrongName_get_PublicKeyToken_m1968460885(L_6, /*hidden argument*/NULL);
		NullCheck(L_5);
		AssemblyName_SetPublicKeyToken_m3032035167(L_5, L_7, /*hidden argument*/NULL);
	}

IL_0034:
	{
		AssemblyName_t894705941 * L_8 = V_0;
		return L_8;
	}
}
// System.Void System.Reflection.Emit.ByRefType::.ctor(System.Type)
extern "C"  void ByRefType__ctor_m2068210324 (ByRefType_t1587086384 * __this, Type_t * ___elementType0, const MethodInfo* method)
{
	{
		Type_t * L_0 = ___elementType0;
		DerivedType__ctor_m4154637955(__this, L_0, /*hidden argument*/NULL);
		return;
	}
}
// System.Boolean System.Reflection.Emit.ByRefType::IsByRefImpl()
extern "C"  bool ByRefType_IsByRefImpl_m3683903251 (ByRefType_t1587086384 * __this, const MethodInfo* method)
{
	{
		return (bool)1;
	}
}
// System.Type System.Reflection.Emit.ByRefType::get_BaseType()
extern const Il2CppType* Il2CppArray_0_0_0_var;
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern const uint32_t ByRefType_get_BaseType_m3405859119_MetadataUsageId;
extern "C"  Type_t * ByRefType_get_BaseType_m3405859119 (ByRefType_t1587086384 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ByRefType_get_BaseType_m3405859119_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_0 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Il2CppArray_0_0_0_var), /*hidden argument*/NULL);
		return L_0;
	}
}
// System.String System.Reflection.Emit.ByRefType::FormatName(System.String)
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral372029308;
extern const uint32_t ByRefType_FormatName_m3716172668_MetadataUsageId;
extern "C"  String_t* ByRefType_FormatName_m3716172668 (ByRefType_t1587086384 * __this, String_t* ___elementName0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ByRefType_FormatName_m3716172668_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		String_t* L_0 = ___elementName0;
		if (L_0)
		{
			goto IL_0008;
		}
	}
	{
		return (String_t*)NULL;
	}

IL_0008:
	{
		String_t* L_1 = ___elementName0;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_2 = String_Concat_m2596409543(NULL /*static, unused*/, L_1, _stringLiteral372029308, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.Type System.Reflection.Emit.ByRefType::MakeByRefType()
extern Il2CppClass* ArgumentException_t3259014390_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral912151980;
extern const uint32_t ByRefType_MakeByRefType_m2150335175_MetadataUsageId;
extern "C"  Type_t * ByRefType_MakeByRefType_m2150335175 (ByRefType_t1587086384 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ByRefType_MakeByRefType_m2150335175_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ArgumentException_t3259014390 * L_0 = (ArgumentException_t3259014390 *)il2cpp_codegen_object_new(ArgumentException_t3259014390_il2cpp_TypeInfo_var);
		ArgumentException__ctor_m3739475201(L_0, _stringLiteral912151980, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Void System.Reflection.Emit.ConstructorBuilder::.ctor(System.Reflection.Emit.TypeBuilder,System.Reflection.MethodAttributes,System.Reflection.CallingConventions,System.Type[],System.Type[][],System.Type[][])
extern Il2CppClass* ConstructorInfo_t2851816542_il2cpp_TypeInfo_var;
extern Il2CppClass* ArgumentException_t3259014390_il2cpp_TypeInfo_var;
extern Il2CppClass* TypeU5BU5D_t1664964607_il2cpp_TypeInfo_var;
extern Il2CppClass* ModuleBuilder_t4156028127_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral1262676163;
extern Il2CppCodeGenString* _stringLiteral3462160554;
extern const uint32_t ConstructorBuilder__ctor_m2001998159_MetadataUsageId;
extern "C"  void ConstructorBuilder__ctor_m2001998159 (ConstructorBuilder_t700974433 * __this, TypeBuilder_t3308873219 * ___tb0, int32_t ___attributes1, int32_t ___callingConvention2, TypeU5BU5D_t1664964607* ___parameterTypes3, TypeU5BU5DU5BU5D_t2318378278* ___paramModReq4, TypeU5BU5DU5BU5D_t2318378278* ___paramModOpt5, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ConstructorBuilder__ctor_m2001998159_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	MethodToken_t3991686330  V_1;
	memset(&V_1, 0, sizeof(V_1));
	{
		__this->set_init_locals_10((bool)1);
		IL2CPP_RUNTIME_CLASS_INIT(ConstructorInfo_t2851816542_il2cpp_TypeInfo_var);
		ConstructorInfo__ctor_m3847352284(__this, /*hidden argument*/NULL);
		int32_t L_0 = ___attributes1;
		__this->set_attrs_4(((int32_t)((int32_t)((int32_t)((int32_t)L_0|(int32_t)((int32_t)2048)))|(int32_t)((int32_t)4096))));
		int32_t L_1 = ___callingConvention2;
		__this->set_call_conv_7(L_1);
		TypeU5BU5D_t1664964607* L_2 = ___parameterTypes3;
		if (!L_2)
		{
			goto IL_007c;
		}
	}
	{
		V_0 = 0;
		goto IL_0052;
	}

IL_0035:
	{
		TypeU5BU5D_t1664964607* L_3 = ___parameterTypes3;
		int32_t L_4 = V_0;
		NullCheck(L_3);
		int32_t L_5 = L_4;
		Type_t * L_6 = (L_3)->GetAt(static_cast<il2cpp_array_size_t>(L_5));
		if (L_6)
		{
			goto IL_004e;
		}
	}
	{
		ArgumentException_t3259014390 * L_7 = (ArgumentException_t3259014390 *)il2cpp_codegen_object_new(ArgumentException_t3259014390_il2cpp_TypeInfo_var);
		ArgumentException__ctor_m544251339(L_7, _stringLiteral1262676163, _stringLiteral3462160554, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_7);
	}

IL_004e:
	{
		int32_t L_8 = V_0;
		V_0 = ((int32_t)((int32_t)L_8+(int32_t)1));
	}

IL_0052:
	{
		int32_t L_9 = V_0;
		TypeU5BU5D_t1664964607* L_10 = ___parameterTypes3;
		NullCheck(L_10);
		if ((((int32_t)L_9) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_10)->max_length)))))))
		{
			goto IL_0035;
		}
	}
	{
		TypeU5BU5D_t1664964607* L_11 = ___parameterTypes3;
		NullCheck(L_11);
		__this->set_parameters_3(((TypeU5BU5D_t1664964607*)SZArrayNew(TypeU5BU5D_t1664964607_il2cpp_TypeInfo_var, (uint32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_11)->max_length)))))));
		TypeU5BU5D_t1664964607* L_12 = ___parameterTypes3;
		TypeU5BU5D_t1664964607* L_13 = __this->get_parameters_3();
		TypeU5BU5D_t1664964607* L_14 = ___parameterTypes3;
		NullCheck(L_14);
		Array_Copy_m2363740072(NULL /*static, unused*/, (Il2CppArray *)(Il2CppArray *)L_12, (Il2CppArray *)(Il2CppArray *)L_13, (((int32_t)((int32_t)(((Il2CppArray *)L_14)->max_length)))), /*hidden argument*/NULL);
	}

IL_007c:
	{
		TypeBuilder_t3308873219 * L_15 = ___tb0;
		__this->set_type_8(L_15);
		TypeU5BU5DU5BU5D_t2318378278* L_16 = ___paramModReq4;
		__this->set_paramModReq_11(L_16);
		TypeU5BU5DU5BU5D_t2318378278* L_17 = ___paramModOpt5;
		__this->set_paramModOpt_12(L_17);
		int32_t L_18 = ConstructorBuilder_get_next_table_index_m932085784(__this, __this, 6, (bool)1, /*hidden argument*/NULL);
		__this->set_table_idx_6(L_18);
		TypeBuilder_t3308873219 * L_19 = ___tb0;
		NullCheck(L_19);
		Module_t4282841206 * L_20 = TypeBuilder_get_Module_m1668298460(L_19, /*hidden argument*/NULL);
		MethodToken_t3991686330  L_21 = ConstructorBuilder_GetToken_m3945412419(__this, /*hidden argument*/NULL);
		V_1 = L_21;
		int32_t L_22 = MethodToken_get_Token_m3846227497((&V_1), /*hidden argument*/NULL);
		NullCheck(((ModuleBuilder_t4156028127 *)CastclassClass(L_20, ModuleBuilder_t4156028127_il2cpp_TypeInfo_var)));
		ModuleBuilder_RegisterToken_m1388342515(((ModuleBuilder_t4156028127 *)CastclassClass(L_20, ModuleBuilder_t4156028127_il2cpp_TypeInfo_var)), __this, L_22, /*hidden argument*/NULL);
		return;
	}
}
// System.Reflection.CallingConventions System.Reflection.Emit.ConstructorBuilder::get_CallingConvention()
extern "C"  int32_t ConstructorBuilder_get_CallingConvention_m443074051 (ConstructorBuilder_t700974433 * __this, const MethodInfo* method)
{
	{
		int32_t L_0 = __this->get_call_conv_7();
		return L_0;
	}
}
// System.Reflection.Emit.TypeBuilder System.Reflection.Emit.ConstructorBuilder::get_TypeBuilder()
extern "C"  TypeBuilder_t3308873219 * ConstructorBuilder_get_TypeBuilder_m3442952231 (ConstructorBuilder_t700974433 * __this, const MethodInfo* method)
{
	{
		TypeBuilder_t3308873219 * L_0 = __this->get_type_8();
		return L_0;
	}
}
// System.Reflection.ParameterInfo[] System.Reflection.Emit.ConstructorBuilder::GetParameters()
extern "C"  ParameterInfoU5BU5D_t2275869610* ConstructorBuilder_GetParameters_m3711347282 (ConstructorBuilder_t700974433 * __this, const MethodInfo* method)
{
	{
		TypeBuilder_t3308873219 * L_0 = __this->get_type_8();
		NullCheck(L_0);
		bool L_1 = TypeBuilder_get_is_created_m736553860(L_0, /*hidden argument*/NULL);
		if (L_1)
		{
			goto IL_0022;
		}
	}
	{
		bool L_2 = ConstructorBuilder_get_IsCompilerContext_m2796899803(__this, /*hidden argument*/NULL);
		if (L_2)
		{
			goto IL_0022;
		}
	}
	{
		Exception_t1927440687 * L_3 = ConstructorBuilder_not_created_m2150488017(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_3);
	}

IL_0022:
	{
		ParameterInfoU5BU5D_t2275869610* L_4 = ConstructorBuilder_GetParametersInternal_m3775796783(__this, /*hidden argument*/NULL);
		return L_4;
	}
}
// System.Reflection.ParameterInfo[] System.Reflection.Emit.ConstructorBuilder::GetParametersInternal()
extern Il2CppClass* ParameterInfoU5BU5D_t2275869610_il2cpp_TypeInfo_var;
extern Il2CppClass* ParameterInfo_t2249040075_il2cpp_TypeInfo_var;
extern const uint32_t ConstructorBuilder_GetParametersInternal_m3775796783_MetadataUsageId;
extern "C"  ParameterInfoU5BU5D_t2275869610* ConstructorBuilder_GetParametersInternal_m3775796783 (ConstructorBuilder_t700974433 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ConstructorBuilder_GetParametersInternal_m3775796783_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ParameterInfoU5BU5D_t2275869610* V_0 = NULL;
	int32_t V_1 = 0;
	int32_t G_B5_0 = 0;
	ParameterInfoU5BU5D_t2275869610* G_B5_1 = NULL;
	int32_t G_B4_0 = 0;
	ParameterInfoU5BU5D_t2275869610* G_B4_1 = NULL;
	ParameterBuilder_t3344728474 * G_B6_0 = NULL;
	int32_t G_B6_1 = 0;
	ParameterInfoU5BU5D_t2275869610* G_B6_2 = NULL;
	{
		TypeU5BU5D_t1664964607* L_0 = __this->get_parameters_3();
		if (L_0)
		{
			goto IL_0012;
		}
	}
	{
		return ((ParameterInfoU5BU5D_t2275869610*)SZArrayNew(ParameterInfoU5BU5D_t2275869610_il2cpp_TypeInfo_var, (uint32_t)0));
	}

IL_0012:
	{
		TypeU5BU5D_t1664964607* L_1 = __this->get_parameters_3();
		NullCheck(L_1);
		V_0 = ((ParameterInfoU5BU5D_t2275869610*)SZArrayNew(ParameterInfoU5BU5D_t2275869610_il2cpp_TypeInfo_var, (uint32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_1)->max_length))))));
		V_1 = 0;
		goto IL_005a;
	}

IL_0027:
	{
		ParameterInfoU5BU5D_t2275869610* L_2 = V_0;
		int32_t L_3 = V_1;
		ParameterBuilderU5BU5D_t2122994367* L_4 = __this->get_pinfo_9();
		G_B4_0 = L_3;
		G_B4_1 = L_2;
		if (L_4)
		{
			G_B5_0 = L_3;
			G_B5_1 = L_2;
			goto IL_003a;
		}
	}
	{
		G_B6_0 = ((ParameterBuilder_t3344728474 *)(NULL));
		G_B6_1 = G_B4_0;
		G_B6_2 = G_B4_1;
		goto IL_0044;
	}

IL_003a:
	{
		ParameterBuilderU5BU5D_t2122994367* L_5 = __this->get_pinfo_9();
		int32_t L_6 = V_1;
		NullCheck(L_5);
		int32_t L_7 = ((int32_t)((int32_t)L_6+(int32_t)1));
		ParameterBuilder_t3344728474 * L_8 = (L_5)->GetAt(static_cast<il2cpp_array_size_t>(L_7));
		G_B6_0 = L_8;
		G_B6_1 = G_B5_0;
		G_B6_2 = G_B5_1;
	}

IL_0044:
	{
		TypeU5BU5D_t1664964607* L_9 = __this->get_parameters_3();
		int32_t L_10 = V_1;
		NullCheck(L_9);
		int32_t L_11 = L_10;
		Type_t * L_12 = (L_9)->GetAt(static_cast<il2cpp_array_size_t>(L_11));
		int32_t L_13 = V_1;
		ParameterInfo_t2249040075 * L_14 = (ParameterInfo_t2249040075 *)il2cpp_codegen_object_new(ParameterInfo_t2249040075_il2cpp_TypeInfo_var);
		ParameterInfo__ctor_m2149157062(L_14, G_B6_0, L_12, __this, ((int32_t)((int32_t)L_13+(int32_t)1)), /*hidden argument*/NULL);
		NullCheck(G_B6_2);
		ArrayElementTypeCheck (G_B6_2, L_14);
		(G_B6_2)->SetAt(static_cast<il2cpp_array_size_t>(G_B6_1), (ParameterInfo_t2249040075 *)L_14);
		int32_t L_15 = V_1;
		V_1 = ((int32_t)((int32_t)L_15+(int32_t)1));
	}

IL_005a:
	{
		int32_t L_16 = V_1;
		TypeU5BU5D_t1664964607* L_17 = __this->get_parameters_3();
		NullCheck(L_17);
		if ((((int32_t)L_16) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_17)->max_length)))))))
		{
			goto IL_0027;
		}
	}
	{
		ParameterInfoU5BU5D_t2275869610* L_18 = V_0;
		return L_18;
	}
}
// System.Int32 System.Reflection.Emit.ConstructorBuilder::GetParameterCount()
extern "C"  int32_t ConstructorBuilder_GetParameterCount_m2862936870 (ConstructorBuilder_t700974433 * __this, const MethodInfo* method)
{
	{
		TypeU5BU5D_t1664964607* L_0 = __this->get_parameters_3();
		if (L_0)
		{
			goto IL_000d;
		}
	}
	{
		return 0;
	}

IL_000d:
	{
		TypeU5BU5D_t1664964607* L_1 = __this->get_parameters_3();
		NullCheck(L_1);
		return (((int32_t)((int32_t)(((Il2CppArray *)L_1)->max_length))));
	}
}
// System.Object System.Reflection.Emit.ConstructorBuilder::Invoke(System.Object,System.Reflection.BindingFlags,System.Reflection.Binder,System.Object[],System.Globalization.CultureInfo)
extern "C"  Il2CppObject * ConstructorBuilder_Invoke_m2354062201 (ConstructorBuilder_t700974433 * __this, Il2CppObject * ___obj0, int32_t ___invokeAttr1, Binder_t3404612058 * ___binder2, ObjectU5BU5D_t3614634134* ___parameters3, CultureInfo_t3500843524 * ___culture4, const MethodInfo* method)
{
	{
		Exception_t1927440687 * L_0 = ConstructorBuilder_not_supported_m3687319507(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Object System.Reflection.Emit.ConstructorBuilder::Invoke(System.Reflection.BindingFlags,System.Reflection.Binder,System.Object[],System.Globalization.CultureInfo)
extern "C"  Il2CppObject * ConstructorBuilder_Invoke_m2488856091 (ConstructorBuilder_t700974433 * __this, int32_t ___invokeAttr0, Binder_t3404612058 * ___binder1, ObjectU5BU5D_t3614634134* ___parameters2, CultureInfo_t3500843524 * ___culture3, const MethodInfo* method)
{
	{
		Exception_t1927440687 * L_0 = ConstructorBuilder_not_supported_m3687319507(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.RuntimeMethodHandle System.Reflection.Emit.ConstructorBuilder::get_MethodHandle()
extern "C"  RuntimeMethodHandle_t894824333  ConstructorBuilder_get_MethodHandle_m977166569 (ConstructorBuilder_t700974433 * __this, const MethodInfo* method)
{
	{
		Exception_t1927440687 * L_0 = ConstructorBuilder_not_supported_m3687319507(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Reflection.MethodAttributes System.Reflection.Emit.ConstructorBuilder::get_Attributes()
extern "C"  int32_t ConstructorBuilder_get_Attributes_m2137353707 (ConstructorBuilder_t700974433 * __this, const MethodInfo* method)
{
	{
		int32_t L_0 = __this->get_attrs_4();
		return L_0;
	}
}
// System.Type System.Reflection.Emit.ConstructorBuilder::get_ReflectedType()
extern "C"  Type_t * ConstructorBuilder_get_ReflectedType_m3815261871 (ConstructorBuilder_t700974433 * __this, const MethodInfo* method)
{
	{
		TypeBuilder_t3308873219 * L_0 = __this->get_type_8();
		return L_0;
	}
}
// System.Type System.Reflection.Emit.ConstructorBuilder::get_DeclaringType()
extern "C"  Type_t * ConstructorBuilder_get_DeclaringType_m4264602248 (ConstructorBuilder_t700974433 * __this, const MethodInfo* method)
{
	{
		TypeBuilder_t3308873219 * L_0 = __this->get_type_8();
		return L_0;
	}
}
// System.String System.Reflection.Emit.ConstructorBuilder::get_Name()
extern Il2CppClass* ConstructorInfo_t2851816542_il2cpp_TypeInfo_var;
extern const uint32_t ConstructorBuilder_get_Name_m134603075_MetadataUsageId;
extern "C"  String_t* ConstructorBuilder_get_Name_m134603075 (ConstructorBuilder_t700974433 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ConstructorBuilder_get_Name_m134603075_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	String_t* G_B3_0 = NULL;
	{
		int32_t L_0 = __this->get_attrs_4();
		if (!((int32_t)((int32_t)L_0&(int32_t)((int32_t)16))))
		{
			goto IL_0018;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(ConstructorInfo_t2851816542_il2cpp_TypeInfo_var);
		String_t* L_1 = ((ConstructorInfo_t2851816542_StaticFields*)ConstructorInfo_t2851816542_il2cpp_TypeInfo_var->static_fields)->get_TypeConstructorName_1();
		G_B3_0 = L_1;
		goto IL_001d;
	}

IL_0018:
	{
		IL2CPP_RUNTIME_CLASS_INIT(ConstructorInfo_t2851816542_il2cpp_TypeInfo_var);
		String_t* L_2 = ((ConstructorInfo_t2851816542_StaticFields*)ConstructorInfo_t2851816542_il2cpp_TypeInfo_var->static_fields)->get_ConstructorName_0();
		G_B3_0 = L_2;
	}

IL_001d:
	{
		return G_B3_0;
	}
}
// System.Boolean System.Reflection.Emit.ConstructorBuilder::IsDefined(System.Type,System.Boolean)
extern "C"  bool ConstructorBuilder_IsDefined_m2369140139 (ConstructorBuilder_t700974433 * __this, Type_t * ___attributeType0, bool ___inherit1, const MethodInfo* method)
{
	{
		Exception_t1927440687 * L_0 = ConstructorBuilder_not_supported_m3687319507(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Object[] System.Reflection.Emit.ConstructorBuilder::GetCustomAttributes(System.Boolean)
extern Il2CppClass* MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var;
extern const uint32_t ConstructorBuilder_GetCustomAttributes_m1931712364_MetadataUsageId;
extern "C"  ObjectU5BU5D_t3614634134* ConstructorBuilder_GetCustomAttributes_m1931712364 (ConstructorBuilder_t700974433 * __this, bool ___inherit0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ConstructorBuilder_GetCustomAttributes_m1931712364_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		TypeBuilder_t3308873219 * L_0 = __this->get_type_8();
		NullCheck(L_0);
		bool L_1 = TypeBuilder_get_is_created_m736553860(L_0, /*hidden argument*/NULL);
		if (!L_1)
		{
			goto IL_0023;
		}
	}
	{
		bool L_2 = ConstructorBuilder_get_IsCompilerContext_m2796899803(__this, /*hidden argument*/NULL);
		if (!L_2)
		{
			goto IL_0023;
		}
	}
	{
		bool L_3 = ___inherit0;
		IL2CPP_RUNTIME_CLASS_INIT(MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var);
		ObjectU5BU5D_t3614634134* L_4 = MonoCustomAttrs_GetCustomAttributes_m3069779582(NULL /*static, unused*/, __this, L_3, /*hidden argument*/NULL);
		return L_4;
	}

IL_0023:
	{
		Exception_t1927440687 * L_5 = ConstructorBuilder_not_supported_m3687319507(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_5);
	}
}
// System.Object[] System.Reflection.Emit.ConstructorBuilder::GetCustomAttributes(System.Type,System.Boolean)
extern Il2CppClass* MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var;
extern const uint32_t ConstructorBuilder_GetCustomAttributes_m1698596385_MetadataUsageId;
extern "C"  ObjectU5BU5D_t3614634134* ConstructorBuilder_GetCustomAttributes_m1698596385 (ConstructorBuilder_t700974433 * __this, Type_t * ___attributeType0, bool ___inherit1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ConstructorBuilder_GetCustomAttributes_m1698596385_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		TypeBuilder_t3308873219 * L_0 = __this->get_type_8();
		NullCheck(L_0);
		bool L_1 = TypeBuilder_get_is_created_m736553860(L_0, /*hidden argument*/NULL);
		if (!L_1)
		{
			goto IL_0024;
		}
	}
	{
		bool L_2 = ConstructorBuilder_get_IsCompilerContext_m2796899803(__this, /*hidden argument*/NULL);
		if (!L_2)
		{
			goto IL_0024;
		}
	}
	{
		Type_t * L_3 = ___attributeType0;
		bool L_4 = ___inherit1;
		IL2CPP_RUNTIME_CLASS_INIT(MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var);
		ObjectU5BU5D_t3614634134* L_5 = MonoCustomAttrs_GetCustomAttributes_m939426263(NULL /*static, unused*/, __this, L_3, L_4, /*hidden argument*/NULL);
		return L_5;
	}

IL_0024:
	{
		Exception_t1927440687 * L_6 = ConstructorBuilder_not_supported_m3687319507(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_6);
	}
}
// System.Reflection.Emit.ILGenerator System.Reflection.Emit.ConstructorBuilder::GetILGenerator()
extern "C"  ILGenerator_t99948092 * ConstructorBuilder_GetILGenerator_m1407935730 (ConstructorBuilder_t700974433 * __this, const MethodInfo* method)
{
	{
		ILGenerator_t99948092 * L_0 = ConstructorBuilder_GetILGenerator_m1731893569(__this, ((int32_t)64), /*hidden argument*/NULL);
		return L_0;
	}
}
// System.Reflection.Emit.ILGenerator System.Reflection.Emit.ConstructorBuilder::GetILGenerator(System.Int32)
extern Il2CppClass* ModuleBuilder_t4156028127_il2cpp_TypeInfo_var;
extern Il2CppClass* ILGenerator_t99948092_il2cpp_TypeInfo_var;
extern const uint32_t ConstructorBuilder_GetILGenerator_m1731893569_MetadataUsageId;
extern "C"  ILGenerator_t99948092 * ConstructorBuilder_GetILGenerator_m1731893569 (ConstructorBuilder_t700974433 * __this, int32_t ___streamSize0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ConstructorBuilder_GetILGenerator_m1731893569_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ILGenerator_t99948092 * L_0 = __this->get_ilgen_2();
		if (!L_0)
		{
			goto IL_0012;
		}
	}
	{
		ILGenerator_t99948092 * L_1 = __this->get_ilgen_2();
		return L_1;
	}

IL_0012:
	{
		TypeBuilder_t3308873219 * L_2 = __this->get_type_8();
		NullCheck(L_2);
		Module_t4282841206 * L_3 = TypeBuilder_get_Module_m1668298460(L_2, /*hidden argument*/NULL);
		TypeBuilder_t3308873219 * L_4 = __this->get_type_8();
		NullCheck(L_4);
		Module_t4282841206 * L_5 = TypeBuilder_get_Module_m1668298460(L_4, /*hidden argument*/NULL);
		NullCheck(((ModuleBuilder_t4156028127 *)CastclassClass(L_5, ModuleBuilder_t4156028127_il2cpp_TypeInfo_var)));
		Il2CppObject * L_6 = ModuleBuilder_GetTokenGenerator_m4006065550(((ModuleBuilder_t4156028127 *)CastclassClass(L_5, ModuleBuilder_t4156028127_il2cpp_TypeInfo_var)), /*hidden argument*/NULL);
		int32_t L_7 = ___streamSize0;
		ILGenerator_t99948092 * L_8 = (ILGenerator_t99948092 *)il2cpp_codegen_object_new(ILGenerator_t99948092_il2cpp_TypeInfo_var);
		ILGenerator__ctor_m3365621387(L_8, L_3, L_6, L_7, /*hidden argument*/NULL);
		__this->set_ilgen_2(L_8);
		ILGenerator_t99948092 * L_9 = __this->get_ilgen_2();
		return L_9;
	}
}
// System.Reflection.Emit.MethodToken System.Reflection.Emit.ConstructorBuilder::GetToken()
extern "C"  MethodToken_t3991686330  ConstructorBuilder_GetToken_m3945412419 (ConstructorBuilder_t700974433 * __this, const MethodInfo* method)
{
	{
		int32_t L_0 = __this->get_table_idx_6();
		MethodToken_t3991686330  L_1;
		memset(&L_1, 0, sizeof(L_1));
		MethodToken__ctor_m3671357474(&L_1, ((int32_t)((int32_t)((int32_t)100663296)|(int32_t)L_0)), /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Reflection.Module System.Reflection.Emit.ConstructorBuilder::get_Module()
extern "C"  Module_t4282841206 * ConstructorBuilder_get_Module_m2159174298 (ConstructorBuilder_t700974433 * __this, const MethodInfo* method)
{
	{
		Module_t4282841206 * L_0 = MemberInfo_get_Module_m3957426656(__this, /*hidden argument*/NULL);
		return L_0;
	}
}
// System.String System.Reflection.Emit.ConstructorBuilder::ToString()
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral2307484441;
extern Il2CppCodeGenString* _stringLiteral522332250;
extern const uint32_t ConstructorBuilder_ToString_m347700767_MetadataUsageId;
extern "C"  String_t* ConstructorBuilder_ToString_m347700767 (ConstructorBuilder_t700974433 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ConstructorBuilder_ToString_m347700767_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		TypeBuilder_t3308873219 * L_0 = __this->get_type_8();
		NullCheck(L_0);
		String_t* L_1 = TypeBuilder_get_Name_m170882803(L_0, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_2 = String_Concat_m612901809(NULL /*static, unused*/, _stringLiteral2307484441, L_1, _stringLiteral522332250, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.Void System.Reflection.Emit.ConstructorBuilder::fixup()
extern Il2CppClass* ILGenerator_t99948092_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* InvalidOperationException_t721527559_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral2470364202;
extern Il2CppCodeGenString* _stringLiteral2747925653;
extern const uint32_t ConstructorBuilder_fixup_m836985654_MetadataUsageId;
extern "C"  void ConstructorBuilder_fixup_m836985654 (ConstructorBuilder_t700974433 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ConstructorBuilder_fixup_m836985654_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		int32_t L_0 = __this->get_attrs_4();
		if (((int32_t)((int32_t)L_0&(int32_t)((int32_t)9216))))
		{
			goto IL_0058;
		}
	}
	{
		int32_t L_1 = __this->get_iattrs_5();
		if (((int32_t)((int32_t)L_1&(int32_t)((int32_t)4099))))
		{
			goto IL_0058;
		}
	}
	{
		ILGenerator_t99948092 * L_2 = __this->get_ilgen_2();
		if (!L_2)
		{
			goto IL_003d;
		}
	}
	{
		ILGenerator_t99948092 * L_3 = __this->get_ilgen_2();
		IL2CPP_RUNTIME_CLASS_INIT(ILGenerator_t99948092_il2cpp_TypeInfo_var);
		int32_t L_4 = ILGenerator_Mono_GetCurrentOffset_m3553856682(NULL /*static, unused*/, L_3, /*hidden argument*/NULL);
		if (L_4)
		{
			goto IL_0058;
		}
	}

IL_003d:
	{
		String_t* L_5 = ConstructorBuilder_get_Name_m134603075(__this, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_6 = String_Concat_m612901809(NULL /*static, unused*/, _stringLiteral2470364202, L_5, _stringLiteral2747925653, /*hidden argument*/NULL);
		InvalidOperationException_t721527559 * L_7 = (InvalidOperationException_t721527559 *)il2cpp_codegen_object_new(InvalidOperationException_t721527559_il2cpp_TypeInfo_var);
		InvalidOperationException__ctor_m2801133788(L_7, L_6, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_7);
	}

IL_0058:
	{
		ILGenerator_t99948092 * L_8 = __this->get_ilgen_2();
		if (!L_8)
		{
			goto IL_006e;
		}
	}
	{
		ILGenerator_t99948092 * L_9 = __this->get_ilgen_2();
		NullCheck(L_9);
		ILGenerator_label_fixup_m1325994348(L_9, /*hidden argument*/NULL);
	}

IL_006e:
	{
		return;
	}
}
// System.Int32 System.Reflection.Emit.ConstructorBuilder::get_next_table_index(System.Object,System.Int32,System.Boolean)
extern "C"  int32_t ConstructorBuilder_get_next_table_index_m932085784 (ConstructorBuilder_t700974433 * __this, Il2CppObject * ___obj0, int32_t ___table1, bool ___inc2, const MethodInfo* method)
{
	{
		TypeBuilder_t3308873219 * L_0 = __this->get_type_8();
		Il2CppObject * L_1 = ___obj0;
		int32_t L_2 = ___table1;
		bool L_3 = ___inc2;
		NullCheck(L_0);
		int32_t L_4 = TypeBuilder_get_next_table_index_m1415870184(L_0, L_1, L_2, L_3, /*hidden argument*/NULL);
		return L_4;
	}
}
// System.Boolean System.Reflection.Emit.ConstructorBuilder::get_IsCompilerContext()
extern Il2CppClass* ModuleBuilder_t4156028127_il2cpp_TypeInfo_var;
extern Il2CppClass* AssemblyBuilder_t1646117627_il2cpp_TypeInfo_var;
extern const uint32_t ConstructorBuilder_get_IsCompilerContext_m2796899803_MetadataUsageId;
extern "C"  bool ConstructorBuilder_get_IsCompilerContext_m2796899803 (ConstructorBuilder_t700974433 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ConstructorBuilder_get_IsCompilerContext_m2796899803_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ModuleBuilder_t4156028127 * V_0 = NULL;
	AssemblyBuilder_t1646117627 * V_1 = NULL;
	{
		TypeBuilder_t3308873219 * L_0 = ConstructorBuilder_get_TypeBuilder_m3442952231(__this, /*hidden argument*/NULL);
		NullCheck(L_0);
		Module_t4282841206 * L_1 = TypeBuilder_get_Module_m1668298460(L_0, /*hidden argument*/NULL);
		V_0 = ((ModuleBuilder_t4156028127 *)CastclassClass(L_1, ModuleBuilder_t4156028127_il2cpp_TypeInfo_var));
		ModuleBuilder_t4156028127 * L_2 = V_0;
		NullCheck(L_2);
		Assembly_t4268412390 * L_3 = Module_get_Assembly_m3690289982(L_2, /*hidden argument*/NULL);
		V_1 = ((AssemblyBuilder_t1646117627 *)CastclassSealed(L_3, AssemblyBuilder_t1646117627_il2cpp_TypeInfo_var));
		AssemblyBuilder_t1646117627 * L_4 = V_1;
		NullCheck(L_4);
		bool L_5 = AssemblyBuilder_get_IsCompilerContext_m2864230005(L_4, /*hidden argument*/NULL);
		return L_5;
	}
}
// System.Exception System.Reflection.Emit.ConstructorBuilder::not_supported()
extern Il2CppClass* NotSupportedException_t1793819818_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral4087454587;
extern const uint32_t ConstructorBuilder_not_supported_m3687319507_MetadataUsageId;
extern "C"  Exception_t1927440687 * ConstructorBuilder_not_supported_m3687319507 (ConstructorBuilder_t700974433 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ConstructorBuilder_not_supported_m3687319507_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		NotSupportedException_t1793819818 * L_0 = (NotSupportedException_t1793819818 *)il2cpp_codegen_object_new(NotSupportedException_t1793819818_il2cpp_TypeInfo_var);
		NotSupportedException__ctor_m836173213(L_0, _stringLiteral4087454587, /*hidden argument*/NULL);
		return L_0;
	}
}
// System.Exception System.Reflection.Emit.ConstructorBuilder::not_created()
extern Il2CppClass* NotSupportedException_t1793819818_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral2499557300;
extern const uint32_t ConstructorBuilder_not_created_m2150488017_MetadataUsageId;
extern "C"  Exception_t1927440687 * ConstructorBuilder_not_created_m2150488017 (ConstructorBuilder_t700974433 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ConstructorBuilder_not_created_m2150488017_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		NotSupportedException_t1793819818 * L_0 = (NotSupportedException_t1793819818 *)il2cpp_codegen_object_new(NotSupportedException_t1793819818_il2cpp_TypeInfo_var);
		NotSupportedException__ctor_m836173213(L_0, _stringLiteral2499557300, /*hidden argument*/NULL);
		return L_0;
	}
}
// System.Void System.Reflection.Emit.DerivedType::.ctor(System.Type)
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern const uint32_t DerivedType__ctor_m4154637955_MetadataUsageId;
extern "C"  void DerivedType__ctor_m4154637955 (DerivedType_t1016359113 * __this, Type_t * ___elementType0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (DerivedType__ctor_m4154637955_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type__ctor_m882675131(__this, /*hidden argument*/NULL);
		Type_t * L_0 = ___elementType0;
		__this->set_elementType_8(L_0);
		return;
	}
}
// System.Void System.Reflection.Emit.DerivedType::create_unmanaged_type(System.Type)
extern "C"  void DerivedType_create_unmanaged_type_m3164160613 (Il2CppObject * __this /* static, unused */, Type_t * ___type0, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef void (*DerivedType_create_unmanaged_type_m3164160613_ftn) (Type_t *);
	 ((DerivedType_create_unmanaged_type_m3164160613_ftn)mscorlib::System::Reflection::Emit::DerivedType::create_unmanaged_type) (___type0);
}
// System.Type[] System.Reflection.Emit.DerivedType::GetInterfaces()
extern Il2CppClass* NotSupportedException_t1793819818_il2cpp_TypeInfo_var;
extern const uint32_t DerivedType_GetInterfaces_m2710649328_MetadataUsageId;
extern "C"  TypeU5BU5D_t1664964607* DerivedType_GetInterfaces_m2710649328 (DerivedType_t1016359113 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (DerivedType_GetInterfaces_m2710649328_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		NotSupportedException_t1793819818 * L_0 = (NotSupportedException_t1793819818 *)il2cpp_codegen_object_new(NotSupportedException_t1793819818_il2cpp_TypeInfo_var);
		NotSupportedException__ctor_m3232764727(L_0, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Type System.Reflection.Emit.DerivedType::GetElementType()
extern "C"  Type_t * DerivedType_GetElementType_m659905870 (DerivedType_t1016359113 * __this, const MethodInfo* method)
{
	{
		Type_t * L_0 = __this->get_elementType_8();
		return L_0;
	}
}
// System.Reflection.EventInfo System.Reflection.Emit.DerivedType::GetEvent(System.String,System.Reflection.BindingFlags)
extern Il2CppClass* NotSupportedException_t1793819818_il2cpp_TypeInfo_var;
extern const uint32_t DerivedType_GetEvent_m2165020195_MetadataUsageId;
extern "C"  EventInfo_t * DerivedType_GetEvent_m2165020195 (DerivedType_t1016359113 * __this, String_t* ___name0, int32_t ___bindingAttr1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (DerivedType_GetEvent_m2165020195_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		NotSupportedException_t1793819818 * L_0 = (NotSupportedException_t1793819818 *)il2cpp_codegen_object_new(NotSupportedException_t1793819818_il2cpp_TypeInfo_var);
		NotSupportedException__ctor_m3232764727(L_0, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Reflection.FieldInfo System.Reflection.Emit.DerivedType::GetField(System.String,System.Reflection.BindingFlags)
extern Il2CppClass* NotSupportedException_t1793819818_il2cpp_TypeInfo_var;
extern const uint32_t DerivedType_GetField_m3960169619_MetadataUsageId;
extern "C"  FieldInfo_t * DerivedType_GetField_m3960169619 (DerivedType_t1016359113 * __this, String_t* ___name0, int32_t ___bindingAttr1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (DerivedType_GetField_m3960169619_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		NotSupportedException_t1793819818 * L_0 = (NotSupportedException_t1793819818 *)il2cpp_codegen_object_new(NotSupportedException_t1793819818_il2cpp_TypeInfo_var);
		NotSupportedException__ctor_m3232764727(L_0, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Reflection.FieldInfo[] System.Reflection.Emit.DerivedType::GetFields(System.Reflection.BindingFlags)
extern Il2CppClass* NotSupportedException_t1793819818_il2cpp_TypeInfo_var;
extern const uint32_t DerivedType_GetFields_m2946331416_MetadataUsageId;
extern "C"  FieldInfoU5BU5D_t125053523* DerivedType_GetFields_m2946331416 (DerivedType_t1016359113 * __this, int32_t ___bindingAttr0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (DerivedType_GetFields_m2946331416_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		NotSupportedException_t1793819818 * L_0 = (NotSupportedException_t1793819818 *)il2cpp_codegen_object_new(NotSupportedException_t1793819818_il2cpp_TypeInfo_var);
		NotSupportedException__ctor_m3232764727(L_0, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Reflection.MethodInfo System.Reflection.Emit.DerivedType::GetMethodImpl(System.String,System.Reflection.BindingFlags,System.Reflection.Binder,System.Reflection.CallingConventions,System.Type[],System.Reflection.ParameterModifier[])
extern Il2CppClass* NotSupportedException_t1793819818_il2cpp_TypeInfo_var;
extern const uint32_t DerivedType_GetMethodImpl_m2649456432_MetadataUsageId;
extern "C"  MethodInfo_t * DerivedType_GetMethodImpl_m2649456432 (DerivedType_t1016359113 * __this, String_t* ___name0, int32_t ___bindingAttr1, Binder_t3404612058 * ___binder2, int32_t ___callConvention3, TypeU5BU5D_t1664964607* ___types4, ParameterModifierU5BU5D_t963192633* ___modifiers5, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (DerivedType_GetMethodImpl_m2649456432_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		NotSupportedException_t1793819818 * L_0 = (NotSupportedException_t1793819818 *)il2cpp_codegen_object_new(NotSupportedException_t1793819818_il2cpp_TypeInfo_var);
		NotSupportedException__ctor_m3232764727(L_0, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Reflection.MethodInfo[] System.Reflection.Emit.DerivedType::GetMethods(System.Reflection.BindingFlags)
extern Il2CppClass* NotSupportedException_t1793819818_il2cpp_TypeInfo_var;
extern const uint32_t DerivedType_GetMethods_m165266904_MetadataUsageId;
extern "C"  MethodInfoU5BU5D_t152480188* DerivedType_GetMethods_m165266904 (DerivedType_t1016359113 * __this, int32_t ___bindingAttr0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (DerivedType_GetMethods_m165266904_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		NotSupportedException_t1793819818 * L_0 = (NotSupportedException_t1793819818 *)il2cpp_codegen_object_new(NotSupportedException_t1793819818_il2cpp_TypeInfo_var);
		NotSupportedException__ctor_m3232764727(L_0, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Reflection.PropertyInfo System.Reflection.Emit.DerivedType::GetPropertyImpl(System.String,System.Reflection.BindingFlags,System.Reflection.Binder,System.Type,System.Type[],System.Reflection.ParameterModifier[])
extern Il2CppClass* NotSupportedException_t1793819818_il2cpp_TypeInfo_var;
extern const uint32_t DerivedType_GetPropertyImpl_m1383673951_MetadataUsageId;
extern "C"  PropertyInfo_t * DerivedType_GetPropertyImpl_m1383673951 (DerivedType_t1016359113 * __this, String_t* ___name0, int32_t ___bindingAttr1, Binder_t3404612058 * ___binder2, Type_t * ___returnType3, TypeU5BU5D_t1664964607* ___types4, ParameterModifierU5BU5D_t963192633* ___modifiers5, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (DerivedType_GetPropertyImpl_m1383673951_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		NotSupportedException_t1793819818 * L_0 = (NotSupportedException_t1793819818 *)il2cpp_codegen_object_new(NotSupportedException_t1793819818_il2cpp_TypeInfo_var);
		NotSupportedException__ctor_m3232764727(L_0, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Reflection.ConstructorInfo System.Reflection.Emit.DerivedType::GetConstructorImpl(System.Reflection.BindingFlags,System.Reflection.Binder,System.Reflection.CallingConventions,System.Type[],System.Reflection.ParameterModifier[])
extern Il2CppClass* NotSupportedException_t1793819818_il2cpp_TypeInfo_var;
extern const uint32_t DerivedType_GetConstructorImpl_m129806456_MetadataUsageId;
extern "C"  ConstructorInfo_t2851816542 * DerivedType_GetConstructorImpl_m129806456 (DerivedType_t1016359113 * __this, int32_t ___bindingAttr0, Binder_t3404612058 * ___binder1, int32_t ___callConvention2, TypeU5BU5D_t1664964607* ___types3, ParameterModifierU5BU5D_t963192633* ___modifiers4, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (DerivedType_GetConstructorImpl_m129806456_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		NotSupportedException_t1793819818 * L_0 = (NotSupportedException_t1793819818 *)il2cpp_codegen_object_new(NotSupportedException_t1793819818_il2cpp_TypeInfo_var);
		NotSupportedException__ctor_m3232764727(L_0, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Reflection.TypeAttributes System.Reflection.Emit.DerivedType::GetAttributeFlagsImpl()
extern "C"  int32_t DerivedType_GetAttributeFlagsImpl_m876862795 (DerivedType_t1016359113 * __this, const MethodInfo* method)
{
	{
		Type_t * L_0 = __this->get_elementType_8();
		NullCheck(L_0);
		int32_t L_1 = Type_get_Attributes_m967681955(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Boolean System.Reflection.Emit.DerivedType::HasElementTypeImpl()
extern "C"  bool DerivedType_HasElementTypeImpl_m919717594 (DerivedType_t1016359113 * __this, const MethodInfo* method)
{
	{
		return (bool)1;
	}
}
// System.Boolean System.Reflection.Emit.DerivedType::IsArrayImpl()
extern "C"  bool DerivedType_IsArrayImpl_m684825803 (DerivedType_t1016359113 * __this, const MethodInfo* method)
{
	{
		return (bool)0;
	}
}
// System.Boolean System.Reflection.Emit.DerivedType::IsByRefImpl()
extern "C"  bool DerivedType_IsByRefImpl_m587660994 (DerivedType_t1016359113 * __this, const MethodInfo* method)
{
	{
		return (bool)0;
	}
}
// System.Boolean System.Reflection.Emit.DerivedType::IsPointerImpl()
extern "C"  bool DerivedType_IsPointerImpl_m411817681 (DerivedType_t1016359113 * __this, const MethodInfo* method)
{
	{
		return (bool)0;
	}
}
// System.Boolean System.Reflection.Emit.DerivedType::IsPrimitiveImpl()
extern "C"  bool DerivedType_IsPrimitiveImpl_m346837491 (DerivedType_t1016359113 * __this, const MethodInfo* method)
{
	{
		return (bool)0;
	}
}
// System.Reflection.ConstructorInfo[] System.Reflection.Emit.DerivedType::GetConstructors(System.Reflection.BindingFlags)
extern Il2CppClass* NotSupportedException_t1793819818_il2cpp_TypeInfo_var;
extern const uint32_t DerivedType_GetConstructors_m3174158156_MetadataUsageId;
extern "C"  ConstructorInfoU5BU5D_t1996683371* DerivedType_GetConstructors_m3174158156 (DerivedType_t1016359113 * __this, int32_t ___bindingAttr0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (DerivedType_GetConstructors_m3174158156_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		NotSupportedException_t1793819818 * L_0 = (NotSupportedException_t1793819818 *)il2cpp_codegen_object_new(NotSupportedException_t1793819818_il2cpp_TypeInfo_var);
		NotSupportedException__ctor_m3232764727(L_0, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Object System.Reflection.Emit.DerivedType::InvokeMember(System.String,System.Reflection.BindingFlags,System.Reflection.Binder,System.Object,System.Object[],System.Reflection.ParameterModifier[],System.Globalization.CultureInfo,System.String[])
extern Il2CppClass* NotSupportedException_t1793819818_il2cpp_TypeInfo_var;
extern const uint32_t DerivedType_InvokeMember_m4149586013_MetadataUsageId;
extern "C"  Il2CppObject * DerivedType_InvokeMember_m4149586013 (DerivedType_t1016359113 * __this, String_t* ___name0, int32_t ___invokeAttr1, Binder_t3404612058 * ___binder2, Il2CppObject * ___target3, ObjectU5BU5D_t3614634134* ___args4, ParameterModifierU5BU5D_t963192633* ___modifiers5, CultureInfo_t3500843524 * ___culture6, StringU5BU5D_t1642385972* ___namedParameters7, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (DerivedType_InvokeMember_m4149586013_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		NotSupportedException_t1793819818 * L_0 = (NotSupportedException_t1793819818 *)il2cpp_codegen_object_new(NotSupportedException_t1793819818_il2cpp_TypeInfo_var);
		NotSupportedException__ctor_m3232764727(L_0, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Boolean System.Reflection.Emit.DerivedType::IsInstanceOfType(System.Object)
extern "C"  bool DerivedType_IsInstanceOfType_m1209218194 (DerivedType_t1016359113 * __this, Il2CppObject * ___o0, const MethodInfo* method)
{
	{
		return (bool)0;
	}
}
// System.Boolean System.Reflection.Emit.DerivedType::IsAssignableFrom(System.Type)
extern "C"  bool DerivedType_IsAssignableFrom_m149150570 (DerivedType_t1016359113 * __this, Type_t * ___c0, const MethodInfo* method)
{
	{
		return (bool)0;
	}
}
// System.Boolean System.Reflection.Emit.DerivedType::get_ContainsGenericParameters()
extern "C"  bool DerivedType_get_ContainsGenericParameters_m3700679213 (DerivedType_t1016359113 * __this, const MethodInfo* method)
{
	{
		Type_t * L_0 = __this->get_elementType_8();
		NullCheck(L_0);
		bool L_1 = VirtFuncInvoker0< bool >::Invoke(76 /* System.Boolean System.Type::get_ContainsGenericParameters() */, L_0);
		return L_1;
	}
}
// System.Type System.Reflection.Emit.DerivedType::MakeGenericType(System.Type[])
extern Il2CppClass* NotSupportedException_t1793819818_il2cpp_TypeInfo_var;
extern const uint32_t DerivedType_MakeGenericType_m742223168_MetadataUsageId;
extern "C"  Type_t * DerivedType_MakeGenericType_m742223168 (DerivedType_t1016359113 * __this, TypeU5BU5D_t1664964607* ___typeArguments0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (DerivedType_MakeGenericType_m742223168_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		NotSupportedException_t1793819818 * L_0 = (NotSupportedException_t1793819818 *)il2cpp_codegen_object_new(NotSupportedException_t1793819818_il2cpp_TypeInfo_var);
		NotSupportedException__ctor_m3232764727(L_0, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Type System.Reflection.Emit.DerivedType::MakeByRefType()
extern Il2CppClass* ByRefType_t1587086384_il2cpp_TypeInfo_var;
extern const uint32_t DerivedType_MakeByRefType_m1445183672_MetadataUsageId;
extern "C"  Type_t * DerivedType_MakeByRefType_m1445183672 (DerivedType_t1016359113 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (DerivedType_MakeByRefType_m1445183672_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ByRefType_t1587086384 * L_0 = (ByRefType_t1587086384 *)il2cpp_codegen_object_new(ByRefType_t1587086384_il2cpp_TypeInfo_var);
		ByRefType__ctor_m2068210324(L_0, __this, /*hidden argument*/NULL);
		return L_0;
	}
}
// System.String System.Reflection.Emit.DerivedType::ToString()
extern "C"  String_t* DerivedType_ToString_m747960775 (DerivedType_t1016359113 * __this, const MethodInfo* method)
{
	{
		Type_t * L_0 = __this->get_elementType_8();
		NullCheck(L_0);
		String_t* L_1 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Type::ToString() */, L_0);
		String_t* L_2 = VirtFuncInvoker1< String_t*, String_t* >::Invoke(83 /* System.String System.Reflection.Emit.DerivedType::FormatName(System.String) */, __this, L_1);
		return L_2;
	}
}
// System.Reflection.Assembly System.Reflection.Emit.DerivedType::get_Assembly()
extern "C"  Assembly_t4268412390 * DerivedType_get_Assembly_m1990356726 (DerivedType_t1016359113 * __this, const MethodInfo* method)
{
	{
		Type_t * L_0 = __this->get_elementType_8();
		NullCheck(L_0);
		Assembly_t4268412390 * L_1 = VirtFuncInvoker0< Assembly_t4268412390 * >::Invoke(14 /* System.Reflection.Assembly System.Type::get_Assembly() */, L_0);
		return L_1;
	}
}
// System.String System.Reflection.Emit.DerivedType::get_AssemblyQualifiedName()
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral811305474;
extern const uint32_t DerivedType_get_AssemblyQualifiedName_m2010127631_MetadataUsageId;
extern "C"  String_t* DerivedType_get_AssemblyQualifiedName_m2010127631 (DerivedType_t1016359113 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (DerivedType_get_AssemblyQualifiedName_m2010127631_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	String_t* V_0 = NULL;
	{
		Type_t * L_0 = __this->get_elementType_8();
		NullCheck(L_0);
		String_t* L_1 = VirtFuncInvoker0< String_t* >::Invoke(18 /* System.String System.Type::get_FullName() */, L_0);
		String_t* L_2 = VirtFuncInvoker1< String_t*, String_t* >::Invoke(83 /* System.String System.Reflection.Emit.DerivedType::FormatName(System.String) */, __this, L_1);
		V_0 = L_2;
		String_t* L_3 = V_0;
		if (L_3)
		{
			goto IL_001a;
		}
	}
	{
		return (String_t*)NULL;
	}

IL_001a:
	{
		String_t* L_4 = V_0;
		Type_t * L_5 = __this->get_elementType_8();
		NullCheck(L_5);
		Assembly_t4268412390 * L_6 = VirtFuncInvoker0< Assembly_t4268412390 * >::Invoke(14 /* System.Reflection.Assembly System.Type::get_Assembly() */, L_5);
		NullCheck(L_6);
		String_t* L_7 = VirtFuncInvoker0< String_t* >::Invoke(6 /* System.String System.Reflection.Assembly::get_FullName() */, L_6);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_8 = String_Concat_m612901809(NULL /*static, unused*/, L_4, _stringLiteral811305474, L_7, /*hidden argument*/NULL);
		return L_8;
	}
}
// System.String System.Reflection.Emit.DerivedType::get_FullName()
extern "C"  String_t* DerivedType_get_FullName_m4188379454 (DerivedType_t1016359113 * __this, const MethodInfo* method)
{
	{
		Type_t * L_0 = __this->get_elementType_8();
		NullCheck(L_0);
		String_t* L_1 = VirtFuncInvoker0< String_t* >::Invoke(18 /* System.String System.Type::get_FullName() */, L_0);
		String_t* L_2 = VirtFuncInvoker1< String_t*, String_t* >::Invoke(83 /* System.String System.Reflection.Emit.DerivedType::FormatName(System.String) */, __this, L_1);
		return L_2;
	}
}
// System.String System.Reflection.Emit.DerivedType::get_Name()
extern "C"  String_t* DerivedType_get_Name_m1748632995 (DerivedType_t1016359113 * __this, const MethodInfo* method)
{
	{
		Type_t * L_0 = __this->get_elementType_8();
		NullCheck(L_0);
		String_t* L_1 = VirtFuncInvoker0< String_t* >::Invoke(8 /* System.String System.Reflection.MemberInfo::get_Name() */, L_0);
		String_t* L_2 = VirtFuncInvoker1< String_t*, String_t* >::Invoke(83 /* System.String System.Reflection.Emit.DerivedType::FormatName(System.String) */, __this, L_1);
		return L_2;
	}
}
// System.Reflection.Module System.Reflection.Emit.DerivedType::get_Module()
extern "C"  Module_t4282841206 * DerivedType_get_Module_m2877391270 (DerivedType_t1016359113 * __this, const MethodInfo* method)
{
	{
		Type_t * L_0 = __this->get_elementType_8();
		NullCheck(L_0);
		Module_t4282841206 * L_1 = VirtFuncInvoker0< Module_t4282841206 * >::Invoke(10 /* System.Reflection.Module System.Type::get_Module() */, L_0);
		return L_1;
	}
}
// System.String System.Reflection.Emit.DerivedType::get_Namespace()
extern "C"  String_t* DerivedType_get_Namespace_m3902616023 (DerivedType_t1016359113 * __this, const MethodInfo* method)
{
	{
		Type_t * L_0 = __this->get_elementType_8();
		NullCheck(L_0);
		String_t* L_1 = VirtFuncInvoker0< String_t* >::Invoke(34 /* System.String System.Type::get_Namespace() */, L_0);
		return L_1;
	}
}
// System.RuntimeTypeHandle System.Reflection.Emit.DerivedType::get_TypeHandle()
extern Il2CppClass* NotSupportedException_t1793819818_il2cpp_TypeInfo_var;
extern const uint32_t DerivedType_get_TypeHandle_m1486870245_MetadataUsageId;
extern "C"  RuntimeTypeHandle_t2330101084  DerivedType_get_TypeHandle_m1486870245 (DerivedType_t1016359113 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (DerivedType_get_TypeHandle_m1486870245_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		NotSupportedException_t1793819818 * L_0 = (NotSupportedException_t1793819818 *)il2cpp_codegen_object_new(NotSupportedException_t1793819818_il2cpp_TypeInfo_var);
		NotSupportedException__ctor_m3232764727(L_0, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Type System.Reflection.Emit.DerivedType::get_UnderlyingSystemType()
extern "C"  Type_t * DerivedType_get_UnderlyingSystemType_m3904230233 (DerivedType_t1016359113 * __this, const MethodInfo* method)
{
	{
		DerivedType_create_unmanaged_type_m3164160613(NULL /*static, unused*/, __this, /*hidden argument*/NULL);
		return __this;
	}
}
// System.Boolean System.Reflection.Emit.DerivedType::IsDefined(System.Type,System.Boolean)
extern Il2CppClass* NotSupportedException_t1793819818_il2cpp_TypeInfo_var;
extern const uint32_t DerivedType_IsDefined_m555719351_MetadataUsageId;
extern "C"  bool DerivedType_IsDefined_m555719351 (DerivedType_t1016359113 * __this, Type_t * ___attributeType0, bool ___inherit1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (DerivedType_IsDefined_m555719351_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		NotSupportedException_t1793819818 * L_0 = (NotSupportedException_t1793819818 *)il2cpp_codegen_object_new(NotSupportedException_t1793819818_il2cpp_TypeInfo_var);
		NotSupportedException__ctor_m3232764727(L_0, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Object[] System.Reflection.Emit.DerivedType::GetCustomAttributes(System.Boolean)
extern Il2CppClass* NotSupportedException_t1793819818_il2cpp_TypeInfo_var;
extern const uint32_t DerivedType_GetCustomAttributes_m731216224_MetadataUsageId;
extern "C"  ObjectU5BU5D_t3614634134* DerivedType_GetCustomAttributes_m731216224 (DerivedType_t1016359113 * __this, bool ___inherit0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (DerivedType_GetCustomAttributes_m731216224_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		NotSupportedException_t1793819818 * L_0 = (NotSupportedException_t1793819818 *)il2cpp_codegen_object_new(NotSupportedException_t1793819818_il2cpp_TypeInfo_var);
		NotSupportedException__ctor_m3232764727(L_0, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Object[] System.Reflection.Emit.DerivedType::GetCustomAttributes(System.Type,System.Boolean)
extern Il2CppClass* NotSupportedException_t1793819818_il2cpp_TypeInfo_var;
extern const uint32_t DerivedType_GetCustomAttributes_m4010730569_MetadataUsageId;
extern "C"  ObjectU5BU5D_t3614634134* DerivedType_GetCustomAttributes_m4010730569 (DerivedType_t1016359113 * __this, Type_t * ___attributeType0, bool ___inherit1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (DerivedType_GetCustomAttributes_m4010730569_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		NotSupportedException_t1793819818 * L_0 = (NotSupportedException_t1793819818 *)il2cpp_codegen_object_new(NotSupportedException_t1793819818_il2cpp_TypeInfo_var);
		NotSupportedException__ctor_m3232764727(L_0, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Reflection.Assembly System.Reflection.Emit.EnumBuilder::get_Assembly()
extern "C"  Assembly_t4268412390 * EnumBuilder_get_Assembly_m4285228003 (EnumBuilder_t2808714468 * __this, const MethodInfo* method)
{
	{
		TypeBuilder_t3308873219 * L_0 = __this->get__tb_8();
		NullCheck(L_0);
		Assembly_t4268412390 * L_1 = TypeBuilder_get_Assembly_m492491492(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.String System.Reflection.Emit.EnumBuilder::get_AssemblyQualifiedName()
extern "C"  String_t* EnumBuilder_get_AssemblyQualifiedName_m3662466844 (EnumBuilder_t2808714468 * __this, const MethodInfo* method)
{
	{
		TypeBuilder_t3308873219 * L_0 = __this->get__tb_8();
		NullCheck(L_0);
		String_t* L_1 = TypeBuilder_get_AssemblyQualifiedName_m2097258567(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Type System.Reflection.Emit.EnumBuilder::get_BaseType()
extern "C"  Type_t * EnumBuilder_get_BaseType_m63295819 (EnumBuilder_t2808714468 * __this, const MethodInfo* method)
{
	{
		TypeBuilder_t3308873219 * L_0 = __this->get__tb_8();
		NullCheck(L_0);
		Type_t * L_1 = TypeBuilder_get_BaseType_m4088672180(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Type System.Reflection.Emit.EnumBuilder::get_DeclaringType()
extern "C"  Type_t * EnumBuilder_get_DeclaringType_m1949466083 (EnumBuilder_t2808714468 * __this, const MethodInfo* method)
{
	{
		TypeBuilder_t3308873219 * L_0 = __this->get__tb_8();
		NullCheck(L_0);
		Type_t * L_1 = TypeBuilder_get_DeclaringType_m3236598700(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.String System.Reflection.Emit.EnumBuilder::get_FullName()
extern "C"  String_t* EnumBuilder_get_FullName_m2818393911 (EnumBuilder_t2808714468 * __this, const MethodInfo* method)
{
	{
		TypeBuilder_t3308873219 * L_0 = __this->get__tb_8();
		NullCheck(L_0);
		String_t* L_1 = TypeBuilder_get_FullName_m1626507516(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Reflection.Module System.Reflection.Emit.EnumBuilder::get_Module()
extern "C"  Module_t4282841206 * EnumBuilder_get_Module_m431986379 (EnumBuilder_t2808714468 * __this, const MethodInfo* method)
{
	{
		TypeBuilder_t3308873219 * L_0 = __this->get__tb_8();
		NullCheck(L_0);
		Module_t4282841206 * L_1 = TypeBuilder_get_Module_m1668298460(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.String System.Reflection.Emit.EnumBuilder::get_Name()
extern "C"  String_t* EnumBuilder_get_Name_m2088160658 (EnumBuilder_t2808714468 * __this, const MethodInfo* method)
{
	{
		TypeBuilder_t3308873219 * L_0 = __this->get__tb_8();
		NullCheck(L_0);
		String_t* L_1 = TypeBuilder_get_Name_m170882803(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.String System.Reflection.Emit.EnumBuilder::get_Namespace()
extern "C"  String_t* EnumBuilder_get_Namespace_m3109232562 (EnumBuilder_t2808714468 * __this, const MethodInfo* method)
{
	{
		TypeBuilder_t3308873219 * L_0 = __this->get__tb_8();
		NullCheck(L_0);
		String_t* L_1 = TypeBuilder_get_Namespace_m3562783599(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Type System.Reflection.Emit.EnumBuilder::get_ReflectedType()
extern "C"  Type_t * EnumBuilder_get_ReflectedType_m2679108928 (EnumBuilder_t2808714468 * __this, const MethodInfo* method)
{
	{
		TypeBuilder_t3308873219 * L_0 = __this->get__tb_8();
		NullCheck(L_0);
		Type_t * L_1 = TypeBuilder_get_ReflectedType_m2504081059(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.RuntimeTypeHandle System.Reflection.Emit.EnumBuilder::get_TypeHandle()
extern "C"  RuntimeTypeHandle_t2330101084  EnumBuilder_get_TypeHandle_m724362740 (EnumBuilder_t2808714468 * __this, const MethodInfo* method)
{
	{
		TypeBuilder_t3308873219 * L_0 = __this->get__tb_8();
		NullCheck(L_0);
		RuntimeTypeHandle_t2330101084  L_1 = TypeBuilder_get_TypeHandle_m922348781(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Type System.Reflection.Emit.EnumBuilder::get_UnderlyingSystemType()
extern "C"  Type_t * EnumBuilder_get_UnderlyingSystemType_m1699680520 (EnumBuilder_t2808714468 * __this, const MethodInfo* method)
{
	{
		Type_t * L_0 = __this->get__underlyingType_9();
		return L_0;
	}
}
// System.Reflection.TypeAttributes System.Reflection.Emit.EnumBuilder::GetAttributeFlagsImpl()
extern "C"  int32_t EnumBuilder_GetAttributeFlagsImpl_m4263246832 (EnumBuilder_t2808714468 * __this, const MethodInfo* method)
{
	{
		TypeBuilder_t3308873219 * L_0 = __this->get__tb_8();
		NullCheck(L_0);
		int32_t L_1 = L_0->get_attrs_17();
		return L_1;
	}
}
// System.Reflection.ConstructorInfo System.Reflection.Emit.EnumBuilder::GetConstructorImpl(System.Reflection.BindingFlags,System.Reflection.Binder,System.Reflection.CallingConventions,System.Type[],System.Reflection.ParameterModifier[])
extern "C"  ConstructorInfo_t2851816542 * EnumBuilder_GetConstructorImpl_m331611313 (EnumBuilder_t2808714468 * __this, int32_t ___bindingAttr0, Binder_t3404612058 * ___binder1, int32_t ___callConvention2, TypeU5BU5D_t1664964607* ___types3, ParameterModifierU5BU5D_t963192633* ___modifiers4, const MethodInfo* method)
{
	{
		TypeBuilder_t3308873219 * L_0 = __this->get__tb_8();
		int32_t L_1 = ___bindingAttr0;
		Binder_t3404612058 * L_2 = ___binder1;
		int32_t L_3 = ___callConvention2;
		TypeU5BU5D_t1664964607* L_4 = ___types3;
		ParameterModifierU5BU5D_t963192633* L_5 = ___modifiers4;
		NullCheck(L_0);
		ConstructorInfo_t2851816542 * L_6 = Type_GetConstructor_m835344477(L_0, L_1, L_2, L_3, L_4, L_5, /*hidden argument*/NULL);
		return L_6;
	}
}
// System.Reflection.ConstructorInfo[] System.Reflection.Emit.EnumBuilder::GetConstructors(System.Reflection.BindingFlags)
extern "C"  ConstructorInfoU5BU5D_t1996683371* EnumBuilder_GetConstructors_m3240699827 (EnumBuilder_t2808714468 * __this, int32_t ___bindingAttr0, const MethodInfo* method)
{
	{
		TypeBuilder_t3308873219 * L_0 = __this->get__tb_8();
		int32_t L_1 = ___bindingAttr0;
		NullCheck(L_0);
		ConstructorInfoU5BU5D_t1996683371* L_2 = TypeBuilder_GetConstructors_m774120094(L_0, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.Object[] System.Reflection.Emit.EnumBuilder::GetCustomAttributes(System.Boolean)
extern "C"  ObjectU5BU5D_t3614634134* EnumBuilder_GetCustomAttributes_m432109445 (EnumBuilder_t2808714468 * __this, bool ___inherit0, const MethodInfo* method)
{
	{
		TypeBuilder_t3308873219 * L_0 = __this->get__tb_8();
		bool L_1 = ___inherit0;
		NullCheck(L_0);
		ObjectU5BU5D_t3614634134* L_2 = TypeBuilder_GetCustomAttributes_m1637538574(L_0, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.Object[] System.Reflection.Emit.EnumBuilder::GetCustomAttributes(System.Type,System.Boolean)
extern "C"  ObjectU5BU5D_t3614634134* EnumBuilder_GetCustomAttributes_m2001415610 (EnumBuilder_t2808714468 * __this, Type_t * ___attributeType0, bool ___inherit1, const MethodInfo* method)
{
	{
		TypeBuilder_t3308873219 * L_0 = __this->get__tb_8();
		Type_t * L_1 = ___attributeType0;
		bool L_2 = ___inherit1;
		NullCheck(L_0);
		ObjectU5BU5D_t3614634134* L_3 = TypeBuilder_GetCustomAttributes_m2702632361(L_0, L_1, L_2, /*hidden argument*/NULL);
		return L_3;
	}
}
// System.Type System.Reflection.Emit.EnumBuilder::GetElementType()
extern "C"  Type_t * EnumBuilder_GetElementType_m1228393631 (EnumBuilder_t2808714468 * __this, const MethodInfo* method)
{
	{
		TypeBuilder_t3308873219 * L_0 = __this->get__tb_8();
		NullCheck(L_0);
		Type_t * L_1 = TypeBuilder_GetElementType_m3707448372(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Reflection.EventInfo System.Reflection.Emit.EnumBuilder::GetEvent(System.String,System.Reflection.BindingFlags)
extern "C"  EventInfo_t * EnumBuilder_GetEvent_m3989421960 (EnumBuilder_t2808714468 * __this, String_t* ___name0, int32_t ___bindingAttr1, const MethodInfo* method)
{
	{
		TypeBuilder_t3308873219 * L_0 = __this->get__tb_8();
		String_t* L_1 = ___name0;
		int32_t L_2 = ___bindingAttr1;
		NullCheck(L_0);
		EventInfo_t * L_3 = TypeBuilder_GetEvent_m3876348075(L_0, L_1, L_2, /*hidden argument*/NULL);
		return L_3;
	}
}
// System.Reflection.FieldInfo System.Reflection.Emit.EnumBuilder::GetField(System.String,System.Reflection.BindingFlags)
extern "C"  FieldInfo_t * EnumBuilder_GetField_m1324325036 (EnumBuilder_t2808714468 * __this, String_t* ___name0, int32_t ___bindingAttr1, const MethodInfo* method)
{
	{
		TypeBuilder_t3308873219 * L_0 = __this->get__tb_8();
		String_t* L_1 = ___name0;
		int32_t L_2 = ___bindingAttr1;
		NullCheck(L_0);
		FieldInfo_t * L_3 = TypeBuilder_GetField_m2112455315(L_0, L_1, L_2, /*hidden argument*/NULL);
		return L_3;
	}
}
// System.Reflection.FieldInfo[] System.Reflection.Emit.EnumBuilder::GetFields(System.Reflection.BindingFlags)
extern "C"  FieldInfoU5BU5D_t125053523* EnumBuilder_GetFields_m2003258635 (EnumBuilder_t2808714468 * __this, int32_t ___bindingAttr0, const MethodInfo* method)
{
	{
		TypeBuilder_t3308873219 * L_0 = __this->get__tb_8();
		int32_t L_1 = ___bindingAttr0;
		NullCheck(L_0);
		FieldInfoU5BU5D_t125053523* L_2 = TypeBuilder_GetFields_m3875401338(L_0, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.Type[] System.Reflection.Emit.EnumBuilder::GetInterfaces()
extern "C"  TypeU5BU5D_t1664964607* EnumBuilder_GetInterfaces_m198423261 (EnumBuilder_t2808714468 * __this, const MethodInfo* method)
{
	{
		TypeBuilder_t3308873219 * L_0 = __this->get__tb_8();
		NullCheck(L_0);
		TypeU5BU5D_t1664964607* L_1 = TypeBuilder_GetInterfaces_m1818658502(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Reflection.MethodInfo System.Reflection.Emit.EnumBuilder::GetMethodImpl(System.String,System.Reflection.BindingFlags,System.Reflection.Binder,System.Reflection.CallingConventions,System.Type[],System.Reflection.ParameterModifier[])
extern "C"  MethodInfo_t * EnumBuilder_GetMethodImpl_m2091516387 (EnumBuilder_t2808714468 * __this, String_t* ___name0, int32_t ___bindingAttr1, Binder_t3404612058 * ___binder2, int32_t ___callConvention3, TypeU5BU5D_t1664964607* ___types4, ParameterModifierU5BU5D_t963192633* ___modifiers5, const MethodInfo* method)
{
	{
		TypeU5BU5D_t1664964607* L_0 = ___types4;
		if (L_0)
		{
			goto IL_0015;
		}
	}
	{
		TypeBuilder_t3308873219 * L_1 = __this->get__tb_8();
		String_t* L_2 = ___name0;
		int32_t L_3 = ___bindingAttr1;
		NullCheck(L_1);
		MethodInfo_t * L_4 = Type_GetMethod_m475234662(L_1, L_2, L_3, /*hidden argument*/NULL);
		return L_4;
	}

IL_0015:
	{
		TypeBuilder_t3308873219 * L_5 = __this->get__tb_8();
		String_t* L_6 = ___name0;
		int32_t L_7 = ___bindingAttr1;
		Binder_t3404612058 * L_8 = ___binder2;
		int32_t L_9 = ___callConvention3;
		TypeU5BU5D_t1664964607* L_10 = ___types4;
		ParameterModifierU5BU5D_t963192633* L_11 = ___modifiers5;
		NullCheck(L_5);
		MethodInfo_t * L_12 = Type_GetMethod_m3650909507(L_5, L_6, L_7, L_8, L_9, L_10, L_11, /*hidden argument*/NULL);
		return L_12;
	}
}
// System.Reflection.MethodInfo[] System.Reflection.Emit.EnumBuilder::GetMethods(System.Reflection.BindingFlags)
extern "C"  MethodInfoU5BU5D_t152480188* EnumBuilder_GetMethods_m342174319 (EnumBuilder_t2808714468 * __this, int32_t ___bindingAttr0, const MethodInfo* method)
{
	{
		TypeBuilder_t3308873219 * L_0 = __this->get__tb_8();
		int32_t L_1 = ___bindingAttr0;
		NullCheck(L_0);
		MethodInfoU5BU5D_t152480188* L_2 = TypeBuilder_GetMethods_m4196862738(L_0, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.Reflection.PropertyInfo System.Reflection.Emit.EnumBuilder::GetPropertyImpl(System.String,System.Reflection.BindingFlags,System.Reflection.Binder,System.Type,System.Type[],System.Reflection.ParameterModifier[])
extern "C"  PropertyInfo_t * EnumBuilder_GetPropertyImpl_m2717304076 (EnumBuilder_t2808714468 * __this, String_t* ___name0, int32_t ___bindingAttr1, Binder_t3404612058 * ___binder2, Type_t * ___returnType3, TypeU5BU5D_t1664964607* ___types4, ParameterModifierU5BU5D_t963192633* ___modifiers5, const MethodInfo* method)
{
	{
		Exception_t1927440687 * L_0 = EnumBuilder_CreateNotSupportedException_m62763134(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Boolean System.Reflection.Emit.EnumBuilder::HasElementTypeImpl()
extern "C"  bool EnumBuilder_HasElementTypeImpl_m1414733955 (EnumBuilder_t2808714468 * __this, const MethodInfo* method)
{
	{
		TypeBuilder_t3308873219 * L_0 = __this->get__tb_8();
		NullCheck(L_0);
		bool L_1 = Type_get_HasElementType_m3319917896(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Object System.Reflection.Emit.EnumBuilder::InvokeMember(System.String,System.Reflection.BindingFlags,System.Reflection.Binder,System.Object,System.Object[],System.Reflection.ParameterModifier[],System.Globalization.CultureInfo,System.String[])
extern "C"  Il2CppObject * EnumBuilder_InvokeMember_m633176706 (EnumBuilder_t2808714468 * __this, String_t* ___name0, int32_t ___invokeAttr1, Binder_t3404612058 * ___binder2, Il2CppObject * ___target3, ObjectU5BU5D_t3614634134* ___args4, ParameterModifierU5BU5D_t963192633* ___modifiers5, CultureInfo_t3500843524 * ___culture6, StringU5BU5D_t1642385972* ___namedParameters7, const MethodInfo* method)
{
	{
		TypeBuilder_t3308873219 * L_0 = __this->get__tb_8();
		String_t* L_1 = ___name0;
		int32_t L_2 = ___invokeAttr1;
		Binder_t3404612058 * L_3 = ___binder2;
		Il2CppObject * L_4 = ___target3;
		ObjectU5BU5D_t3614634134* L_5 = ___args4;
		ParameterModifierU5BU5D_t963192633* L_6 = ___modifiers5;
		CultureInfo_t3500843524 * L_7 = ___culture6;
		StringU5BU5D_t1642385972* L_8 = ___namedParameters7;
		NullCheck(L_0);
		Il2CppObject * L_9 = TypeBuilder_InvokeMember_m1992906893(L_0, L_1, L_2, L_3, L_4, L_5, L_6, L_7, L_8, /*hidden argument*/NULL);
		return L_9;
	}
}
// System.Boolean System.Reflection.Emit.EnumBuilder::IsArrayImpl()
extern "C"  bool EnumBuilder_IsArrayImpl_m3185704898 (EnumBuilder_t2808714468 * __this, const MethodInfo* method)
{
	{
		return (bool)0;
	}
}
// System.Boolean System.Reflection.Emit.EnumBuilder::IsByRefImpl()
extern "C"  bool EnumBuilder_IsByRefImpl_m3302439719 (EnumBuilder_t2808714468 * __this, const MethodInfo* method)
{
	{
		return (bool)0;
	}
}
// System.Boolean System.Reflection.Emit.EnumBuilder::IsPointerImpl()
extern "C"  bool EnumBuilder_IsPointerImpl_m2768502902 (EnumBuilder_t2808714468 * __this, const MethodInfo* method)
{
	{
		return (bool)0;
	}
}
// System.Boolean System.Reflection.Emit.EnumBuilder::IsPrimitiveImpl()
extern "C"  bool EnumBuilder_IsPrimitiveImpl_m3485654502 (EnumBuilder_t2808714468 * __this, const MethodInfo* method)
{
	{
		return (bool)0;
	}
}
// System.Boolean System.Reflection.Emit.EnumBuilder::IsValueTypeImpl()
extern "C"  bool EnumBuilder_IsValueTypeImpl_m3635754638 (EnumBuilder_t2808714468 * __this, const MethodInfo* method)
{
	{
		return (bool)1;
	}
}
// System.Boolean System.Reflection.Emit.EnumBuilder::IsDefined(System.Type,System.Boolean)
extern "C"  bool EnumBuilder_IsDefined_m255842204 (EnumBuilder_t2808714468 * __this, Type_t * ___attributeType0, bool ___inherit1, const MethodInfo* method)
{
	{
		TypeBuilder_t3308873219 * L_0 = __this->get__tb_8();
		Type_t * L_1 = ___attributeType0;
		bool L_2 = ___inherit1;
		NullCheck(L_0);
		bool L_3 = TypeBuilder_IsDefined_m3186251655(L_0, L_1, L_2, /*hidden argument*/NULL);
		return L_3;
	}
}
// System.Type System.Reflection.Emit.EnumBuilder::MakeByRefType()
extern Il2CppClass* ByRefType_t1587086384_il2cpp_TypeInfo_var;
extern const uint32_t EnumBuilder_MakeByRefType_m3504630835_MetadataUsageId;
extern "C"  Type_t * EnumBuilder_MakeByRefType_m3504630835 (EnumBuilder_t2808714468 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (EnumBuilder_MakeByRefType_m3504630835_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ByRefType_t1587086384 * L_0 = (ByRefType_t1587086384 *)il2cpp_codegen_object_new(ByRefType_t1587086384_il2cpp_TypeInfo_var);
		ByRefType__ctor_m2068210324(L_0, __this, /*hidden argument*/NULL);
		return L_0;
	}
}
// System.Exception System.Reflection.Emit.EnumBuilder::CreateNotSupportedException()
extern Il2CppClass* NotSupportedException_t1793819818_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral4087454587;
extern const uint32_t EnumBuilder_CreateNotSupportedException_m62763134_MetadataUsageId;
extern "C"  Exception_t1927440687 * EnumBuilder_CreateNotSupportedException_m62763134 (EnumBuilder_t2808714468 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (EnumBuilder_CreateNotSupportedException_m62763134_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		NotSupportedException_t1793819818 * L_0 = (NotSupportedException_t1793819818 *)il2cpp_codegen_object_new(NotSupportedException_t1793819818_il2cpp_TypeInfo_var);
		NotSupportedException__ctor_m836173213(L_0, _stringLiteral4087454587, /*hidden argument*/NULL);
		return L_0;
	}
}
// System.Reflection.FieldAttributes System.Reflection.Emit.FieldBuilder::get_Attributes()
extern "C"  int32_t FieldBuilder_get_Attributes_m2174064290 (FieldBuilder_t2784804005 * __this, const MethodInfo* method)
{
	{
		int32_t L_0 = __this->get_attrs_0();
		return L_0;
	}
}
// System.Type System.Reflection.Emit.FieldBuilder::get_DeclaringType()
extern "C"  Type_t * FieldBuilder_get_DeclaringType_m726107228 (FieldBuilder_t2784804005 * __this, const MethodInfo* method)
{
	{
		TypeBuilder_t3308873219 * L_0 = __this->get_typeb_3();
		return L_0;
	}
}
// System.RuntimeFieldHandle System.Reflection.Emit.FieldBuilder::get_FieldHandle()
extern "C"  RuntimeFieldHandle_t2331729674  FieldBuilder_get_FieldHandle_m1845846823 (FieldBuilder_t2784804005 * __this, const MethodInfo* method)
{
	{
		Exception_t1927440687 * L_0 = FieldBuilder_CreateNotSupportedException_m3999938861(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Type System.Reflection.Emit.FieldBuilder::get_FieldType()
extern "C"  Type_t * FieldBuilder_get_FieldType_m2267463269 (FieldBuilder_t2784804005 * __this, const MethodInfo* method)
{
	{
		Type_t * L_0 = __this->get_type_1();
		return L_0;
	}
}
// System.String System.Reflection.Emit.FieldBuilder::get_Name()
extern "C"  String_t* FieldBuilder_get_Name_m2243491233 (FieldBuilder_t2784804005 * __this, const MethodInfo* method)
{
	{
		String_t* L_0 = __this->get_name_2();
		return L_0;
	}
}
// System.Type System.Reflection.Emit.FieldBuilder::get_ReflectedType()
extern "C"  Type_t * FieldBuilder_get_ReflectedType_m3707619461 (FieldBuilder_t2784804005 * __this, const MethodInfo* method)
{
	{
		TypeBuilder_t3308873219 * L_0 = __this->get_typeb_3();
		return L_0;
	}
}
// System.Object[] System.Reflection.Emit.FieldBuilder::GetCustomAttributes(System.Boolean)
extern Il2CppClass* MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var;
extern const uint32_t FieldBuilder_GetCustomAttributes_m1557425540_MetadataUsageId;
extern "C"  ObjectU5BU5D_t3614634134* FieldBuilder_GetCustomAttributes_m1557425540 (FieldBuilder_t2784804005 * __this, bool ___inherit0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (FieldBuilder_GetCustomAttributes_m1557425540_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		TypeBuilder_t3308873219 * L_0 = __this->get_typeb_3();
		NullCheck(L_0);
		bool L_1 = TypeBuilder_get_is_created_m736553860(L_0, /*hidden argument*/NULL);
		if (!L_1)
		{
			goto IL_0018;
		}
	}
	{
		bool L_2 = ___inherit0;
		IL2CPP_RUNTIME_CLASS_INIT(MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var);
		ObjectU5BU5D_t3614634134* L_3 = MonoCustomAttrs_GetCustomAttributes_m3069779582(NULL /*static, unused*/, __this, L_2, /*hidden argument*/NULL);
		return L_3;
	}

IL_0018:
	{
		Exception_t1927440687 * L_4 = FieldBuilder_CreateNotSupportedException_m3999938861(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_4);
	}
}
// System.Object[] System.Reflection.Emit.FieldBuilder::GetCustomAttributes(System.Type,System.Boolean)
extern Il2CppClass* MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var;
extern const uint32_t FieldBuilder_GetCustomAttributes_m291168515_MetadataUsageId;
extern "C"  ObjectU5BU5D_t3614634134* FieldBuilder_GetCustomAttributes_m291168515 (FieldBuilder_t2784804005 * __this, Type_t * ___attributeType0, bool ___inherit1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (FieldBuilder_GetCustomAttributes_m291168515_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		TypeBuilder_t3308873219 * L_0 = __this->get_typeb_3();
		NullCheck(L_0);
		bool L_1 = TypeBuilder_get_is_created_m736553860(L_0, /*hidden argument*/NULL);
		if (!L_1)
		{
			goto IL_0019;
		}
	}
	{
		Type_t * L_2 = ___attributeType0;
		bool L_3 = ___inherit1;
		IL2CPP_RUNTIME_CLASS_INIT(MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var);
		ObjectU5BU5D_t3614634134* L_4 = MonoCustomAttrs_GetCustomAttributes_m939426263(NULL /*static, unused*/, __this, L_2, L_3, /*hidden argument*/NULL);
		return L_4;
	}

IL_0019:
	{
		Exception_t1927440687 * L_5 = FieldBuilder_CreateNotSupportedException_m3999938861(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_5);
	}
}
// System.Object System.Reflection.Emit.FieldBuilder::GetValue(System.Object)
extern "C"  Il2CppObject * FieldBuilder_GetValue_m1323554150 (FieldBuilder_t2784804005 * __this, Il2CppObject * ___obj0, const MethodInfo* method)
{
	{
		Exception_t1927440687 * L_0 = FieldBuilder_CreateNotSupportedException_m3999938861(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Boolean System.Reflection.Emit.FieldBuilder::IsDefined(System.Type,System.Boolean)
extern "C"  bool FieldBuilder_IsDefined_m2730324893 (FieldBuilder_t2784804005 * __this, Type_t * ___attributeType0, bool ___inherit1, const MethodInfo* method)
{
	{
		Exception_t1927440687 * L_0 = FieldBuilder_CreateNotSupportedException_m3999938861(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Int32 System.Reflection.Emit.FieldBuilder::GetFieldOffset()
extern "C"  int32_t FieldBuilder_GetFieldOffset_m618194385 (FieldBuilder_t2784804005 * __this, const MethodInfo* method)
{
	{
		return 0;
	}
}
// System.Void System.Reflection.Emit.FieldBuilder::SetValue(System.Object,System.Object,System.Reflection.BindingFlags,System.Reflection.Binder,System.Globalization.CultureInfo)
extern "C"  void FieldBuilder_SetValue_m3109503557 (FieldBuilder_t2784804005 * __this, Il2CppObject * ___obj0, Il2CppObject * ___val1, int32_t ___invokeAttr2, Binder_t3404612058 * ___binder3, CultureInfo_t3500843524 * ___culture4, const MethodInfo* method)
{
	{
		Exception_t1927440687 * L_0 = FieldBuilder_CreateNotSupportedException_m3999938861(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Reflection.Emit.UnmanagedMarshal System.Reflection.Emit.FieldBuilder::get_UMarshal()
extern "C"  UnmanagedMarshal_t4270021860 * FieldBuilder_get_UMarshal_m3138919472 (FieldBuilder_t2784804005 * __this, const MethodInfo* method)
{
	{
		UnmanagedMarshal_t4270021860 * L_0 = __this->get_marshal_info_4();
		return L_0;
	}
}
// System.Exception System.Reflection.Emit.FieldBuilder::CreateNotSupportedException()
extern Il2CppClass* NotSupportedException_t1793819818_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral4087454587;
extern const uint32_t FieldBuilder_CreateNotSupportedException_m3999938861_MetadataUsageId;
extern "C"  Exception_t1927440687 * FieldBuilder_CreateNotSupportedException_m3999938861 (FieldBuilder_t2784804005 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (FieldBuilder_CreateNotSupportedException_m3999938861_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		NotSupportedException_t1793819818 * L_0 = (NotSupportedException_t1793819818 *)il2cpp_codegen_object_new(NotSupportedException_t1793819818_il2cpp_TypeInfo_var);
		NotSupportedException__ctor_m836173213(L_0, _stringLiteral4087454587, /*hidden argument*/NULL);
		return L_0;
	}
}
// System.Reflection.Module System.Reflection.Emit.FieldBuilder::get_Module()
extern "C"  Module_t4282841206 * FieldBuilder_get_Module_m1920701714 (FieldBuilder_t2784804005 * __this, const MethodInfo* method)
{
	{
		Module_t4282841206 * L_0 = MemberInfo_get_Module_m3957426656(__this, /*hidden argument*/NULL);
		return L_0;
	}
}
// System.Boolean System.Reflection.Emit.GenericTypeParameterBuilder::IsSubclassOf(System.Type)
extern Il2CppClass* ModuleBuilder_t4156028127_il2cpp_TypeInfo_var;
extern const uint32_t GenericTypeParameterBuilder_IsSubclassOf_m563999142_MetadataUsageId;
extern "C"  bool GenericTypeParameterBuilder_IsSubclassOf_m563999142 (GenericTypeParameterBuilder_t1370236603 * __this, Type_t * ___c0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (GenericTypeParameterBuilder_IsSubclassOf_m563999142_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t G_B7_0 = 0;
	{
		TypeBuilder_t3308873219 * L_0 = __this->get_tbuilder_8();
		NullCheck(L_0);
		Module_t4282841206 * L_1 = TypeBuilder_get_Module_m1668298460(L_0, /*hidden argument*/NULL);
		NullCheck(((ModuleBuilder_t4156028127 *)CastclassClass(L_1, ModuleBuilder_t4156028127_il2cpp_TypeInfo_var)));
		AssemblyBuilder_t1646117627 * L_2 = ((ModuleBuilder_t4156028127 *)CastclassClass(L_1, ModuleBuilder_t4156028127_il2cpp_TypeInfo_var))->get_assemblyb_12();
		NullCheck(L_2);
		bool L_3 = AssemblyBuilder_get_IsCompilerContext_m2864230005(L_2, /*hidden argument*/NULL);
		if (L_3)
		{
			goto IL_0026;
		}
	}
	{
		Exception_t1927440687 * L_4 = GenericTypeParameterBuilder_not_supported_m3784909043(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_4);
	}

IL_0026:
	{
		Type_t * L_5 = GenericTypeParameterBuilder_get_BaseType_m101683868(__this, /*hidden argument*/NULL);
		if (L_5)
		{
			goto IL_0033;
		}
	}
	{
		return (bool)0;
	}

IL_0033:
	{
		Type_t * L_6 = GenericTypeParameterBuilder_get_BaseType_m101683868(__this, /*hidden argument*/NULL);
		Type_t * L_7 = ___c0;
		if ((((Il2CppObject*)(Type_t *)L_6) == ((Il2CppObject*)(Type_t *)L_7)))
		{
			goto IL_004d;
		}
	}
	{
		Type_t * L_8 = GenericTypeParameterBuilder_get_BaseType_m101683868(__this, /*hidden argument*/NULL);
		Type_t * L_9 = ___c0;
		NullCheck(L_8);
		bool L_10 = VirtFuncInvoker1< bool, Type_t * >::Invoke(38 /* System.Boolean System.Type::IsSubclassOf(System.Type) */, L_8, L_9);
		G_B7_0 = ((int32_t)(L_10));
		goto IL_004e;
	}

IL_004d:
	{
		G_B7_0 = 1;
	}

IL_004e:
	{
		return (bool)G_B7_0;
	}
}
// System.Reflection.TypeAttributes System.Reflection.Emit.GenericTypeParameterBuilder::GetAttributeFlagsImpl()
extern Il2CppClass* ModuleBuilder_t4156028127_il2cpp_TypeInfo_var;
extern const uint32_t GenericTypeParameterBuilder_GetAttributeFlagsImpl_m3338182267_MetadataUsageId;
extern "C"  int32_t GenericTypeParameterBuilder_GetAttributeFlagsImpl_m3338182267 (GenericTypeParameterBuilder_t1370236603 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (GenericTypeParameterBuilder_GetAttributeFlagsImpl_m3338182267_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		TypeBuilder_t3308873219 * L_0 = __this->get_tbuilder_8();
		NullCheck(L_0);
		Module_t4282841206 * L_1 = TypeBuilder_get_Module_m1668298460(L_0, /*hidden argument*/NULL);
		NullCheck(((ModuleBuilder_t4156028127 *)CastclassClass(L_1, ModuleBuilder_t4156028127_il2cpp_TypeInfo_var)));
		AssemblyBuilder_t1646117627 * L_2 = ((ModuleBuilder_t4156028127 *)CastclassClass(L_1, ModuleBuilder_t4156028127_il2cpp_TypeInfo_var))->get_assemblyb_12();
		NullCheck(L_2);
		bool L_3 = AssemblyBuilder_get_IsCompilerContext_m2864230005(L_2, /*hidden argument*/NULL);
		if (!L_3)
		{
			goto IL_0021;
		}
	}
	{
		return (int32_t)(1);
	}

IL_0021:
	{
		Exception_t1927440687 * L_4 = GenericTypeParameterBuilder_not_supported_m3784909043(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_4);
	}
}
// System.Reflection.ConstructorInfo System.Reflection.Emit.GenericTypeParameterBuilder::GetConstructorImpl(System.Reflection.BindingFlags,System.Reflection.Binder,System.Reflection.CallingConventions,System.Type[],System.Reflection.ParameterModifier[])
extern "C"  ConstructorInfo_t2851816542 * GenericTypeParameterBuilder_GetConstructorImpl_m2310028502 (GenericTypeParameterBuilder_t1370236603 * __this, int32_t ___bindingAttr0, Binder_t3404612058 * ___binder1, int32_t ___callConvention2, TypeU5BU5D_t1664964607* ___types3, ParameterModifierU5BU5D_t963192633* ___modifiers4, const MethodInfo* method)
{
	{
		Exception_t1927440687 * L_0 = GenericTypeParameterBuilder_not_supported_m3784909043(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Reflection.ConstructorInfo[] System.Reflection.Emit.GenericTypeParameterBuilder::GetConstructors(System.Reflection.BindingFlags)
extern "C"  ConstructorInfoU5BU5D_t1996683371* GenericTypeParameterBuilder_GetConstructors_m103067670 (GenericTypeParameterBuilder_t1370236603 * __this, int32_t ___bindingAttr0, const MethodInfo* method)
{
	{
		Exception_t1927440687 * L_0 = GenericTypeParameterBuilder_not_supported_m3784909043(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Reflection.EventInfo System.Reflection.Emit.GenericTypeParameterBuilder::GetEvent(System.String,System.Reflection.BindingFlags)
extern "C"  EventInfo_t * GenericTypeParameterBuilder_GetEvent_m4210567427 (GenericTypeParameterBuilder_t1370236603 * __this, String_t* ___name0, int32_t ___bindingAttr1, const MethodInfo* method)
{
	{
		Exception_t1927440687 * L_0 = GenericTypeParameterBuilder_not_supported_m3784909043(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Reflection.FieldInfo System.Reflection.Emit.GenericTypeParameterBuilder::GetField(System.String,System.Reflection.BindingFlags)
extern "C"  FieldInfo_t * GenericTypeParameterBuilder_GetField_m1135650395 (GenericTypeParameterBuilder_t1370236603 * __this, String_t* ___name0, int32_t ___bindingAttr1, const MethodInfo* method)
{
	{
		Exception_t1927440687 * L_0 = GenericTypeParameterBuilder_not_supported_m3784909043(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Reflection.FieldInfo[] System.Reflection.Emit.GenericTypeParameterBuilder::GetFields(System.Reflection.BindingFlags)
extern "C"  FieldInfoU5BU5D_t125053523* GenericTypeParameterBuilder_GetFields_m1855948450 (GenericTypeParameterBuilder_t1370236603 * __this, int32_t ___bindingAttr0, const MethodInfo* method)
{
	{
		Exception_t1927440687 * L_0 = GenericTypeParameterBuilder_not_supported_m3784909043(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Type[] System.Reflection.Emit.GenericTypeParameterBuilder::GetInterfaces()
extern "C"  TypeU5BU5D_t1664964607* GenericTypeParameterBuilder_GetInterfaces_m922686350 (GenericTypeParameterBuilder_t1370236603 * __this, const MethodInfo* method)
{
	{
		Exception_t1927440687 * L_0 = GenericTypeParameterBuilder_not_supported_m3784909043(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Reflection.MethodInfo[] System.Reflection.Emit.GenericTypeParameterBuilder::GetMethods(System.Reflection.BindingFlags)
extern "C"  MethodInfoU5BU5D_t152480188* GenericTypeParameterBuilder_GetMethods_m1243855818 (GenericTypeParameterBuilder_t1370236603 * __this, int32_t ___bindingAttr0, const MethodInfo* method)
{
	{
		Exception_t1927440687 * L_0 = GenericTypeParameterBuilder_not_supported_m3784909043(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Reflection.MethodInfo System.Reflection.Emit.GenericTypeParameterBuilder::GetMethodImpl(System.String,System.Reflection.BindingFlags,System.Reflection.Binder,System.Reflection.CallingConventions,System.Type[],System.Reflection.ParameterModifier[])
extern "C"  MethodInfo_t * GenericTypeParameterBuilder_GetMethodImpl_m528545634 (GenericTypeParameterBuilder_t1370236603 * __this, String_t* ___name0, int32_t ___bindingAttr1, Binder_t3404612058 * ___binder2, int32_t ___callConvention3, TypeU5BU5D_t1664964607* ___types4, ParameterModifierU5BU5D_t963192633* ___modifiers5, const MethodInfo* method)
{
	{
		Exception_t1927440687 * L_0 = GenericTypeParameterBuilder_not_supported_m3784909043(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Reflection.PropertyInfo System.Reflection.Emit.GenericTypeParameterBuilder::GetPropertyImpl(System.String,System.Reflection.BindingFlags,System.Reflection.Binder,System.Type,System.Type[],System.Reflection.ParameterModifier[])
extern "C"  PropertyInfo_t * GenericTypeParameterBuilder_GetPropertyImpl_m3566422383 (GenericTypeParameterBuilder_t1370236603 * __this, String_t* ___name0, int32_t ___bindingAttr1, Binder_t3404612058 * ___binder2, Type_t * ___returnType3, TypeU5BU5D_t1664964607* ___types4, ParameterModifierU5BU5D_t963192633* ___modifiers5, const MethodInfo* method)
{
	{
		Exception_t1927440687 * L_0 = GenericTypeParameterBuilder_not_supported_m3784909043(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Boolean System.Reflection.Emit.GenericTypeParameterBuilder::HasElementTypeImpl()
extern "C"  bool GenericTypeParameterBuilder_HasElementTypeImpl_m2592272488 (GenericTypeParameterBuilder_t1370236603 * __this, const MethodInfo* method)
{
	{
		return (bool)0;
	}
}
// System.Boolean System.Reflection.Emit.GenericTypeParameterBuilder::IsAssignableFrom(System.Type)
extern "C"  bool GenericTypeParameterBuilder_IsAssignableFrom_m3874566384 (GenericTypeParameterBuilder_t1370236603 * __this, Type_t * ___c0, const MethodInfo* method)
{
	{
		Exception_t1927440687 * L_0 = GenericTypeParameterBuilder_not_supported_m3784909043(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Boolean System.Reflection.Emit.GenericTypeParameterBuilder::IsInstanceOfType(System.Object)
extern "C"  bool GenericTypeParameterBuilder_IsInstanceOfType_m2048682904 (GenericTypeParameterBuilder_t1370236603 * __this, Il2CppObject * ___o0, const MethodInfo* method)
{
	{
		Exception_t1927440687 * L_0 = GenericTypeParameterBuilder_not_supported_m3784909043(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Boolean System.Reflection.Emit.GenericTypeParameterBuilder::IsArrayImpl()
extern "C"  bool GenericTypeParameterBuilder_IsArrayImpl_m1786931395 (GenericTypeParameterBuilder_t1370236603 * __this, const MethodInfo* method)
{
	{
		return (bool)0;
	}
}
// System.Boolean System.Reflection.Emit.GenericTypeParameterBuilder::IsByRefImpl()
extern "C"  bool GenericTypeParameterBuilder_IsByRefImpl_m3339093128 (GenericTypeParameterBuilder_t1370236603 * __this, const MethodInfo* method)
{
	{
		return (bool)0;
	}
}
// System.Boolean System.Reflection.Emit.GenericTypeParameterBuilder::IsPointerImpl()
extern "C"  bool GenericTypeParameterBuilder_IsPointerImpl_m4265374617 (GenericTypeParameterBuilder_t1370236603 * __this, const MethodInfo* method)
{
	{
		return (bool)0;
	}
}
// System.Boolean System.Reflection.Emit.GenericTypeParameterBuilder::IsPrimitiveImpl()
extern "C"  bool GenericTypeParameterBuilder_IsPrimitiveImpl_m1198748291 (GenericTypeParameterBuilder_t1370236603 * __this, const MethodInfo* method)
{
	{
		return (bool)0;
	}
}
// System.Boolean System.Reflection.Emit.GenericTypeParameterBuilder::IsValueTypeImpl()
extern "C"  bool GenericTypeParameterBuilder_IsValueTypeImpl_m20800593 (GenericTypeParameterBuilder_t1370236603 * __this, const MethodInfo* method)
{
	int32_t G_B3_0 = 0;
	{
		Type_t * L_0 = __this->get_base_type_11();
		if (!L_0)
		{
			goto IL_001b;
		}
	}
	{
		Type_t * L_1 = __this->get_base_type_11();
		NullCheck(L_1);
		bool L_2 = Type_get_IsValueType_m1733572463(L_1, /*hidden argument*/NULL);
		G_B3_0 = ((int32_t)(L_2));
		goto IL_001c;
	}

IL_001b:
	{
		G_B3_0 = 0;
	}

IL_001c:
	{
		return (bool)G_B3_0;
	}
}
// System.Object System.Reflection.Emit.GenericTypeParameterBuilder::InvokeMember(System.String,System.Reflection.BindingFlags,System.Reflection.Binder,System.Object,System.Object[],System.Reflection.ParameterModifier[],System.Globalization.CultureInfo,System.String[])
extern "C"  Il2CppObject * GenericTypeParameterBuilder_InvokeMember_m1055646245 (GenericTypeParameterBuilder_t1370236603 * __this, String_t* ___name0, int32_t ___invokeAttr1, Binder_t3404612058 * ___binder2, Il2CppObject * ___target3, ObjectU5BU5D_t3614634134* ___args4, ParameterModifierU5BU5D_t963192633* ___modifiers5, CultureInfo_t3500843524 * ___culture6, StringU5BU5D_t1642385972* ___namedParameters7, const MethodInfo* method)
{
	{
		Exception_t1927440687 * L_0 = GenericTypeParameterBuilder_not_supported_m3784909043(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Type System.Reflection.Emit.GenericTypeParameterBuilder::GetElementType()
extern "C"  Type_t * GenericTypeParameterBuilder_GetElementType_m2702341452 (GenericTypeParameterBuilder_t1370236603 * __this, const MethodInfo* method)
{
	{
		Exception_t1927440687 * L_0 = GenericTypeParameterBuilder_not_supported_m3784909043(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Type System.Reflection.Emit.GenericTypeParameterBuilder::get_UnderlyingSystemType()
extern "C"  Type_t * GenericTypeParameterBuilder_get_UnderlyingSystemType_m200578513 (GenericTypeParameterBuilder_t1370236603 * __this, const MethodInfo* method)
{
	{
		return __this;
	}
}
// System.Reflection.Assembly System.Reflection.Emit.GenericTypeParameterBuilder::get_Assembly()
extern "C"  Assembly_t4268412390 * GenericTypeParameterBuilder_get_Assembly_m2103587580 (GenericTypeParameterBuilder_t1370236603 * __this, const MethodInfo* method)
{
	{
		TypeBuilder_t3308873219 * L_0 = __this->get_tbuilder_8();
		NullCheck(L_0);
		Assembly_t4268412390 * L_1 = TypeBuilder_get_Assembly_m492491492(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.String System.Reflection.Emit.GenericTypeParameterBuilder::get_AssemblyQualifiedName()
extern "C"  String_t* GenericTypeParameterBuilder_get_AssemblyQualifiedName_m902593295 (GenericTypeParameterBuilder_t1370236603 * __this, const MethodInfo* method)
{
	{
		return (String_t*)NULL;
	}
}
// System.Type System.Reflection.Emit.GenericTypeParameterBuilder::get_BaseType()
extern "C"  Type_t * GenericTypeParameterBuilder_get_BaseType_m101683868 (GenericTypeParameterBuilder_t1370236603 * __this, const MethodInfo* method)
{
	{
		Type_t * L_0 = __this->get_base_type_11();
		return L_0;
	}
}
// System.String System.Reflection.Emit.GenericTypeParameterBuilder::get_FullName()
extern "C"  String_t* GenericTypeParameterBuilder_get_FullName_m3508212436 (GenericTypeParameterBuilder_t1370236603 * __this, const MethodInfo* method)
{
	{
		return (String_t*)NULL;
	}
}
// System.Boolean System.Reflection.Emit.GenericTypeParameterBuilder::IsDefined(System.Type,System.Boolean)
extern "C"  bool GenericTypeParameterBuilder_IsDefined_m1413593919 (GenericTypeParameterBuilder_t1370236603 * __this, Type_t * ___attributeType0, bool ___inherit1, const MethodInfo* method)
{
	{
		Exception_t1927440687 * L_0 = GenericTypeParameterBuilder_not_supported_m3784909043(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Object[] System.Reflection.Emit.GenericTypeParameterBuilder::GetCustomAttributes(System.Boolean)
extern "C"  ObjectU5BU5D_t3614634134* GenericTypeParameterBuilder_GetCustomAttributes_m1330155190 (GenericTypeParameterBuilder_t1370236603 * __this, bool ___inherit0, const MethodInfo* method)
{
	{
		Exception_t1927440687 * L_0 = GenericTypeParameterBuilder_not_supported_m3784909043(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Object[] System.Reflection.Emit.GenericTypeParameterBuilder::GetCustomAttributes(System.Type,System.Boolean)
extern "C"  ObjectU5BU5D_t3614634134* GenericTypeParameterBuilder_GetCustomAttributes_m3266536625 (GenericTypeParameterBuilder_t1370236603 * __this, Type_t * ___attributeType0, bool ___inherit1, const MethodInfo* method)
{
	{
		Exception_t1927440687 * L_0 = GenericTypeParameterBuilder_not_supported_m3784909043(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.String System.Reflection.Emit.GenericTypeParameterBuilder::get_Name()
extern "C"  String_t* GenericTypeParameterBuilder_get_Name_m2640162747 (GenericTypeParameterBuilder_t1370236603 * __this, const MethodInfo* method)
{
	{
		String_t* L_0 = __this->get_name_10();
		return L_0;
	}
}
// System.String System.Reflection.Emit.GenericTypeParameterBuilder::get_Namespace()
extern "C"  String_t* GenericTypeParameterBuilder_get_Namespace_m1776615511 (GenericTypeParameterBuilder_t1370236603 * __this, const MethodInfo* method)
{
	{
		return (String_t*)NULL;
	}
}
// System.Reflection.Module System.Reflection.Emit.GenericTypeParameterBuilder::get_Module()
extern "C"  Module_t4282841206 * GenericTypeParameterBuilder_get_Module_m2427847092 (GenericTypeParameterBuilder_t1370236603 * __this, const MethodInfo* method)
{
	{
		TypeBuilder_t3308873219 * L_0 = __this->get_tbuilder_8();
		NullCheck(L_0);
		Module_t4282841206 * L_1 = TypeBuilder_get_Module_m1668298460(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Type System.Reflection.Emit.GenericTypeParameterBuilder::get_DeclaringType()
extern "C"  Type_t * GenericTypeParameterBuilder_get_DeclaringType_m1652924692 (GenericTypeParameterBuilder_t1370236603 * __this, const MethodInfo* method)
{
	Type_t * G_B3_0 = NULL;
	{
		MethodBuilder_t644187984 * L_0 = __this->get_mbuilder_9();
		if (!L_0)
		{
			goto IL_001b;
		}
	}
	{
		MethodBuilder_t644187984 * L_1 = __this->get_mbuilder_9();
		NullCheck(L_1);
		Type_t * L_2 = MethodBuilder_get_DeclaringType_m2734207591(L_1, /*hidden argument*/NULL);
		G_B3_0 = L_2;
		goto IL_0021;
	}

IL_001b:
	{
		TypeBuilder_t3308873219 * L_3 = __this->get_tbuilder_8();
		G_B3_0 = ((Type_t *)(L_3));
	}

IL_0021:
	{
		return G_B3_0;
	}
}
// System.Type System.Reflection.Emit.GenericTypeParameterBuilder::get_ReflectedType()
extern "C"  Type_t * GenericTypeParameterBuilder_get_ReflectedType_m562256091 (GenericTypeParameterBuilder_t1370236603 * __this, const MethodInfo* method)
{
	{
		Type_t * L_0 = GenericTypeParameterBuilder_get_DeclaringType_m1652924692(__this, /*hidden argument*/NULL);
		return L_0;
	}
}
// System.RuntimeTypeHandle System.Reflection.Emit.GenericTypeParameterBuilder::get_TypeHandle()
extern "C"  RuntimeTypeHandle_t2330101084  GenericTypeParameterBuilder_get_TypeHandle_m3293062357 (GenericTypeParameterBuilder_t1370236603 * __this, const MethodInfo* method)
{
	{
		Exception_t1927440687 * L_0 = GenericTypeParameterBuilder_not_supported_m3784909043(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Type[] System.Reflection.Emit.GenericTypeParameterBuilder::GetGenericArguments()
extern Il2CppClass* InvalidOperationException_t721527559_il2cpp_TypeInfo_var;
extern const uint32_t GenericTypeParameterBuilder_GetGenericArguments_m277381309_MetadataUsageId;
extern "C"  TypeU5BU5D_t1664964607* GenericTypeParameterBuilder_GetGenericArguments_m277381309 (GenericTypeParameterBuilder_t1370236603 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (GenericTypeParameterBuilder_GetGenericArguments_m277381309_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		InvalidOperationException_t721527559 * L_0 = (InvalidOperationException_t721527559 *)il2cpp_codegen_object_new(InvalidOperationException_t721527559_il2cpp_TypeInfo_var);
		InvalidOperationException__ctor_m102359810(L_0, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Type System.Reflection.Emit.GenericTypeParameterBuilder::GetGenericTypeDefinition()
extern Il2CppClass* InvalidOperationException_t721527559_il2cpp_TypeInfo_var;
extern const uint32_t GenericTypeParameterBuilder_GetGenericTypeDefinition_m2936287336_MetadataUsageId;
extern "C"  Type_t * GenericTypeParameterBuilder_GetGenericTypeDefinition_m2936287336 (GenericTypeParameterBuilder_t1370236603 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (GenericTypeParameterBuilder_GetGenericTypeDefinition_m2936287336_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		InvalidOperationException_t721527559 * L_0 = (InvalidOperationException_t721527559 *)il2cpp_codegen_object_new(InvalidOperationException_t721527559_il2cpp_TypeInfo_var);
		InvalidOperationException__ctor_m102359810(L_0, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Boolean System.Reflection.Emit.GenericTypeParameterBuilder::get_ContainsGenericParameters()
extern "C"  bool GenericTypeParameterBuilder_get_ContainsGenericParameters_m1449092549 (GenericTypeParameterBuilder_t1370236603 * __this, const MethodInfo* method)
{
	{
		return (bool)1;
	}
}
// System.Boolean System.Reflection.Emit.GenericTypeParameterBuilder::get_IsGenericParameter()
extern "C"  bool GenericTypeParameterBuilder_get_IsGenericParameter_m1565478927 (GenericTypeParameterBuilder_t1370236603 * __this, const MethodInfo* method)
{
	{
		return (bool)1;
	}
}
// System.Boolean System.Reflection.Emit.GenericTypeParameterBuilder::get_IsGenericType()
extern "C"  bool GenericTypeParameterBuilder_get_IsGenericType_m1883522222 (GenericTypeParameterBuilder_t1370236603 * __this, const MethodInfo* method)
{
	{
		return (bool)0;
	}
}
// System.Boolean System.Reflection.Emit.GenericTypeParameterBuilder::get_IsGenericTypeDefinition()
extern "C"  bool GenericTypeParameterBuilder_get_IsGenericTypeDefinition_m2790308279 (GenericTypeParameterBuilder_t1370236603 * __this, const MethodInfo* method)
{
	{
		return (bool)0;
	}
}
// System.Exception System.Reflection.Emit.GenericTypeParameterBuilder::not_supported()
extern Il2CppClass* NotSupportedException_t1793819818_il2cpp_TypeInfo_var;
extern const uint32_t GenericTypeParameterBuilder_not_supported_m3784909043_MetadataUsageId;
extern "C"  Exception_t1927440687 * GenericTypeParameterBuilder_not_supported_m3784909043 (GenericTypeParameterBuilder_t1370236603 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (GenericTypeParameterBuilder_not_supported_m3784909043_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		NotSupportedException_t1793819818 * L_0 = (NotSupportedException_t1793819818 *)il2cpp_codegen_object_new(NotSupportedException_t1793819818_il2cpp_TypeInfo_var);
		NotSupportedException__ctor_m3232764727(L_0, /*hidden argument*/NULL);
		return L_0;
	}
}
// System.String System.Reflection.Emit.GenericTypeParameterBuilder::ToString()
extern "C"  String_t* GenericTypeParameterBuilder_ToString_m4223425511 (GenericTypeParameterBuilder_t1370236603 * __this, const MethodInfo* method)
{
	{
		String_t* L_0 = __this->get_name_10();
		return L_0;
	}
}
// System.Boolean System.Reflection.Emit.GenericTypeParameterBuilder::Equals(System.Object)
extern "C"  bool GenericTypeParameterBuilder_Equals_m2498927509 (GenericTypeParameterBuilder_t1370236603 * __this, Il2CppObject * ___o0, const MethodInfo* method)
{
	{
		Il2CppObject * L_0 = ___o0;
		bool L_1 = Type_Equals_m1272005660(__this, L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Int32 System.Reflection.Emit.GenericTypeParameterBuilder::GetHashCode()
extern "C"  int32_t GenericTypeParameterBuilder_GetHashCode_m867619899 (GenericTypeParameterBuilder_t1370236603 * __this, const MethodInfo* method)
{
	{
		int32_t L_0 = Type_GetHashCode_m1150382148(__this, /*hidden argument*/NULL);
		return L_0;
	}
}
// System.Type System.Reflection.Emit.GenericTypeParameterBuilder::MakeByRefType()
extern Il2CppClass* ByRefType_t1587086384_il2cpp_TypeInfo_var;
extern const uint32_t GenericTypeParameterBuilder_MakeByRefType_m4279657370_MetadataUsageId;
extern "C"  Type_t * GenericTypeParameterBuilder_MakeByRefType_m4279657370 (GenericTypeParameterBuilder_t1370236603 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (GenericTypeParameterBuilder_MakeByRefType_m4279657370_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ByRefType_t1587086384 * L_0 = (ByRefType_t1587086384 *)il2cpp_codegen_object_new(ByRefType_t1587086384_il2cpp_TypeInfo_var);
		ByRefType__ctor_m2068210324(L_0, __this, /*hidden argument*/NULL);
		return L_0;
	}
}
// System.Type System.Reflection.Emit.GenericTypeParameterBuilder::MakeGenericType(System.Type[])
extern "C"  Type_t * GenericTypeParameterBuilder_MakeGenericType_m2955814622 (GenericTypeParameterBuilder_t1370236603 * __this, TypeU5BU5D_t1664964607* ___typeArguments0, const MethodInfo* method)
{
	{
		TypeU5BU5D_t1664964607* L_0 = ___typeArguments0;
		Type_t * L_1 = Type_MakeGenericType_m2765875033(__this, L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Void System.Reflection.Emit.ILGenerator::.ctor(System.Reflection.Module,System.Reflection.Emit.TokenGenerator,System.Int32)
extern Il2CppClass* ByteU5BU5D_t3397334013_il2cpp_TypeInfo_var;
extern Il2CppClass* ILTokenInfoU5BU5D_t4103159791_il2cpp_TypeInfo_var;
extern const uint32_t ILGenerator__ctor_m3365621387_MetadataUsageId;
extern "C"  void ILGenerator__ctor_m3365621387 (ILGenerator_t99948092 * __this, Module_t4282841206 * ___m0, Il2CppObject * ___token_gen1, int32_t ___size2, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ILGenerator__ctor_m3365621387_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		int32_t L_0 = ___size2;
		if ((((int32_t)L_0) >= ((int32_t)0)))
		{
			goto IL_0014;
		}
	}
	{
		___size2 = ((int32_t)128);
	}

IL_0014:
	{
		int32_t L_1 = ___size2;
		__this->set_code_1(((ByteU5BU5D_t3397334013*)SZArrayNew(ByteU5BU5D_t3397334013_il2cpp_TypeInfo_var, (uint32_t)L_1)));
		__this->set_token_fixups_6(((ILTokenInfoU5BU5D_t4103159791*)SZArrayNew(ILTokenInfoU5BU5D_t4103159791_il2cpp_TypeInfo_var, (uint32_t)8)));
		Module_t4282841206 * L_2 = ___m0;
		__this->set_module_10(L_2);
		Il2CppObject * L_3 = ___token_gen1;
		__this->set_token_gen_11(L_3);
		return;
	}
}
// System.Void System.Reflection.Emit.ILGenerator::.cctor()
extern const Il2CppType* Void_t1841601450_0_0_0_var;
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern Il2CppClass* ILGenerator_t99948092_il2cpp_TypeInfo_var;
extern const uint32_t ILGenerator__cctor_m3943061018_MetadataUsageId;
extern "C"  void ILGenerator__cctor_m3943061018 (Il2CppObject * __this /* static, unused */, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ILGenerator__cctor_m3943061018_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_0 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Void_t1841601450_0_0_0_var), /*hidden argument*/NULL);
		((ILGenerator_t99948092_StaticFields*)ILGenerator_t99948092_il2cpp_TypeInfo_var->static_fields)->set_void_type_0(L_0);
		return;
	}
}
// System.Void System.Reflection.Emit.ILGenerator::add_token_fixup(System.Reflection.MemberInfo)
extern Il2CppClass* ILTokenInfoU5BU5D_t4103159791_il2cpp_TypeInfo_var;
extern const uint32_t ILGenerator_add_token_fixup_m3261621911_MetadataUsageId;
extern "C"  void ILGenerator_add_token_fixup_m3261621911 (ILGenerator_t99948092 * __this, MemberInfo_t * ___mi0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ILGenerator_add_token_fixup_m3261621911_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ILTokenInfoU5BU5D_t4103159791* V_0 = NULL;
	int32_t V_1 = 0;
	{
		int32_t L_0 = __this->get_num_token_fixups_5();
		ILTokenInfoU5BU5D_t4103159791* L_1 = __this->get_token_fixups_6();
		NullCheck(L_1);
		if ((!(((uint32_t)L_0) == ((uint32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_1)->max_length))))))))
		{
			goto IL_0035;
		}
	}
	{
		int32_t L_2 = __this->get_num_token_fixups_5();
		V_0 = ((ILTokenInfoU5BU5D_t4103159791*)SZArrayNew(ILTokenInfoU5BU5D_t4103159791_il2cpp_TypeInfo_var, (uint32_t)((int32_t)((int32_t)L_2*(int32_t)2))));
		ILTokenInfoU5BU5D_t4103159791* L_3 = __this->get_token_fixups_6();
		ILTokenInfoU5BU5D_t4103159791* L_4 = V_0;
		NullCheck((Il2CppArray *)(Il2CppArray *)L_3);
		Array_CopyTo_m4061033315((Il2CppArray *)(Il2CppArray *)L_3, (Il2CppArray *)(Il2CppArray *)L_4, 0, /*hidden argument*/NULL);
		ILTokenInfoU5BU5D_t4103159791* L_5 = V_0;
		__this->set_token_fixups_6(L_5);
	}

IL_0035:
	{
		ILTokenInfoU5BU5D_t4103159791* L_6 = __this->get_token_fixups_6();
		int32_t L_7 = __this->get_num_token_fixups_5();
		NullCheck(L_6);
		MemberInfo_t * L_8 = ___mi0;
		((L_6)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_7)))->set_member_0(L_8);
		ILTokenInfoU5BU5D_t4103159791* L_9 = __this->get_token_fixups_6();
		int32_t L_10 = __this->get_num_token_fixups_5();
		int32_t L_11 = L_10;
		V_1 = L_11;
		__this->set_num_token_fixups_5(((int32_t)((int32_t)L_11+(int32_t)1)));
		int32_t L_12 = V_1;
		NullCheck(L_9);
		int32_t L_13 = __this->get_code_len_2();
		((L_9)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_12)))->set_code_pos_1(L_13);
		return;
	}
}
// System.Void System.Reflection.Emit.ILGenerator::make_room(System.Int32)
extern Il2CppClass* ByteU5BU5D_t3397334013_il2cpp_TypeInfo_var;
extern const uint32_t ILGenerator_make_room_m373147874_MetadataUsageId;
extern "C"  void ILGenerator_make_room_m373147874 (ILGenerator_t99948092 * __this, int32_t ___nbytes0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ILGenerator_make_room_m373147874_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ByteU5BU5D_t3397334013* V_0 = NULL;
	{
		int32_t L_0 = __this->get_code_len_2();
		int32_t L_1 = ___nbytes0;
		ByteU5BU5D_t3397334013* L_2 = __this->get_code_1();
		NullCheck(L_2);
		if ((((int32_t)((int32_t)((int32_t)L_0+(int32_t)L_1))) >= ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_2)->max_length)))))))
		{
			goto IL_0016;
		}
	}
	{
		return;
	}

IL_0016:
	{
		int32_t L_3 = __this->get_code_len_2();
		int32_t L_4 = ___nbytes0;
		V_0 = ((ByteU5BU5D_t3397334013*)SZArrayNew(ByteU5BU5D_t3397334013_il2cpp_TypeInfo_var, (uint32_t)((int32_t)((int32_t)((int32_t)((int32_t)((int32_t)((int32_t)L_3+(int32_t)L_4))*(int32_t)2))+(int32_t)((int32_t)128)))));
		ByteU5BU5D_t3397334013* L_5 = __this->get_code_1();
		ByteU5BU5D_t3397334013* L_6 = V_0;
		ByteU5BU5D_t3397334013* L_7 = __this->get_code_1();
		NullCheck(L_7);
		Array_Copy_m3808317496(NULL /*static, unused*/, (Il2CppArray *)(Il2CppArray *)L_5, 0, (Il2CppArray *)(Il2CppArray *)L_6, 0, (((int32_t)((int32_t)(((Il2CppArray *)L_7)->max_length)))), /*hidden argument*/NULL);
		ByteU5BU5D_t3397334013* L_8 = V_0;
		__this->set_code_1(L_8);
		return;
	}
}
// System.Void System.Reflection.Emit.ILGenerator::emit_int(System.Int32)
extern "C"  void ILGenerator_emit_int_m1061022647 (ILGenerator_t99948092 * __this, int32_t ___val0, const MethodInfo* method)
{
	int32_t V_0 = 0;
	{
		ByteU5BU5D_t3397334013* L_0 = __this->get_code_1();
		int32_t L_1 = __this->get_code_len_2();
		int32_t L_2 = L_1;
		V_0 = L_2;
		__this->set_code_len_2(((int32_t)((int32_t)L_2+(int32_t)1)));
		int32_t L_3 = V_0;
		int32_t L_4 = ___val0;
		NullCheck(L_0);
		(L_0)->SetAt(static_cast<il2cpp_array_size_t>(L_3), (uint8_t)(((int32_t)((uint8_t)((int32_t)((int32_t)L_4&(int32_t)((int32_t)255)))))));
		ByteU5BU5D_t3397334013* L_5 = __this->get_code_1();
		int32_t L_6 = __this->get_code_len_2();
		int32_t L_7 = L_6;
		V_0 = L_7;
		__this->set_code_len_2(((int32_t)((int32_t)L_7+(int32_t)1)));
		int32_t L_8 = V_0;
		int32_t L_9 = ___val0;
		NullCheck(L_5);
		(L_5)->SetAt(static_cast<il2cpp_array_size_t>(L_8), (uint8_t)(((int32_t)((uint8_t)((int32_t)((int32_t)((int32_t)((int32_t)L_9>>(int32_t)8))&(int32_t)((int32_t)255)))))));
		ByteU5BU5D_t3397334013* L_10 = __this->get_code_1();
		int32_t L_11 = __this->get_code_len_2();
		int32_t L_12 = L_11;
		V_0 = L_12;
		__this->set_code_len_2(((int32_t)((int32_t)L_12+(int32_t)1)));
		int32_t L_13 = V_0;
		int32_t L_14 = ___val0;
		NullCheck(L_10);
		(L_10)->SetAt(static_cast<il2cpp_array_size_t>(L_13), (uint8_t)(((int32_t)((uint8_t)((int32_t)((int32_t)((int32_t)((int32_t)L_14>>(int32_t)((int32_t)16)))&(int32_t)((int32_t)255)))))));
		ByteU5BU5D_t3397334013* L_15 = __this->get_code_1();
		int32_t L_16 = __this->get_code_len_2();
		int32_t L_17 = L_16;
		V_0 = L_17;
		__this->set_code_len_2(((int32_t)((int32_t)L_17+(int32_t)1)));
		int32_t L_18 = V_0;
		int32_t L_19 = ___val0;
		NullCheck(L_15);
		(L_15)->SetAt(static_cast<il2cpp_array_size_t>(L_18), (uint8_t)(((int32_t)((uint8_t)((int32_t)((int32_t)((int32_t)((int32_t)L_19>>(int32_t)((int32_t)24)))&(int32_t)((int32_t)255)))))));
		return;
	}
}
// System.Void System.Reflection.Emit.ILGenerator::ll_emit(System.Reflection.Emit.OpCode)
extern "C"  void ILGenerator_ll_emit_m2087647272 (ILGenerator_t99948092 * __this, OpCode_t2247480392  ___opcode0, const MethodInfo* method)
{
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	{
		int32_t L_0 = OpCode_get_Size_m481593949((&___opcode0), /*hidden argument*/NULL);
		if ((!(((uint32_t)L_0) == ((uint32_t)2))))
		{
			goto IL_002c;
		}
	}
	{
		ByteU5BU5D_t3397334013* L_1 = __this->get_code_1();
		int32_t L_2 = __this->get_code_len_2();
		int32_t L_3 = L_2;
		V_0 = L_3;
		__this->set_code_len_2(((int32_t)((int32_t)L_3+(int32_t)1)));
		int32_t L_4 = V_0;
		uint8_t L_5 = (&___opcode0)->get_op1_0();
		NullCheck(L_1);
		(L_1)->SetAt(static_cast<il2cpp_array_size_t>(L_4), (uint8_t)L_5);
	}

IL_002c:
	{
		ByteU5BU5D_t3397334013* L_6 = __this->get_code_1();
		int32_t L_7 = __this->get_code_len_2();
		int32_t L_8 = L_7;
		V_0 = L_8;
		__this->set_code_len_2(((int32_t)((int32_t)L_8+(int32_t)1)));
		int32_t L_9 = V_0;
		uint8_t L_10 = (&___opcode0)->get_op2_1();
		NullCheck(L_6);
		(L_6)->SetAt(static_cast<il2cpp_array_size_t>(L_9), (uint8_t)L_10);
		int32_t L_11 = OpCode_get_StackBehaviourPush_m1922356444((&___opcode0), /*hidden argument*/NULL);
		V_1 = L_11;
		int32_t L_12 = V_1;
		if (((int32_t)((int32_t)L_12-(int32_t)((int32_t)19))) == 0)
		{
			goto IL_0085;
		}
		if (((int32_t)((int32_t)L_12-(int32_t)((int32_t)19))) == 1)
		{
			goto IL_0098;
		}
		if (((int32_t)((int32_t)L_12-(int32_t)((int32_t)19))) == 2)
		{
			goto IL_0085;
		}
		if (((int32_t)((int32_t)L_12-(int32_t)((int32_t)19))) == 3)
		{
			goto IL_0085;
		}
		if (((int32_t)((int32_t)L_12-(int32_t)((int32_t)19))) == 4)
		{
			goto IL_0085;
		}
		if (((int32_t)((int32_t)L_12-(int32_t)((int32_t)19))) == 5)
		{
			goto IL_0085;
		}
		if (((int32_t)((int32_t)L_12-(int32_t)((int32_t)19))) == 6)
		{
			goto IL_0085;
		}
		if (((int32_t)((int32_t)L_12-(int32_t)((int32_t)19))) == 7)
		{
			goto IL_00ab;
		}
		if (((int32_t)((int32_t)L_12-(int32_t)((int32_t)19))) == 8)
		{
			goto IL_0085;
		}
	}
	{
		goto IL_00ab;
	}

IL_0085:
	{
		int32_t L_13 = __this->get_cur_stack_4();
		__this->set_cur_stack_4(((int32_t)((int32_t)L_13+(int32_t)1)));
		goto IL_00ab;
	}

IL_0098:
	{
		int32_t L_14 = __this->get_cur_stack_4();
		__this->set_cur_stack_4(((int32_t)((int32_t)L_14+(int32_t)2)));
		goto IL_00ab;
	}

IL_00ab:
	{
		int32_t L_15 = __this->get_max_stack_3();
		int32_t L_16 = __this->get_cur_stack_4();
		if ((((int32_t)L_15) >= ((int32_t)L_16)))
		{
			goto IL_00c8;
		}
	}
	{
		int32_t L_17 = __this->get_cur_stack_4();
		__this->set_max_stack_3(L_17);
	}

IL_00c8:
	{
		int32_t L_18 = OpCode_get_StackBehaviourPop_m3787015663((&___opcode0), /*hidden argument*/NULL);
		V_1 = L_18;
		int32_t L_19 = V_1;
		if (((int32_t)((int32_t)L_19-(int32_t)1)) == 0)
		{
			goto IL_014a;
		}
		if (((int32_t)((int32_t)L_19-(int32_t)1)) == 1)
		{
			goto IL_015d;
		}
		if (((int32_t)((int32_t)L_19-(int32_t)1)) == 2)
		{
			goto IL_014a;
		}
		if (((int32_t)((int32_t)L_19-(int32_t)1)) == 3)
		{
			goto IL_015d;
		}
		if (((int32_t)((int32_t)L_19-(int32_t)1)) == 4)
		{
			goto IL_015d;
		}
		if (((int32_t)((int32_t)L_19-(int32_t)1)) == 5)
		{
			goto IL_015d;
		}
		if (((int32_t)((int32_t)L_19-(int32_t)1)) == 6)
		{
			goto IL_0170;
		}
		if (((int32_t)((int32_t)L_19-(int32_t)1)) == 7)
		{
			goto IL_015d;
		}
		if (((int32_t)((int32_t)L_19-(int32_t)1)) == 8)
		{
			goto IL_015d;
		}
		if (((int32_t)((int32_t)L_19-(int32_t)1)) == 9)
		{
			goto IL_014a;
		}
		if (((int32_t)((int32_t)L_19-(int32_t)1)) == 10)
		{
			goto IL_015d;
		}
		if (((int32_t)((int32_t)L_19-(int32_t)1)) == 11)
		{
			goto IL_015d;
		}
		if (((int32_t)((int32_t)L_19-(int32_t)1)) == 12)
		{
			goto IL_0170;
		}
		if (((int32_t)((int32_t)L_19-(int32_t)1)) == 13)
		{
			goto IL_0170;
		}
		if (((int32_t)((int32_t)L_19-(int32_t)1)) == 14)
		{
			goto IL_0170;
		}
		if (((int32_t)((int32_t)L_19-(int32_t)1)) == 15)
		{
			goto IL_0170;
		}
		if (((int32_t)((int32_t)L_19-(int32_t)1)) == 16)
		{
			goto IL_0170;
		}
		if (((int32_t)((int32_t)L_19-(int32_t)1)) == 17)
		{
			goto IL_0183;
		}
		if (((int32_t)((int32_t)L_19-(int32_t)1)) == 18)
		{
			goto IL_0183;
		}
		if (((int32_t)((int32_t)L_19-(int32_t)1)) == 19)
		{
			goto IL_0183;
		}
		if (((int32_t)((int32_t)L_19-(int32_t)1)) == 20)
		{
			goto IL_0183;
		}
		if (((int32_t)((int32_t)L_19-(int32_t)1)) == 21)
		{
			goto IL_0183;
		}
		if (((int32_t)((int32_t)L_19-(int32_t)1)) == 22)
		{
			goto IL_0183;
		}
		if (((int32_t)((int32_t)L_19-(int32_t)1)) == 23)
		{
			goto IL_0183;
		}
		if (((int32_t)((int32_t)L_19-(int32_t)1)) == 24)
		{
			goto IL_0183;
		}
		if (((int32_t)((int32_t)L_19-(int32_t)1)) == 25)
		{
			goto IL_0145;
		}
	}
	{
		goto IL_0183;
	}

IL_0145:
	{
		goto IL_0183;
	}

IL_014a:
	{
		int32_t L_20 = __this->get_cur_stack_4();
		__this->set_cur_stack_4(((int32_t)((int32_t)L_20-(int32_t)1)));
		goto IL_0183;
	}

IL_015d:
	{
		int32_t L_21 = __this->get_cur_stack_4();
		__this->set_cur_stack_4(((int32_t)((int32_t)L_21-(int32_t)2)));
		goto IL_0183;
	}

IL_0170:
	{
		int32_t L_22 = __this->get_cur_stack_4();
		__this->set_cur_stack_4(((int32_t)((int32_t)L_22-(int32_t)3)));
		goto IL_0183;
	}

IL_0183:
	{
		return;
	}
}
// System.Void System.Reflection.Emit.ILGenerator::Emit(System.Reflection.Emit.OpCode)
extern "C"  void ILGenerator_Emit_m531109645 (ILGenerator_t99948092 * __this, OpCode_t2247480392  ___opcode0, const MethodInfo* method)
{
	{
		ILGenerator_make_room_m373147874(__this, 2, /*hidden argument*/NULL);
		OpCode_t2247480392  L_0 = ___opcode0;
		ILGenerator_ll_emit_m2087647272(__this, L_0, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Reflection.Emit.ILGenerator::Emit(System.Reflection.Emit.OpCode,System.Reflection.ConstructorInfo)
extern Il2CppClass* TokenGenerator_t4150817334_il2cpp_TypeInfo_var;
extern const uint32_t ILGenerator_Emit_m116557729_MetadataUsageId;
extern "C"  void ILGenerator_Emit_m116557729 (ILGenerator_t99948092 * __this, OpCode_t2247480392  ___opcode0, ConstructorInfo_t2851816542 * ___con1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ILGenerator_Emit_m116557729_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	{
		Il2CppObject * L_0 = __this->get_token_gen_11();
		ConstructorInfo_t2851816542 * L_1 = ___con1;
		NullCheck(L_0);
		int32_t L_2 = InterfaceFuncInvoker1< int32_t, MemberInfo_t * >::Invoke(0 /* System.Int32 System.Reflection.Emit.TokenGenerator::GetToken(System.Reflection.MemberInfo) */, TokenGenerator_t4150817334_il2cpp_TypeInfo_var, L_0, L_1);
		V_0 = L_2;
		ILGenerator_make_room_m373147874(__this, 6, /*hidden argument*/NULL);
		OpCode_t2247480392  L_3 = ___opcode0;
		ILGenerator_ll_emit_m2087647272(__this, L_3, /*hidden argument*/NULL);
		ConstructorInfo_t2851816542 * L_4 = ___con1;
		NullCheck(L_4);
		Type_t * L_5 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.MemberInfo::get_DeclaringType() */, L_4);
		NullCheck(L_5);
		Module_t4282841206 * L_6 = VirtFuncInvoker0< Module_t4282841206 * >::Invoke(10 /* System.Reflection.Module System.Type::get_Module() */, L_5);
		Module_t4282841206 * L_7 = __this->get_module_10();
		if ((!(((Il2CppObject*)(Module_t4282841206 *)L_6) == ((Il2CppObject*)(Module_t4282841206 *)L_7))))
		{
			goto IL_0038;
		}
	}
	{
		ConstructorInfo_t2851816542 * L_8 = ___con1;
		ILGenerator_add_token_fixup_m3261621911(__this, L_8, /*hidden argument*/NULL);
	}

IL_0038:
	{
		int32_t L_9 = V_0;
		ILGenerator_emit_int_m1061022647(__this, L_9, /*hidden argument*/NULL);
		int32_t L_10 = OpCode_get_StackBehaviourPop_m3787015663((&___opcode0), /*hidden argument*/NULL);
		if ((!(((uint32_t)L_10) == ((uint32_t)((int32_t)26)))))
		{
			goto IL_0060;
		}
	}
	{
		int32_t L_11 = __this->get_cur_stack_4();
		ConstructorInfo_t2851816542 * L_12 = ___con1;
		NullCheck(L_12);
		int32_t L_13 = VirtFuncInvoker0< int32_t >::Invoke(15 /* System.Int32 System.Reflection.MethodBase::GetParameterCount() */, L_12);
		__this->set_cur_stack_4(((int32_t)((int32_t)L_11-(int32_t)L_13)));
	}

IL_0060:
	{
		return;
	}
}
// System.Void System.Reflection.Emit.ILGenerator::label_fixup()
extern Il2CppClass* ArgumentException_t3259014390_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral2950669223;
extern const uint32_t ILGenerator_label_fixup_m1325994348_MetadataUsageId;
extern "C"  void ILGenerator_label_fixup_m1325994348 (ILGenerator_t99948092 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ILGenerator_label_fixup_m1325994348_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	{
		V_0 = 0;
		goto IL_00e6;
	}

IL_0007:
	{
		LabelDataU5BU5D_t4181946617* L_0 = __this->get_labels_7();
		LabelFixupU5BU5D_t2807174223* L_1 = __this->get_fixups_8();
		int32_t L_2 = V_0;
		NullCheck(L_1);
		int32_t L_3 = ((L_1)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2)))->get_label_idx_2();
		NullCheck(L_0);
		int32_t L_4 = ((L_0)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3)))->get_addr_0();
		if ((((int32_t)L_4) >= ((int32_t)0)))
		{
			goto IL_0039;
		}
	}
	{
		ArgumentException_t3259014390 * L_5 = (ArgumentException_t3259014390 *)il2cpp_codegen_object_new(ArgumentException_t3259014390_il2cpp_TypeInfo_var);
		ArgumentException__ctor_m3739475201(L_5, _stringLiteral2950669223, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_5);
	}

IL_0039:
	{
		LabelDataU5BU5D_t4181946617* L_6 = __this->get_labels_7();
		LabelFixupU5BU5D_t2807174223* L_7 = __this->get_fixups_8();
		int32_t L_8 = V_0;
		NullCheck(L_7);
		int32_t L_9 = ((L_7)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_8)))->get_label_idx_2();
		NullCheck(L_6);
		int32_t L_10 = ((L_6)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_9)))->get_addr_0();
		LabelFixupU5BU5D_t2807174223* L_11 = __this->get_fixups_8();
		int32_t L_12 = V_0;
		NullCheck(L_11);
		int32_t L_13 = ((L_11)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_12)))->get_pos_1();
		LabelFixupU5BU5D_t2807174223* L_14 = __this->get_fixups_8();
		int32_t L_15 = V_0;
		NullCheck(L_14);
		int32_t L_16 = ((L_14)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_15)))->get_offset_0();
		V_1 = ((int32_t)((int32_t)L_10-(int32_t)((int32_t)((int32_t)L_13+(int32_t)L_16))));
		LabelFixupU5BU5D_t2807174223* L_17 = __this->get_fixups_8();
		int32_t L_18 = V_0;
		NullCheck(L_17);
		int32_t L_19 = ((L_17)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_18)))->get_offset_0();
		if ((!(((uint32_t)L_19) == ((uint32_t)1))))
		{
			goto IL_00b6;
		}
	}
	{
		ByteU5BU5D_t3397334013* L_20 = __this->get_code_1();
		LabelFixupU5BU5D_t2807174223* L_21 = __this->get_fixups_8();
		int32_t L_22 = V_0;
		NullCheck(L_21);
		int32_t L_23 = ((L_21)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_22)))->get_pos_1();
		int32_t L_24 = V_1;
		NullCheck(L_20);
		(L_20)->SetAt(static_cast<il2cpp_array_size_t>(L_23), (uint8_t)(((int32_t)((uint8_t)(((int8_t)((int8_t)L_24)))))));
		goto IL_00e2;
	}

IL_00b6:
	{
		int32_t L_25 = __this->get_code_len_2();
		V_2 = L_25;
		LabelFixupU5BU5D_t2807174223* L_26 = __this->get_fixups_8();
		int32_t L_27 = V_0;
		NullCheck(L_26);
		int32_t L_28 = ((L_26)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_27)))->get_pos_1();
		__this->set_code_len_2(L_28);
		int32_t L_29 = V_1;
		ILGenerator_emit_int_m1061022647(__this, L_29, /*hidden argument*/NULL);
		int32_t L_30 = V_2;
		__this->set_code_len_2(L_30);
	}

IL_00e2:
	{
		int32_t L_31 = V_0;
		V_0 = ((int32_t)((int32_t)L_31+(int32_t)1));
	}

IL_00e6:
	{
		int32_t L_32 = V_0;
		int32_t L_33 = __this->get_num_fixups_9();
		if ((((int32_t)L_32) < ((int32_t)L_33)))
		{
			goto IL_0007;
		}
	}
	{
		return;
	}
}
// System.Int32 System.Reflection.Emit.ILGenerator::Mono_GetCurrentOffset(System.Reflection.Emit.ILGenerator)
extern "C"  int32_t ILGenerator_Mono_GetCurrentOffset_m3553856682 (Il2CppObject * __this /* static, unused */, ILGenerator_t99948092 * ___ig0, const MethodInfo* method)
{
	{
		ILGenerator_t99948092 * L_0 = ___ig0;
		NullCheck(L_0);
		int32_t L_1 = L_0->get_code_len_2();
		return L_1;
	}
}
// Conversion methods for marshalling of: System.Reflection.Emit.ILTokenInfo
extern "C" void ILTokenInfo_t149559338_marshal_pinvoke(const ILTokenInfo_t149559338& unmarshaled, ILTokenInfo_t149559338_marshaled_pinvoke& marshaled)
{
	Il2CppCodeGenException* ___member_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'member' of type 'ILTokenInfo': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___member_0Exception);
}
extern "C" void ILTokenInfo_t149559338_marshal_pinvoke_back(const ILTokenInfo_t149559338_marshaled_pinvoke& marshaled, ILTokenInfo_t149559338& unmarshaled)
{
	Il2CppCodeGenException* ___member_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'member' of type 'ILTokenInfo': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___member_0Exception);
}
// Conversion method for clean up from marshalling of: System.Reflection.Emit.ILTokenInfo
extern "C" void ILTokenInfo_t149559338_marshal_pinvoke_cleanup(ILTokenInfo_t149559338_marshaled_pinvoke& marshaled)
{
}
// Conversion methods for marshalling of: System.Reflection.Emit.ILTokenInfo
extern "C" void ILTokenInfo_t149559338_marshal_com(const ILTokenInfo_t149559338& unmarshaled, ILTokenInfo_t149559338_marshaled_com& marshaled)
{
	Il2CppCodeGenException* ___member_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'member' of type 'ILTokenInfo': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___member_0Exception);
}
extern "C" void ILTokenInfo_t149559338_marshal_com_back(const ILTokenInfo_t149559338_marshaled_com& marshaled, ILTokenInfo_t149559338& unmarshaled)
{
	Il2CppCodeGenException* ___member_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'member' of type 'ILTokenInfo': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___member_0Exception);
}
// Conversion method for clean up from marshalling of: System.Reflection.Emit.ILTokenInfo
extern "C" void ILTokenInfo_t149559338_marshal_com_cleanup(ILTokenInfo_t149559338_marshaled_com& marshaled)
{
}
// System.Boolean System.Reflection.Emit.MethodBuilder::get_ContainsGenericParameters()
extern Il2CppClass* NotSupportedException_t1793819818_il2cpp_TypeInfo_var;
extern const uint32_t MethodBuilder_get_ContainsGenericParameters_m138212064_MetadataUsageId;
extern "C"  bool MethodBuilder_get_ContainsGenericParameters_m138212064 (MethodBuilder_t644187984 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MethodBuilder_get_ContainsGenericParameters_m138212064_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		NotSupportedException_t1793819818 * L_0 = (NotSupportedException_t1793819818 *)il2cpp_codegen_object_new(NotSupportedException_t1793819818_il2cpp_TypeInfo_var);
		NotSupportedException__ctor_m3232764727(L_0, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.RuntimeMethodHandle System.Reflection.Emit.MethodBuilder::get_MethodHandle()
extern "C"  RuntimeMethodHandle_t894824333  MethodBuilder_get_MethodHandle_m3494271250 (MethodBuilder_t644187984 * __this, const MethodInfo* method)
{
	{
		Exception_t1927440687 * L_0 = MethodBuilder_NotSupported_m1885110731(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Type System.Reflection.Emit.MethodBuilder::get_ReturnType()
extern "C"  Type_t * MethodBuilder_get_ReturnType_m446668188 (MethodBuilder_t644187984 * __this, const MethodInfo* method)
{
	{
		Type_t * L_0 = __this->get_rtype_0();
		return L_0;
	}
}
// System.Type System.Reflection.Emit.MethodBuilder::get_ReflectedType()
extern "C"  Type_t * MethodBuilder_get_ReflectedType_m1320609136 (MethodBuilder_t644187984 * __this, const MethodInfo* method)
{
	{
		TypeBuilder_t3308873219 * L_0 = __this->get_type_7();
		return L_0;
	}
}
// System.Type System.Reflection.Emit.MethodBuilder::get_DeclaringType()
extern "C"  Type_t * MethodBuilder_get_DeclaringType_m2734207591 (MethodBuilder_t644187984 * __this, const MethodInfo* method)
{
	{
		TypeBuilder_t3308873219 * L_0 = __this->get_type_7();
		return L_0;
	}
}
// System.String System.Reflection.Emit.MethodBuilder::get_Name()
extern "C"  String_t* MethodBuilder_get_Name_m845253610 (MethodBuilder_t644187984 * __this, const MethodInfo* method)
{
	{
		String_t* L_0 = __this->get_name_4();
		return L_0;
	}
}
// System.Reflection.MethodAttributes System.Reflection.Emit.MethodBuilder::get_Attributes()
extern "C"  int32_t MethodBuilder_get_Attributes_m3678061338 (MethodBuilder_t644187984 * __this, const MethodInfo* method)
{
	{
		int32_t L_0 = __this->get_attrs_2();
		return L_0;
	}
}
// System.Reflection.CallingConventions System.Reflection.Emit.MethodBuilder::get_CallingConvention()
extern "C"  int32_t MethodBuilder_get_CallingConvention_m3885044904 (MethodBuilder_t644187984 * __this, const MethodInfo* method)
{
	{
		int32_t L_0 = __this->get_call_conv_10();
		return L_0;
	}
}
// System.Reflection.MethodInfo System.Reflection.Emit.MethodBuilder::GetBaseDefinition()
extern "C"  MethodInfo_t * MethodBuilder_GetBaseDefinition_m774166361 (MethodBuilder_t644187984 * __this, const MethodInfo* method)
{
	{
		return __this;
	}
}
// System.Reflection.ParameterInfo[] System.Reflection.Emit.MethodBuilder::GetParameters()
extern Il2CppClass* ParameterInfoU5BU5D_t2275869610_il2cpp_TypeInfo_var;
extern Il2CppClass* ParameterInfo_t2249040075_il2cpp_TypeInfo_var;
extern const uint32_t MethodBuilder_GetParameters_m3436317083_MetadataUsageId;
extern "C"  ParameterInfoU5BU5D_t2275869610* MethodBuilder_GetParameters_m3436317083 (MethodBuilder_t644187984 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MethodBuilder_GetParameters_m3436317083_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ParameterInfoU5BU5D_t2275869610* V_0 = NULL;
	int32_t V_1 = 0;
	int32_t G_B7_0 = 0;
	ParameterInfoU5BU5D_t2275869610* G_B7_1 = NULL;
	int32_t G_B6_0 = 0;
	ParameterInfoU5BU5D_t2275869610* G_B6_1 = NULL;
	ParameterBuilder_t3344728474 * G_B8_0 = NULL;
	int32_t G_B8_1 = 0;
	ParameterInfoU5BU5D_t2275869610* G_B8_2 = NULL;
	{
		TypeBuilder_t3308873219 * L_0 = __this->get_type_7();
		NullCheck(L_0);
		bool L_1 = TypeBuilder_get_is_created_m736553860(L_0, /*hidden argument*/NULL);
		if (L_1)
		{
			goto IL_0017;
		}
	}
	{
		Exception_t1927440687 * L_2 = MethodBuilder_NotSupported_m1885110731(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_2);
	}

IL_0017:
	{
		TypeU5BU5D_t1664964607* L_3 = __this->get_parameters_1();
		if (L_3)
		{
			goto IL_0024;
		}
	}
	{
		return (ParameterInfoU5BU5D_t2275869610*)NULL;
	}

IL_0024:
	{
		TypeU5BU5D_t1664964607* L_4 = __this->get_parameters_1();
		NullCheck(L_4);
		V_0 = ((ParameterInfoU5BU5D_t2275869610*)SZArrayNew(ParameterInfoU5BU5D_t2275869610_il2cpp_TypeInfo_var, (uint32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_4)->max_length))))));
		V_1 = 0;
		goto IL_006c;
	}

IL_0039:
	{
		ParameterInfoU5BU5D_t2275869610* L_5 = V_0;
		int32_t L_6 = V_1;
		ParameterBuilderU5BU5D_t2122994367* L_7 = __this->get_pinfo_8();
		G_B6_0 = L_6;
		G_B6_1 = L_5;
		if (L_7)
		{
			G_B7_0 = L_6;
			G_B7_1 = L_5;
			goto IL_004c;
		}
	}
	{
		G_B8_0 = ((ParameterBuilder_t3344728474 *)(NULL));
		G_B8_1 = G_B6_0;
		G_B8_2 = G_B6_1;
		goto IL_0056;
	}

IL_004c:
	{
		ParameterBuilderU5BU5D_t2122994367* L_8 = __this->get_pinfo_8();
		int32_t L_9 = V_1;
		NullCheck(L_8);
		int32_t L_10 = ((int32_t)((int32_t)L_9+(int32_t)1));
		ParameterBuilder_t3344728474 * L_11 = (L_8)->GetAt(static_cast<il2cpp_array_size_t>(L_10));
		G_B8_0 = L_11;
		G_B8_1 = G_B7_0;
		G_B8_2 = G_B7_1;
	}

IL_0056:
	{
		TypeU5BU5D_t1664964607* L_12 = __this->get_parameters_1();
		int32_t L_13 = V_1;
		NullCheck(L_12);
		int32_t L_14 = L_13;
		Type_t * L_15 = (L_12)->GetAt(static_cast<il2cpp_array_size_t>(L_14));
		int32_t L_16 = V_1;
		ParameterInfo_t2249040075 * L_17 = (ParameterInfo_t2249040075 *)il2cpp_codegen_object_new(ParameterInfo_t2249040075_il2cpp_TypeInfo_var);
		ParameterInfo__ctor_m2149157062(L_17, G_B8_0, L_15, __this, ((int32_t)((int32_t)L_16+(int32_t)1)), /*hidden argument*/NULL);
		NullCheck(G_B8_2);
		ArrayElementTypeCheck (G_B8_2, L_17);
		(G_B8_2)->SetAt(static_cast<il2cpp_array_size_t>(G_B8_1), (ParameterInfo_t2249040075 *)L_17);
		int32_t L_18 = V_1;
		V_1 = ((int32_t)((int32_t)L_18+(int32_t)1));
	}

IL_006c:
	{
		int32_t L_19 = V_1;
		TypeU5BU5D_t1664964607* L_20 = __this->get_parameters_1();
		NullCheck(L_20);
		if ((((int32_t)L_19) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_20)->max_length)))))))
		{
			goto IL_0039;
		}
	}
	{
		ParameterInfoU5BU5D_t2275869610* L_21 = V_0;
		return L_21;
	}
}
// System.Int32 System.Reflection.Emit.MethodBuilder::GetParameterCount()
extern "C"  int32_t MethodBuilder_GetParameterCount_m467267889 (MethodBuilder_t644187984 * __this, const MethodInfo* method)
{
	{
		TypeU5BU5D_t1664964607* L_0 = __this->get_parameters_1();
		if (L_0)
		{
			goto IL_000d;
		}
	}
	{
		return 0;
	}

IL_000d:
	{
		TypeU5BU5D_t1664964607* L_1 = __this->get_parameters_1();
		NullCheck(L_1);
		return (((int32_t)((int32_t)(((Il2CppArray *)L_1)->max_length))));
	}
}
// System.Object System.Reflection.Emit.MethodBuilder::Invoke(System.Object,System.Reflection.BindingFlags,System.Reflection.Binder,System.Object[],System.Globalization.CultureInfo)
extern "C"  Il2CppObject * MethodBuilder_Invoke_m1874904900 (MethodBuilder_t644187984 * __this, Il2CppObject * ___obj0, int32_t ___invokeAttr1, Binder_t3404612058 * ___binder2, ObjectU5BU5D_t3614634134* ___parameters3, CultureInfo_t3500843524 * ___culture4, const MethodInfo* method)
{
	{
		Exception_t1927440687 * L_0 = MethodBuilder_NotSupported_m1885110731(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Boolean System.Reflection.Emit.MethodBuilder::IsDefined(System.Type,System.Boolean)
extern "C"  bool MethodBuilder_IsDefined_m723964180 (MethodBuilder_t644187984 * __this, Type_t * ___attributeType0, bool ___inherit1, const MethodInfo* method)
{
	{
		Exception_t1927440687 * L_0 = MethodBuilder_NotSupported_m1885110731(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Object[] System.Reflection.Emit.MethodBuilder::GetCustomAttributes(System.Boolean)
extern Il2CppClass* MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var;
extern const uint32_t MethodBuilder_GetCustomAttributes_m923430117_MetadataUsageId;
extern "C"  ObjectU5BU5D_t3614634134* MethodBuilder_GetCustomAttributes_m923430117 (MethodBuilder_t644187984 * __this, bool ___inherit0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MethodBuilder_GetCustomAttributes_m923430117_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		TypeBuilder_t3308873219 * L_0 = __this->get_type_7();
		NullCheck(L_0);
		bool L_1 = TypeBuilder_get_is_created_m736553860(L_0, /*hidden argument*/NULL);
		if (!L_1)
		{
			goto IL_0018;
		}
	}
	{
		bool L_2 = ___inherit0;
		IL2CPP_RUNTIME_CLASS_INIT(MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var);
		ObjectU5BU5D_t3614634134* L_3 = MonoCustomAttrs_GetCustomAttributes_m3069779582(NULL /*static, unused*/, __this, L_2, /*hidden argument*/NULL);
		return L_3;
	}

IL_0018:
	{
		Exception_t1927440687 * L_4 = MethodBuilder_NotSupported_m1885110731(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_4);
	}
}
// System.Object[] System.Reflection.Emit.MethodBuilder::GetCustomAttributes(System.Type,System.Boolean)
extern Il2CppClass* MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var;
extern const uint32_t MethodBuilder_GetCustomAttributes_m454145582_MetadataUsageId;
extern "C"  ObjectU5BU5D_t3614634134* MethodBuilder_GetCustomAttributes_m454145582 (MethodBuilder_t644187984 * __this, Type_t * ___attributeType0, bool ___inherit1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MethodBuilder_GetCustomAttributes_m454145582_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		TypeBuilder_t3308873219 * L_0 = __this->get_type_7();
		NullCheck(L_0);
		bool L_1 = TypeBuilder_get_is_created_m736553860(L_0, /*hidden argument*/NULL);
		if (!L_1)
		{
			goto IL_0019;
		}
	}
	{
		Type_t * L_2 = ___attributeType0;
		bool L_3 = ___inherit1;
		IL2CPP_RUNTIME_CLASS_INIT(MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var);
		ObjectU5BU5D_t3614634134* L_4 = MonoCustomAttrs_GetCustomAttributes_m939426263(NULL /*static, unused*/, __this, L_2, L_3, /*hidden argument*/NULL);
		return L_4;
	}

IL_0019:
	{
		Exception_t1927440687 * L_5 = MethodBuilder_NotSupported_m1885110731(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_5);
	}
}
// System.Void System.Reflection.Emit.MethodBuilder::check_override()
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* TypeLoadException_t723359155_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral3019672120;
extern const uint32_t MethodBuilder_check_override_m3042345804_MetadataUsageId;
extern "C"  void MethodBuilder_check_override_m3042345804 (MethodBuilder_t644187984 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MethodBuilder_check_override_m3042345804_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		MethodInfo_t * L_0 = __this->get_override_method_9();
		if (!L_0)
		{
			goto IL_0042;
		}
	}
	{
		MethodInfo_t * L_1 = __this->get_override_method_9();
		NullCheck(L_1);
		bool L_2 = MethodBase_get_IsVirtual_m1107721718(L_1, /*hidden argument*/NULL);
		if (!L_2)
		{
			goto IL_0042;
		}
	}
	{
		bool L_3 = MethodBase_get_IsVirtual_m1107721718(__this, /*hidden argument*/NULL);
		if (L_3)
		{
			goto IL_0042;
		}
	}
	{
		String_t* L_4 = __this->get_name_4();
		MethodInfo_t * L_5 = __this->get_override_method_9();
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_6 = String_Format_m1811873526(NULL /*static, unused*/, _stringLiteral3019672120, L_4, L_5, /*hidden argument*/NULL);
		TypeLoadException_t723359155 * L_7 = (TypeLoadException_t723359155 *)il2cpp_codegen_object_new(TypeLoadException_t723359155_il2cpp_TypeInfo_var);
		TypeLoadException__ctor_m1903359728(L_7, L_6, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_7);
	}

IL_0042:
	{
		return;
	}
}
// System.Void System.Reflection.Emit.MethodBuilder::fixup()
extern Il2CppClass* ILGenerator_t99948092_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* InvalidOperationException_t721527559_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral1027522002;
extern const uint32_t MethodBuilder_fixup_m4217981161_MetadataUsageId;
extern "C"  void MethodBuilder_fixup_m4217981161 (MethodBuilder_t644187984 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MethodBuilder_fixup_m4217981161_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		int32_t L_0 = __this->get_attrs_2();
		if (((int32_t)((int32_t)L_0&(int32_t)((int32_t)9216))))
		{
			goto IL_0076;
		}
	}
	{
		int32_t L_1 = __this->get_iattrs_3();
		if (((int32_t)((int32_t)L_1&(int32_t)((int32_t)4099))))
		{
			goto IL_0076;
		}
	}
	{
		ILGenerator_t99948092 * L_2 = __this->get_ilgen_6();
		if (!L_2)
		{
			goto IL_003d;
		}
	}
	{
		ILGenerator_t99948092 * L_3 = __this->get_ilgen_6();
		IL2CPP_RUNTIME_CLASS_INIT(ILGenerator_t99948092_il2cpp_TypeInfo_var);
		int32_t L_4 = ILGenerator_Mono_GetCurrentOffset_m3553856682(NULL /*static, unused*/, L_3, /*hidden argument*/NULL);
		if (L_4)
		{
			goto IL_0076;
		}
	}

IL_003d:
	{
		ByteU5BU5D_t3397334013* L_5 = __this->get_code_5();
		if (!L_5)
		{
			goto IL_0055;
		}
	}
	{
		ByteU5BU5D_t3397334013* L_6 = __this->get_code_5();
		NullCheck(L_6);
		if ((((int32_t)((int32_t)(((Il2CppArray *)L_6)->max_length)))))
		{
			goto IL_0076;
		}
	}

IL_0055:
	{
		Type_t * L_7 = MethodBuilder_get_DeclaringType_m2734207591(__this, /*hidden argument*/NULL);
		NullCheck(L_7);
		String_t* L_8 = VirtFuncInvoker0< String_t* >::Invoke(18 /* System.String System.Type::get_FullName() */, L_7);
		String_t* L_9 = MethodBuilder_get_Name_m845253610(__this, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_10 = String_Format_m1811873526(NULL /*static, unused*/, _stringLiteral1027522002, L_8, L_9, /*hidden argument*/NULL);
		InvalidOperationException_t721527559 * L_11 = (InvalidOperationException_t721527559 *)il2cpp_codegen_object_new(InvalidOperationException_t721527559_il2cpp_TypeInfo_var);
		InvalidOperationException__ctor_m2801133788(L_11, L_10, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_11);
	}

IL_0076:
	{
		ILGenerator_t99948092 * L_12 = __this->get_ilgen_6();
		if (!L_12)
		{
			goto IL_008c;
		}
	}
	{
		ILGenerator_t99948092 * L_13 = __this->get_ilgen_6();
		NullCheck(L_13);
		ILGenerator_label_fixup_m1325994348(L_13, /*hidden argument*/NULL);
	}

IL_008c:
	{
		return;
	}
}
// System.String System.Reflection.Emit.MethodBuilder::ToString()
extern Il2CppClass* StringU5BU5D_t1642385972_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral1403619109;
extern Il2CppCodeGenString* _stringLiteral2874782298;
extern Il2CppCodeGenString* _stringLiteral372029425;
extern const uint32_t MethodBuilder_ToString_m2051053888_MetadataUsageId;
extern "C"  String_t* MethodBuilder_ToString_m2051053888 (MethodBuilder_t644187984 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MethodBuilder_ToString_m2051053888_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		StringU5BU5D_t1642385972* L_0 = ((StringU5BU5D_t1642385972*)SZArrayNew(StringU5BU5D_t1642385972_il2cpp_TypeInfo_var, (uint32_t)5));
		NullCheck(L_0);
		ArrayElementTypeCheck (L_0, _stringLiteral1403619109);
		(L_0)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)_stringLiteral1403619109);
		StringU5BU5D_t1642385972* L_1 = L_0;
		TypeBuilder_t3308873219 * L_2 = __this->get_type_7();
		NullCheck(L_2);
		String_t* L_3 = TypeBuilder_get_Name_m170882803(L_2, /*hidden argument*/NULL);
		NullCheck(L_1);
		ArrayElementTypeCheck (L_1, L_3);
		(L_1)->SetAt(static_cast<il2cpp_array_size_t>(1), (String_t*)L_3);
		StringU5BU5D_t1642385972* L_4 = L_1;
		NullCheck(L_4);
		ArrayElementTypeCheck (L_4, _stringLiteral2874782298);
		(L_4)->SetAt(static_cast<il2cpp_array_size_t>(2), (String_t*)_stringLiteral2874782298);
		StringU5BU5D_t1642385972* L_5 = L_4;
		String_t* L_6 = __this->get_name_4();
		NullCheck(L_5);
		ArrayElementTypeCheck (L_5, L_6);
		(L_5)->SetAt(static_cast<il2cpp_array_size_t>(3), (String_t*)L_6);
		StringU5BU5D_t1642385972* L_7 = L_5;
		NullCheck(L_7);
		ArrayElementTypeCheck (L_7, _stringLiteral372029425);
		(L_7)->SetAt(static_cast<il2cpp_array_size_t>(4), (String_t*)_stringLiteral372029425);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_8 = String_Concat_m626692867(NULL /*static, unused*/, L_7, /*hidden argument*/NULL);
		return L_8;
	}
}
// System.Boolean System.Reflection.Emit.MethodBuilder::Equals(System.Object)
extern "C"  bool MethodBuilder_Equals_m1205580640 (MethodBuilder_t644187984 * __this, Il2CppObject * ___obj0, const MethodInfo* method)
{
	{
		Il2CppObject * L_0 = ___obj0;
		bool L_1 = Object_Equals_m753388391(__this, L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Int32 System.Reflection.Emit.MethodBuilder::GetHashCode()
extern "C"  int32_t MethodBuilder_GetHashCode_m1713271764 (MethodBuilder_t644187984 * __this, const MethodInfo* method)
{
	{
		String_t* L_0 = __this->get_name_4();
		NullCheck(L_0);
		int32_t L_1 = String_GetHashCode_m931956593(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Int32 System.Reflection.Emit.MethodBuilder::get_next_table_index(System.Object,System.Int32,System.Boolean)
extern "C"  int32_t MethodBuilder_get_next_table_index_m683309027 (MethodBuilder_t644187984 * __this, Il2CppObject * ___obj0, int32_t ___table1, bool ___inc2, const MethodInfo* method)
{
	{
		TypeBuilder_t3308873219 * L_0 = __this->get_type_7();
		Il2CppObject * L_1 = ___obj0;
		int32_t L_2 = ___table1;
		bool L_3 = ___inc2;
		NullCheck(L_0);
		int32_t L_4 = TypeBuilder_get_next_table_index_m1415870184(L_0, L_1, L_2, L_3, /*hidden argument*/NULL);
		return L_4;
	}
}
// System.Exception System.Reflection.Emit.MethodBuilder::NotSupported()
extern Il2CppClass* NotSupportedException_t1793819818_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral4087454587;
extern const uint32_t MethodBuilder_NotSupported_m1885110731_MetadataUsageId;
extern "C"  Exception_t1927440687 * MethodBuilder_NotSupported_m1885110731 (MethodBuilder_t644187984 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MethodBuilder_NotSupported_m1885110731_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		NotSupportedException_t1793819818 * L_0 = (NotSupportedException_t1793819818 *)il2cpp_codegen_object_new(NotSupportedException_t1793819818_il2cpp_TypeInfo_var);
		NotSupportedException__ctor_m836173213(L_0, _stringLiteral4087454587, /*hidden argument*/NULL);
		return L_0;
	}
}
// System.Reflection.MethodInfo System.Reflection.Emit.MethodBuilder::MakeGenericMethod(System.Type[])
extern "C"  MethodInfo_t * MethodBuilder_MakeGenericMethod_m303913412 (MethodBuilder_t644187984 * __this, TypeU5BU5D_t1664964607* ___typeArguments0, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef MethodInfo_t * (*MethodBuilder_MakeGenericMethod_m303913412_ftn) (MethodBuilder_t644187984 *, TypeU5BU5D_t1664964607*);
	return  ((MethodBuilder_MakeGenericMethod_m303913412_ftn)mscorlib::System::Reflection::Emit::MethodBuilder::MakeGenericMethod) (__this, ___typeArguments0);
}
// System.Boolean System.Reflection.Emit.MethodBuilder::get_IsGenericMethodDefinition()
extern "C"  bool MethodBuilder_get_IsGenericMethodDefinition_m4284232991 (MethodBuilder_t644187984 * __this, const MethodInfo* method)
{
	{
		GenericTypeParameterBuilderU5BU5D_t358971386* L_0 = __this->get_generic_params_11();
		return (bool)((((int32_t)((((Il2CppObject*)(GenericTypeParameterBuilderU5BU5D_t358971386*)L_0) == ((Il2CppObject*)(Il2CppObject *)NULL))? 1 : 0)) == ((int32_t)0))? 1 : 0);
	}
}
// System.Boolean System.Reflection.Emit.MethodBuilder::get_IsGenericMethod()
extern "C"  bool MethodBuilder_get_IsGenericMethod_m770496854 (MethodBuilder_t644187984 * __this, const MethodInfo* method)
{
	{
		GenericTypeParameterBuilderU5BU5D_t358971386* L_0 = __this->get_generic_params_11();
		return (bool)((((int32_t)((((Il2CppObject*)(GenericTypeParameterBuilderU5BU5D_t358971386*)L_0) == ((Il2CppObject*)(Il2CppObject *)NULL))? 1 : 0)) == ((int32_t)0))? 1 : 0);
	}
}
// System.Type[] System.Reflection.Emit.MethodBuilder::GetGenericArguments()
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern Il2CppClass* TypeU5BU5D_t1664964607_il2cpp_TypeInfo_var;
extern const uint32_t MethodBuilder_GetGenericArguments_m948618404_MetadataUsageId;
extern "C"  TypeU5BU5D_t1664964607* MethodBuilder_GetGenericArguments_m948618404 (MethodBuilder_t644187984 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MethodBuilder_GetGenericArguments_m948618404_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	TypeU5BU5D_t1664964607* V_0 = NULL;
	int32_t V_1 = 0;
	{
		GenericTypeParameterBuilderU5BU5D_t358971386* L_0 = __this->get_generic_params_11();
		if (L_0)
		{
			goto IL_0011;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		TypeU5BU5D_t1664964607* L_1 = ((Type_t_StaticFields*)Type_t_il2cpp_TypeInfo_var->static_fields)->get_EmptyTypes_3();
		return L_1;
	}

IL_0011:
	{
		GenericTypeParameterBuilderU5BU5D_t358971386* L_2 = __this->get_generic_params_11();
		NullCheck(L_2);
		V_0 = ((TypeU5BU5D_t1664964607*)SZArrayNew(TypeU5BU5D_t1664964607_il2cpp_TypeInfo_var, (uint32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_2)->max_length))))));
		V_1 = 0;
		goto IL_0035;
	}

IL_0026:
	{
		TypeU5BU5D_t1664964607* L_3 = V_0;
		int32_t L_4 = V_1;
		GenericTypeParameterBuilderU5BU5D_t358971386* L_5 = __this->get_generic_params_11();
		int32_t L_6 = V_1;
		NullCheck(L_5);
		int32_t L_7 = L_6;
		GenericTypeParameterBuilder_t1370236603 * L_8 = (L_5)->GetAt(static_cast<il2cpp_array_size_t>(L_7));
		NullCheck(L_3);
		ArrayElementTypeCheck (L_3, L_8);
		(L_3)->SetAt(static_cast<il2cpp_array_size_t>(L_4), (Type_t *)L_8);
		int32_t L_9 = V_1;
		V_1 = ((int32_t)((int32_t)L_9+(int32_t)1));
	}

IL_0035:
	{
		int32_t L_10 = V_1;
		GenericTypeParameterBuilderU5BU5D_t358971386* L_11 = __this->get_generic_params_11();
		NullCheck(L_11);
		if ((((int32_t)L_10) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_11)->max_length)))))))
		{
			goto IL_0026;
		}
	}
	{
		TypeU5BU5D_t1664964607* L_12 = V_0;
		return L_12;
	}
}
// System.Reflection.Module System.Reflection.Emit.MethodBuilder::get_Module()
extern "C"  Module_t4282841206 * MethodBuilder_get_Module_m2867334479 (MethodBuilder_t644187984 * __this, const MethodInfo* method)
{
	{
		Module_t4282841206 * L_0 = MemberInfo_get_Module_m3957426656(__this, /*hidden argument*/NULL);
		return L_0;
	}
}
// System.Void System.Reflection.Emit.MethodToken::.ctor(System.Int32)
extern "C"  void MethodToken__ctor_m3671357474 (MethodToken_t3991686330 * __this, int32_t ___val0, const MethodInfo* method)
{
	{
		int32_t L_0 = ___val0;
		__this->set_tokValue_0(L_0);
		return;
	}
}
extern "C"  void MethodToken__ctor_m3671357474_AdjustorThunk (Il2CppObject * __this, int32_t ___val0, const MethodInfo* method)
{
	MethodToken_t3991686330 * _thisAdjusted = reinterpret_cast<MethodToken_t3991686330 *>(__this + 1);
	MethodToken__ctor_m3671357474(_thisAdjusted, ___val0, method);
}
// System.Void System.Reflection.Emit.MethodToken::.cctor()
extern Il2CppClass* MethodToken_t3991686330_il2cpp_TypeInfo_var;
extern const uint32_t MethodToken__cctor_m2172944774_MetadataUsageId;
extern "C"  void MethodToken__cctor_m2172944774 (Il2CppObject * __this /* static, unused */, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MethodToken__cctor_m2172944774_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	MethodToken_t3991686330  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		Initobj (MethodToken_t3991686330_il2cpp_TypeInfo_var, (&V_0));
		MethodToken_t3991686330  L_0 = V_0;
		((MethodToken_t3991686330_StaticFields*)MethodToken_t3991686330_il2cpp_TypeInfo_var->static_fields)->set_Empty_1(L_0);
		return;
	}
}
// System.Boolean System.Reflection.Emit.MethodToken::Equals(System.Object)
extern Il2CppClass* MethodToken_t3991686330_il2cpp_TypeInfo_var;
extern const uint32_t MethodToken_Equals_m533761838_MetadataUsageId;
extern "C"  bool MethodToken_Equals_m533761838 (MethodToken_t3991686330 * __this, Il2CppObject * ___obj0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MethodToken_Equals_m533761838_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	bool V_0 = false;
	MethodToken_t3991686330  V_1;
	memset(&V_1, 0, sizeof(V_1));
	{
		Il2CppObject * L_0 = ___obj0;
		V_0 = (bool)((!(((Il2CppObject*)(Il2CppObject *)((Il2CppObject *)IsInstSealed(L_0, MethodToken_t3991686330_il2cpp_TypeInfo_var))) <= ((Il2CppObject*)(Il2CppObject *)NULL)))? 1 : 0);
		bool L_1 = V_0;
		if (!L_1)
		{
			goto IL_0027;
		}
	}
	{
		Il2CppObject * L_2 = ___obj0;
		V_1 = ((*(MethodToken_t3991686330 *)((MethodToken_t3991686330 *)UnBox (L_2, MethodToken_t3991686330_il2cpp_TypeInfo_var))));
		int32_t L_3 = __this->get_tokValue_0();
		int32_t L_4 = (&V_1)->get_tokValue_0();
		V_0 = (bool)((((int32_t)L_3) == ((int32_t)L_4))? 1 : 0);
	}

IL_0027:
	{
		bool L_5 = V_0;
		return L_5;
	}
}
extern "C"  bool MethodToken_Equals_m533761838_AdjustorThunk (Il2CppObject * __this, Il2CppObject * ___obj0, const MethodInfo* method)
{
	MethodToken_t3991686330 * _thisAdjusted = reinterpret_cast<MethodToken_t3991686330 *>(__this + 1);
	return MethodToken_Equals_m533761838(_thisAdjusted, ___obj0, method);
}
// System.Int32 System.Reflection.Emit.MethodToken::GetHashCode()
extern "C"  int32_t MethodToken_GetHashCode_m1405492030 (MethodToken_t3991686330 * __this, const MethodInfo* method)
{
	{
		int32_t L_0 = __this->get_tokValue_0();
		return L_0;
	}
}
extern "C"  int32_t MethodToken_GetHashCode_m1405492030_AdjustorThunk (Il2CppObject * __this, const MethodInfo* method)
{
	MethodToken_t3991686330 * _thisAdjusted = reinterpret_cast<MethodToken_t3991686330 *>(__this + 1);
	return MethodToken_GetHashCode_m1405492030(_thisAdjusted, method);
}
// System.Int32 System.Reflection.Emit.MethodToken::get_Token()
extern "C"  int32_t MethodToken_get_Token_m3846227497 (MethodToken_t3991686330 * __this, const MethodInfo* method)
{
	{
		int32_t L_0 = __this->get_tokValue_0();
		return L_0;
	}
}
extern "C"  int32_t MethodToken_get_Token_m3846227497_AdjustorThunk (Il2CppObject * __this, const MethodInfo* method)
{
	MethodToken_t3991686330 * _thisAdjusted = reinterpret_cast<MethodToken_t3991686330 *>(__this + 1);
	return MethodToken_get_Token_m3846227497(_thisAdjusted, method);
}
// System.Void System.Reflection.Emit.ModuleBuilder::.cctor()
extern Il2CppClass* CharU5BU5D_t1328083999_il2cpp_TypeInfo_var;
extern Il2CppClass* ModuleBuilder_t4156028127_il2cpp_TypeInfo_var;
extern const uint32_t ModuleBuilder__cctor_m2985766025_MetadataUsageId;
extern "C"  void ModuleBuilder__cctor_m2985766025 (Il2CppObject * __this /* static, unused */, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ModuleBuilder__cctor_m2985766025_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		CharU5BU5D_t1328083999* L_0 = ((CharU5BU5D_t1328083999*)SZArrayNew(CharU5BU5D_t1328083999_il2cpp_TypeInfo_var, (uint32_t)3));
		NullCheck(L_0);
		(L_0)->SetAt(static_cast<il2cpp_array_size_t>(0), (Il2CppChar)((int32_t)38));
		CharU5BU5D_t1328083999* L_1 = L_0;
		NullCheck(L_1);
		(L_1)->SetAt(static_cast<il2cpp_array_size_t>(1), (Il2CppChar)((int32_t)91));
		CharU5BU5D_t1328083999* L_2 = L_1;
		NullCheck(L_2);
		(L_2)->SetAt(static_cast<il2cpp_array_size_t>(2), (Il2CppChar)((int32_t)42));
		((ModuleBuilder_t4156028127_StaticFields*)ModuleBuilder_t4156028127_il2cpp_TypeInfo_var->static_fields)->set_type_modifiers_15(L_2);
		return;
	}
}
// System.Int32 System.Reflection.Emit.ModuleBuilder::get_next_table_index(System.Object,System.Int32,System.Boolean)
extern Il2CppClass* Int32U5BU5D_t3030399641_il2cpp_TypeInfo_var;
extern const uint32_t ModuleBuilder_get_next_table_index_m1552645388_MetadataUsageId;
extern "C"  int32_t ModuleBuilder_get_next_table_index_m1552645388 (ModuleBuilder_t4156028127 * __this, Il2CppObject * ___obj0, int32_t ___table1, bool ___inc2, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ModuleBuilder_get_next_table_index_m1552645388_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	{
		Int32U5BU5D_t3030399641* L_0 = __this->get_table_indexes_13();
		if (L_0)
		{
			goto IL_003d;
		}
	}
	{
		__this->set_table_indexes_13(((Int32U5BU5D_t3030399641*)SZArrayNew(Int32U5BU5D_t3030399641_il2cpp_TypeInfo_var, (uint32_t)((int32_t)64))));
		V_0 = 0;
		goto IL_002c;
	}

IL_001f:
	{
		Int32U5BU5D_t3030399641* L_1 = __this->get_table_indexes_13();
		int32_t L_2 = V_0;
		NullCheck(L_1);
		(L_1)->SetAt(static_cast<il2cpp_array_size_t>(L_2), (int32_t)1);
		int32_t L_3 = V_0;
		V_0 = ((int32_t)((int32_t)L_3+(int32_t)1));
	}

IL_002c:
	{
		int32_t L_4 = V_0;
		if ((((int32_t)L_4) < ((int32_t)((int32_t)64))))
		{
			goto IL_001f;
		}
	}
	{
		Int32U5BU5D_t3030399641* L_5 = __this->get_table_indexes_13();
		NullCheck(L_5);
		(L_5)->SetAt(static_cast<il2cpp_array_size_t>(2), (int32_t)2);
	}

IL_003d:
	{
		bool L_6 = ___inc2;
		if (!L_6)
		{
			goto IL_0058;
		}
	}
	{
		Int32U5BU5D_t3030399641* L_7 = __this->get_table_indexes_13();
		int32_t L_8 = ___table1;
		NullCheck(L_7);
		int32_t* L_9 = ((L_7)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_8)));
		int32_t L_10 = (*((int32_t*)L_9));
		V_1 = L_10;
		*((int32_t*)(L_9)) = (int32_t)((int32_t)((int32_t)L_10+(int32_t)1));
		int32_t L_11 = V_1;
		return L_11;
	}

IL_0058:
	{
		Int32U5BU5D_t3030399641* L_12 = __this->get_table_indexes_13();
		int32_t L_13 = ___table1;
		NullCheck(L_12);
		int32_t L_14 = L_13;
		int32_t L_15 = (L_12)->GetAt(static_cast<il2cpp_array_size_t>(L_14));
		return L_15;
	}
}
// System.Type[] System.Reflection.Emit.ModuleBuilder::GetTypes()
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern Il2CppClass* TypeU5BU5D_t1664964607_il2cpp_TypeInfo_var;
extern const uint32_t ModuleBuilder_GetTypes_m93550753_MetadataUsageId;
extern "C"  TypeU5BU5D_t1664964607* ModuleBuilder_GetTypes_m93550753 (ModuleBuilder_t4156028127 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ModuleBuilder_GetTypes_m93550753_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	TypeU5BU5D_t1664964607* V_1 = NULL;
	int32_t V_2 = 0;
	{
		TypeBuilderU5BU5D_t4254476946* L_0 = __this->get_types_11();
		if (L_0)
		{
			goto IL_0011;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		TypeU5BU5D_t1664964607* L_1 = ((Type_t_StaticFields*)Type_t_il2cpp_TypeInfo_var->static_fields)->get_EmptyTypes_3();
		return L_1;
	}

IL_0011:
	{
		int32_t L_2 = __this->get_num_types_10();
		V_0 = L_2;
		int32_t L_3 = V_0;
		V_1 = ((TypeU5BU5D_t1664964607*)SZArrayNew(TypeU5BU5D_t1664964607_il2cpp_TypeInfo_var, (uint32_t)L_3));
		TypeBuilderU5BU5D_t4254476946* L_4 = __this->get_types_11();
		TypeU5BU5D_t1664964607* L_5 = V_1;
		int32_t L_6 = V_0;
		Array_Copy_m2363740072(NULL /*static, unused*/, (Il2CppArray *)(Il2CppArray *)L_4, (Il2CppArray *)(Il2CppArray *)L_5, L_6, /*hidden argument*/NULL);
		V_2 = 0;
		goto IL_0059;
	}

IL_0033:
	{
		TypeBuilderU5BU5D_t4254476946* L_7 = __this->get_types_11();
		int32_t L_8 = V_2;
		NullCheck(L_7);
		int32_t L_9 = L_8;
		TypeBuilder_t3308873219 * L_10 = (L_7)->GetAt(static_cast<il2cpp_array_size_t>(L_9));
		NullCheck(L_10);
		bool L_11 = TypeBuilder_get_is_created_m736553860(L_10, /*hidden argument*/NULL);
		if (!L_11)
		{
			goto IL_0055;
		}
	}
	{
		TypeU5BU5D_t1664964607* L_12 = V_1;
		int32_t L_13 = V_2;
		TypeBuilderU5BU5D_t4254476946* L_14 = __this->get_types_11();
		int32_t L_15 = V_2;
		NullCheck(L_14);
		int32_t L_16 = L_15;
		TypeBuilder_t3308873219 * L_17 = (L_14)->GetAt(static_cast<il2cpp_array_size_t>(L_16));
		NullCheck(L_17);
		Type_t * L_18 = TypeBuilder_CreateType_m4126056124(L_17, /*hidden argument*/NULL);
		NullCheck(L_12);
		ArrayElementTypeCheck (L_12, L_18);
		(L_12)->SetAt(static_cast<il2cpp_array_size_t>(L_13), (Type_t *)L_18);
	}

IL_0055:
	{
		int32_t L_19 = V_2;
		V_2 = ((int32_t)((int32_t)L_19+(int32_t)1));
	}

IL_0059:
	{
		int32_t L_20 = V_2;
		TypeU5BU5D_t1664964607* L_21 = V_1;
		NullCheck(L_21);
		if ((((int32_t)L_20) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_21)->max_length)))))))
		{
			goto IL_0033;
		}
	}
	{
		TypeU5BU5D_t1664964607* L_22 = V_1;
		return L_22;
	}
}
// System.Int32 System.Reflection.Emit.ModuleBuilder::getToken(System.Reflection.Emit.ModuleBuilder,System.Object)
extern "C"  int32_t ModuleBuilder_getToken_m972612049 (Il2CppObject * __this /* static, unused */, ModuleBuilder_t4156028127 * ___mb0, Il2CppObject * ___obj1, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef int32_t (*ModuleBuilder_getToken_m972612049_ftn) (ModuleBuilder_t4156028127 *, Il2CppObject *);
	return  ((ModuleBuilder_getToken_m972612049_ftn)mscorlib::System::Reflection::Emit::ModuleBuilder::getToken) (___mb0, ___obj1);
}
// System.Int32 System.Reflection.Emit.ModuleBuilder::GetToken(System.Reflection.MemberInfo)
extern Il2CppClass* ModuleBuilder_t4156028127_il2cpp_TypeInfo_var;
extern const uint32_t ModuleBuilder_GetToken_m4190668737_MetadataUsageId;
extern "C"  int32_t ModuleBuilder_GetToken_m4190668737 (ModuleBuilder_t4156028127 * __this, MemberInfo_t * ___member0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ModuleBuilder_GetToken_m4190668737_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		MemberInfo_t * L_0 = ___member0;
		IL2CPP_RUNTIME_CLASS_INIT(ModuleBuilder_t4156028127_il2cpp_TypeInfo_var);
		int32_t L_1 = ModuleBuilder_getToken_m972612049(NULL /*static, unused*/, __this, L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Void System.Reflection.Emit.ModuleBuilder::RegisterToken(System.Object,System.Int32)
extern "C"  void ModuleBuilder_RegisterToken_m1388342515 (ModuleBuilder_t4156028127 * __this, Il2CppObject * ___obj0, int32_t ___token1, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef void (*ModuleBuilder_RegisterToken_m1388342515_ftn) (ModuleBuilder_t4156028127 *, Il2CppObject *, int32_t);
	 ((ModuleBuilder_RegisterToken_m1388342515_ftn)mscorlib::System::Reflection::Emit::ModuleBuilder::RegisterToken) (__this, ___obj0, ___token1);
}
// System.Reflection.Emit.TokenGenerator System.Reflection.Emit.ModuleBuilder::GetTokenGenerator()
extern Il2CppClass* ModuleBuilderTokenGenerator_t578872653_il2cpp_TypeInfo_var;
extern const uint32_t ModuleBuilder_GetTokenGenerator_m4006065550_MetadataUsageId;
extern "C"  Il2CppObject * ModuleBuilder_GetTokenGenerator_m4006065550 (ModuleBuilder_t4156028127 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ModuleBuilder_GetTokenGenerator_m4006065550_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ModuleBuilderTokenGenerator_t578872653 * L_0 = __this->get_token_gen_14();
		if (L_0)
		{
			goto IL_0017;
		}
	}
	{
		ModuleBuilderTokenGenerator_t578872653 * L_1 = (ModuleBuilderTokenGenerator_t578872653 *)il2cpp_codegen_object_new(ModuleBuilderTokenGenerator_t578872653_il2cpp_TypeInfo_var);
		ModuleBuilderTokenGenerator__ctor_m1041652642(L_1, __this, /*hidden argument*/NULL);
		__this->set_token_gen_14(L_1);
	}

IL_0017:
	{
		ModuleBuilderTokenGenerator_t578872653 * L_2 = __this->get_token_gen_14();
		return L_2;
	}
}
// System.Void System.Reflection.Emit.ModuleBuilderTokenGenerator::.ctor(System.Reflection.Emit.ModuleBuilder)
extern "C"  void ModuleBuilderTokenGenerator__ctor_m1041652642 (ModuleBuilderTokenGenerator_t578872653 * __this, ModuleBuilder_t4156028127 * ___mb0, const MethodInfo* method)
{
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		ModuleBuilder_t4156028127 * L_0 = ___mb0;
		__this->set_mb_0(L_0);
		return;
	}
}
// System.Int32 System.Reflection.Emit.ModuleBuilderTokenGenerator::GetToken(System.Reflection.MemberInfo)
extern "C"  int32_t ModuleBuilderTokenGenerator_GetToken_m3427457873 (ModuleBuilderTokenGenerator_t578872653 * __this, MemberInfo_t * ___member0, const MethodInfo* method)
{
	{
		ModuleBuilder_t4156028127 * L_0 = __this->get_mb_0();
		MemberInfo_t * L_1 = ___member0;
		NullCheck(L_0);
		int32_t L_2 = ModuleBuilder_GetToken_m4190668737(L_0, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.Void System.Reflection.Emit.OpCode::.ctor(System.Int32,System.Int32)
extern "C"  void OpCode__ctor_m3329993003 (OpCode_t2247480392 * __this, int32_t ___p0, int32_t ___q1, const MethodInfo* method)
{
	{
		int32_t L_0 = ___p0;
		__this->set_op1_0((((int32_t)((uint8_t)((int32_t)((int32_t)L_0&(int32_t)((int32_t)255)))))));
		int32_t L_1 = ___p0;
		__this->set_op2_1((((int32_t)((uint8_t)((int32_t)((int32_t)((int32_t)((int32_t)L_1>>(int32_t)8))&(int32_t)((int32_t)255)))))));
		int32_t L_2 = ___p0;
		__this->set_push_2((((int32_t)((uint8_t)((int32_t)((int32_t)((int32_t)((int32_t)L_2>>(int32_t)((int32_t)16)))&(int32_t)((int32_t)255)))))));
		int32_t L_3 = ___p0;
		__this->set_pop_3((((int32_t)((uint8_t)((int32_t)((int32_t)((int32_t)((int32_t)L_3>>(int32_t)((int32_t)24)))&(int32_t)((int32_t)255)))))));
		int32_t L_4 = ___q1;
		__this->set_size_4((((int32_t)((uint8_t)((int32_t)((int32_t)L_4&(int32_t)((int32_t)255)))))));
		int32_t L_5 = ___q1;
		__this->set_type_5((((int32_t)((uint8_t)((int32_t)((int32_t)((int32_t)((int32_t)L_5>>(int32_t)8))&(int32_t)((int32_t)255)))))));
		int32_t L_6 = ___q1;
		__this->set_args_6((((int32_t)((uint8_t)((int32_t)((int32_t)((int32_t)((int32_t)L_6>>(int32_t)((int32_t)16)))&(int32_t)((int32_t)255)))))));
		int32_t L_7 = ___q1;
		__this->set_flow_7((((int32_t)((uint8_t)((int32_t)((int32_t)((int32_t)((int32_t)L_7>>(int32_t)((int32_t)24)))&(int32_t)((int32_t)255)))))));
		return;
	}
}
extern "C"  void OpCode__ctor_m3329993003_AdjustorThunk (Il2CppObject * __this, int32_t ___p0, int32_t ___q1, const MethodInfo* method)
{
	OpCode_t2247480392 * _thisAdjusted = reinterpret_cast<OpCode_t2247480392 *>(__this + 1);
	OpCode__ctor_m3329993003(_thisAdjusted, ___p0, ___q1, method);
}
// System.Int32 System.Reflection.Emit.OpCode::GetHashCode()
extern "C"  int32_t OpCode_GetHashCode_m2974727122 (OpCode_t2247480392 * __this, const MethodInfo* method)
{
	{
		String_t* L_0 = OpCode_get_Name_m3225695398(__this, /*hidden argument*/NULL);
		NullCheck(L_0);
		int32_t L_1 = String_GetHashCode_m931956593(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
extern "C"  int32_t OpCode_GetHashCode_m2974727122_AdjustorThunk (Il2CppObject * __this, const MethodInfo* method)
{
	OpCode_t2247480392 * _thisAdjusted = reinterpret_cast<OpCode_t2247480392 *>(__this + 1);
	return OpCode_GetHashCode_m2974727122(_thisAdjusted, method);
}
// System.Boolean System.Reflection.Emit.OpCode::Equals(System.Object)
extern Il2CppClass* OpCode_t2247480392_il2cpp_TypeInfo_var;
extern const uint32_t OpCode_Equals_m3738130494_MetadataUsageId;
extern "C"  bool OpCode_Equals_m3738130494 (OpCode_t2247480392 * __this, Il2CppObject * ___obj0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (OpCode_Equals_m3738130494_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	OpCode_t2247480392  V_0;
	memset(&V_0, 0, sizeof(V_0));
	int32_t G_B6_0 = 0;
	{
		Il2CppObject * L_0 = ___obj0;
		if (!L_0)
		{
			goto IL_0011;
		}
	}
	{
		Il2CppObject * L_1 = ___obj0;
		if (((Il2CppObject *)IsInstSealed(L_1, OpCode_t2247480392_il2cpp_TypeInfo_var)))
		{
			goto IL_0013;
		}
	}

IL_0011:
	{
		return (bool)0;
	}

IL_0013:
	{
		Il2CppObject * L_2 = ___obj0;
		V_0 = ((*(OpCode_t2247480392 *)((OpCode_t2247480392 *)UnBox (L_2, OpCode_t2247480392_il2cpp_TypeInfo_var))));
		uint8_t L_3 = (&V_0)->get_op1_0();
		uint8_t L_4 = __this->get_op1_0();
		if ((!(((uint32_t)L_3) == ((uint32_t)L_4))))
		{
			goto IL_003d;
		}
	}
	{
		uint8_t L_5 = (&V_0)->get_op2_1();
		uint8_t L_6 = __this->get_op2_1();
		G_B6_0 = ((((int32_t)L_5) == ((int32_t)L_6))? 1 : 0);
		goto IL_003e;
	}

IL_003d:
	{
		G_B6_0 = 0;
	}

IL_003e:
	{
		return (bool)G_B6_0;
	}
}
extern "C"  bool OpCode_Equals_m3738130494_AdjustorThunk (Il2CppObject * __this, Il2CppObject * ___obj0, const MethodInfo* method)
{
	OpCode_t2247480392 * _thisAdjusted = reinterpret_cast<OpCode_t2247480392 *>(__this + 1);
	return OpCode_Equals_m3738130494(_thisAdjusted, ___obj0, method);
}
// System.String System.Reflection.Emit.OpCode::ToString()
extern "C"  String_t* OpCode_ToString_m854294924 (OpCode_t2247480392 * __this, const MethodInfo* method)
{
	{
		String_t* L_0 = OpCode_get_Name_m3225695398(__this, /*hidden argument*/NULL);
		return L_0;
	}
}
extern "C"  String_t* OpCode_ToString_m854294924_AdjustorThunk (Il2CppObject * __this, const MethodInfo* method)
{
	OpCode_t2247480392 * _thisAdjusted = reinterpret_cast<OpCode_t2247480392 *>(__this + 1);
	return OpCode_ToString_m854294924(_thisAdjusted, method);
}
// System.String System.Reflection.Emit.OpCode::get_Name()
extern Il2CppClass* OpCodeNames_t1907134268_il2cpp_TypeInfo_var;
extern const uint32_t OpCode_get_Name_m3225695398_MetadataUsageId;
extern "C"  String_t* OpCode_get_Name_m3225695398 (OpCode_t2247480392 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (OpCode_get_Name_m3225695398_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		uint8_t L_0 = __this->get_op1_0();
		if ((!(((uint32_t)L_0) == ((uint32_t)((int32_t)255)))))
		{
			goto IL_001d;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(OpCodeNames_t1907134268_il2cpp_TypeInfo_var);
		StringU5BU5D_t1642385972* L_1 = ((OpCodeNames_t1907134268_StaticFields*)OpCodeNames_t1907134268_il2cpp_TypeInfo_var->static_fields)->get_names_0();
		uint8_t L_2 = __this->get_op2_1();
		NullCheck(L_1);
		uint8_t L_3 = L_2;
		String_t* L_4 = (L_1)->GetAt(static_cast<il2cpp_array_size_t>(L_3));
		return L_4;
	}

IL_001d:
	{
		IL2CPP_RUNTIME_CLASS_INIT(OpCodeNames_t1907134268_il2cpp_TypeInfo_var);
		StringU5BU5D_t1642385972* L_5 = ((OpCodeNames_t1907134268_StaticFields*)OpCodeNames_t1907134268_il2cpp_TypeInfo_var->static_fields)->get_names_0();
		uint8_t L_6 = __this->get_op2_1();
		NullCheck(L_5);
		int32_t L_7 = ((int32_t)((int32_t)((int32_t)256)+(int32_t)L_6));
		String_t* L_8 = (L_5)->GetAt(static_cast<il2cpp_array_size_t>(L_7));
		return L_8;
	}
}
extern "C"  String_t* OpCode_get_Name_m3225695398_AdjustorThunk (Il2CppObject * __this, const MethodInfo* method)
{
	OpCode_t2247480392 * _thisAdjusted = reinterpret_cast<OpCode_t2247480392 *>(__this + 1);
	return OpCode_get_Name_m3225695398(_thisAdjusted, method);
}
// System.Int32 System.Reflection.Emit.OpCode::get_Size()
extern "C"  int32_t OpCode_get_Size_m481593949 (OpCode_t2247480392 * __this, const MethodInfo* method)
{
	{
		uint8_t L_0 = __this->get_size_4();
		return L_0;
	}
}
extern "C"  int32_t OpCode_get_Size_m481593949_AdjustorThunk (Il2CppObject * __this, const MethodInfo* method)
{
	OpCode_t2247480392 * _thisAdjusted = reinterpret_cast<OpCode_t2247480392 *>(__this + 1);
	return OpCode_get_Size_m481593949(_thisAdjusted, method);
}
// System.Reflection.Emit.StackBehaviour System.Reflection.Emit.OpCode::get_StackBehaviourPop()
extern "C"  int32_t OpCode_get_StackBehaviourPop_m3787015663 (OpCode_t2247480392 * __this, const MethodInfo* method)
{
	{
		uint8_t L_0 = __this->get_pop_3();
		return (int32_t)(L_0);
	}
}
extern "C"  int32_t OpCode_get_StackBehaviourPop_m3787015663_AdjustorThunk (Il2CppObject * __this, const MethodInfo* method)
{
	OpCode_t2247480392 * _thisAdjusted = reinterpret_cast<OpCode_t2247480392 *>(__this + 1);
	return OpCode_get_StackBehaviourPop_m3787015663(_thisAdjusted, method);
}
// System.Reflection.Emit.StackBehaviour System.Reflection.Emit.OpCode::get_StackBehaviourPush()
extern "C"  int32_t OpCode_get_StackBehaviourPush_m1922356444 (OpCode_t2247480392 * __this, const MethodInfo* method)
{
	{
		uint8_t L_0 = __this->get_push_2();
		return (int32_t)(L_0);
	}
}
extern "C"  int32_t OpCode_get_StackBehaviourPush_m1922356444_AdjustorThunk (Il2CppObject * __this, const MethodInfo* method)
{
	OpCode_t2247480392 * _thisAdjusted = reinterpret_cast<OpCode_t2247480392 *>(__this + 1);
	return OpCode_get_StackBehaviourPush_m1922356444(_thisAdjusted, method);
}
// System.Void System.Reflection.Emit.OpCodeNames::.cctor()
extern Il2CppClass* StringU5BU5D_t1642385972_il2cpp_TypeInfo_var;
extern Il2CppClass* OpCodeNames_t1907134268_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral1502598669;
extern Il2CppCodeGenString* _stringLiteral1185218007;
extern Il2CppCodeGenString* _stringLiteral2751713072;
extern Il2CppCodeGenString* _stringLiteral2751713071;
extern Il2CppCodeGenString* _stringLiteral2751713070;
extern Il2CppCodeGenString* _stringLiteral2751713069;
extern Il2CppCodeGenString* _stringLiteral264743190;
extern Il2CppCodeGenString* _stringLiteral264743191;
extern Il2CppCodeGenString* _stringLiteral264743188;
extern Il2CppCodeGenString* _stringLiteral264743189;
extern Il2CppCodeGenString* _stringLiteral1784784505;
extern Il2CppCodeGenString* _stringLiteral1784784504;
extern Il2CppCodeGenString* _stringLiteral1784784507;
extern Il2CppCodeGenString* _stringLiteral1784784506;
extern Il2CppCodeGenString* _stringLiteral2751713005;
extern Il2CppCodeGenString* _stringLiteral1100455270;
extern Il2CppCodeGenString* _stringLiteral4049510564;
extern Il2CppCodeGenString* _stringLiteral264743253;
extern Il2CppCodeGenString* _stringLiteral2638390804;
extern Il2CppCodeGenString* _stringLiteral1784784442;
extern Il2CppCodeGenString* _stringLiteral3082303075;
extern Il2CppCodeGenString* _stringLiteral1962649898;
extern Il2CppCodeGenString* _stringLiteral980025156;
extern Il2CppCodeGenString* _stringLiteral3708908511;
extern Il2CppCodeGenString* _stringLiteral2142824570;
extern Il2CppCodeGenString* _stringLiteral576740629;
extern Il2CppCodeGenString* _stringLiteral2949393624;
extern Il2CppCodeGenString* _stringLiteral1383309683;
extern Il2CppCodeGenString* _stringLiteral4112193038;
extern Il2CppCodeGenString* _stringLiteral2546109097;
extern Il2CppCodeGenString* _stringLiteral1336255516;
extern Il2CppCodeGenString* _stringLiteral3426583509;
extern Il2CppCodeGenString* _stringLiteral3869444298;
extern Il2CppCodeGenString* _stringLiteral1900075830;
extern Il2CppCodeGenString* _stringLiteral3869444319;
extern Il2CppCodeGenString* _stringLiteral1900075851;
extern Il2CppCodeGenString* _stringLiteral2309167265;
extern Il2CppCodeGenString* _stringLiteral1502598839;
extern Il2CppCodeGenString* _stringLiteral2665398215;
extern Il2CppCodeGenString* _stringLiteral405904562;
extern Il2CppCodeGenString* _stringLiteral593459723;
extern Il2CppCodeGenString* _stringLiteral3021628803;
extern Il2CppCodeGenString* _stringLiteral2872924125;
extern Il2CppCodeGenString* _stringLiteral4155532722;
extern Il2CppCodeGenString* _stringLiteral580173191;
extern Il2CppCodeGenString* _stringLiteral4249871051;
extern Il2CppCodeGenString* _stringLiteral2562826957;
extern Il2CppCodeGenString* _stringLiteral2562827420;
extern Il2CppCodeGenString* _stringLiteral492701940;
extern Il2CppCodeGenString* _stringLiteral492702403;
extern Il2CppCodeGenString* _stringLiteral1177873969;
extern Il2CppCodeGenString* _stringLiteral1949211150;
extern Il2CppCodeGenString* _stringLiteral1949226429;
extern Il2CppCodeGenString* _stringLiteral2931642683;
extern Il2CppCodeGenString* _stringLiteral2931657962;
extern Il2CppCodeGenString* _stringLiteral381169818;
extern Il2CppCodeGenString* _stringLiteral3919028385;
extern Il2CppCodeGenString* _stringLiteral1197692486;
extern Il2CppCodeGenString* _stringLiteral3021628310;
extern Il2CppCodeGenString* _stringLiteral1858828876;
extern Il2CppCodeGenString* _stringLiteral1858828893;
extern Il2CppCodeGenString* _stringLiteral4231481871;
extern Il2CppCodeGenString* _stringLiteral4231481888;
extern Il2CppCodeGenString* _stringLiteral1023736718;
extern Il2CppCodeGenString* _stringLiteral1168705793;
extern Il2CppCodeGenString* _stringLiteral1168706256;
extern Il2CppCodeGenString* _stringLiteral3187195076;
extern Il2CppCodeGenString* _stringLiteral3187195539;
extern Il2CppCodeGenString* _stringLiteral2446678658;
extern Il2CppCodeGenString* _stringLiteral1126264221;
extern Il2CppCodeGenString* _stringLiteral1126264225;
extern Il2CppCodeGenString* _stringLiteral1529548748;
extern Il2CppCodeGenString* _stringLiteral1529548752;
extern Il2CppCodeGenString* _stringLiteral366749334;
extern Il2CppCodeGenString* _stringLiteral366749338;
extern Il2CppCodeGenString* _stringLiteral2336117802;
extern Il2CppCodeGenString* _stringLiteral3255745202;
extern Il2CppCodeGenString* _stringLiteral366749343;
extern Il2CppCodeGenString* _stringLiteral2336117811;
extern Il2CppCodeGenString* _stringLiteral448491076;
extern Il2CppCodeGenString* _stringLiteral3365436115;
extern Il2CppCodeGenString* _stringLiteral1151034034;
extern Il2CppCodeGenString* _stringLiteral1554318561;
extern Il2CppCodeGenString* _stringLiteral391519147;
extern Il2CppCodeGenString* _stringLiteral2360887615;
extern Il2CppCodeGenString* _stringLiteral391519138;
extern Il2CppCodeGenString* _stringLiteral2360887606;
extern Il2CppCodeGenString* _stringLiteral292744773;
extern Il2CppCodeGenString* _stringLiteral2309168132;
extern Il2CppCodeGenString* _stringLiteral2309167540;
extern Il2CppCodeGenString* _stringLiteral339798803;
extern Il2CppCodeGenString* _stringLiteral3236305790;
extern Il2CppCodeGenString* _stringLiteral3021628826;
extern Il2CppCodeGenString* _stringLiteral3332181807;
extern Il2CppCodeGenString* _stringLiteral3068682295;
extern Il2CppCodeGenString* _stringLiteral381169821;
extern Il2CppCodeGenString* _stringLiteral1502599105;
extern Il2CppCodeGenString* _stringLiteral1905883611;
extern Il2CppCodeGenString* _stringLiteral1905883589;
extern Il2CppCodeGenString* _stringLiteral3155263474;
extern Il2CppCodeGenString* _stringLiteral3021628428;
extern Il2CppCodeGenString* _stringLiteral1502598673;
extern Il2CppCodeGenString* _stringLiteral762051712;
extern Il2CppCodeGenString* _stringLiteral762051709;
extern Il2CppCodeGenString* _stringLiteral762051707;
extern Il2CppCodeGenString* _stringLiteral762051719;
extern Il2CppCodeGenString* _stringLiteral2684366008;
extern Il2CppCodeGenString* _stringLiteral2684366020;
extern Il2CppCodeGenString* _stringLiteral3443880895;
extern Il2CppCodeGenString* _stringLiteral3443880907;
extern Il2CppCodeGenString* _stringLiteral119238135;
extern Il2CppCodeGenString* _stringLiteral2710897270;
extern Il2CppCodeGenString* _stringLiteral4182611163;
extern Il2CppCodeGenString* _stringLiteral2307351665;
extern Il2CppCodeGenString* _stringLiteral2148391703;
extern Il2CppCodeGenString* _stringLiteral807095503;
extern Il2CppCodeGenString* _stringLiteral1729362418;
extern Il2CppCodeGenString* _stringLiteral2993908237;
extern Il2CppCodeGenString* _stringLiteral2979673950;
extern Il2CppCodeGenString* _stringLiteral2697347422;
extern Il2CppCodeGenString* _stringLiteral2663581612;
extern Il2CppCodeGenString* _stringLiteral1408556295;
extern Il2CppCodeGenString* _stringLiteral627234437;
extern Il2CppCodeGenString* _stringLiteral1563015653;
extern Il2CppCodeGenString* _stringLiteral3457282118;
extern Il2CppCodeGenString* _stringLiteral3082391656;
extern Il2CppCodeGenString* _stringLiteral2146264690;
extern Il2CppCodeGenString* _stringLiteral330911302;
extern Il2CppCodeGenString* _stringLiteral330911141;
extern Il2CppCodeGenString* _stringLiteral330910955;
extern Il2CppCodeGenString* _stringLiteral330910815;
extern Il2CppCodeGenString* _stringLiteral3202370362;
extern Il2CppCodeGenString* _stringLiteral3202370201;
extern Il2CppCodeGenString* _stringLiteral3202370015;
extern Il2CppCodeGenString* _stringLiteral3202369875;
extern Il2CppCodeGenString* _stringLiteral1778729099;
extern Il2CppCodeGenString* _stringLiteral339994567;
extern Il2CppCodeGenString* _stringLiteral1502598545;
extern Il2CppCodeGenString* _stringLiteral2477512525;
extern Il2CppCodeGenString* _stringLiteral1453727839;
extern Il2CppCodeGenString* _stringLiteral1689674280;
extern Il2CppCodeGenString* _stringLiteral2559449315;
extern Il2CppCodeGenString* _stringLiteral4172587423;
extern Il2CppCodeGenString* _stringLiteral2559449314;
extern Il2CppCodeGenString* _stringLiteral4172587422;
extern Il2CppCodeGenString* _stringLiteral2559449312;
extern Il2CppCodeGenString* _stringLiteral4172587420;
extern Il2CppCodeGenString* _stringLiteral2559449324;
extern Il2CppCodeGenString* _stringLiteral178545620;
extern Il2CppCodeGenString* _stringLiteral3769302893;
extern Il2CppCodeGenString* _stringLiteral3769302905;
extern Il2CppCodeGenString* _stringLiteral1684498374;
extern Il2CppCodeGenString* _stringLiteral3073335381;
extern Il2CppCodeGenString* _stringLiteral1180572518;
extern Il2CppCodeGenString* _stringLiteral1180572519;
extern Il2CppCodeGenString* _stringLiteral1180572521;
extern Il2CppCodeGenString* _stringLiteral1180572509;
extern Il2CppCodeGenString* _stringLiteral3815347542;
extern Il2CppCodeGenString* _stringLiteral3815347530;
extern Il2CppCodeGenString* _stringLiteral2501047121;
extern Il2CppCodeGenString* _stringLiteral4090385577;
extern Il2CppCodeGenString* _stringLiteral1314794950;
extern Il2CppCodeGenString* _stringLiteral1002339398;
extern Il2CppCodeGenString* _stringLiteral782255611;
extern Il2CppCodeGenString* _stringLiteral4176545519;
extern Il2CppCodeGenString* _stringLiteral782255608;
extern Il2CppCodeGenString* _stringLiteral4176545516;
extern Il2CppCodeGenString* _stringLiteral782255606;
extern Il2CppCodeGenString* _stringLiteral4176545514;
extern Il2CppCodeGenString* _stringLiteral782255602;
extern Il2CppCodeGenString* _stringLiteral4176545510;
extern Il2CppCodeGenString* _stringLiteral3401875426;
extern Il2CppCodeGenString* _stringLiteral3514721169;
extern Il2CppCodeGenString* _stringLiteral1157131249;
extern Il2CppCodeGenString* _stringLiteral3161666159;
extern Il2CppCodeGenString* _stringLiteral3443880897;
extern Il2CppCodeGenString* _stringLiteral3443880900;
extern Il2CppCodeGenString* _stringLiteral3162669967;
extern Il2CppCodeGenString* _stringLiteral3715361322;
extern Il2CppCodeGenString* _stringLiteral2814683934;
extern Il2CppCodeGenString* _stringLiteral4076537830;
extern Il2CppCodeGenString* _stringLiteral2716565177;
extern Il2CppCodeGenString* _stringLiteral2807062197;
extern Il2CppCodeGenString* _stringLiteral3530008064;
extern Il2CppCodeGenString* _stringLiteral2807702533;
extern Il2CppCodeGenString* _stringLiteral3551139248;
extern Il2CppCodeGenString* _stringLiteral876476942;
extern Il2CppCodeGenString* _stringLiteral2448513723;
extern Il2CppCodeGenString* _stringLiteral3753663670;
extern Il2CppCodeGenString* _stringLiteral480825959;
extern Il2CppCodeGenString* _stringLiteral1549531859;
extern Il2CppCodeGenString* _stringLiteral88067259;
extern Il2CppCodeGenString* _stringLiteral88067260;
extern Il2CppCodeGenString* _stringLiteral88067257;
extern Il2CppCodeGenString* _stringLiteral88067258;
extern Il2CppCodeGenString* _stringLiteral88067255;
extern Il2CppCodeGenString* _stringLiteral88067256;
extern Il2CppCodeGenString* _stringLiteral88067253;
extern Il2CppCodeGenString* _stringLiteral1884584617;
extern Il2CppCodeGenString* _stringLiteral47382726;
extern Il2CppCodeGenString* _stringLiteral3021628343;
extern Il2CppCodeGenString* _stringLiteral1858828924;
extern Il2CppCodeGenString* _stringLiteral1168707281;
extern Il2CppCodeGenString* _stringLiteral4231481919;
extern Il2CppCodeGenString* _stringLiteral3187196564;
extern Il2CppCodeGenString* _stringLiteral2307351242;
extern Il2CppCodeGenString* _stringLiteral1933872749;
extern Il2CppCodeGenString* _stringLiteral3470150638;
extern Il2CppCodeGenString* _stringLiteral3660249737;
extern Il2CppCodeGenString* _stringLiteral2858725215;
extern Il2CppCodeGenString* _stringLiteral4229665356;
extern Il2CppCodeGenString* _stringLiteral3236762065;
extern Il2CppCodeGenString* _stringLiteral2193318831;
extern Il2CppCodeGenString* _stringLiteral4185878269;
extern Il2CppCodeGenString* _stringLiteral2034147359;
extern Il2CppCodeGenString* _stringLiteral3098091945;
extern Il2CppCodeGenString* _stringLiteral1186066636;
extern Il2CppCodeGenString* _stringLiteral593465470;
extern Il2CppCodeGenString* _stringLiteral3094106929;
extern Il2CppCodeGenString* _stringLiteral2255081476;
extern Il2CppCodeGenString* _stringLiteral1548097516;
extern Il2CppCodeGenString* _stringLiteral318169515;
extern Il2CppCodeGenString* _stringLiteral2819848329;
extern Il2CppCodeGenString* _stringLiteral365513102;
extern Il2CppCodeGenString* _stringLiteral4255559471;
extern Il2CppCodeGenString* _stringLiteral3626041882;
extern const uint32_t OpCodeNames__cctor_m2437275178_MetadataUsageId;
extern "C"  void OpCodeNames__cctor_m2437275178 (Il2CppObject * __this /* static, unused */, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (OpCodeNames__cctor_m2437275178_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		StringU5BU5D_t1642385972* L_0 = ((StringU5BU5D_t1642385972*)SZArrayNew(StringU5BU5D_t1642385972_il2cpp_TypeInfo_var, (uint32_t)((int32_t)304)));
		NullCheck(L_0);
		ArrayElementTypeCheck (L_0, _stringLiteral1502598669);
		(L_0)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)_stringLiteral1502598669);
		StringU5BU5D_t1642385972* L_1 = L_0;
		NullCheck(L_1);
		ArrayElementTypeCheck (L_1, _stringLiteral1185218007);
		(L_1)->SetAt(static_cast<il2cpp_array_size_t>(1), (String_t*)_stringLiteral1185218007);
		StringU5BU5D_t1642385972* L_2 = L_1;
		NullCheck(L_2);
		ArrayElementTypeCheck (L_2, _stringLiteral2751713072);
		(L_2)->SetAt(static_cast<il2cpp_array_size_t>(2), (String_t*)_stringLiteral2751713072);
		StringU5BU5D_t1642385972* L_3 = L_2;
		NullCheck(L_3);
		ArrayElementTypeCheck (L_3, _stringLiteral2751713071);
		(L_3)->SetAt(static_cast<il2cpp_array_size_t>(3), (String_t*)_stringLiteral2751713071);
		StringU5BU5D_t1642385972* L_4 = L_3;
		NullCheck(L_4);
		ArrayElementTypeCheck (L_4, _stringLiteral2751713070);
		(L_4)->SetAt(static_cast<il2cpp_array_size_t>(4), (String_t*)_stringLiteral2751713070);
		StringU5BU5D_t1642385972* L_5 = L_4;
		NullCheck(L_5);
		ArrayElementTypeCheck (L_5, _stringLiteral2751713069);
		(L_5)->SetAt(static_cast<il2cpp_array_size_t>(5), (String_t*)_stringLiteral2751713069);
		StringU5BU5D_t1642385972* L_6 = L_5;
		NullCheck(L_6);
		ArrayElementTypeCheck (L_6, _stringLiteral264743190);
		(L_6)->SetAt(static_cast<il2cpp_array_size_t>(6), (String_t*)_stringLiteral264743190);
		StringU5BU5D_t1642385972* L_7 = L_6;
		NullCheck(L_7);
		ArrayElementTypeCheck (L_7, _stringLiteral264743191);
		(L_7)->SetAt(static_cast<il2cpp_array_size_t>(7), (String_t*)_stringLiteral264743191);
		StringU5BU5D_t1642385972* L_8 = L_7;
		NullCheck(L_8);
		ArrayElementTypeCheck (L_8, _stringLiteral264743188);
		(L_8)->SetAt(static_cast<il2cpp_array_size_t>(8), (String_t*)_stringLiteral264743188);
		StringU5BU5D_t1642385972* L_9 = L_8;
		NullCheck(L_9);
		ArrayElementTypeCheck (L_9, _stringLiteral264743189);
		(L_9)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)9)), (String_t*)_stringLiteral264743189);
		StringU5BU5D_t1642385972* L_10 = L_9;
		NullCheck(L_10);
		ArrayElementTypeCheck (L_10, _stringLiteral1784784505);
		(L_10)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)10)), (String_t*)_stringLiteral1784784505);
		StringU5BU5D_t1642385972* L_11 = L_10;
		NullCheck(L_11);
		ArrayElementTypeCheck (L_11, _stringLiteral1784784504);
		(L_11)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)11)), (String_t*)_stringLiteral1784784504);
		StringU5BU5D_t1642385972* L_12 = L_11;
		NullCheck(L_12);
		ArrayElementTypeCheck (L_12, _stringLiteral1784784507);
		(L_12)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)12)), (String_t*)_stringLiteral1784784507);
		StringU5BU5D_t1642385972* L_13 = L_12;
		NullCheck(L_13);
		ArrayElementTypeCheck (L_13, _stringLiteral1784784506);
		(L_13)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)13)), (String_t*)_stringLiteral1784784506);
		StringU5BU5D_t1642385972* L_14 = L_13;
		NullCheck(L_14);
		ArrayElementTypeCheck (L_14, _stringLiteral2751713005);
		(L_14)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)14)), (String_t*)_stringLiteral2751713005);
		StringU5BU5D_t1642385972* L_15 = L_14;
		NullCheck(L_15);
		ArrayElementTypeCheck (L_15, _stringLiteral1100455270);
		(L_15)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)15)), (String_t*)_stringLiteral1100455270);
		StringU5BU5D_t1642385972* L_16 = L_15;
		NullCheck(L_16);
		ArrayElementTypeCheck (L_16, _stringLiteral4049510564);
		(L_16)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)16)), (String_t*)_stringLiteral4049510564);
		StringU5BU5D_t1642385972* L_17 = L_16;
		NullCheck(L_17);
		ArrayElementTypeCheck (L_17, _stringLiteral264743253);
		(L_17)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)17)), (String_t*)_stringLiteral264743253);
		StringU5BU5D_t1642385972* L_18 = L_17;
		NullCheck(L_18);
		ArrayElementTypeCheck (L_18, _stringLiteral2638390804);
		(L_18)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)18)), (String_t*)_stringLiteral2638390804);
		StringU5BU5D_t1642385972* L_19 = L_18;
		NullCheck(L_19);
		ArrayElementTypeCheck (L_19, _stringLiteral1784784442);
		(L_19)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)19)), (String_t*)_stringLiteral1784784442);
		StringU5BU5D_t1642385972* L_20 = L_19;
		NullCheck(L_20);
		ArrayElementTypeCheck (L_20, _stringLiteral3082303075);
		(L_20)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)20)), (String_t*)_stringLiteral3082303075);
		StringU5BU5D_t1642385972* L_21 = L_20;
		NullCheck(L_21);
		ArrayElementTypeCheck (L_21, _stringLiteral1962649898);
		(L_21)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)21)), (String_t*)_stringLiteral1962649898);
		StringU5BU5D_t1642385972* L_22 = L_21;
		NullCheck(L_22);
		ArrayElementTypeCheck (L_22, _stringLiteral980025156);
		(L_22)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)22)), (String_t*)_stringLiteral980025156);
		StringU5BU5D_t1642385972* L_23 = L_22;
		NullCheck(L_23);
		ArrayElementTypeCheck (L_23, _stringLiteral3708908511);
		(L_23)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)23)), (String_t*)_stringLiteral3708908511);
		StringU5BU5D_t1642385972* L_24 = L_23;
		NullCheck(L_24);
		ArrayElementTypeCheck (L_24, _stringLiteral2142824570);
		(L_24)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)24)), (String_t*)_stringLiteral2142824570);
		StringU5BU5D_t1642385972* L_25 = L_24;
		NullCheck(L_25);
		ArrayElementTypeCheck (L_25, _stringLiteral576740629);
		(L_25)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)25)), (String_t*)_stringLiteral576740629);
		StringU5BU5D_t1642385972* L_26 = L_25;
		NullCheck(L_26);
		ArrayElementTypeCheck (L_26, _stringLiteral2949393624);
		(L_26)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)26)), (String_t*)_stringLiteral2949393624);
		StringU5BU5D_t1642385972* L_27 = L_26;
		NullCheck(L_27);
		ArrayElementTypeCheck (L_27, _stringLiteral1383309683);
		(L_27)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)27)), (String_t*)_stringLiteral1383309683);
		StringU5BU5D_t1642385972* L_28 = L_27;
		NullCheck(L_28);
		ArrayElementTypeCheck (L_28, _stringLiteral4112193038);
		(L_28)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)28)), (String_t*)_stringLiteral4112193038);
		StringU5BU5D_t1642385972* L_29 = L_28;
		NullCheck(L_29);
		ArrayElementTypeCheck (L_29, _stringLiteral2546109097);
		(L_29)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)29)), (String_t*)_stringLiteral2546109097);
		StringU5BU5D_t1642385972* L_30 = L_29;
		NullCheck(L_30);
		ArrayElementTypeCheck (L_30, _stringLiteral1336255516);
		(L_30)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)30)), (String_t*)_stringLiteral1336255516);
		StringU5BU5D_t1642385972* L_31 = L_30;
		NullCheck(L_31);
		ArrayElementTypeCheck (L_31, _stringLiteral3426583509);
		(L_31)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)31)), (String_t*)_stringLiteral3426583509);
		StringU5BU5D_t1642385972* L_32 = L_31;
		NullCheck(L_32);
		ArrayElementTypeCheck (L_32, _stringLiteral3869444298);
		(L_32)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)32)), (String_t*)_stringLiteral3869444298);
		StringU5BU5D_t1642385972* L_33 = L_32;
		NullCheck(L_33);
		ArrayElementTypeCheck (L_33, _stringLiteral1900075830);
		(L_33)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)33)), (String_t*)_stringLiteral1900075830);
		StringU5BU5D_t1642385972* L_34 = L_33;
		NullCheck(L_34);
		ArrayElementTypeCheck (L_34, _stringLiteral3869444319);
		(L_34)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)34)), (String_t*)_stringLiteral3869444319);
		StringU5BU5D_t1642385972* L_35 = L_34;
		NullCheck(L_35);
		ArrayElementTypeCheck (L_35, _stringLiteral1900075851);
		(L_35)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)35)), (String_t*)_stringLiteral1900075851);
		StringU5BU5D_t1642385972* L_36 = L_35;
		NullCheck(L_36);
		ArrayElementTypeCheck (L_36, _stringLiteral2309167265);
		(L_36)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)37)), (String_t*)_stringLiteral2309167265);
		StringU5BU5D_t1642385972* L_37 = L_36;
		NullCheck(L_37);
		ArrayElementTypeCheck (L_37, _stringLiteral1502598839);
		(L_37)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)38)), (String_t*)_stringLiteral1502598839);
		StringU5BU5D_t1642385972* L_38 = L_37;
		NullCheck(L_38);
		ArrayElementTypeCheck (L_38, _stringLiteral2665398215);
		(L_38)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)39)), (String_t*)_stringLiteral2665398215);
		StringU5BU5D_t1642385972* L_39 = L_38;
		NullCheck(L_39);
		ArrayElementTypeCheck (L_39, _stringLiteral405904562);
		(L_39)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)40)), (String_t*)_stringLiteral405904562);
		StringU5BU5D_t1642385972* L_40 = L_39;
		NullCheck(L_40);
		ArrayElementTypeCheck (L_40, _stringLiteral593459723);
		(L_40)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)41)), (String_t*)_stringLiteral593459723);
		StringU5BU5D_t1642385972* L_41 = L_40;
		NullCheck(L_41);
		ArrayElementTypeCheck (L_41, _stringLiteral3021628803);
		(L_41)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)42)), (String_t*)_stringLiteral3021628803);
		StringU5BU5D_t1642385972* L_42 = L_41;
		NullCheck(L_42);
		ArrayElementTypeCheck (L_42, _stringLiteral2872924125);
		(L_42)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)43)), (String_t*)_stringLiteral2872924125);
		StringU5BU5D_t1642385972* L_43 = L_42;
		NullCheck(L_43);
		ArrayElementTypeCheck (L_43, _stringLiteral4155532722);
		(L_43)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)44)), (String_t*)_stringLiteral4155532722);
		StringU5BU5D_t1642385972* L_44 = L_43;
		NullCheck(L_44);
		ArrayElementTypeCheck (L_44, _stringLiteral580173191);
		(L_44)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)45)), (String_t*)_stringLiteral580173191);
		StringU5BU5D_t1642385972* L_45 = L_44;
		NullCheck(L_45);
		ArrayElementTypeCheck (L_45, _stringLiteral4249871051);
		(L_45)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)46)), (String_t*)_stringLiteral4249871051);
		StringU5BU5D_t1642385972* L_46 = L_45;
		NullCheck(L_46);
		ArrayElementTypeCheck (L_46, _stringLiteral2562826957);
		(L_46)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)47)), (String_t*)_stringLiteral2562826957);
		StringU5BU5D_t1642385972* L_47 = L_46;
		NullCheck(L_47);
		ArrayElementTypeCheck (L_47, _stringLiteral2562827420);
		(L_47)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)48)), (String_t*)_stringLiteral2562827420);
		StringU5BU5D_t1642385972* L_48 = L_47;
		NullCheck(L_48);
		ArrayElementTypeCheck (L_48, _stringLiteral492701940);
		(L_48)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)49)), (String_t*)_stringLiteral492701940);
		StringU5BU5D_t1642385972* L_49 = L_48;
		NullCheck(L_49);
		ArrayElementTypeCheck (L_49, _stringLiteral492702403);
		(L_49)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)50)), (String_t*)_stringLiteral492702403);
		StringU5BU5D_t1642385972* L_50 = L_49;
		NullCheck(L_50);
		ArrayElementTypeCheck (L_50, _stringLiteral1177873969);
		(L_50)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)51)), (String_t*)_stringLiteral1177873969);
		StringU5BU5D_t1642385972* L_51 = L_50;
		NullCheck(L_51);
		ArrayElementTypeCheck (L_51, _stringLiteral1949211150);
		(L_51)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)52)), (String_t*)_stringLiteral1949211150);
		StringU5BU5D_t1642385972* L_52 = L_51;
		NullCheck(L_52);
		ArrayElementTypeCheck (L_52, _stringLiteral1949226429);
		(L_52)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)53)), (String_t*)_stringLiteral1949226429);
		StringU5BU5D_t1642385972* L_53 = L_52;
		NullCheck(L_53);
		ArrayElementTypeCheck (L_53, _stringLiteral2931642683);
		(L_53)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)54)), (String_t*)_stringLiteral2931642683);
		StringU5BU5D_t1642385972* L_54 = L_53;
		NullCheck(L_54);
		ArrayElementTypeCheck (L_54, _stringLiteral2931657962);
		(L_54)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)55)), (String_t*)_stringLiteral2931657962);
		StringU5BU5D_t1642385972* L_55 = L_54;
		NullCheck(L_55);
		ArrayElementTypeCheck (L_55, _stringLiteral381169818);
		(L_55)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)56)), (String_t*)_stringLiteral381169818);
		StringU5BU5D_t1642385972* L_56 = L_55;
		NullCheck(L_56);
		ArrayElementTypeCheck (L_56, _stringLiteral3919028385);
		(L_56)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)57)), (String_t*)_stringLiteral3919028385);
		StringU5BU5D_t1642385972* L_57 = L_56;
		NullCheck(L_57);
		ArrayElementTypeCheck (L_57, _stringLiteral1197692486);
		(L_57)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)58)), (String_t*)_stringLiteral1197692486);
		StringU5BU5D_t1642385972* L_58 = L_57;
		NullCheck(L_58);
		ArrayElementTypeCheck (L_58, _stringLiteral3021628310);
		(L_58)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)59)), (String_t*)_stringLiteral3021628310);
		StringU5BU5D_t1642385972* L_59 = L_58;
		NullCheck(L_59);
		ArrayElementTypeCheck (L_59, _stringLiteral1858828876);
		(L_59)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)60)), (String_t*)_stringLiteral1858828876);
		StringU5BU5D_t1642385972* L_60 = L_59;
		NullCheck(L_60);
		ArrayElementTypeCheck (L_60, _stringLiteral1858828893);
		(L_60)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)61)), (String_t*)_stringLiteral1858828893);
		StringU5BU5D_t1642385972* L_61 = L_60;
		NullCheck(L_61);
		ArrayElementTypeCheck (L_61, _stringLiteral4231481871);
		(L_61)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)62)), (String_t*)_stringLiteral4231481871);
		StringU5BU5D_t1642385972* L_62 = L_61;
		NullCheck(L_62);
		ArrayElementTypeCheck (L_62, _stringLiteral4231481888);
		(L_62)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)63)), (String_t*)_stringLiteral4231481888);
		StringU5BU5D_t1642385972* L_63 = L_62;
		NullCheck(L_63);
		ArrayElementTypeCheck (L_63, _stringLiteral1023736718);
		(L_63)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)64)), (String_t*)_stringLiteral1023736718);
		StringU5BU5D_t1642385972* L_64 = L_63;
		NullCheck(L_64);
		ArrayElementTypeCheck (L_64, _stringLiteral1168705793);
		(L_64)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)65)), (String_t*)_stringLiteral1168705793);
		StringU5BU5D_t1642385972* L_65 = L_64;
		NullCheck(L_65);
		ArrayElementTypeCheck (L_65, _stringLiteral1168706256);
		(L_65)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)66)), (String_t*)_stringLiteral1168706256);
		StringU5BU5D_t1642385972* L_66 = L_65;
		NullCheck(L_66);
		ArrayElementTypeCheck (L_66, _stringLiteral3187195076);
		(L_66)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)67)), (String_t*)_stringLiteral3187195076);
		StringU5BU5D_t1642385972* L_67 = L_66;
		NullCheck(L_67);
		ArrayElementTypeCheck (L_67, _stringLiteral3187195539);
		(L_67)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)68)), (String_t*)_stringLiteral3187195539);
		StringU5BU5D_t1642385972* L_68 = L_67;
		NullCheck(L_68);
		ArrayElementTypeCheck (L_68, _stringLiteral2446678658);
		(L_68)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)69)), (String_t*)_stringLiteral2446678658);
		StringU5BU5D_t1642385972* L_69 = L_68;
		NullCheck(L_69);
		ArrayElementTypeCheck (L_69, _stringLiteral1126264221);
		(L_69)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)70)), (String_t*)_stringLiteral1126264221);
		StringU5BU5D_t1642385972* L_70 = L_69;
		NullCheck(L_70);
		ArrayElementTypeCheck (L_70, _stringLiteral1126264225);
		(L_70)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)71)), (String_t*)_stringLiteral1126264225);
		StringU5BU5D_t1642385972* L_71 = L_70;
		NullCheck(L_71);
		ArrayElementTypeCheck (L_71, _stringLiteral1529548748);
		(L_71)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)72)), (String_t*)_stringLiteral1529548748);
		StringU5BU5D_t1642385972* L_72 = L_71;
		NullCheck(L_72);
		ArrayElementTypeCheck (L_72, _stringLiteral1529548752);
		(L_72)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)73)), (String_t*)_stringLiteral1529548752);
		StringU5BU5D_t1642385972* L_73 = L_72;
		NullCheck(L_73);
		ArrayElementTypeCheck (L_73, _stringLiteral366749334);
		(L_73)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)74)), (String_t*)_stringLiteral366749334);
		StringU5BU5D_t1642385972* L_74 = L_73;
		NullCheck(L_74);
		ArrayElementTypeCheck (L_74, _stringLiteral366749338);
		(L_74)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)75)), (String_t*)_stringLiteral366749338);
		StringU5BU5D_t1642385972* L_75 = L_74;
		NullCheck(L_75);
		ArrayElementTypeCheck (L_75, _stringLiteral2336117802);
		(L_75)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)76)), (String_t*)_stringLiteral2336117802);
		StringU5BU5D_t1642385972* L_76 = L_75;
		NullCheck(L_76);
		ArrayElementTypeCheck (L_76, _stringLiteral3255745202);
		(L_76)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)77)), (String_t*)_stringLiteral3255745202);
		StringU5BU5D_t1642385972* L_77 = L_76;
		NullCheck(L_77);
		ArrayElementTypeCheck (L_77, _stringLiteral366749343);
		(L_77)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)78)), (String_t*)_stringLiteral366749343);
		StringU5BU5D_t1642385972* L_78 = L_77;
		NullCheck(L_78);
		ArrayElementTypeCheck (L_78, _stringLiteral2336117811);
		(L_78)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)79)), (String_t*)_stringLiteral2336117811);
		StringU5BU5D_t1642385972* L_79 = L_78;
		NullCheck(L_79);
		ArrayElementTypeCheck (L_79, _stringLiteral448491076);
		(L_79)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)80)), (String_t*)_stringLiteral448491076);
		StringU5BU5D_t1642385972* L_80 = L_79;
		NullCheck(L_80);
		ArrayElementTypeCheck (L_80, _stringLiteral3365436115);
		(L_80)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)81)), (String_t*)_stringLiteral3365436115);
		StringU5BU5D_t1642385972* L_81 = L_80;
		NullCheck(L_81);
		ArrayElementTypeCheck (L_81, _stringLiteral1151034034);
		(L_81)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)82)), (String_t*)_stringLiteral1151034034);
		StringU5BU5D_t1642385972* L_82 = L_81;
		NullCheck(L_82);
		ArrayElementTypeCheck (L_82, _stringLiteral1554318561);
		(L_82)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)83)), (String_t*)_stringLiteral1554318561);
		StringU5BU5D_t1642385972* L_83 = L_82;
		NullCheck(L_83);
		ArrayElementTypeCheck (L_83, _stringLiteral391519147);
		(L_83)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)84)), (String_t*)_stringLiteral391519147);
		StringU5BU5D_t1642385972* L_84 = L_83;
		NullCheck(L_84);
		ArrayElementTypeCheck (L_84, _stringLiteral2360887615);
		(L_84)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)85)), (String_t*)_stringLiteral2360887615);
		StringU5BU5D_t1642385972* L_85 = L_84;
		NullCheck(L_85);
		ArrayElementTypeCheck (L_85, _stringLiteral391519138);
		(L_85)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)86)), (String_t*)_stringLiteral391519138);
		StringU5BU5D_t1642385972* L_86 = L_85;
		NullCheck(L_86);
		ArrayElementTypeCheck (L_86, _stringLiteral2360887606);
		(L_86)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)87)), (String_t*)_stringLiteral2360887606);
		StringU5BU5D_t1642385972* L_87 = L_86;
		NullCheck(L_87);
		ArrayElementTypeCheck (L_87, _stringLiteral292744773);
		(L_87)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)88)), (String_t*)_stringLiteral292744773);
		StringU5BU5D_t1642385972* L_88 = L_87;
		NullCheck(L_88);
		ArrayElementTypeCheck (L_88, _stringLiteral2309168132);
		(L_88)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)89)), (String_t*)_stringLiteral2309168132);
		StringU5BU5D_t1642385972* L_89 = L_88;
		NullCheck(L_89);
		ArrayElementTypeCheck (L_89, _stringLiteral2309167540);
		(L_89)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)90)), (String_t*)_stringLiteral2309167540);
		StringU5BU5D_t1642385972* L_90 = L_89;
		NullCheck(L_90);
		ArrayElementTypeCheck (L_90, _stringLiteral339798803);
		(L_90)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)91)), (String_t*)_stringLiteral339798803);
		StringU5BU5D_t1642385972* L_91 = L_90;
		NullCheck(L_91);
		ArrayElementTypeCheck (L_91, _stringLiteral3236305790);
		(L_91)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)92)), (String_t*)_stringLiteral3236305790);
		StringU5BU5D_t1642385972* L_92 = L_91;
		NullCheck(L_92);
		ArrayElementTypeCheck (L_92, _stringLiteral3021628826);
		(L_92)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)93)), (String_t*)_stringLiteral3021628826);
		StringU5BU5D_t1642385972* L_93 = L_92;
		NullCheck(L_93);
		ArrayElementTypeCheck (L_93, _stringLiteral3332181807);
		(L_93)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)94)), (String_t*)_stringLiteral3332181807);
		StringU5BU5D_t1642385972* L_94 = L_93;
		NullCheck(L_94);
		ArrayElementTypeCheck (L_94, _stringLiteral3068682295);
		(L_94)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)95)), (String_t*)_stringLiteral3068682295);
		StringU5BU5D_t1642385972* L_95 = L_94;
		NullCheck(L_95);
		ArrayElementTypeCheck (L_95, _stringLiteral381169821);
		(L_95)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)96)), (String_t*)_stringLiteral381169821);
		StringU5BU5D_t1642385972* L_96 = L_95;
		NullCheck(L_96);
		ArrayElementTypeCheck (L_96, _stringLiteral1502599105);
		(L_96)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)97)), (String_t*)_stringLiteral1502599105);
		StringU5BU5D_t1642385972* L_97 = L_96;
		NullCheck(L_97);
		ArrayElementTypeCheck (L_97, _stringLiteral1905883611);
		(L_97)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)98)), (String_t*)_stringLiteral1905883611);
		StringU5BU5D_t1642385972* L_98 = L_97;
		NullCheck(L_98);
		ArrayElementTypeCheck (L_98, _stringLiteral1905883589);
		(L_98)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)99)), (String_t*)_stringLiteral1905883589);
		StringU5BU5D_t1642385972* L_99 = L_98;
		NullCheck(L_99);
		ArrayElementTypeCheck (L_99, _stringLiteral3155263474);
		(L_99)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)100)), (String_t*)_stringLiteral3155263474);
		StringU5BU5D_t1642385972* L_100 = L_99;
		NullCheck(L_100);
		ArrayElementTypeCheck (L_100, _stringLiteral3021628428);
		(L_100)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)101)), (String_t*)_stringLiteral3021628428);
		StringU5BU5D_t1642385972* L_101 = L_100;
		NullCheck(L_101);
		ArrayElementTypeCheck (L_101, _stringLiteral1502598673);
		(L_101)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)102)), (String_t*)_stringLiteral1502598673);
		StringU5BU5D_t1642385972* L_102 = L_101;
		NullCheck(L_102);
		ArrayElementTypeCheck (L_102, _stringLiteral762051712);
		(L_102)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)103)), (String_t*)_stringLiteral762051712);
		StringU5BU5D_t1642385972* L_103 = L_102;
		NullCheck(L_103);
		ArrayElementTypeCheck (L_103, _stringLiteral762051709);
		(L_103)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)104)), (String_t*)_stringLiteral762051709);
		StringU5BU5D_t1642385972* L_104 = L_103;
		NullCheck(L_104);
		ArrayElementTypeCheck (L_104, _stringLiteral762051707);
		(L_104)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)105)), (String_t*)_stringLiteral762051707);
		StringU5BU5D_t1642385972* L_105 = L_104;
		NullCheck(L_105);
		ArrayElementTypeCheck (L_105, _stringLiteral762051719);
		(L_105)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)106)), (String_t*)_stringLiteral762051719);
		StringU5BU5D_t1642385972* L_106 = L_105;
		NullCheck(L_106);
		ArrayElementTypeCheck (L_106, _stringLiteral2684366008);
		(L_106)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)107)), (String_t*)_stringLiteral2684366008);
		StringU5BU5D_t1642385972* L_107 = L_106;
		NullCheck(L_107);
		ArrayElementTypeCheck (L_107, _stringLiteral2684366020);
		(L_107)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)108)), (String_t*)_stringLiteral2684366020);
		StringU5BU5D_t1642385972* L_108 = L_107;
		NullCheck(L_108);
		ArrayElementTypeCheck (L_108, _stringLiteral3443880895);
		(L_108)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)109)), (String_t*)_stringLiteral3443880895);
		StringU5BU5D_t1642385972* L_109 = L_108;
		NullCheck(L_109);
		ArrayElementTypeCheck (L_109, _stringLiteral3443880907);
		(L_109)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)110)), (String_t*)_stringLiteral3443880907);
		StringU5BU5D_t1642385972* L_110 = L_109;
		NullCheck(L_110);
		ArrayElementTypeCheck (L_110, _stringLiteral119238135);
		(L_110)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)111)), (String_t*)_stringLiteral119238135);
		StringU5BU5D_t1642385972* L_111 = L_110;
		NullCheck(L_111);
		ArrayElementTypeCheck (L_111, _stringLiteral2710897270);
		(L_111)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)112)), (String_t*)_stringLiteral2710897270);
		StringU5BU5D_t1642385972* L_112 = L_111;
		NullCheck(L_112);
		ArrayElementTypeCheck (L_112, _stringLiteral4182611163);
		(L_112)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)113)), (String_t*)_stringLiteral4182611163);
		StringU5BU5D_t1642385972* L_113 = L_112;
		NullCheck(L_113);
		ArrayElementTypeCheck (L_113, _stringLiteral2307351665);
		(L_113)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)114)), (String_t*)_stringLiteral2307351665);
		StringU5BU5D_t1642385972* L_114 = L_113;
		NullCheck(L_114);
		ArrayElementTypeCheck (L_114, _stringLiteral2148391703);
		(L_114)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)115)), (String_t*)_stringLiteral2148391703);
		StringU5BU5D_t1642385972* L_115 = L_114;
		NullCheck(L_115);
		ArrayElementTypeCheck (L_115, _stringLiteral807095503);
		(L_115)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)116)), (String_t*)_stringLiteral807095503);
		StringU5BU5D_t1642385972* L_116 = L_115;
		NullCheck(L_116);
		ArrayElementTypeCheck (L_116, _stringLiteral1729362418);
		(L_116)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)117)), (String_t*)_stringLiteral1729362418);
		StringU5BU5D_t1642385972* L_117 = L_116;
		NullCheck(L_117);
		ArrayElementTypeCheck (L_117, _stringLiteral2993908237);
		(L_117)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)118)), (String_t*)_stringLiteral2993908237);
		StringU5BU5D_t1642385972* L_118 = L_117;
		NullCheck(L_118);
		ArrayElementTypeCheck (L_118, _stringLiteral2979673950);
		(L_118)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)121)), (String_t*)_stringLiteral2979673950);
		StringU5BU5D_t1642385972* L_119 = L_118;
		NullCheck(L_119);
		ArrayElementTypeCheck (L_119, _stringLiteral2697347422);
		(L_119)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)122)), (String_t*)_stringLiteral2697347422);
		StringU5BU5D_t1642385972* L_120 = L_119;
		NullCheck(L_120);
		ArrayElementTypeCheck (L_120, _stringLiteral2663581612);
		(L_120)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)123)), (String_t*)_stringLiteral2663581612);
		StringU5BU5D_t1642385972* L_121 = L_120;
		NullCheck(L_121);
		ArrayElementTypeCheck (L_121, _stringLiteral1408556295);
		(L_121)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)124)), (String_t*)_stringLiteral1408556295);
		StringU5BU5D_t1642385972* L_122 = L_121;
		NullCheck(L_122);
		ArrayElementTypeCheck (L_122, _stringLiteral627234437);
		(L_122)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)125)), (String_t*)_stringLiteral627234437);
		StringU5BU5D_t1642385972* L_123 = L_122;
		NullCheck(L_123);
		ArrayElementTypeCheck (L_123, _stringLiteral1563015653);
		(L_123)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)126)), (String_t*)_stringLiteral1563015653);
		StringU5BU5D_t1642385972* L_124 = L_123;
		NullCheck(L_124);
		ArrayElementTypeCheck (L_124, _stringLiteral3457282118);
		(L_124)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)127)), (String_t*)_stringLiteral3457282118);
		StringU5BU5D_t1642385972* L_125 = L_124;
		NullCheck(L_125);
		ArrayElementTypeCheck (L_125, _stringLiteral3082391656);
		(L_125)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)128)), (String_t*)_stringLiteral3082391656);
		StringU5BU5D_t1642385972* L_126 = L_125;
		NullCheck(L_126);
		ArrayElementTypeCheck (L_126, _stringLiteral2146264690);
		(L_126)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)129)), (String_t*)_stringLiteral2146264690);
		StringU5BU5D_t1642385972* L_127 = L_126;
		NullCheck(L_127);
		ArrayElementTypeCheck (L_127, _stringLiteral330911302);
		(L_127)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)130)), (String_t*)_stringLiteral330911302);
		StringU5BU5D_t1642385972* L_128 = L_127;
		NullCheck(L_128);
		ArrayElementTypeCheck (L_128, _stringLiteral330911141);
		(L_128)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)131)), (String_t*)_stringLiteral330911141);
		StringU5BU5D_t1642385972* L_129 = L_128;
		NullCheck(L_129);
		ArrayElementTypeCheck (L_129, _stringLiteral330910955);
		(L_129)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)132)), (String_t*)_stringLiteral330910955);
		StringU5BU5D_t1642385972* L_130 = L_129;
		NullCheck(L_130);
		ArrayElementTypeCheck (L_130, _stringLiteral330910815);
		(L_130)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)133)), (String_t*)_stringLiteral330910815);
		StringU5BU5D_t1642385972* L_131 = L_130;
		NullCheck(L_131);
		ArrayElementTypeCheck (L_131, _stringLiteral3202370362);
		(L_131)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)134)), (String_t*)_stringLiteral3202370362);
		StringU5BU5D_t1642385972* L_132 = L_131;
		NullCheck(L_132);
		ArrayElementTypeCheck (L_132, _stringLiteral3202370201);
		(L_132)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)135)), (String_t*)_stringLiteral3202370201);
		StringU5BU5D_t1642385972* L_133 = L_132;
		NullCheck(L_133);
		ArrayElementTypeCheck (L_133, _stringLiteral3202370015);
		(L_133)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)136)), (String_t*)_stringLiteral3202370015);
		StringU5BU5D_t1642385972* L_134 = L_133;
		NullCheck(L_134);
		ArrayElementTypeCheck (L_134, _stringLiteral3202369875);
		(L_134)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)137)), (String_t*)_stringLiteral3202369875);
		StringU5BU5D_t1642385972* L_135 = L_134;
		NullCheck(L_135);
		ArrayElementTypeCheck (L_135, _stringLiteral1778729099);
		(L_135)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)138)), (String_t*)_stringLiteral1778729099);
		StringU5BU5D_t1642385972* L_136 = L_135;
		NullCheck(L_136);
		ArrayElementTypeCheck (L_136, _stringLiteral339994567);
		(L_136)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)139)), (String_t*)_stringLiteral339994567);
		StringU5BU5D_t1642385972* L_137 = L_136;
		NullCheck(L_137);
		ArrayElementTypeCheck (L_137, _stringLiteral1502598545);
		(L_137)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)140)), (String_t*)_stringLiteral1502598545);
		StringU5BU5D_t1642385972* L_138 = L_137;
		NullCheck(L_138);
		ArrayElementTypeCheck (L_138, _stringLiteral2477512525);
		(L_138)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)141)), (String_t*)_stringLiteral2477512525);
		StringU5BU5D_t1642385972* L_139 = L_138;
		NullCheck(L_139);
		ArrayElementTypeCheck (L_139, _stringLiteral1453727839);
		(L_139)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)142)), (String_t*)_stringLiteral1453727839);
		StringU5BU5D_t1642385972* L_140 = L_139;
		NullCheck(L_140);
		ArrayElementTypeCheck (L_140, _stringLiteral1689674280);
		(L_140)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)143)), (String_t*)_stringLiteral1689674280);
		StringU5BU5D_t1642385972* L_141 = L_140;
		NullCheck(L_141);
		ArrayElementTypeCheck (L_141, _stringLiteral2559449315);
		(L_141)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)144)), (String_t*)_stringLiteral2559449315);
		StringU5BU5D_t1642385972* L_142 = L_141;
		NullCheck(L_142);
		ArrayElementTypeCheck (L_142, _stringLiteral4172587423);
		(L_142)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)145)), (String_t*)_stringLiteral4172587423);
		StringU5BU5D_t1642385972* L_143 = L_142;
		NullCheck(L_143);
		ArrayElementTypeCheck (L_143, _stringLiteral2559449314);
		(L_143)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)146)), (String_t*)_stringLiteral2559449314);
		StringU5BU5D_t1642385972* L_144 = L_143;
		NullCheck(L_144);
		ArrayElementTypeCheck (L_144, _stringLiteral4172587422);
		(L_144)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)147)), (String_t*)_stringLiteral4172587422);
		StringU5BU5D_t1642385972* L_145 = L_144;
		NullCheck(L_145);
		ArrayElementTypeCheck (L_145, _stringLiteral2559449312);
		(L_145)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)148)), (String_t*)_stringLiteral2559449312);
		StringU5BU5D_t1642385972* L_146 = L_145;
		NullCheck(L_146);
		ArrayElementTypeCheck (L_146, _stringLiteral4172587420);
		(L_146)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)149)), (String_t*)_stringLiteral4172587420);
		StringU5BU5D_t1642385972* L_147 = L_146;
		NullCheck(L_147);
		ArrayElementTypeCheck (L_147, _stringLiteral2559449324);
		(L_147)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)150)), (String_t*)_stringLiteral2559449324);
		StringU5BU5D_t1642385972* L_148 = L_147;
		NullCheck(L_148);
		ArrayElementTypeCheck (L_148, _stringLiteral178545620);
		(L_148)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)151)), (String_t*)_stringLiteral178545620);
		StringU5BU5D_t1642385972* L_149 = L_148;
		NullCheck(L_149);
		ArrayElementTypeCheck (L_149, _stringLiteral3769302893);
		(L_149)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)152)), (String_t*)_stringLiteral3769302893);
		StringU5BU5D_t1642385972* L_150 = L_149;
		NullCheck(L_150);
		ArrayElementTypeCheck (L_150, _stringLiteral3769302905);
		(L_150)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)153)), (String_t*)_stringLiteral3769302905);
		StringU5BU5D_t1642385972* L_151 = L_150;
		NullCheck(L_151);
		ArrayElementTypeCheck (L_151, _stringLiteral1684498374);
		(L_151)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)154)), (String_t*)_stringLiteral1684498374);
		StringU5BU5D_t1642385972* L_152 = L_151;
		NullCheck(L_152);
		ArrayElementTypeCheck (L_152, _stringLiteral3073335381);
		(L_152)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)155)), (String_t*)_stringLiteral3073335381);
		StringU5BU5D_t1642385972* L_153 = L_152;
		NullCheck(L_153);
		ArrayElementTypeCheck (L_153, _stringLiteral1180572518);
		(L_153)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)156)), (String_t*)_stringLiteral1180572518);
		StringU5BU5D_t1642385972* L_154 = L_153;
		NullCheck(L_154);
		ArrayElementTypeCheck (L_154, _stringLiteral1180572519);
		(L_154)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)157)), (String_t*)_stringLiteral1180572519);
		StringU5BU5D_t1642385972* L_155 = L_154;
		NullCheck(L_155);
		ArrayElementTypeCheck (L_155, _stringLiteral1180572521);
		(L_155)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)158)), (String_t*)_stringLiteral1180572521);
		StringU5BU5D_t1642385972* L_156 = L_155;
		NullCheck(L_156);
		ArrayElementTypeCheck (L_156, _stringLiteral1180572509);
		(L_156)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)159)), (String_t*)_stringLiteral1180572509);
		StringU5BU5D_t1642385972* L_157 = L_156;
		NullCheck(L_157);
		ArrayElementTypeCheck (L_157, _stringLiteral3815347542);
		(L_157)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)160)), (String_t*)_stringLiteral3815347542);
		StringU5BU5D_t1642385972* L_158 = L_157;
		NullCheck(L_158);
		ArrayElementTypeCheck (L_158, _stringLiteral3815347530);
		(L_158)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)161)), (String_t*)_stringLiteral3815347530);
		StringU5BU5D_t1642385972* L_159 = L_158;
		NullCheck(L_159);
		ArrayElementTypeCheck (L_159, _stringLiteral2501047121);
		(L_159)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)162)), (String_t*)_stringLiteral2501047121);
		StringU5BU5D_t1642385972* L_160 = L_159;
		NullCheck(L_160);
		ArrayElementTypeCheck (L_160, _stringLiteral4090385577);
		(L_160)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)163)), (String_t*)_stringLiteral4090385577);
		StringU5BU5D_t1642385972* L_161 = L_160;
		NullCheck(L_161);
		ArrayElementTypeCheck (L_161, _stringLiteral1314794950);
		(L_161)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)164)), (String_t*)_stringLiteral1314794950);
		StringU5BU5D_t1642385972* L_162 = L_161;
		NullCheck(L_162);
		ArrayElementTypeCheck (L_162, _stringLiteral1002339398);
		(L_162)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)165)), (String_t*)_stringLiteral1002339398);
		StringU5BU5D_t1642385972* L_163 = L_162;
		NullCheck(L_163);
		ArrayElementTypeCheck (L_163, _stringLiteral782255611);
		(L_163)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)179)), (String_t*)_stringLiteral782255611);
		StringU5BU5D_t1642385972* L_164 = L_163;
		NullCheck(L_164);
		ArrayElementTypeCheck (L_164, _stringLiteral4176545519);
		(L_164)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)180)), (String_t*)_stringLiteral4176545519);
		StringU5BU5D_t1642385972* L_165 = L_164;
		NullCheck(L_165);
		ArrayElementTypeCheck (L_165, _stringLiteral782255608);
		(L_165)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)181)), (String_t*)_stringLiteral782255608);
		StringU5BU5D_t1642385972* L_166 = L_165;
		NullCheck(L_166);
		ArrayElementTypeCheck (L_166, _stringLiteral4176545516);
		(L_166)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)182)), (String_t*)_stringLiteral4176545516);
		StringU5BU5D_t1642385972* L_167 = L_166;
		NullCheck(L_167);
		ArrayElementTypeCheck (L_167, _stringLiteral782255606);
		(L_167)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)183)), (String_t*)_stringLiteral782255606);
		StringU5BU5D_t1642385972* L_168 = L_167;
		NullCheck(L_168);
		ArrayElementTypeCheck (L_168, _stringLiteral4176545514);
		(L_168)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)184)), (String_t*)_stringLiteral4176545514);
		StringU5BU5D_t1642385972* L_169 = L_168;
		NullCheck(L_169);
		ArrayElementTypeCheck (L_169, _stringLiteral782255602);
		(L_169)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)185)), (String_t*)_stringLiteral782255602);
		StringU5BU5D_t1642385972* L_170 = L_169;
		NullCheck(L_170);
		ArrayElementTypeCheck (L_170, _stringLiteral4176545510);
		(L_170)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)186)), (String_t*)_stringLiteral4176545510);
		StringU5BU5D_t1642385972* L_171 = L_170;
		NullCheck(L_171);
		ArrayElementTypeCheck (L_171, _stringLiteral3401875426);
		(L_171)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)194)), (String_t*)_stringLiteral3401875426);
		StringU5BU5D_t1642385972* L_172 = L_171;
		NullCheck(L_172);
		ArrayElementTypeCheck (L_172, _stringLiteral3514721169);
		(L_172)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)195)), (String_t*)_stringLiteral3514721169);
		StringU5BU5D_t1642385972* L_173 = L_172;
		NullCheck(L_173);
		ArrayElementTypeCheck (L_173, _stringLiteral1157131249);
		(L_173)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)198)), (String_t*)_stringLiteral1157131249);
		StringU5BU5D_t1642385972* L_174 = L_173;
		NullCheck(L_174);
		ArrayElementTypeCheck (L_174, _stringLiteral3161666159);
		(L_174)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)208)), (String_t*)_stringLiteral3161666159);
		StringU5BU5D_t1642385972* L_175 = L_174;
		NullCheck(L_175);
		ArrayElementTypeCheck (L_175, _stringLiteral3443880897);
		(L_175)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)209)), (String_t*)_stringLiteral3443880897);
		StringU5BU5D_t1642385972* L_176 = L_175;
		NullCheck(L_176);
		ArrayElementTypeCheck (L_176, _stringLiteral3443880900);
		(L_176)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)210)), (String_t*)_stringLiteral3443880900);
		StringU5BU5D_t1642385972* L_177 = L_176;
		NullCheck(L_177);
		ArrayElementTypeCheck (L_177, _stringLiteral3162669967);
		(L_177)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)211)), (String_t*)_stringLiteral3162669967);
		StringU5BU5D_t1642385972* L_178 = L_177;
		NullCheck(L_178);
		ArrayElementTypeCheck (L_178, _stringLiteral3715361322);
		(L_178)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)212)), (String_t*)_stringLiteral3715361322);
		StringU5BU5D_t1642385972* L_179 = L_178;
		NullCheck(L_179);
		ArrayElementTypeCheck (L_179, _stringLiteral2814683934);
		(L_179)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)213)), (String_t*)_stringLiteral2814683934);
		StringU5BU5D_t1642385972* L_180 = L_179;
		NullCheck(L_180);
		ArrayElementTypeCheck (L_180, _stringLiteral4076537830);
		(L_180)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)214)), (String_t*)_stringLiteral4076537830);
		StringU5BU5D_t1642385972* L_181 = L_180;
		NullCheck(L_181);
		ArrayElementTypeCheck (L_181, _stringLiteral2716565177);
		(L_181)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)215)), (String_t*)_stringLiteral2716565177);
		StringU5BU5D_t1642385972* L_182 = L_181;
		NullCheck(L_182);
		ArrayElementTypeCheck (L_182, _stringLiteral2807062197);
		(L_182)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)216)), (String_t*)_stringLiteral2807062197);
		StringU5BU5D_t1642385972* L_183 = L_182;
		NullCheck(L_183);
		ArrayElementTypeCheck (L_183, _stringLiteral3530008064);
		(L_183)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)217)), (String_t*)_stringLiteral3530008064);
		StringU5BU5D_t1642385972* L_184 = L_183;
		NullCheck(L_184);
		ArrayElementTypeCheck (L_184, _stringLiteral2807702533);
		(L_184)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)218)), (String_t*)_stringLiteral2807702533);
		StringU5BU5D_t1642385972* L_185 = L_184;
		NullCheck(L_185);
		ArrayElementTypeCheck (L_185, _stringLiteral3551139248);
		(L_185)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)219)), (String_t*)_stringLiteral3551139248);
		StringU5BU5D_t1642385972* L_186 = L_185;
		NullCheck(L_186);
		ArrayElementTypeCheck (L_186, _stringLiteral876476942);
		(L_186)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)220)), (String_t*)_stringLiteral876476942);
		StringU5BU5D_t1642385972* L_187 = L_186;
		NullCheck(L_187);
		ArrayElementTypeCheck (L_187, _stringLiteral2448513723);
		(L_187)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)221)), (String_t*)_stringLiteral2448513723);
		StringU5BU5D_t1642385972* L_188 = L_187;
		NullCheck(L_188);
		ArrayElementTypeCheck (L_188, _stringLiteral3753663670);
		(L_188)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)222)), (String_t*)_stringLiteral3753663670);
		StringU5BU5D_t1642385972* L_189 = L_188;
		NullCheck(L_189);
		ArrayElementTypeCheck (L_189, _stringLiteral480825959);
		(L_189)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)223)), (String_t*)_stringLiteral480825959);
		StringU5BU5D_t1642385972* L_190 = L_189;
		NullCheck(L_190);
		ArrayElementTypeCheck (L_190, _stringLiteral1549531859);
		(L_190)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)224)), (String_t*)_stringLiteral1549531859);
		StringU5BU5D_t1642385972* L_191 = L_190;
		NullCheck(L_191);
		ArrayElementTypeCheck (L_191, _stringLiteral88067259);
		(L_191)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)248)), (String_t*)_stringLiteral88067259);
		StringU5BU5D_t1642385972* L_192 = L_191;
		NullCheck(L_192);
		ArrayElementTypeCheck (L_192, _stringLiteral88067260);
		(L_192)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)249)), (String_t*)_stringLiteral88067260);
		StringU5BU5D_t1642385972* L_193 = L_192;
		NullCheck(L_193);
		ArrayElementTypeCheck (L_193, _stringLiteral88067257);
		(L_193)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)250)), (String_t*)_stringLiteral88067257);
		StringU5BU5D_t1642385972* L_194 = L_193;
		NullCheck(L_194);
		ArrayElementTypeCheck (L_194, _stringLiteral88067258);
		(L_194)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)251)), (String_t*)_stringLiteral88067258);
		StringU5BU5D_t1642385972* L_195 = L_194;
		NullCheck(L_195);
		ArrayElementTypeCheck (L_195, _stringLiteral88067255);
		(L_195)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)252)), (String_t*)_stringLiteral88067255);
		StringU5BU5D_t1642385972* L_196 = L_195;
		NullCheck(L_196);
		ArrayElementTypeCheck (L_196, _stringLiteral88067256);
		(L_196)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)253)), (String_t*)_stringLiteral88067256);
		StringU5BU5D_t1642385972* L_197 = L_196;
		NullCheck(L_197);
		ArrayElementTypeCheck (L_197, _stringLiteral88067253);
		(L_197)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)254)), (String_t*)_stringLiteral88067253);
		StringU5BU5D_t1642385972* L_198 = L_197;
		NullCheck(L_198);
		ArrayElementTypeCheck (L_198, _stringLiteral1884584617);
		(L_198)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)255)), (String_t*)_stringLiteral1884584617);
		StringU5BU5D_t1642385972* L_199 = L_198;
		NullCheck(L_199);
		ArrayElementTypeCheck (L_199, _stringLiteral47382726);
		(L_199)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)256)), (String_t*)_stringLiteral47382726);
		StringU5BU5D_t1642385972* L_200 = L_199;
		NullCheck(L_200);
		ArrayElementTypeCheck (L_200, _stringLiteral3021628343);
		(L_200)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)257)), (String_t*)_stringLiteral3021628343);
		StringU5BU5D_t1642385972* L_201 = L_200;
		NullCheck(L_201);
		ArrayElementTypeCheck (L_201, _stringLiteral1858828924);
		(L_201)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)258)), (String_t*)_stringLiteral1858828924);
		StringU5BU5D_t1642385972* L_202 = L_201;
		NullCheck(L_202);
		ArrayElementTypeCheck (L_202, _stringLiteral1168707281);
		(L_202)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)259)), (String_t*)_stringLiteral1168707281);
		StringU5BU5D_t1642385972* L_203 = L_202;
		NullCheck(L_203);
		ArrayElementTypeCheck (L_203, _stringLiteral4231481919);
		(L_203)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)260)), (String_t*)_stringLiteral4231481919);
		StringU5BU5D_t1642385972* L_204 = L_203;
		NullCheck(L_204);
		ArrayElementTypeCheck (L_204, _stringLiteral3187196564);
		(L_204)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)261)), (String_t*)_stringLiteral3187196564);
		StringU5BU5D_t1642385972* L_205 = L_204;
		NullCheck(L_205);
		ArrayElementTypeCheck (L_205, _stringLiteral2307351242);
		(L_205)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)262)), (String_t*)_stringLiteral2307351242);
		StringU5BU5D_t1642385972* L_206 = L_205;
		NullCheck(L_206);
		ArrayElementTypeCheck (L_206, _stringLiteral1933872749);
		(L_206)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)263)), (String_t*)_stringLiteral1933872749);
		StringU5BU5D_t1642385972* L_207 = L_206;
		NullCheck(L_207);
		ArrayElementTypeCheck (L_207, _stringLiteral3470150638);
		(L_207)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)265)), (String_t*)_stringLiteral3470150638);
		StringU5BU5D_t1642385972* L_208 = L_207;
		NullCheck(L_208);
		ArrayElementTypeCheck (L_208, _stringLiteral3660249737);
		(L_208)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)266)), (String_t*)_stringLiteral3660249737);
		StringU5BU5D_t1642385972* L_209 = L_208;
		NullCheck(L_209);
		ArrayElementTypeCheck (L_209, _stringLiteral2858725215);
		(L_209)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)267)), (String_t*)_stringLiteral2858725215);
		StringU5BU5D_t1642385972* L_210 = L_209;
		NullCheck(L_210);
		ArrayElementTypeCheck (L_210, _stringLiteral4229665356);
		(L_210)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)268)), (String_t*)_stringLiteral4229665356);
		StringU5BU5D_t1642385972* L_211 = L_210;
		NullCheck(L_211);
		ArrayElementTypeCheck (L_211, _stringLiteral3236762065);
		(L_211)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)269)), (String_t*)_stringLiteral3236762065);
		StringU5BU5D_t1642385972* L_212 = L_211;
		NullCheck(L_212);
		ArrayElementTypeCheck (L_212, _stringLiteral2193318831);
		(L_212)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)270)), (String_t*)_stringLiteral2193318831);
		StringU5BU5D_t1642385972* L_213 = L_212;
		NullCheck(L_213);
		ArrayElementTypeCheck (L_213, _stringLiteral4185878269);
		(L_213)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)271)), (String_t*)_stringLiteral4185878269);
		StringU5BU5D_t1642385972* L_214 = L_213;
		NullCheck(L_214);
		ArrayElementTypeCheck (L_214, _stringLiteral2034147359);
		(L_214)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)273)), (String_t*)_stringLiteral2034147359);
		StringU5BU5D_t1642385972* L_215 = L_214;
		NullCheck(L_215);
		ArrayElementTypeCheck (L_215, _stringLiteral3098091945);
		(L_215)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)274)), (String_t*)_stringLiteral3098091945);
		StringU5BU5D_t1642385972* L_216 = L_215;
		NullCheck(L_216);
		ArrayElementTypeCheck (L_216, _stringLiteral1186066636);
		(L_216)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)275)), (String_t*)_stringLiteral1186066636);
		StringU5BU5D_t1642385972* L_217 = L_216;
		NullCheck(L_217);
		ArrayElementTypeCheck (L_217, _stringLiteral593465470);
		(L_217)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)276)), (String_t*)_stringLiteral593465470);
		StringU5BU5D_t1642385972* L_218 = L_217;
		NullCheck(L_218);
		ArrayElementTypeCheck (L_218, _stringLiteral3094106929);
		(L_218)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)277)), (String_t*)_stringLiteral3094106929);
		StringU5BU5D_t1642385972* L_219 = L_218;
		NullCheck(L_219);
		ArrayElementTypeCheck (L_219, _stringLiteral2255081476);
		(L_219)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)278)), (String_t*)_stringLiteral2255081476);
		StringU5BU5D_t1642385972* L_220 = L_219;
		NullCheck(L_220);
		ArrayElementTypeCheck (L_220, _stringLiteral1548097516);
		(L_220)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)279)), (String_t*)_stringLiteral1548097516);
		StringU5BU5D_t1642385972* L_221 = L_220;
		NullCheck(L_221);
		ArrayElementTypeCheck (L_221, _stringLiteral318169515);
		(L_221)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)280)), (String_t*)_stringLiteral318169515);
		StringU5BU5D_t1642385972* L_222 = L_221;
		NullCheck(L_222);
		ArrayElementTypeCheck (L_222, _stringLiteral2819848329);
		(L_222)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)282)), (String_t*)_stringLiteral2819848329);
		StringU5BU5D_t1642385972* L_223 = L_222;
		NullCheck(L_223);
		ArrayElementTypeCheck (L_223, _stringLiteral365513102);
		(L_223)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)284)), (String_t*)_stringLiteral365513102);
		StringU5BU5D_t1642385972* L_224 = L_223;
		NullCheck(L_224);
		ArrayElementTypeCheck (L_224, _stringLiteral4255559471);
		(L_224)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)285)), (String_t*)_stringLiteral4255559471);
		StringU5BU5D_t1642385972* L_225 = L_224;
		NullCheck(L_225);
		ArrayElementTypeCheck (L_225, _stringLiteral3626041882);
		(L_225)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)286)), (String_t*)_stringLiteral3626041882);
		((OpCodeNames_t1907134268_StaticFields*)OpCodeNames_t1907134268_il2cpp_TypeInfo_var->static_fields)->set_names_0(L_225);
		return;
	}
}
// System.Void System.Reflection.Emit.OpCodes::.cctor()
extern Il2CppClass* OpCodes_t3494785031_il2cpp_TypeInfo_var;
extern const uint32_t OpCodes__cctor_m939885911_MetadataUsageId;
extern "C"  void OpCodes__cctor_m939885911 (Il2CppObject * __this /* static, unused */, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (OpCodes__cctor_m939885911_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		OpCode_t2247480392  L_0;
		memset(&L_0, 0, sizeof(L_0));
		OpCode__ctor_m3329993003(&L_0, ((int32_t)1179903), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Nop_0(L_0);
		OpCode_t2247480392  L_1;
		memset(&L_1, 0, sizeof(L_1));
		OpCode__ctor_m3329993003(&L_1, ((int32_t)1180159), ((int32_t)17106177), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Break_1(L_1);
		OpCode_t2247480392  L_2;
		memset(&L_2, 0, sizeof(L_2));
		OpCode__ctor_m3329993003(&L_2, ((int32_t)1245951), ((int32_t)84214017), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldarg_0_2(L_2);
		OpCode_t2247480392  L_3;
		memset(&L_3, 0, sizeof(L_3));
		OpCode__ctor_m3329993003(&L_3, ((int32_t)1246207), ((int32_t)84214017), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldarg_1_3(L_3);
		OpCode_t2247480392  L_4;
		memset(&L_4, 0, sizeof(L_4));
		OpCode__ctor_m3329993003(&L_4, ((int32_t)1246463), ((int32_t)84214017), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldarg_2_4(L_4);
		OpCode_t2247480392  L_5;
		memset(&L_5, 0, sizeof(L_5));
		OpCode__ctor_m3329993003(&L_5, ((int32_t)1246719), ((int32_t)84214017), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldarg_3_5(L_5);
		OpCode_t2247480392  L_6;
		memset(&L_6, 0, sizeof(L_6));
		OpCode__ctor_m3329993003(&L_6, ((int32_t)1246975), ((int32_t)84214017), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldloc_0_6(L_6);
		OpCode_t2247480392  L_7;
		memset(&L_7, 0, sizeof(L_7));
		OpCode__ctor_m3329993003(&L_7, ((int32_t)1247231), ((int32_t)84214017), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldloc_1_7(L_7);
		OpCode_t2247480392  L_8;
		memset(&L_8, 0, sizeof(L_8));
		OpCode__ctor_m3329993003(&L_8, ((int32_t)1247487), ((int32_t)84214017), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldloc_2_8(L_8);
		OpCode_t2247480392  L_9;
		memset(&L_9, 0, sizeof(L_9));
		OpCode__ctor_m3329993003(&L_9, ((int32_t)1247743), ((int32_t)84214017), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldloc_3_9(L_9);
		OpCode_t2247480392  L_10;
		memset(&L_10, 0, sizeof(L_10));
		OpCode__ctor_m3329993003(&L_10, ((int32_t)17959679), ((int32_t)84214017), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Stloc_0_10(L_10);
		OpCode_t2247480392  L_11;
		memset(&L_11, 0, sizeof(L_11));
		OpCode__ctor_m3329993003(&L_11, ((int32_t)17959935), ((int32_t)84214017), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Stloc_1_11(L_11);
		OpCode_t2247480392  L_12;
		memset(&L_12, 0, sizeof(L_12));
		OpCode__ctor_m3329993003(&L_12, ((int32_t)17960191), ((int32_t)84214017), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Stloc_2_12(L_12);
		OpCode_t2247480392  L_13;
		memset(&L_13, 0, sizeof(L_13));
		OpCode__ctor_m3329993003(&L_13, ((int32_t)17960447), ((int32_t)84214017), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Stloc_3_13(L_13);
		OpCode_t2247480392  L_14;
		memset(&L_14, 0, sizeof(L_14));
		OpCode__ctor_m3329993003(&L_14, ((int32_t)1249023), ((int32_t)85065985), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldarg_S_14(L_14);
		OpCode_t2247480392  L_15;
		memset(&L_15, 0, sizeof(L_15));
		OpCode__ctor_m3329993003(&L_15, ((int32_t)1380351), ((int32_t)85065985), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldarga_S_15(L_15);
		OpCode_t2247480392  L_16;
		memset(&L_16, 0, sizeof(L_16));
		OpCode__ctor_m3329993003(&L_16, ((int32_t)17961215), ((int32_t)85065985), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Starg_S_16(L_16);
		OpCode_t2247480392  L_17;
		memset(&L_17, 0, sizeof(L_17));
		OpCode__ctor_m3329993003(&L_17, ((int32_t)1249791), ((int32_t)85065985), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldloc_S_17(L_17);
		OpCode_t2247480392  L_18;
		memset(&L_18, 0, sizeof(L_18));
		OpCode__ctor_m3329993003(&L_18, ((int32_t)1381119), ((int32_t)85065985), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldloca_S_18(L_18);
		OpCode_t2247480392  L_19;
		memset(&L_19, 0, sizeof(L_19));
		OpCode__ctor_m3329993003(&L_19, ((int32_t)17961983), ((int32_t)85065985), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Stloc_S_19(L_19);
		OpCode_t2247480392  L_20;
		memset(&L_20, 0, sizeof(L_20));
		OpCode__ctor_m3329993003(&L_20, ((int32_t)1643775), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldnull_20(L_20);
		OpCode_t2247480392  L_21;
		memset(&L_21, 0, sizeof(L_21));
		OpCode__ctor_m3329993003(&L_21, ((int32_t)1381887), ((int32_t)84214017), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldc_I4_M1_21(L_21);
		OpCode_t2247480392  L_22;
		memset(&L_22, 0, sizeof(L_22));
		OpCode__ctor_m3329993003(&L_22, ((int32_t)1382143), ((int32_t)84214017), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldc_I4_0_22(L_22);
		OpCode_t2247480392  L_23;
		memset(&L_23, 0, sizeof(L_23));
		OpCode__ctor_m3329993003(&L_23, ((int32_t)1382399), ((int32_t)84214017), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldc_I4_1_23(L_23);
		OpCode_t2247480392  L_24;
		memset(&L_24, 0, sizeof(L_24));
		OpCode__ctor_m3329993003(&L_24, ((int32_t)1382655), ((int32_t)84214017), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldc_I4_2_24(L_24);
		OpCode_t2247480392  L_25;
		memset(&L_25, 0, sizeof(L_25));
		OpCode__ctor_m3329993003(&L_25, ((int32_t)1382911), ((int32_t)84214017), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldc_I4_3_25(L_25);
		OpCode_t2247480392  L_26;
		memset(&L_26, 0, sizeof(L_26));
		OpCode__ctor_m3329993003(&L_26, ((int32_t)1383167), ((int32_t)84214017), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldc_I4_4_26(L_26);
		OpCode_t2247480392  L_27;
		memset(&L_27, 0, sizeof(L_27));
		OpCode__ctor_m3329993003(&L_27, ((int32_t)1383423), ((int32_t)84214017), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldc_I4_5_27(L_27);
		OpCode_t2247480392  L_28;
		memset(&L_28, 0, sizeof(L_28));
		OpCode__ctor_m3329993003(&L_28, ((int32_t)1383679), ((int32_t)84214017), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldc_I4_6_28(L_28);
		OpCode_t2247480392  L_29;
		memset(&L_29, 0, sizeof(L_29));
		OpCode__ctor_m3329993003(&L_29, ((int32_t)1383935), ((int32_t)84214017), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldc_I4_7_29(L_29);
		OpCode_t2247480392  L_30;
		memset(&L_30, 0, sizeof(L_30));
		OpCode__ctor_m3329993003(&L_30, ((int32_t)1384191), ((int32_t)84214017), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldc_I4_8_30(L_30);
		OpCode_t2247480392  L_31;
		memset(&L_31, 0, sizeof(L_31));
		OpCode__ctor_m3329993003(&L_31, ((int32_t)1384447), ((int32_t)84934913), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldc_I4_S_31(L_31);
		OpCode_t2247480392  L_32;
		memset(&L_32, 0, sizeof(L_32));
		OpCode__ctor_m3329993003(&L_32, ((int32_t)1384703), ((int32_t)84018433), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldc_I4_32(L_32);
		OpCode_t2247480392  L_33;
		memset(&L_33, 0, sizeof(L_33));
		OpCode__ctor_m3329993003(&L_33, ((int32_t)1450495), ((int32_t)84083969), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldc_I8_33(L_33);
		OpCode_t2247480392  L_34;
		memset(&L_34, 0, sizeof(L_34));
		OpCode__ctor_m3329993003(&L_34, ((int32_t)1516287), ((int32_t)85001473), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldc_R4_34(L_34);
		OpCode_t2247480392  L_35;
		memset(&L_35, 0, sizeof(L_35));
		OpCode__ctor_m3329993003(&L_35, ((int32_t)1582079), ((int32_t)84346113), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldc_R8_35(L_35);
		OpCode_t2247480392  L_36;
		memset(&L_36, 0, sizeof(L_36));
		OpCode__ctor_m3329993003(&L_36, ((int32_t)18097663), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Dup_36(L_36);
		OpCode_t2247480392  L_37;
		memset(&L_37, 0, sizeof(L_37));
		OpCode__ctor_m3329993003(&L_37, ((int32_t)17966847), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Pop_37(L_37);
		OpCode_t2247480392  L_38;
		memset(&L_38, 0, sizeof(L_38));
		OpCode__ctor_m3329993003(&L_38, ((int32_t)1189887), ((int32_t)33817857), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Jmp_38(L_38);
		OpCode_t2247480392  L_39;
		memset(&L_39, 0, sizeof(L_39));
		OpCode__ctor_m3329993003(&L_39, ((int32_t)437987583), ((int32_t)33817857), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Call_39(L_39);
		OpCode_t2247480392  L_40;
		memset(&L_40, 0, sizeof(L_40));
		OpCode__ctor_m3329993003(&L_40, ((int32_t)437987839), ((int32_t)34145537), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Calli_40(L_40);
		OpCode_t2247480392  L_41;
		memset(&L_41, 0, sizeof(L_41));
		OpCode__ctor_m3329993003(&L_41, ((int32_t)437398271), ((int32_t)117769473), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ret_41(L_41);
		OpCode_t2247480392  L_42;
		memset(&L_42, 0, sizeof(L_42));
		OpCode__ctor_m3329993003(&L_42, ((int32_t)1190911), ((int32_t)983297), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Br_S_42(L_42);
		OpCode_t2247480392  L_43;
		memset(&L_43, 0, sizeof(L_43));
		OpCode__ctor_m3329993003(&L_43, ((int32_t)51522815), ((int32_t)51314945), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Brfalse_S_43(L_43);
		OpCode_t2247480392  L_44;
		memset(&L_44, 0, sizeof(L_44));
		OpCode__ctor_m3329993003(&L_44, ((int32_t)51523071), ((int32_t)51314945), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Brtrue_S_44(L_44);
		OpCode_t2247480392  L_45;
		memset(&L_45, 0, sizeof(L_45));
		OpCode__ctor_m3329993003(&L_45, ((int32_t)34746111), ((int32_t)51314945), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Beq_S_45(L_45);
		OpCode_t2247480392  L_46;
		memset(&L_46, 0, sizeof(L_46));
		OpCode__ctor_m3329993003(&L_46, ((int32_t)34746367), ((int32_t)51314945), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Bge_S_46(L_46);
		OpCode_t2247480392  L_47;
		memset(&L_47, 0, sizeof(L_47));
		OpCode__ctor_m3329993003(&L_47, ((int32_t)34746623), ((int32_t)51314945), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Bgt_S_47(L_47);
		OpCode_t2247480392  L_48;
		memset(&L_48, 0, sizeof(L_48));
		OpCode__ctor_m3329993003(&L_48, ((int32_t)34746879), ((int32_t)51314945), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ble_S_48(L_48);
		OpCode_t2247480392  L_49;
		memset(&L_49, 0, sizeof(L_49));
		OpCode__ctor_m3329993003(&L_49, ((int32_t)34747135), ((int32_t)51314945), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Blt_S_49(L_49);
		OpCode_t2247480392  L_50;
		memset(&L_50, 0, sizeof(L_50));
		OpCode__ctor_m3329993003(&L_50, ((int32_t)34747391), ((int32_t)51314945), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Bne_Un_S_50(L_50);
		OpCode_t2247480392  L_51;
		memset(&L_51, 0, sizeof(L_51));
		OpCode__ctor_m3329993003(&L_51, ((int32_t)34747647), ((int32_t)51314945), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Bge_Un_S_51(L_51);
		OpCode_t2247480392  L_52;
		memset(&L_52, 0, sizeof(L_52));
		OpCode__ctor_m3329993003(&L_52, ((int32_t)34747903), ((int32_t)51314945), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Bgt_Un_S_52(L_52);
		OpCode_t2247480392  L_53;
		memset(&L_53, 0, sizeof(L_53));
		OpCode__ctor_m3329993003(&L_53, ((int32_t)34748159), ((int32_t)51314945), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ble_Un_S_53(L_53);
		OpCode_t2247480392  L_54;
		memset(&L_54, 0, sizeof(L_54));
		OpCode__ctor_m3329993003(&L_54, ((int32_t)34748415), ((int32_t)51314945), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Blt_Un_S_54(L_54);
		OpCode_t2247480392  L_55;
		memset(&L_55, 0, sizeof(L_55));
		OpCode__ctor_m3329993003(&L_55, ((int32_t)1194239), ((int32_t)1281), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Br_55(L_55);
		OpCode_t2247480392  L_56;
		memset(&L_56, 0, sizeof(L_56));
		OpCode__ctor_m3329993003(&L_56, ((int32_t)51526143), ((int32_t)50332929), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Brfalse_56(L_56);
		OpCode_t2247480392  L_57;
		memset(&L_57, 0, sizeof(L_57));
		OpCode__ctor_m3329993003(&L_57, ((int32_t)51526399), ((int32_t)50332929), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Brtrue_57(L_57);
		OpCode_t2247480392  L_58;
		memset(&L_58, 0, sizeof(L_58));
		OpCode__ctor_m3329993003(&L_58, ((int32_t)34749439), ((int32_t)50331905), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Beq_58(L_58);
		OpCode_t2247480392  L_59;
		memset(&L_59, 0, sizeof(L_59));
		OpCode__ctor_m3329993003(&L_59, ((int32_t)34749695), ((int32_t)50331905), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Bge_59(L_59);
		OpCode_t2247480392  L_60;
		memset(&L_60, 0, sizeof(L_60));
		OpCode__ctor_m3329993003(&L_60, ((int32_t)34749951), ((int32_t)50331905), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Bgt_60(L_60);
		OpCode_t2247480392  L_61;
		memset(&L_61, 0, sizeof(L_61));
		OpCode__ctor_m3329993003(&L_61, ((int32_t)34750207), ((int32_t)50331905), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ble_61(L_61);
		OpCode_t2247480392  L_62;
		memset(&L_62, 0, sizeof(L_62));
		OpCode__ctor_m3329993003(&L_62, ((int32_t)34750463), ((int32_t)50331905), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Blt_62(L_62);
		OpCode_t2247480392  L_63;
		memset(&L_63, 0, sizeof(L_63));
		OpCode__ctor_m3329993003(&L_63, ((int32_t)34750719), ((int32_t)50331905), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Bne_Un_63(L_63);
		OpCode_t2247480392  L_64;
		memset(&L_64, 0, sizeof(L_64));
		OpCode__ctor_m3329993003(&L_64, ((int32_t)34750975), ((int32_t)50331905), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Bge_Un_64(L_64);
		OpCode_t2247480392  L_65;
		memset(&L_65, 0, sizeof(L_65));
		OpCode__ctor_m3329993003(&L_65, ((int32_t)34751231), ((int32_t)50331905), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Bgt_Un_65(L_65);
		OpCode_t2247480392  L_66;
		memset(&L_66, 0, sizeof(L_66));
		OpCode__ctor_m3329993003(&L_66, ((int32_t)34751487), ((int32_t)50331905), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ble_Un_66(L_66);
		OpCode_t2247480392  L_67;
		memset(&L_67, 0, sizeof(L_67));
		OpCode__ctor_m3329993003(&L_67, ((int32_t)34751743), ((int32_t)50331905), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Blt_Un_67(L_67);
		OpCode_t2247480392  L_68;
		memset(&L_68, 0, sizeof(L_68));
		OpCode__ctor_m3329993003(&L_68, ((int32_t)51529215), ((int32_t)51053825), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Switch_68(L_68);
		OpCode_t2247480392  L_69;
		memset(&L_69, 0, sizeof(L_69));
		OpCode__ctor_m3329993003(&L_69, ((int32_t)51726079), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldind_I1_69(L_69);
		OpCode_t2247480392  L_70;
		memset(&L_70, 0, sizeof(L_70));
		OpCode__ctor_m3329993003(&L_70, ((int32_t)51726335), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldind_U1_70(L_70);
		OpCode_t2247480392  L_71;
		memset(&L_71, 0, sizeof(L_71));
		OpCode__ctor_m3329993003(&L_71, ((int32_t)51726591), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldind_I2_71(L_71);
		OpCode_t2247480392  L_72;
		memset(&L_72, 0, sizeof(L_72));
		OpCode__ctor_m3329993003(&L_72, ((int32_t)51726847), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldind_U2_72(L_72);
		OpCode_t2247480392  L_73;
		memset(&L_73, 0, sizeof(L_73));
		OpCode__ctor_m3329993003(&L_73, ((int32_t)51727103), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldind_I4_73(L_73);
		OpCode_t2247480392  L_74;
		memset(&L_74, 0, sizeof(L_74));
		OpCode__ctor_m3329993003(&L_74, ((int32_t)51727359), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldind_U4_74(L_74);
		OpCode_t2247480392  L_75;
		memset(&L_75, 0, sizeof(L_75));
		OpCode__ctor_m3329993003(&L_75, ((int32_t)51793151), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldind_I8_75(L_75);
		OpCode_t2247480392  L_76;
		memset(&L_76, 0, sizeof(L_76));
		OpCode__ctor_m3329993003(&L_76, ((int32_t)51727871), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldind_I_76(L_76);
		OpCode_t2247480392  L_77;
		memset(&L_77, 0, sizeof(L_77));
		OpCode__ctor_m3329993003(&L_77, ((int32_t)51859199), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldind_R4_77(L_77);
		OpCode_t2247480392  L_78;
		memset(&L_78, 0, sizeof(L_78));
		OpCode__ctor_m3329993003(&L_78, ((int32_t)51924991), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldind_R8_78(L_78);
		OpCode_t2247480392  L_79;
		memset(&L_79, 0, sizeof(L_79));
		OpCode__ctor_m3329993003(&L_79, ((int32_t)51990783), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldind_Ref_79(L_79);
		OpCode_t2247480392  L_80;
		memset(&L_80, 0, sizeof(L_80));
		OpCode__ctor_m3329993003(&L_80, ((int32_t)85086719), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Stind_Ref_80(L_80);
		OpCode_t2247480392  L_81;
		memset(&L_81, 0, sizeof(L_81));
		OpCode__ctor_m3329993003(&L_81, ((int32_t)85086975), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Stind_I1_81(L_81);
		OpCode_t2247480392  L_82;
		memset(&L_82, 0, sizeof(L_82));
		OpCode__ctor_m3329993003(&L_82, ((int32_t)85087231), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Stind_I2_82(L_82);
		OpCode_t2247480392  L_83;
		memset(&L_83, 0, sizeof(L_83));
		OpCode__ctor_m3329993003(&L_83, ((int32_t)85087487), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Stind_I4_83(L_83);
		OpCode_t2247480392  L_84;
		memset(&L_84, 0, sizeof(L_84));
		OpCode__ctor_m3329993003(&L_84, ((int32_t)101864959), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Stind_I8_84(L_84);
		OpCode_t2247480392  L_85;
		memset(&L_85, 0, sizeof(L_85));
		OpCode__ctor_m3329993003(&L_85, ((int32_t)135419647), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Stind_R4_85(L_85);
		OpCode_t2247480392  L_86;
		memset(&L_86, 0, sizeof(L_86));
		OpCode__ctor_m3329993003(&L_86, ((int32_t)152197119), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Stind_R8_86(L_86);
		OpCode_t2247480392  L_87;
		memset(&L_87, 0, sizeof(L_87));
		OpCode__ctor_m3329993003(&L_87, ((int32_t)34822399), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Add_87(L_87);
		OpCode_t2247480392  L_88;
		memset(&L_88, 0, sizeof(L_88));
		OpCode__ctor_m3329993003(&L_88, ((int32_t)34822655), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Sub_88(L_88);
		OpCode_t2247480392  L_89;
		memset(&L_89, 0, sizeof(L_89));
		OpCode__ctor_m3329993003(&L_89, ((int32_t)34822911), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Mul_89(L_89);
		OpCode_t2247480392  L_90;
		memset(&L_90, 0, sizeof(L_90));
		OpCode__ctor_m3329993003(&L_90, ((int32_t)34823167), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Div_90(L_90);
		OpCode_t2247480392  L_91;
		memset(&L_91, 0, sizeof(L_91));
		OpCode__ctor_m3329993003(&L_91, ((int32_t)34823423), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Div_Un_91(L_91);
		OpCode_t2247480392  L_92;
		memset(&L_92, 0, sizeof(L_92));
		OpCode__ctor_m3329993003(&L_92, ((int32_t)34823679), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Rem_92(L_92);
		OpCode_t2247480392  L_93;
		memset(&L_93, 0, sizeof(L_93));
		OpCode__ctor_m3329993003(&L_93, ((int32_t)34823935), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Rem_Un_93(L_93);
		OpCode_t2247480392  L_94;
		memset(&L_94, 0, sizeof(L_94));
		OpCode__ctor_m3329993003(&L_94, ((int32_t)34824191), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_And_94(L_94);
		OpCode_t2247480392  L_95;
		memset(&L_95, 0, sizeof(L_95));
		OpCode__ctor_m3329993003(&L_95, ((int32_t)34824447), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Or_95(L_95);
		OpCode_t2247480392  L_96;
		memset(&L_96, 0, sizeof(L_96));
		OpCode__ctor_m3329993003(&L_96, ((int32_t)34824703), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Xor_96(L_96);
		OpCode_t2247480392  L_97;
		memset(&L_97, 0, sizeof(L_97));
		OpCode__ctor_m3329993003(&L_97, ((int32_t)34824959), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Shl_97(L_97);
		OpCode_t2247480392  L_98;
		memset(&L_98, 0, sizeof(L_98));
		OpCode__ctor_m3329993003(&L_98, ((int32_t)34825215), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Shr_98(L_98);
		OpCode_t2247480392  L_99;
		memset(&L_99, 0, sizeof(L_99));
		OpCode__ctor_m3329993003(&L_99, ((int32_t)34825471), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Shr_Un_99(L_99);
		OpCode_t2247480392  L_100;
		memset(&L_100, 0, sizeof(L_100));
		OpCode__ctor_m3329993003(&L_100, ((int32_t)18048511), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Neg_100(L_100);
		OpCode_t2247480392  L_101;
		memset(&L_101, 0, sizeof(L_101));
		OpCode__ctor_m3329993003(&L_101, ((int32_t)18048767), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Not_101(L_101);
		OpCode_t2247480392  L_102;
		memset(&L_102, 0, sizeof(L_102));
		OpCode__ctor_m3329993003(&L_102, ((int32_t)18180095), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Conv_I1_102(L_102);
		OpCode_t2247480392  L_103;
		memset(&L_103, 0, sizeof(L_103));
		OpCode__ctor_m3329993003(&L_103, ((int32_t)18180351), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Conv_I2_103(L_103);
		OpCode_t2247480392  L_104;
		memset(&L_104, 0, sizeof(L_104));
		OpCode__ctor_m3329993003(&L_104, ((int32_t)18180607), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Conv_I4_104(L_104);
		OpCode_t2247480392  L_105;
		memset(&L_105, 0, sizeof(L_105));
		OpCode__ctor_m3329993003(&L_105, ((int32_t)18246399), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Conv_I8_105(L_105);
		OpCode_t2247480392  L_106;
		memset(&L_106, 0, sizeof(L_106));
		OpCode__ctor_m3329993003(&L_106, ((int32_t)18312191), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Conv_R4_106(L_106);
		OpCode_t2247480392  L_107;
		memset(&L_107, 0, sizeof(L_107));
		OpCode__ctor_m3329993003(&L_107, ((int32_t)18377983), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Conv_R8_107(L_107);
		OpCode_t2247480392  L_108;
		memset(&L_108, 0, sizeof(L_108));
		OpCode__ctor_m3329993003(&L_108, ((int32_t)18181631), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Conv_U4_108(L_108);
		OpCode_t2247480392  L_109;
		memset(&L_109, 0, sizeof(L_109));
		OpCode__ctor_m3329993003(&L_109, ((int32_t)18247423), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Conv_U8_109(L_109);
		OpCode_t2247480392  L_110;
		memset(&L_110, 0, sizeof(L_110));
		OpCode__ctor_m3329993003(&L_110, ((int32_t)438005759), ((int32_t)33817345), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Callvirt_110(L_110);
		OpCode_t2247480392  L_111;
		memset(&L_111, 0, sizeof(L_111));
		OpCode__ctor_m3329993003(&L_111, ((int32_t)85094655), ((int32_t)84738817), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Cpobj_111(L_111);
		OpCode_t2247480392  L_112;
		memset(&L_112, 0, sizeof(L_112));
		OpCode__ctor_m3329993003(&L_112, ((int32_t)51606015), ((int32_t)84738817), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldobj_112(L_112);
		OpCode_t2247480392  L_113;
		memset(&L_113, 0, sizeof(L_113));
		OpCode__ctor_m3329993003(&L_113, ((int32_t)1667839), ((int32_t)84542209), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldstr_113(L_113);
		OpCode_t2247480392  L_114;
		memset(&L_114, 0, sizeof(L_114));
		OpCode__ctor_m3329993003(&L_114, ((int32_t)437875711), ((int32_t)33817345), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Newobj_114(L_114);
		OpCode_t2247480392  L_115;
		memset(&L_115, 0, sizeof(L_115));
		OpCode__ctor_m3329993003(&L_115, ((int32_t)169440511), ((int32_t)84738817), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Castclass_115(L_115);
		OpCode_t2247480392  L_116;
		memset(&L_116, 0, sizeof(L_116));
		OpCode__ctor_m3329993003(&L_116, ((int32_t)169178623), ((int32_t)84738817), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Isinst_116(L_116);
		OpCode_t2247480392  L_117;
		memset(&L_117, 0, sizeof(L_117));
		OpCode__ctor_m3329993003(&L_117, ((int32_t)18380543), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Conv_R_Un_117(L_117);
		OpCode_t2247480392  L_118;
		memset(&L_118, 0, sizeof(L_118));
		OpCode__ctor_m3329993003(&L_118, ((int32_t)169179647), ((int32_t)84739329), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Unbox_118(L_118);
		OpCode_t2247480392  L_119;
		memset(&L_119, 0, sizeof(L_119));
		OpCode__ctor_m3329993003(&L_119, ((int32_t)168983295), ((int32_t)134546177), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Throw_119(L_119);
		OpCode_t2247480392  L_120;
		memset(&L_120, 0, sizeof(L_120));
		OpCode__ctor_m3329993003(&L_120, ((int32_t)169049087), ((int32_t)83952385), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldfld_120(L_120);
		OpCode_t2247480392  L_121;
		memset(&L_121, 0, sizeof(L_121));
		OpCode__ctor_m3329993003(&L_121, ((int32_t)169180415), ((int32_t)83952385), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldflda_121(L_121);
		OpCode_t2247480392  L_122;
		memset(&L_122, 0, sizeof(L_122));
		OpCode__ctor_m3329993003(&L_122, ((int32_t)185761279), ((int32_t)83952385), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Stfld_122(L_122);
		OpCode_t2247480392  L_123;
		memset(&L_123, 0, sizeof(L_123));
		OpCode__ctor_m3329993003(&L_123, ((int32_t)1277695), ((int32_t)83952385), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldsfld_123(L_123);
		OpCode_t2247480392  L_124;
		memset(&L_124, 0, sizeof(L_124));
		OpCode__ctor_m3329993003(&L_124, ((int32_t)1409023), ((int32_t)83952385), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldsflda_124(L_124);
		OpCode_t2247480392  L_125;
		memset(&L_125, 0, sizeof(L_125));
		OpCode__ctor_m3329993003(&L_125, ((int32_t)17989887), ((int32_t)83952385), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Stsfld_125(L_125);
		OpCode_t2247480392  L_126;
		memset(&L_126, 0, sizeof(L_126));
		OpCode__ctor_m3329993003(&L_126, ((int32_t)68321791), ((int32_t)84739329), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Stobj_126(L_126);
		OpCode_t2247480392  L_127;
		memset(&L_127, 0, sizeof(L_127));
		OpCode__ctor_m3329993003(&L_127, ((int32_t)18187007), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Conv_Ovf_I1_Un_127(L_127);
		OpCode_t2247480392  L_128;
		memset(&L_128, 0, sizeof(L_128));
		OpCode__ctor_m3329993003(&L_128, ((int32_t)18187263), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Conv_Ovf_I2_Un_128(L_128);
		OpCode_t2247480392  L_129;
		memset(&L_129, 0, sizeof(L_129));
		OpCode__ctor_m3329993003(&L_129, ((int32_t)18187519), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Conv_Ovf_I4_Un_129(L_129);
		OpCode_t2247480392  L_130;
		memset(&L_130, 0, sizeof(L_130));
		OpCode__ctor_m3329993003(&L_130, ((int32_t)18253311), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Conv_Ovf_I8_Un_130(L_130);
		OpCode_t2247480392  L_131;
		memset(&L_131, 0, sizeof(L_131));
		OpCode__ctor_m3329993003(&L_131, ((int32_t)18188031), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Conv_Ovf_U1_Un_131(L_131);
		OpCode_t2247480392  L_132;
		memset(&L_132, 0, sizeof(L_132));
		OpCode__ctor_m3329993003(&L_132, ((int32_t)18188287), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Conv_Ovf_U2_Un_132(L_132);
		OpCode_t2247480392  L_133;
		memset(&L_133, 0, sizeof(L_133));
		OpCode__ctor_m3329993003(&L_133, ((int32_t)18188543), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Conv_Ovf_U4_Un_133(L_133);
		OpCode_t2247480392  L_134;
		memset(&L_134, 0, sizeof(L_134));
		OpCode__ctor_m3329993003(&L_134, ((int32_t)18254335), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Conv_Ovf_U8_Un_134(L_134);
		OpCode_t2247480392  L_135;
		memset(&L_135, 0, sizeof(L_135));
		OpCode__ctor_m3329993003(&L_135, ((int32_t)18189055), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Conv_Ovf_I_Un_135(L_135);
		OpCode_t2247480392  L_136;
		memset(&L_136, 0, sizeof(L_136));
		OpCode__ctor_m3329993003(&L_136, ((int32_t)18189311), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Conv_Ovf_U_Un_136(L_136);
		OpCode_t2247480392  L_137;
		memset(&L_137, 0, sizeof(L_137));
		OpCode__ctor_m3329993003(&L_137, ((int32_t)18451711), ((int32_t)84739329), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Box_137(L_137);
		OpCode_t2247480392  L_138;
		memset(&L_138, 0, sizeof(L_138));
		OpCode__ctor_m3329993003(&L_138, ((int32_t)52006399), ((int32_t)84738817), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Newarr_138(L_138);
		OpCode_t2247480392  L_139;
		memset(&L_139, 0, sizeof(L_139));
		OpCode__ctor_m3329993003(&L_139, ((int32_t)169185023), ((int32_t)84214529), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldlen_139(L_139);
		OpCode_t2247480392  L_140;
		memset(&L_140, 0, sizeof(L_140));
		OpCode__ctor_m3329993003(&L_140, ((int32_t)202739711), ((int32_t)84738817), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldelema_140(L_140);
		OpCode_t2247480392  L_141;
		memset(&L_141, 0, sizeof(L_141));
		OpCode__ctor_m3329993003(&L_141, ((int32_t)202739967), ((int32_t)84214529), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldelem_I1_141(L_141);
		OpCode_t2247480392  L_142;
		memset(&L_142, 0, sizeof(L_142));
		OpCode__ctor_m3329993003(&L_142, ((int32_t)202740223), ((int32_t)84214529), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldelem_U1_142(L_142);
		OpCode_t2247480392  L_143;
		memset(&L_143, 0, sizeof(L_143));
		OpCode__ctor_m3329993003(&L_143, ((int32_t)202740479), ((int32_t)84214529), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldelem_I2_143(L_143);
		OpCode_t2247480392  L_144;
		memset(&L_144, 0, sizeof(L_144));
		OpCode__ctor_m3329993003(&L_144, ((int32_t)202740735), ((int32_t)84214529), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldelem_U2_144(L_144);
		OpCode_t2247480392  L_145;
		memset(&L_145, 0, sizeof(L_145));
		OpCode__ctor_m3329993003(&L_145, ((int32_t)202740991), ((int32_t)84214529), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldelem_I4_145(L_145);
		OpCode_t2247480392  L_146;
		memset(&L_146, 0, sizeof(L_146));
		OpCode__ctor_m3329993003(&L_146, ((int32_t)202741247), ((int32_t)84214529), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldelem_U4_146(L_146);
		OpCode_t2247480392  L_147;
		memset(&L_147, 0, sizeof(L_147));
		OpCode__ctor_m3329993003(&L_147, ((int32_t)202807039), ((int32_t)84214529), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldelem_I8_147(L_147);
		OpCode_t2247480392  L_148;
		memset(&L_148, 0, sizeof(L_148));
		OpCode__ctor_m3329993003(&L_148, ((int32_t)202741759), ((int32_t)84214529), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldelem_I_148(L_148);
		OpCode_t2247480392  L_149;
		memset(&L_149, 0, sizeof(L_149));
		OpCode__ctor_m3329993003(&L_149, ((int32_t)202873087), ((int32_t)84214529), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldelem_R4_149(L_149);
		OpCode_t2247480392  L_150;
		memset(&L_150, 0, sizeof(L_150));
		OpCode__ctor_m3329993003(&L_150, ((int32_t)202938879), ((int32_t)84214529), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldelem_R8_150(L_150);
		OpCode_t2247480392  L_151;
		memset(&L_151, 0, sizeof(L_151));
		OpCode__ctor_m3329993003(&L_151, ((int32_t)203004671), ((int32_t)84214529), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldelem_Ref_151(L_151);
		OpCode_t2247480392  L_152;
		memset(&L_152, 0, sizeof(L_152));
		OpCode__ctor_m3329993003(&L_152, ((int32_t)219323391), ((int32_t)84214529), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Stelem_I_152(L_152);
		OpCode_t2247480392  L_153;
		memset(&L_153, 0, sizeof(L_153));
		OpCode__ctor_m3329993003(&L_153, ((int32_t)219323647), ((int32_t)84214529), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Stelem_I1_153(L_153);
		OpCode_t2247480392  L_154;
		memset(&L_154, 0, sizeof(L_154));
		OpCode__ctor_m3329993003(&L_154, ((int32_t)219323903), ((int32_t)84214529), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Stelem_I2_154(L_154);
		OpCode_t2247480392  L_155;
		memset(&L_155, 0, sizeof(L_155));
		OpCode__ctor_m3329993003(&L_155, ((int32_t)219324159), ((int32_t)84214529), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Stelem_I4_155(L_155);
		OpCode_t2247480392  L_156;
		memset(&L_156, 0, sizeof(L_156));
		OpCode__ctor_m3329993003(&L_156, ((int32_t)236101631), ((int32_t)84214529), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Stelem_I8_156(L_156);
		OpCode_t2247480392  L_157;
		memset(&L_157, 0, sizeof(L_157));
		OpCode__ctor_m3329993003(&L_157, ((int32_t)252879103), ((int32_t)84214529), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Stelem_R4_157(L_157);
		OpCode_t2247480392  L_158;
		memset(&L_158, 0, sizeof(L_158));
		OpCode__ctor_m3329993003(&L_158, ((int32_t)269656575), ((int32_t)84214529), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Stelem_R8_158(L_158);
		OpCode_t2247480392  L_159;
		memset(&L_159, 0, sizeof(L_159));
		OpCode__ctor_m3329993003(&L_159, ((int32_t)286434047), ((int32_t)84214529), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Stelem_Ref_159(L_159);
		OpCode_t2247480392  L_160;
		memset(&L_160, 0, sizeof(L_160));
		OpCode__ctor_m3329993003(&L_160, ((int32_t)202613759), ((int32_t)84738817), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldelem_160(L_160);
		OpCode_t2247480392  L_161;
		memset(&L_161, 0, sizeof(L_161));
		OpCode__ctor_m3329993003(&L_161, ((int32_t)470983935), ((int32_t)84738817), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Stelem_161(L_161);
		OpCode_t2247480392  L_162;
		memset(&L_162, 0, sizeof(L_162));
		OpCode__ctor_m3329993003(&L_162, ((int32_t)169059839), ((int32_t)84738817), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Unbox_Any_162(L_162);
		OpCode_t2247480392  L_163;
		memset(&L_163, 0, sizeof(L_163));
		OpCode__ctor_m3329993003(&L_163, ((int32_t)18199551), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Conv_Ovf_I1_163(L_163);
		OpCode_t2247480392  L_164;
		memset(&L_164, 0, sizeof(L_164));
		OpCode__ctor_m3329993003(&L_164, ((int32_t)18199807), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Conv_Ovf_U1_164(L_164);
		OpCode_t2247480392  L_165;
		memset(&L_165, 0, sizeof(L_165));
		OpCode__ctor_m3329993003(&L_165, ((int32_t)18200063), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Conv_Ovf_I2_165(L_165);
		OpCode_t2247480392  L_166;
		memset(&L_166, 0, sizeof(L_166));
		OpCode__ctor_m3329993003(&L_166, ((int32_t)18200319), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Conv_Ovf_U2_166(L_166);
		OpCode_t2247480392  L_167;
		memset(&L_167, 0, sizeof(L_167));
		OpCode__ctor_m3329993003(&L_167, ((int32_t)18200575), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Conv_Ovf_I4_167(L_167);
		OpCode_t2247480392  L_168;
		memset(&L_168, 0, sizeof(L_168));
		OpCode__ctor_m3329993003(&L_168, ((int32_t)18200831), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Conv_Ovf_U4_168(L_168);
		OpCode_t2247480392  L_169;
		memset(&L_169, 0, sizeof(L_169));
		OpCode__ctor_m3329993003(&L_169, ((int32_t)18266623), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Conv_Ovf_I8_169(L_169);
		OpCode_t2247480392  L_170;
		memset(&L_170, 0, sizeof(L_170));
		OpCode__ctor_m3329993003(&L_170, ((int32_t)18266879), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Conv_Ovf_U8_170(L_170);
		OpCode_t2247480392  L_171;
		memset(&L_171, 0, sizeof(L_171));
		OpCode__ctor_m3329993003(&L_171, ((int32_t)18203391), ((int32_t)84739329), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Refanyval_171(L_171);
		OpCode_t2247480392  L_172;
		memset(&L_172, 0, sizeof(L_172));
		OpCode__ctor_m3329993003(&L_172, ((int32_t)18400255), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ckfinite_172(L_172);
		OpCode_t2247480392  L_173;
		memset(&L_173, 0, sizeof(L_173));
		OpCode__ctor_m3329993003(&L_173, ((int32_t)51627775), ((int32_t)84739329), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Mkrefany_173(L_173);
		OpCode_t2247480392  L_174;
		memset(&L_174, 0, sizeof(L_174));
		OpCode__ctor_m3329993003(&L_174, ((int32_t)1429759), ((int32_t)84673793), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldtoken_174(L_174);
		OpCode_t2247480392  L_175;
		memset(&L_175, 0, sizeof(L_175));
		OpCode__ctor_m3329993003(&L_175, ((int32_t)18207231), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Conv_U2_175(L_175);
		OpCode_t2247480392  L_176;
		memset(&L_176, 0, sizeof(L_176));
		OpCode__ctor_m3329993003(&L_176, ((int32_t)18207487), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Conv_U1_176(L_176);
		OpCode_t2247480392  L_177;
		memset(&L_177, 0, sizeof(L_177));
		OpCode__ctor_m3329993003(&L_177, ((int32_t)18207743), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Conv_I_177(L_177);
		OpCode_t2247480392  L_178;
		memset(&L_178, 0, sizeof(L_178));
		OpCode__ctor_m3329993003(&L_178, ((int32_t)18207999), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Conv_Ovf_I_178(L_178);
		OpCode_t2247480392  L_179;
		memset(&L_179, 0, sizeof(L_179));
		OpCode__ctor_m3329993003(&L_179, ((int32_t)18208255), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Conv_Ovf_U_179(L_179);
		OpCode_t2247480392  L_180;
		memset(&L_180, 0, sizeof(L_180));
		OpCode__ctor_m3329993003(&L_180, ((int32_t)34854655), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Add_Ovf_180(L_180);
		OpCode_t2247480392  L_181;
		memset(&L_181, 0, sizeof(L_181));
		OpCode__ctor_m3329993003(&L_181, ((int32_t)34854911), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Add_Ovf_Un_181(L_181);
		OpCode_t2247480392  L_182;
		memset(&L_182, 0, sizeof(L_182));
		OpCode__ctor_m3329993003(&L_182, ((int32_t)34855167), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Mul_Ovf_182(L_182);
		OpCode_t2247480392  L_183;
		memset(&L_183, 0, sizeof(L_183));
		OpCode__ctor_m3329993003(&L_183, ((int32_t)34855423), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Mul_Ovf_Un_183(L_183);
		OpCode_t2247480392  L_184;
		memset(&L_184, 0, sizeof(L_184));
		OpCode__ctor_m3329993003(&L_184, ((int32_t)34855679), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Sub_Ovf_184(L_184);
		OpCode_t2247480392  L_185;
		memset(&L_185, 0, sizeof(L_185));
		OpCode__ctor_m3329993003(&L_185, ((int32_t)34855935), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Sub_Ovf_Un_185(L_185);
		OpCode_t2247480392  L_186;
		memset(&L_186, 0, sizeof(L_186));
		OpCode__ctor_m3329993003(&L_186, ((int32_t)1236223), ((int32_t)117769473), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Endfinally_186(L_186);
		OpCode_t2247480392  L_187;
		memset(&L_187, 0, sizeof(L_187));
		OpCode__ctor_m3329993003(&L_187, ((int32_t)1236479), ((int32_t)1281), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Leave_187(L_187);
		OpCode_t2247480392  L_188;
		memset(&L_188, 0, sizeof(L_188));
		OpCode__ctor_m3329993003(&L_188, ((int32_t)1236735), ((int32_t)984321), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Leave_S_188(L_188);
		OpCode_t2247480392  L_189;
		memset(&L_189, 0, sizeof(L_189));
		OpCode__ctor_m3329993003(&L_189, ((int32_t)85123071), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Stind_I_189(L_189);
		OpCode_t2247480392  L_190;
		memset(&L_190, 0, sizeof(L_190));
		OpCode__ctor_m3329993003(&L_190, ((int32_t)18211071), ((int32_t)84215041), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Conv_U_190(L_190);
		OpCode_t2247480392  L_191;
		memset(&L_191, 0, sizeof(L_191));
		OpCode__ctor_m3329993003(&L_191, ((int32_t)1243391), ((int32_t)67437057), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Prefix7_191(L_191);
		OpCode_t2247480392  L_192;
		memset(&L_192, 0, sizeof(L_192));
		OpCode__ctor_m3329993003(&L_192, ((int32_t)1243647), ((int32_t)67437057), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Prefix6_192(L_192);
		OpCode_t2247480392  L_193;
		memset(&L_193, 0, sizeof(L_193));
		OpCode__ctor_m3329993003(&L_193, ((int32_t)1243903), ((int32_t)67437057), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Prefix5_193(L_193);
		OpCode_t2247480392  L_194;
		memset(&L_194, 0, sizeof(L_194));
		OpCode__ctor_m3329993003(&L_194, ((int32_t)1244159), ((int32_t)67437057), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Prefix4_194(L_194);
		OpCode_t2247480392  L_195;
		memset(&L_195, 0, sizeof(L_195));
		OpCode__ctor_m3329993003(&L_195, ((int32_t)1244415), ((int32_t)67437057), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Prefix3_195(L_195);
		OpCode_t2247480392  L_196;
		memset(&L_196, 0, sizeof(L_196));
		OpCode__ctor_m3329993003(&L_196, ((int32_t)1244671), ((int32_t)67437057), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Prefix2_196(L_196);
		OpCode_t2247480392  L_197;
		memset(&L_197, 0, sizeof(L_197));
		OpCode__ctor_m3329993003(&L_197, ((int32_t)1244927), ((int32_t)67437057), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Prefix1_197(L_197);
		OpCode_t2247480392  L_198;
		memset(&L_198, 0, sizeof(L_198));
		OpCode__ctor_m3329993003(&L_198, ((int32_t)1245183), ((int32_t)67437057), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Prefixref_198(L_198);
		OpCode_t2247480392  L_199;
		memset(&L_199, 0, sizeof(L_199));
		OpCode__ctor_m3329993003(&L_199, ((int32_t)1376510), ((int32_t)84215042), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Arglist_199(L_199);
		OpCode_t2247480392  L_200;
		memset(&L_200, 0, sizeof(L_200));
		OpCode__ctor_m3329993003(&L_200, ((int32_t)34931198), ((int32_t)84215042), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ceq_200(L_200);
		OpCode_t2247480392  L_201;
		memset(&L_201, 0, sizeof(L_201));
		OpCode__ctor_m3329993003(&L_201, ((int32_t)34931454), ((int32_t)84215042), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Cgt_201(L_201);
		OpCode_t2247480392  L_202;
		memset(&L_202, 0, sizeof(L_202));
		OpCode__ctor_m3329993003(&L_202, ((int32_t)34931710), ((int32_t)84215042), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Cgt_Un_202(L_202);
		OpCode_t2247480392  L_203;
		memset(&L_203, 0, sizeof(L_203));
		OpCode__ctor_m3329993003(&L_203, ((int32_t)34931966), ((int32_t)84215042), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Clt_203(L_203);
		OpCode_t2247480392  L_204;
		memset(&L_204, 0, sizeof(L_204));
		OpCode__ctor_m3329993003(&L_204, ((int32_t)34932222), ((int32_t)84215042), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Clt_Un_204(L_204);
		OpCode_t2247480392  L_205;
		memset(&L_205, 0, sizeof(L_205));
		OpCode__ctor_m3329993003(&L_205, ((int32_t)1378046), ((int32_t)84149506), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldftn_205(L_205);
		OpCode_t2247480392  L_206;
		memset(&L_206, 0, sizeof(L_206));
		OpCode__ctor_m3329993003(&L_206, ((int32_t)169150462), ((int32_t)84149506), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldvirtftn_206(L_206);
		OpCode_t2247480392  L_207;
		memset(&L_207, 0, sizeof(L_207));
		OpCode__ctor_m3329993003(&L_207, ((int32_t)1247742), ((int32_t)84804866), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldarg_207(L_207);
		OpCode_t2247480392  L_208;
		memset(&L_208, 0, sizeof(L_208));
		OpCode__ctor_m3329993003(&L_208, ((int32_t)1379070), ((int32_t)84804866), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldarga_208(L_208);
		OpCode_t2247480392  L_209;
		memset(&L_209, 0, sizeof(L_209));
		OpCode__ctor_m3329993003(&L_209, ((int32_t)17959934), ((int32_t)84804866), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Starg_209(L_209);
		OpCode_t2247480392  L_210;
		memset(&L_210, 0, sizeof(L_210));
		OpCode__ctor_m3329993003(&L_210, ((int32_t)1248510), ((int32_t)84804866), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldloc_210(L_210);
		OpCode_t2247480392  L_211;
		memset(&L_211, 0, sizeof(L_211));
		OpCode__ctor_m3329993003(&L_211, ((int32_t)1379838), ((int32_t)84804866), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Ldloca_211(L_211);
		OpCode_t2247480392  L_212;
		memset(&L_212, 0, sizeof(L_212));
		OpCode__ctor_m3329993003(&L_212, ((int32_t)17960702), ((int32_t)84804866), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Stloc_212(L_212);
		OpCode_t2247480392  L_213;
		memset(&L_213, 0, sizeof(L_213));
		OpCode__ctor_m3329993003(&L_213, ((int32_t)51711998), ((int32_t)84215042), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Localloc_213(L_213);
		OpCode_t2247480392  L_214;
		memset(&L_214, 0, sizeof(L_214));
		OpCode__ctor_m3329993003(&L_214, ((int32_t)51515902), ((int32_t)117769474), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Endfilter_214(L_214);
		OpCode_t2247480392  L_215;
		memset(&L_215, 0, sizeof(L_215));
		OpCode__ctor_m3329993003(&L_215, ((int32_t)1184510), ((int32_t)68158466), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Unaligned_215(L_215);
		OpCode_t2247480392  L_216;
		memset(&L_216, 0, sizeof(L_216));
		OpCode__ctor_m3329993003(&L_216, ((int32_t)1184766), ((int32_t)67437570), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Volatile_216(L_216);
		OpCode_t2247480392  L_217;
		memset(&L_217, 0, sizeof(L_217));
		OpCode__ctor_m3329993003(&L_217, ((int32_t)1185022), ((int32_t)67437570), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Tailcall_217(L_217);
		OpCode_t2247480392  L_218;
		memset(&L_218, 0, sizeof(L_218));
		OpCode__ctor_m3329993003(&L_218, ((int32_t)51516926), ((int32_t)84738818), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Initobj_218(L_218);
		OpCode_t2247480392  L_219;
		memset(&L_219, 0, sizeof(L_219));
		OpCode__ctor_m3329993003(&L_219, ((int32_t)1185534), ((int32_t)67961858), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Constrained_219(L_219);
		OpCode_t2247480392  L_220;
		memset(&L_220, 0, sizeof(L_220));
		OpCode__ctor_m3329993003(&L_220, ((int32_t)118626302), ((int32_t)84215042), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Cpblk_220(L_220);
		OpCode_t2247480392  L_221;
		memset(&L_221, 0, sizeof(L_221));
		OpCode__ctor_m3329993003(&L_221, ((int32_t)118626558), ((int32_t)84215042), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Initblk_221(L_221);
		OpCode_t2247480392  L_222;
		memset(&L_222, 0, sizeof(L_222));
		OpCode__ctor_m3329993003(&L_222, ((int32_t)1186558), ((int32_t)134546178), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Rethrow_222(L_222);
		OpCode_t2247480392  L_223;
		memset(&L_223, 0, sizeof(L_223));
		OpCode__ctor_m3329993003(&L_223, ((int32_t)1383678), ((int32_t)84739330), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Sizeof_223(L_223);
		OpCode_t2247480392  L_224;
		memset(&L_224, 0, sizeof(L_224));
		OpCode__ctor_m3329993003(&L_224, ((int32_t)18161150), ((int32_t)84215042), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Refanytype_224(L_224);
		OpCode_t2247480392  L_225;
		memset(&L_225, 0, sizeof(L_225));
		OpCode__ctor_m3329993003(&L_225, ((int32_t)1187582), ((int32_t)67437570), /*hidden argument*/NULL);
		((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->set_Readonly_225(L_225);
		return;
	}
}
// System.Int32 System.Reflection.Emit.ParameterBuilder::get_Attributes()
extern "C"  int32_t ParameterBuilder_get_Attributes_m2421099277 (ParameterBuilder_t3344728474 * __this, const MethodInfo* method)
{
	{
		int32_t L_0 = __this->get_attrs_1();
		return L_0;
	}
}
// System.String System.Reflection.Emit.ParameterBuilder::get_Name()
extern "C"  String_t* ParameterBuilder_get_Name_m4058709354 (ParameterBuilder_t3344728474 * __this, const MethodInfo* method)
{
	{
		String_t* L_0 = __this->get_name_0();
		return L_0;
	}
}
// System.Int32 System.Reflection.Emit.ParameterBuilder::get_Position()
extern "C"  int32_t ParameterBuilder_get_Position_m4023585547 (ParameterBuilder_t3344728474 * __this, const MethodInfo* method)
{
	{
		int32_t L_0 = __this->get_position_2();
		return L_0;
	}
}
// System.Reflection.TypeAttributes System.Reflection.Emit.TypeBuilder::GetAttributeFlagsImpl()
extern "C"  int32_t TypeBuilder_GetAttributeFlagsImpl_m2593449699 (TypeBuilder_t3308873219 * __this, const MethodInfo* method)
{
	{
		int32_t L_0 = __this->get_attrs_17();
		return L_0;
	}
}
// System.Void System.Reflection.Emit.TypeBuilder::setup_internal_class(System.Reflection.Emit.TypeBuilder)
extern "C"  void TypeBuilder_setup_internal_class_m235812026 (TypeBuilder_t3308873219 * __this, TypeBuilder_t3308873219 * ___tb0, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef void (*TypeBuilder_setup_internal_class_m235812026_ftn) (TypeBuilder_t3308873219 *, TypeBuilder_t3308873219 *);
	 ((TypeBuilder_setup_internal_class_m235812026_ftn)mscorlib::System::Reflection::Emit::TypeBuilder::setup_internal_class) (__this, ___tb0);
}
// System.Void System.Reflection.Emit.TypeBuilder::create_generic_class()
extern "C"  void TypeBuilder_create_generic_class_m986834171 (TypeBuilder_t3308873219 * __this, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef void (*TypeBuilder_create_generic_class_m986834171_ftn) (TypeBuilder_t3308873219 *);
	 ((TypeBuilder_create_generic_class_m986834171_ftn)mscorlib::System::Reflection::Emit::TypeBuilder::create_generic_class) (__this);
}
// System.Reflection.Assembly System.Reflection.Emit.TypeBuilder::get_Assembly()
extern "C"  Assembly_t4268412390 * TypeBuilder_get_Assembly_m492491492 (TypeBuilder_t3308873219 * __this, const MethodInfo* method)
{
	{
		ModuleBuilder_t4156028127 * L_0 = __this->get_pmodule_18();
		NullCheck(L_0);
		Assembly_t4268412390 * L_1 = Module_get_Assembly_m3690289982(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.String System.Reflection.Emit.TypeBuilder::get_AssemblyQualifiedName()
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral811305474;
extern const uint32_t TypeBuilder_get_AssemblyQualifiedName_m2097258567_MetadataUsageId;
extern "C"  String_t* TypeBuilder_get_AssemblyQualifiedName_m2097258567 (TypeBuilder_t3308873219 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (TypeBuilder_get_AssemblyQualifiedName_m2097258567_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		String_t* L_0 = __this->get_fullname_21();
		Assembly_t4268412390 * L_1 = TypeBuilder_get_Assembly_m492491492(__this, /*hidden argument*/NULL);
		NullCheck(L_1);
		String_t* L_2 = VirtFuncInvoker0< String_t* >::Invoke(6 /* System.String System.Reflection.Assembly::get_FullName() */, L_1);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_3 = String_Concat_m612901809(NULL /*static, unused*/, L_0, _stringLiteral811305474, L_2, /*hidden argument*/NULL);
		return L_3;
	}
}
// System.Type System.Reflection.Emit.TypeBuilder::get_BaseType()
extern "C"  Type_t * TypeBuilder_get_BaseType_m4088672180 (TypeBuilder_t3308873219 * __this, const MethodInfo* method)
{
	{
		Type_t * L_0 = __this->get_parent_10();
		return L_0;
	}
}
// System.Type System.Reflection.Emit.TypeBuilder::get_DeclaringType()
extern "C"  Type_t * TypeBuilder_get_DeclaringType_m3236598700 (TypeBuilder_t3308873219 * __this, const MethodInfo* method)
{
	{
		Type_t * L_0 = __this->get_nesting_type_11();
		return L_0;
	}
}
// System.Type System.Reflection.Emit.TypeBuilder::get_UnderlyingSystemType()
extern Il2CppClass* InvalidOperationException_t721527559_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral700545517;
extern const uint32_t TypeBuilder_get_UnderlyingSystemType_m392404521_MetadataUsageId;
extern "C"  Type_t * TypeBuilder_get_UnderlyingSystemType_m392404521 (TypeBuilder_t3308873219 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (TypeBuilder_get_UnderlyingSystemType_m392404521_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		bool L_0 = TypeBuilder_get_is_created_m736553860(__this, /*hidden argument*/NULL);
		if (!L_0)
		{
			goto IL_0017;
		}
	}
	{
		Type_t * L_1 = __this->get_created_20();
		NullCheck(L_1);
		Type_t * L_2 = VirtFuncInvoker0< Type_t * >::Invoke(36 /* System.Type System.Type::get_UnderlyingSystemType() */, L_1);
		return L_2;
	}

IL_0017:
	{
		bool L_3 = Type_get_IsEnum_m313908919(__this, /*hidden argument*/NULL);
		if (!L_3)
		{
			goto IL_004a;
		}
	}
	{
		bool L_4 = TypeBuilder_get_IsCompilerContext_m3623403919(__this, /*hidden argument*/NULL);
		if (L_4)
		{
			goto IL_004a;
		}
	}
	{
		Type_t * L_5 = __this->get_underlying_type_23();
		if (!L_5)
		{
			goto IL_003f;
		}
	}
	{
		Type_t * L_6 = __this->get_underlying_type_23();
		return L_6;
	}

IL_003f:
	{
		InvalidOperationException_t721527559 * L_7 = (InvalidOperationException_t721527559 *)il2cpp_codegen_object_new(InvalidOperationException_t721527559_il2cpp_TypeInfo_var);
		InvalidOperationException__ctor_m2801133788(L_7, _stringLiteral700545517, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_7);
	}

IL_004a:
	{
		return __this;
	}
}
// System.String System.Reflection.Emit.TypeBuilder::get_FullName()
extern "C"  String_t* TypeBuilder_get_FullName_m1626507516 (TypeBuilder_t3308873219 * __this, const MethodInfo* method)
{
	{
		String_t* L_0 = __this->get_fullname_21();
		return L_0;
	}
}
// System.Reflection.Module System.Reflection.Emit.TypeBuilder::get_Module()
extern "C"  Module_t4282841206 * TypeBuilder_get_Module_m1668298460 (TypeBuilder_t3308873219 * __this, const MethodInfo* method)
{
	{
		ModuleBuilder_t4156028127 * L_0 = __this->get_pmodule_18();
		return L_0;
	}
}
// System.String System.Reflection.Emit.TypeBuilder::get_Name()
extern "C"  String_t* TypeBuilder_get_Name_m170882803 (TypeBuilder_t3308873219 * __this, const MethodInfo* method)
{
	{
		String_t* L_0 = __this->get_tname_8();
		return L_0;
	}
}
// System.String System.Reflection.Emit.TypeBuilder::get_Namespace()
extern "C"  String_t* TypeBuilder_get_Namespace_m3562783599 (TypeBuilder_t3308873219 * __this, const MethodInfo* method)
{
	{
		String_t* L_0 = __this->get_nspace_9();
		return L_0;
	}
}
// System.Type System.Reflection.Emit.TypeBuilder::get_ReflectedType()
extern "C"  Type_t * TypeBuilder_get_ReflectedType_m2504081059 (TypeBuilder_t3308873219 * __this, const MethodInfo* method)
{
	{
		Type_t * L_0 = __this->get_nesting_type_11();
		return L_0;
	}
}
// System.Reflection.ConstructorInfo System.Reflection.Emit.TypeBuilder::GetConstructorImpl(System.Reflection.BindingFlags,System.Reflection.Binder,System.Reflection.CallingConventions,System.Type[],System.Reflection.ParameterModifier[])
extern const Il2CppType* Il2CppObject_0_0_0_var;
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern Il2CppClass* AmbiguousMatchException_t1406414556_il2cpp_TypeInfo_var;
extern Il2CppClass* MethodBaseU5BU5D_t2597254495_il2cpp_TypeInfo_var;
extern Il2CppClass* Binder_t3404612058_il2cpp_TypeInfo_var;
extern Il2CppClass* ConstructorInfo_t2851816542_il2cpp_TypeInfo_var;
extern const uint32_t TypeBuilder_GetConstructorImpl_m4192168686_MetadataUsageId;
extern "C"  ConstructorInfo_t2851816542 * TypeBuilder_GetConstructorImpl_m4192168686 (TypeBuilder_t3308873219 * __this, int32_t ___bindingAttr0, Binder_t3404612058 * ___binder1, int32_t ___callConvention2, TypeU5BU5D_t1664964607* ___types3, ParameterModifierU5BU5D_t963192633* ___modifiers4, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (TypeBuilder_GetConstructorImpl_m4192168686_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ConstructorBuilder_t700974433 * V_0 = NULL;
	int32_t V_1 = 0;
	ConstructorBuilder_t700974433 * V_2 = NULL;
	ConstructorBuilderU5BU5D_t775814140* V_3 = NULL;
	int32_t V_4 = 0;
	MethodBaseU5BU5D_t2597254495* V_5 = NULL;
	ConstructorInfo_t2851816542 * V_6 = NULL;
	ConstructorBuilderU5BU5D_t775814140* V_7 = NULL;
	int32_t V_8 = 0;
	{
		TypeBuilder_check_created_m2929267877(__this, /*hidden argument*/NULL);
		Type_t * L_0 = __this->get_created_20();
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_1 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Il2CppObject_0_0_0_var), /*hidden argument*/NULL);
		if ((!(((Il2CppObject*)(Type_t *)L_0) == ((Il2CppObject*)(Type_t *)L_1))))
		{
			goto IL_0112;
		}
	}
	{
		ConstructorBuilderU5BU5D_t775814140* L_2 = __this->get_ctors_15();
		if (L_2)
		{
			goto IL_0028;
		}
	}
	{
		return (ConstructorInfo_t2851816542 *)NULL;
	}

IL_0028:
	{
		V_0 = (ConstructorBuilder_t700974433 *)NULL;
		V_1 = 0;
		ConstructorBuilderU5BU5D_t775814140* L_3 = __this->get_ctors_15();
		V_3 = L_3;
		V_4 = 0;
		goto IL_0064;
	}

IL_003b:
	{
		ConstructorBuilderU5BU5D_t775814140* L_4 = V_3;
		int32_t L_5 = V_4;
		NullCheck(L_4);
		int32_t L_6 = L_5;
		ConstructorBuilder_t700974433 * L_7 = (L_4)->GetAt(static_cast<il2cpp_array_size_t>(L_6));
		V_2 = L_7;
		int32_t L_8 = ___callConvention2;
		if ((((int32_t)L_8) == ((int32_t)3)))
		{
			goto IL_0058;
		}
	}
	{
		ConstructorBuilder_t700974433 * L_9 = V_2;
		NullCheck(L_9);
		int32_t L_10 = ConstructorBuilder_get_CallingConvention_m443074051(L_9, /*hidden argument*/NULL);
		int32_t L_11 = ___callConvention2;
		if ((((int32_t)L_10) == ((int32_t)L_11)))
		{
			goto IL_0058;
		}
	}
	{
		goto IL_005e;
	}

IL_0058:
	{
		ConstructorBuilder_t700974433 * L_12 = V_2;
		V_0 = L_12;
		int32_t L_13 = V_1;
		V_1 = ((int32_t)((int32_t)L_13+(int32_t)1));
	}

IL_005e:
	{
		int32_t L_14 = V_4;
		V_4 = ((int32_t)((int32_t)L_14+(int32_t)1));
	}

IL_0064:
	{
		int32_t L_15 = V_4;
		ConstructorBuilderU5BU5D_t775814140* L_16 = V_3;
		NullCheck(L_16);
		if ((((int32_t)L_15) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_16)->max_length)))))))
		{
			goto IL_003b;
		}
	}
	{
		int32_t L_17 = V_1;
		if (L_17)
		{
			goto IL_0076;
		}
	}
	{
		return (ConstructorInfo_t2851816542 *)NULL;
	}

IL_0076:
	{
		TypeU5BU5D_t1664964607* L_18 = ___types3;
		if (L_18)
		{
			goto IL_008c;
		}
	}
	{
		int32_t L_19 = V_1;
		if ((((int32_t)L_19) <= ((int32_t)1)))
		{
			goto IL_008a;
		}
	}
	{
		AmbiguousMatchException_t1406414556 * L_20 = (AmbiguousMatchException_t1406414556 *)il2cpp_codegen_object_new(AmbiguousMatchException_t1406414556_il2cpp_TypeInfo_var);
		AmbiguousMatchException__ctor_m2088048346(L_20, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_20);
	}

IL_008a:
	{
		ConstructorBuilder_t700974433 * L_21 = V_0;
		return L_21;
	}

IL_008c:
	{
		int32_t L_22 = V_1;
		V_5 = ((MethodBaseU5BU5D_t2597254495*)SZArrayNew(MethodBaseU5BU5D_t2597254495_il2cpp_TypeInfo_var, (uint32_t)L_22));
		int32_t L_23 = V_1;
		if ((!(((uint32_t)L_23) == ((uint32_t)1))))
		{
			goto IL_00a5;
		}
	}
	{
		MethodBaseU5BU5D_t2597254495* L_24 = V_5;
		ConstructorBuilder_t700974433 * L_25 = V_0;
		NullCheck(L_24);
		ArrayElementTypeCheck (L_24, L_25);
		(L_24)->SetAt(static_cast<il2cpp_array_size_t>(0), (MethodBase_t904190842 *)L_25);
		goto IL_00f2;
	}

IL_00a5:
	{
		V_1 = 0;
		ConstructorBuilderU5BU5D_t775814140* L_26 = __this->get_ctors_15();
		V_7 = L_26;
		V_8 = 0;
		goto IL_00e7;
	}

IL_00b7:
	{
		ConstructorBuilderU5BU5D_t775814140* L_27 = V_7;
		int32_t L_28 = V_8;
		NullCheck(L_27);
		int32_t L_29 = L_28;
		ConstructorBuilder_t700974433 * L_30 = (L_27)->GetAt(static_cast<il2cpp_array_size_t>(L_29));
		V_6 = L_30;
		int32_t L_31 = ___callConvention2;
		if ((((int32_t)L_31) == ((int32_t)3)))
		{
			goto IL_00d7;
		}
	}
	{
		ConstructorInfo_t2851816542 * L_32 = V_6;
		NullCheck(L_32);
		int32_t L_33 = VirtFuncInvoker0< int32_t >::Invoke(20 /* System.Reflection.CallingConventions System.Reflection.MethodBase::get_CallingConvention() */, L_32);
		int32_t L_34 = ___callConvention2;
		if ((((int32_t)L_33) == ((int32_t)L_34)))
		{
			goto IL_00d7;
		}
	}
	{
		goto IL_00e1;
	}

IL_00d7:
	{
		MethodBaseU5BU5D_t2597254495* L_35 = V_5;
		int32_t L_36 = V_1;
		int32_t L_37 = L_36;
		V_1 = ((int32_t)((int32_t)L_37+(int32_t)1));
		ConstructorInfo_t2851816542 * L_38 = V_6;
		NullCheck(L_35);
		ArrayElementTypeCheck (L_35, L_38);
		(L_35)->SetAt(static_cast<il2cpp_array_size_t>(L_37), (MethodBase_t904190842 *)L_38);
	}

IL_00e1:
	{
		int32_t L_39 = V_8;
		V_8 = ((int32_t)((int32_t)L_39+(int32_t)1));
	}

IL_00e7:
	{
		int32_t L_40 = V_8;
		ConstructorBuilderU5BU5D_t775814140* L_41 = V_7;
		NullCheck(L_41);
		if ((((int32_t)L_40) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_41)->max_length)))))))
		{
			goto IL_00b7;
		}
	}

IL_00f2:
	{
		Binder_t3404612058 * L_42 = ___binder1;
		if (L_42)
		{
			goto IL_00ff;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(Binder_t3404612058_il2cpp_TypeInfo_var);
		Binder_t3404612058 * L_43 = Binder_get_DefaultBinder_m965620943(NULL /*static, unused*/, /*hidden argument*/NULL);
		___binder1 = L_43;
	}

IL_00ff:
	{
		Binder_t3404612058 * L_44 = ___binder1;
		int32_t L_45 = ___bindingAttr0;
		MethodBaseU5BU5D_t2597254495* L_46 = V_5;
		TypeU5BU5D_t1664964607* L_47 = ___types3;
		ParameterModifierU5BU5D_t963192633* L_48 = ___modifiers4;
		NullCheck(L_44);
		MethodBase_t904190842 * L_49 = VirtFuncInvoker4< MethodBase_t904190842 *, int32_t, MethodBaseU5BU5D_t2597254495*, TypeU5BU5D_t1664964607*, ParameterModifierU5BU5D_t963192633* >::Invoke(7 /* System.Reflection.MethodBase System.Reflection.Binder::SelectMethod(System.Reflection.BindingFlags,System.Reflection.MethodBase[],System.Type[],System.Reflection.ParameterModifier[]) */, L_44, L_45, L_46, L_47, L_48);
		return ((ConstructorInfo_t2851816542 *)CastclassClass(L_49, ConstructorInfo_t2851816542_il2cpp_TypeInfo_var));
	}

IL_0112:
	{
		Type_t * L_50 = __this->get_created_20();
		int32_t L_51 = ___bindingAttr0;
		Binder_t3404612058 * L_52 = ___binder1;
		int32_t L_53 = ___callConvention2;
		TypeU5BU5D_t1664964607* L_54 = ___types3;
		ParameterModifierU5BU5D_t963192633* L_55 = ___modifiers4;
		NullCheck(L_50);
		ConstructorInfo_t2851816542 * L_56 = Type_GetConstructor_m835344477(L_50, L_51, L_52, L_53, L_54, L_55, /*hidden argument*/NULL);
		return L_56;
	}
}
// System.Boolean System.Reflection.Emit.TypeBuilder::IsDefined(System.Type,System.Boolean)
extern Il2CppClass* NotSupportedException_t1793819818_il2cpp_TypeInfo_var;
extern Il2CppClass* MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var;
extern const uint32_t TypeBuilder_IsDefined_m3186251655_MetadataUsageId;
extern "C"  bool TypeBuilder_IsDefined_m3186251655 (TypeBuilder_t3308873219 * __this, Type_t * ___attributeType0, bool ___inherit1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (TypeBuilder_IsDefined_m3186251655_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		bool L_0 = TypeBuilder_get_is_created_m736553860(__this, /*hidden argument*/NULL);
		if (L_0)
		{
			goto IL_001c;
		}
	}
	{
		bool L_1 = TypeBuilder_get_IsCompilerContext_m3623403919(__this, /*hidden argument*/NULL);
		if (L_1)
		{
			goto IL_001c;
		}
	}
	{
		NotSupportedException_t1793819818 * L_2 = (NotSupportedException_t1793819818 *)il2cpp_codegen_object_new(NotSupportedException_t1793819818_il2cpp_TypeInfo_var);
		NotSupportedException__ctor_m3232764727(L_2, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_2);
	}

IL_001c:
	{
		Type_t * L_3 = ___attributeType0;
		bool L_4 = ___inherit1;
		IL2CPP_RUNTIME_CLASS_INIT(MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var);
		bool L_5 = MonoCustomAttrs_IsDefined_m3820363041(NULL /*static, unused*/, __this, L_3, L_4, /*hidden argument*/NULL);
		return L_5;
	}
}
// System.Object[] System.Reflection.Emit.TypeBuilder::GetCustomAttributes(System.Boolean)
extern "C"  ObjectU5BU5D_t3614634134* TypeBuilder_GetCustomAttributes_m1637538574 (TypeBuilder_t3308873219 * __this, bool ___inherit0, const MethodInfo* method)
{
	{
		TypeBuilder_check_created_m2929267877(__this, /*hidden argument*/NULL);
		Type_t * L_0 = __this->get_created_20();
		bool L_1 = ___inherit0;
		NullCheck(L_0);
		ObjectU5BU5D_t3614634134* L_2 = VirtFuncInvoker1< ObjectU5BU5D_t3614634134*, bool >::Invoke(12 /* System.Object[] System.Reflection.MemberInfo::GetCustomAttributes(System.Boolean) */, L_0, L_1);
		return L_2;
	}
}
// System.Object[] System.Reflection.Emit.TypeBuilder::GetCustomAttributes(System.Type,System.Boolean)
extern "C"  ObjectU5BU5D_t3614634134* TypeBuilder_GetCustomAttributes_m2702632361 (TypeBuilder_t3308873219 * __this, Type_t * ___attributeType0, bool ___inherit1, const MethodInfo* method)
{
	{
		TypeBuilder_check_created_m2929267877(__this, /*hidden argument*/NULL);
		Type_t * L_0 = __this->get_created_20();
		Type_t * L_1 = ___attributeType0;
		bool L_2 = ___inherit1;
		NullCheck(L_0);
		ObjectU5BU5D_t3614634134* L_3 = VirtFuncInvoker2< ObjectU5BU5D_t3614634134*, Type_t *, bool >::Invoke(13 /* System.Object[] System.Reflection.MemberInfo::GetCustomAttributes(System.Type,System.Boolean) */, L_0, L_1, L_2);
		return L_3;
	}
}
// System.Reflection.Emit.ConstructorBuilder System.Reflection.Emit.TypeBuilder::DefineConstructor(System.Reflection.MethodAttributes,System.Reflection.CallingConventions,System.Type[])
extern "C"  ConstructorBuilder_t700974433 * TypeBuilder_DefineConstructor_m3431248509 (TypeBuilder_t3308873219 * __this, int32_t ___attributes0, int32_t ___callingConvention1, TypeU5BU5D_t1664964607* ___parameterTypes2, const MethodInfo* method)
{
	{
		int32_t L_0 = ___attributes0;
		int32_t L_1 = ___callingConvention1;
		TypeU5BU5D_t1664964607* L_2 = ___parameterTypes2;
		ConstructorBuilder_t700974433 * L_3 = TypeBuilder_DefineConstructor_m2972481149(__this, L_0, L_1, L_2, (TypeU5BU5DU5BU5D_t2318378278*)(TypeU5BU5DU5BU5D_t2318378278*)NULL, (TypeU5BU5DU5BU5D_t2318378278*)(TypeU5BU5DU5BU5D_t2318378278*)NULL, /*hidden argument*/NULL);
		return L_3;
	}
}
// System.Reflection.Emit.ConstructorBuilder System.Reflection.Emit.TypeBuilder::DefineConstructor(System.Reflection.MethodAttributes,System.Reflection.CallingConventions,System.Type[],System.Type[][],System.Type[][])
extern Il2CppClass* ConstructorBuilder_t700974433_il2cpp_TypeInfo_var;
extern Il2CppClass* ConstructorBuilderU5BU5D_t775814140_il2cpp_TypeInfo_var;
extern const uint32_t TypeBuilder_DefineConstructor_m2972481149_MetadataUsageId;
extern "C"  ConstructorBuilder_t700974433 * TypeBuilder_DefineConstructor_m2972481149 (TypeBuilder_t3308873219 * __this, int32_t ___attributes0, int32_t ___callingConvention1, TypeU5BU5D_t1664964607* ___parameterTypes2, TypeU5BU5DU5BU5D_t2318378278* ___requiredCustomModifiers3, TypeU5BU5DU5BU5D_t2318378278* ___optionalCustomModifiers4, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (TypeBuilder_DefineConstructor_m2972481149_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ConstructorBuilder_t700974433 * V_0 = NULL;
	ConstructorBuilderU5BU5D_t775814140* V_1 = NULL;
	{
		TypeBuilder_check_not_created_m2785532739(__this, /*hidden argument*/NULL);
		int32_t L_0 = ___attributes0;
		int32_t L_1 = ___callingConvention1;
		TypeU5BU5D_t1664964607* L_2 = ___parameterTypes2;
		TypeU5BU5DU5BU5D_t2318378278* L_3 = ___requiredCustomModifiers3;
		TypeU5BU5DU5BU5D_t2318378278* L_4 = ___optionalCustomModifiers4;
		ConstructorBuilder_t700974433 * L_5 = (ConstructorBuilder_t700974433 *)il2cpp_codegen_object_new(ConstructorBuilder_t700974433_il2cpp_TypeInfo_var);
		ConstructorBuilder__ctor_m2001998159(L_5, __this, L_0, L_1, L_2, L_3, L_4, /*hidden argument*/NULL);
		V_0 = L_5;
		ConstructorBuilderU5BU5D_t775814140* L_6 = __this->get_ctors_15();
		if (!L_6)
		{
			goto IL_005a;
		}
	}
	{
		ConstructorBuilderU5BU5D_t775814140* L_7 = __this->get_ctors_15();
		NullCheck(L_7);
		V_1 = ((ConstructorBuilderU5BU5D_t775814140*)SZArrayNew(ConstructorBuilderU5BU5D_t775814140_il2cpp_TypeInfo_var, (uint32_t)((int32_t)((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_7)->max_length))))+(int32_t)1))));
		ConstructorBuilderU5BU5D_t775814140* L_8 = __this->get_ctors_15();
		ConstructorBuilderU5BU5D_t775814140* L_9 = V_1;
		ConstructorBuilderU5BU5D_t775814140* L_10 = __this->get_ctors_15();
		NullCheck(L_10);
		Array_Copy_m2363740072(NULL /*static, unused*/, (Il2CppArray *)(Il2CppArray *)L_8, (Il2CppArray *)(Il2CppArray *)L_9, (((int32_t)((int32_t)(((Il2CppArray *)L_10)->max_length)))), /*hidden argument*/NULL);
		ConstructorBuilderU5BU5D_t775814140* L_11 = V_1;
		ConstructorBuilderU5BU5D_t775814140* L_12 = __this->get_ctors_15();
		NullCheck(L_12);
		ConstructorBuilder_t700974433 * L_13 = V_0;
		NullCheck(L_11);
		ArrayElementTypeCheck (L_11, L_13);
		(L_11)->SetAt(static_cast<il2cpp_array_size_t>((((int32_t)((int32_t)(((Il2CppArray *)L_12)->max_length))))), (ConstructorBuilder_t700974433 *)L_13);
		ConstructorBuilderU5BU5D_t775814140* L_14 = V_1;
		__this->set_ctors_15(L_14);
		goto IL_006f;
	}

IL_005a:
	{
		__this->set_ctors_15(((ConstructorBuilderU5BU5D_t775814140*)SZArrayNew(ConstructorBuilderU5BU5D_t775814140_il2cpp_TypeInfo_var, (uint32_t)1)));
		ConstructorBuilderU5BU5D_t775814140* L_15 = __this->get_ctors_15();
		ConstructorBuilder_t700974433 * L_16 = V_0;
		NullCheck(L_15);
		ArrayElementTypeCheck (L_15, L_16);
		(L_15)->SetAt(static_cast<il2cpp_array_size_t>(0), (ConstructorBuilder_t700974433 *)L_16);
	}

IL_006f:
	{
		ConstructorBuilder_t700974433 * L_17 = V_0;
		return L_17;
	}
}
// System.Reflection.Emit.ConstructorBuilder System.Reflection.Emit.TypeBuilder::DefineDefaultConstructor(System.Reflection.MethodAttributes)
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern Il2CppClass* NotSupportedException_t1793819818_il2cpp_TypeInfo_var;
extern Il2CppClass* OpCodes_t3494785031_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral2507326364;
extern const uint32_t TypeBuilder_DefineDefaultConstructor_m2225828699_MetadataUsageId;
extern "C"  ConstructorBuilder_t700974433 * TypeBuilder_DefineDefaultConstructor_m2225828699 (TypeBuilder_t3308873219 * __this, int32_t ___attributes0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (TypeBuilder_DefineDefaultConstructor_m2225828699_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Type_t * V_0 = NULL;
	ConstructorInfo_t2851816542 * V_1 = NULL;
	ConstructorBuilder_t700974433 * V_2 = NULL;
	ILGenerator_t99948092 * V_3 = NULL;
	{
		Type_t * L_0 = __this->get_parent_10();
		if (!L_0)
		{
			goto IL_0017;
		}
	}
	{
		Type_t * L_1 = __this->get_parent_10();
		V_0 = L_1;
		goto IL_0028;
	}

IL_0017:
	{
		ModuleBuilder_t4156028127 * L_2 = __this->get_pmodule_18();
		NullCheck(L_2);
		AssemblyBuilder_t1646117627 * L_3 = L_2->get_assemblyb_12();
		NullCheck(L_3);
		Type_t * L_4 = L_3->get_corlib_object_type_12();
		V_0 = L_4;
	}

IL_0028:
	{
		Type_t * L_5 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		TypeU5BU5D_t1664964607* L_6 = ((Type_t_StaticFields*)Type_t_il2cpp_TypeInfo_var->static_fields)->get_EmptyTypes_3();
		NullCheck(L_5);
		ConstructorInfo_t2851816542 * L_7 = Type_GetConstructor_m663514781(L_5, ((int32_t)52), (Binder_t3404612058 *)NULL, L_6, (ParameterModifierU5BU5D_t963192633*)(ParameterModifierU5BU5D_t963192633*)NULL, /*hidden argument*/NULL);
		V_1 = L_7;
		ConstructorInfo_t2851816542 * L_8 = V_1;
		if (L_8)
		{
			goto IL_0049;
		}
	}
	{
		NotSupportedException_t1793819818 * L_9 = (NotSupportedException_t1793819818 *)il2cpp_codegen_object_new(NotSupportedException_t1793819818_il2cpp_TypeInfo_var);
		NotSupportedException__ctor_m836173213(L_9, _stringLiteral2507326364, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_9);
	}

IL_0049:
	{
		int32_t L_10 = ___attributes0;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		TypeU5BU5D_t1664964607* L_11 = ((Type_t_StaticFields*)Type_t_il2cpp_TypeInfo_var->static_fields)->get_EmptyTypes_3();
		ConstructorBuilder_t700974433 * L_12 = TypeBuilder_DefineConstructor_m3431248509(__this, L_10, 1, L_11, /*hidden argument*/NULL);
		V_2 = L_12;
		ConstructorBuilder_t700974433 * L_13 = V_2;
		NullCheck(L_13);
		ILGenerator_t99948092 * L_14 = ConstructorBuilder_GetILGenerator_m1407935730(L_13, /*hidden argument*/NULL);
		V_3 = L_14;
		ILGenerator_t99948092 * L_15 = V_3;
		IL2CPP_RUNTIME_CLASS_INIT(OpCodes_t3494785031_il2cpp_TypeInfo_var);
		OpCode_t2247480392  L_16 = ((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->get_Ldarg_0_2();
		NullCheck(L_15);
		VirtActionInvoker1< OpCode_t2247480392  >::Invoke(4 /* System.Void System.Reflection.Emit.ILGenerator::Emit(System.Reflection.Emit.OpCode) */, L_15, L_16);
		ILGenerator_t99948092 * L_17 = V_3;
		OpCode_t2247480392  L_18 = ((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->get_Call_39();
		ConstructorInfo_t2851816542 * L_19 = V_1;
		NullCheck(L_17);
		VirtActionInvoker2< OpCode_t2247480392 , ConstructorInfo_t2851816542 * >::Invoke(5 /* System.Void System.Reflection.Emit.ILGenerator::Emit(System.Reflection.Emit.OpCode,System.Reflection.ConstructorInfo) */, L_17, L_18, L_19);
		ILGenerator_t99948092 * L_20 = V_3;
		OpCode_t2247480392  L_21 = ((OpCodes_t3494785031_StaticFields*)OpCodes_t3494785031_il2cpp_TypeInfo_var->static_fields)->get_Ret_41();
		NullCheck(L_20);
		VirtActionInvoker1< OpCode_t2247480392  >::Invoke(4 /* System.Void System.Reflection.Emit.ILGenerator::Emit(System.Reflection.Emit.OpCode) */, L_20, L_21);
		ConstructorBuilder_t700974433 * L_22 = V_2;
		return L_22;
	}
}
// System.Type System.Reflection.Emit.TypeBuilder::create_runtime_class(System.Reflection.Emit.TypeBuilder)
extern "C"  Type_t * TypeBuilder_create_runtime_class_m2719530260 (TypeBuilder_t3308873219 * __this, TypeBuilder_t3308873219 * ___tb0, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef Type_t * (*TypeBuilder_create_runtime_class_m2719530260_ftn) (TypeBuilder_t3308873219 *, TypeBuilder_t3308873219 *);
	return  ((TypeBuilder_create_runtime_class_m2719530260_ftn)mscorlib::System::Reflection::Emit::TypeBuilder::create_runtime_class) (__this, ___tb0);
}
// System.Boolean System.Reflection.Emit.TypeBuilder::is_nested_in(System.Type)
extern "C"  bool TypeBuilder_is_nested_in_m3557898035 (TypeBuilder_t3308873219 * __this, Type_t * ___t0, const MethodInfo* method)
{
	{
		goto IL_0016;
	}

IL_0005:
	{
		Type_t * L_0 = ___t0;
		if ((!(((Il2CppObject*)(Type_t *)L_0) == ((Il2CppObject*)(TypeBuilder_t3308873219 *)__this))))
		{
			goto IL_000e;
		}
	}
	{
		return (bool)1;
	}

IL_000e:
	{
		Type_t * L_1 = ___t0;
		NullCheck(L_1);
		Type_t * L_2 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Type::get_DeclaringType() */, L_1);
		___t0 = L_2;
	}

IL_0016:
	{
		Type_t * L_3 = ___t0;
		if (L_3)
		{
			goto IL_0005;
		}
	}
	{
		return (bool)0;
	}
}
// System.Boolean System.Reflection.Emit.TypeBuilder::has_ctor_method()
extern Il2CppClass* ConstructorInfo_t2851816542_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern const uint32_t TypeBuilder_has_ctor_method_m3449702467_MetadataUsageId;
extern "C"  bool TypeBuilder_has_ctor_method_m3449702467 (TypeBuilder_t3308873219 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (TypeBuilder_has_ctor_method_m3449702467_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	MethodBuilder_t644187984 * V_2 = NULL;
	{
		V_0 = ((int32_t)6144);
		V_1 = 0;
		goto IL_003f;
	}

IL_000d:
	{
		MethodBuilderU5BU5D_t4238041457* L_0 = __this->get_methods_14();
		int32_t L_1 = V_1;
		NullCheck(L_0);
		int32_t L_2 = L_1;
		MethodBuilder_t644187984 * L_3 = (L_0)->GetAt(static_cast<il2cpp_array_size_t>(L_2));
		V_2 = L_3;
		MethodBuilder_t644187984 * L_4 = V_2;
		NullCheck(L_4);
		String_t* L_5 = MethodBuilder_get_Name_m845253610(L_4, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(ConstructorInfo_t2851816542_il2cpp_TypeInfo_var);
		String_t* L_6 = ((ConstructorInfo_t2851816542_StaticFields*)ConstructorInfo_t2851816542_il2cpp_TypeInfo_var->static_fields)->get_ConstructorName_0();
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_7 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_5, L_6, /*hidden argument*/NULL);
		if (!L_7)
		{
			goto IL_003b;
		}
	}
	{
		MethodBuilder_t644187984 * L_8 = V_2;
		NullCheck(L_8);
		int32_t L_9 = MethodBuilder_get_Attributes_m3678061338(L_8, /*hidden argument*/NULL);
		int32_t L_10 = V_0;
		int32_t L_11 = V_0;
		if ((!(((uint32_t)((int32_t)((int32_t)L_9&(int32_t)L_10))) == ((uint32_t)L_11))))
		{
			goto IL_003b;
		}
	}
	{
		return (bool)1;
	}

IL_003b:
	{
		int32_t L_12 = V_1;
		V_1 = ((int32_t)((int32_t)L_12+(int32_t)1));
	}

IL_003f:
	{
		int32_t L_13 = V_1;
		int32_t L_14 = __this->get_num_methods_13();
		if ((((int32_t)L_13) < ((int32_t)L_14)))
		{
			goto IL_000d;
		}
	}
	{
		return (bool)0;
	}
}
// System.Type System.Reflection.Emit.TypeBuilder::CreateType()
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* TypeBuilder_t3308873219_il2cpp_TypeInfo_var;
extern Il2CppClass* ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var;
extern Il2CppClass* TypeLoadException_t723359155_il2cpp_TypeInfo_var;
extern Il2CppClass* InvalidOperationException_t721527559_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral216645436;
extern Il2CppCodeGenString* _stringLiteral2411675321;
extern Il2CppCodeGenString* _stringLiteral2625238862;
extern Il2CppCodeGenString* _stringLiteral2961462794;
extern Il2CppCodeGenString* _stringLiteral159398136;
extern Il2CppCodeGenString* _stringLiteral959906687;
extern const uint32_t TypeBuilder_CreateType_m4126056124_MetadataUsageId;
extern "C"  Type_t * TypeBuilder_CreateType_m4126056124 (TypeBuilder_t3308873219 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (TypeBuilder_CreateType_m4126056124_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	FieldBuilder_t2784804005 * V_0 = NULL;
	FieldBuilderU5BU5D_t867683112* V_1 = NULL;
	int32_t V_2 = 0;
	Type_t * V_3 = NULL;
	TypeBuilder_t3308873219 * V_4 = NULL;
	bool V_5 = false;
	int32_t V_6 = 0;
	MethodBuilder_t644187984 * V_7 = NULL;
	ConstructorBuilder_t700974433 * V_8 = NULL;
	ConstructorBuilderU5BU5D_t775814140* V_9 = NULL;
	int32_t V_10 = 0;
	{
		bool L_0 = __this->get_createTypeCalled_22();
		if (!L_0)
		{
			goto IL_0012;
		}
	}
	{
		Type_t * L_1 = __this->get_created_20();
		return L_1;
	}

IL_0012:
	{
		bool L_2 = Type_get_IsInterface_m3583817465(__this, /*hidden argument*/NULL);
		if (L_2)
		{
			goto IL_0069;
		}
	}
	{
		Type_t * L_3 = __this->get_parent_10();
		if (L_3)
		{
			goto IL_0069;
		}
	}
	{
		ModuleBuilder_t4156028127 * L_4 = __this->get_pmodule_18();
		NullCheck(L_4);
		AssemblyBuilder_t1646117627 * L_5 = L_4->get_assemblyb_12();
		NullCheck(L_5);
		Type_t * L_6 = L_5->get_corlib_object_type_12();
		if ((((Il2CppObject*)(TypeBuilder_t3308873219 *)__this) == ((Il2CppObject*)(Type_t *)L_6)))
		{
			goto IL_0069;
		}
	}
	{
		String_t* L_7 = TypeBuilder_get_FullName_m1626507516(__this, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_8 = String_op_Inequality_m304203149(NULL /*static, unused*/, L_7, _stringLiteral216645436, /*hidden argument*/NULL);
		if (!L_8)
		{
			goto IL_0069;
		}
	}
	{
		ModuleBuilder_t4156028127 * L_9 = __this->get_pmodule_18();
		NullCheck(L_9);
		AssemblyBuilder_t1646117627 * L_10 = L_9->get_assemblyb_12();
		NullCheck(L_10);
		Type_t * L_11 = L_10->get_corlib_object_type_12();
		TypeBuilder_SetParent_m387557893(__this, L_11, /*hidden argument*/NULL);
	}

IL_0069:
	{
		TypeBuilder_create_generic_class_m986834171(__this, /*hidden argument*/NULL);
		FieldBuilderU5BU5D_t867683112* L_12 = __this->get_fields_16();
		if (!L_12)
		{
			goto IL_010c;
		}
	}
	{
		FieldBuilderU5BU5D_t867683112* L_13 = __this->get_fields_16();
		V_1 = L_13;
		V_2 = 0;
		goto IL_0103;
	}

IL_0088:
	{
		FieldBuilderU5BU5D_t867683112* L_14 = V_1;
		int32_t L_15 = V_2;
		NullCheck(L_14);
		int32_t L_16 = L_15;
		FieldBuilder_t2784804005 * L_17 = (L_14)->GetAt(static_cast<il2cpp_array_size_t>(L_16));
		V_0 = L_17;
		FieldBuilder_t2784804005 * L_18 = V_0;
		if (L_18)
		{
			goto IL_0097;
		}
	}
	{
		goto IL_00ff;
	}

IL_0097:
	{
		FieldBuilder_t2784804005 * L_19 = V_0;
		NullCheck(L_19);
		Type_t * L_20 = FieldBuilder_get_FieldType_m2267463269(L_19, /*hidden argument*/NULL);
		V_3 = L_20;
		FieldBuilder_t2784804005 * L_21 = V_0;
		NullCheck(L_21);
		bool L_22 = FieldInfo_get_IsStatic_m1411173225(L_21, /*hidden argument*/NULL);
		if (L_22)
		{
			goto IL_00ff;
		}
	}
	{
		Type_t * L_23 = V_3;
		if (!((TypeBuilder_t3308873219 *)IsInstSealed(L_23, TypeBuilder_t3308873219_il2cpp_TypeInfo_var)))
		{
			goto IL_00ff;
		}
	}
	{
		Type_t * L_24 = V_3;
		NullCheck(L_24);
		bool L_25 = Type_get_IsValueType_m1733572463(L_24, /*hidden argument*/NULL);
		if (!L_25)
		{
			goto IL_00ff;
		}
	}
	{
		Type_t * L_26 = V_3;
		if ((((Il2CppObject*)(Type_t *)L_26) == ((Il2CppObject*)(TypeBuilder_t3308873219 *)__this)))
		{
			goto IL_00ff;
		}
	}
	{
		Type_t * L_27 = V_3;
		bool L_28 = TypeBuilder_is_nested_in_m3557898035(__this, L_27, /*hidden argument*/NULL);
		if (!L_28)
		{
			goto IL_00ff;
		}
	}
	{
		Type_t * L_29 = V_3;
		V_4 = ((TypeBuilder_t3308873219 *)CastclassSealed(L_29, TypeBuilder_t3308873219_il2cpp_TypeInfo_var));
		TypeBuilder_t3308873219 * L_30 = V_4;
		NullCheck(L_30);
		bool L_31 = TypeBuilder_get_is_created_m736553860(L_30, /*hidden argument*/NULL);
		if (L_31)
		{
			goto IL_00ff;
		}
	}
	{
		AppDomain_t2719102437 * L_32 = AppDomain_get_CurrentDomain_m3432767403(NULL /*static, unused*/, /*hidden argument*/NULL);
		TypeBuilder_t3308873219 * L_33 = V_4;
		NullCheck(L_32);
		AppDomain_DoTypeResolve_m381738210(L_32, L_33, /*hidden argument*/NULL);
		TypeBuilder_t3308873219 * L_34 = V_4;
		NullCheck(L_34);
		bool L_35 = TypeBuilder_get_is_created_m736553860(L_34, /*hidden argument*/NULL);
		if (L_35)
		{
			goto IL_00ff;
		}
	}

IL_00ff:
	{
		int32_t L_36 = V_2;
		V_2 = ((int32_t)((int32_t)L_36+(int32_t)1));
	}

IL_0103:
	{
		int32_t L_37 = V_2;
		FieldBuilderU5BU5D_t867683112* L_38 = V_1;
		NullCheck(L_38);
		if ((((int32_t)L_37) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_38)->max_length)))))))
		{
			goto IL_0088;
		}
	}

IL_010c:
	{
		Type_t * L_39 = __this->get_parent_10();
		if (!L_39)
		{
			goto IL_0162;
		}
	}
	{
		Type_t * L_40 = __this->get_parent_10();
		NullCheck(L_40);
		bool L_41 = Type_get_IsSealed_m2380985836(L_40, /*hidden argument*/NULL);
		if (!L_41)
		{
			goto IL_0162;
		}
	}
	{
		ObjectU5BU5D_t3614634134* L_42 = ((ObjectU5BU5D_t3614634134*)SZArrayNew(ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var, (uint32_t)5));
		NullCheck(L_42);
		ArrayElementTypeCheck (L_42, _stringLiteral2411675321);
		(L_42)->SetAt(static_cast<il2cpp_array_size_t>(0), (Il2CppObject *)_stringLiteral2411675321);
		ObjectU5BU5D_t3614634134* L_43 = L_42;
		String_t* L_44 = TypeBuilder_get_FullName_m1626507516(__this, /*hidden argument*/NULL);
		NullCheck(L_43);
		ArrayElementTypeCheck (L_43, L_44);
		(L_43)->SetAt(static_cast<il2cpp_array_size_t>(1), (Il2CppObject *)L_44);
		ObjectU5BU5D_t3614634134* L_45 = L_43;
		NullCheck(L_45);
		ArrayElementTypeCheck (L_45, _stringLiteral2625238862);
		(L_45)->SetAt(static_cast<il2cpp_array_size_t>(2), (Il2CppObject *)_stringLiteral2625238862);
		ObjectU5BU5D_t3614634134* L_46 = L_45;
		Assembly_t4268412390 * L_47 = TypeBuilder_get_Assembly_m492491492(__this, /*hidden argument*/NULL);
		NullCheck(L_46);
		ArrayElementTypeCheck (L_46, L_47);
		(L_46)->SetAt(static_cast<il2cpp_array_size_t>(3), (Il2CppObject *)L_47);
		ObjectU5BU5D_t3614634134* L_48 = L_46;
		NullCheck(L_48);
		ArrayElementTypeCheck (L_48, _stringLiteral2961462794);
		(L_48)->SetAt(static_cast<il2cpp_array_size_t>(4), (Il2CppObject *)_stringLiteral2961462794);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_49 = String_Concat_m3881798623(NULL /*static, unused*/, L_48, /*hidden argument*/NULL);
		TypeLoadException_t723359155 * L_50 = (TypeLoadException_t723359155 *)il2cpp_codegen_object_new(TypeLoadException_t723359155_il2cpp_TypeInfo_var);
		TypeLoadException__ctor_m1903359728(L_50, L_49, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_50);
	}

IL_0162:
	{
		Type_t * L_51 = __this->get_parent_10();
		ModuleBuilder_t4156028127 * L_52 = __this->get_pmodule_18();
		NullCheck(L_52);
		AssemblyBuilder_t1646117627 * L_53 = L_52->get_assemblyb_12();
		NullCheck(L_53);
		Type_t * L_54 = L_53->get_corlib_enum_type_14();
		if ((!(((Il2CppObject*)(Type_t *)L_51) == ((Il2CppObject*)(Type_t *)L_54))))
		{
			goto IL_01c3;
		}
	}
	{
		MethodBuilderU5BU5D_t4238041457* L_55 = __this->get_methods_14();
		if (!L_55)
		{
			goto IL_01c3;
		}
	}
	{
		ObjectU5BU5D_t3614634134* L_56 = ((ObjectU5BU5D_t3614634134*)SZArrayNew(ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var, (uint32_t)5));
		NullCheck(L_56);
		ArrayElementTypeCheck (L_56, _stringLiteral2411675321);
		(L_56)->SetAt(static_cast<il2cpp_array_size_t>(0), (Il2CppObject *)_stringLiteral2411675321);
		ObjectU5BU5D_t3614634134* L_57 = L_56;
		String_t* L_58 = TypeBuilder_get_FullName_m1626507516(__this, /*hidden argument*/NULL);
		NullCheck(L_57);
		ArrayElementTypeCheck (L_57, L_58);
		(L_57)->SetAt(static_cast<il2cpp_array_size_t>(1), (Il2CppObject *)L_58);
		ObjectU5BU5D_t3614634134* L_59 = L_57;
		NullCheck(L_59);
		ArrayElementTypeCheck (L_59, _stringLiteral2625238862);
		(L_59)->SetAt(static_cast<il2cpp_array_size_t>(2), (Il2CppObject *)_stringLiteral2625238862);
		ObjectU5BU5D_t3614634134* L_60 = L_59;
		Assembly_t4268412390 * L_61 = TypeBuilder_get_Assembly_m492491492(__this, /*hidden argument*/NULL);
		NullCheck(L_60);
		ArrayElementTypeCheck (L_60, L_61);
		(L_60)->SetAt(static_cast<il2cpp_array_size_t>(3), (Il2CppObject *)L_61);
		ObjectU5BU5D_t3614634134* L_62 = L_60;
		NullCheck(L_62);
		ArrayElementTypeCheck (L_62, _stringLiteral159398136);
		(L_62)->SetAt(static_cast<il2cpp_array_size_t>(4), (Il2CppObject *)_stringLiteral159398136);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_63 = String_Concat_m3881798623(NULL /*static, unused*/, L_62, /*hidden argument*/NULL);
		TypeLoadException_t723359155 * L_64 = (TypeLoadException_t723359155 *)il2cpp_codegen_object_new(TypeLoadException_t723359155_il2cpp_TypeInfo_var);
		TypeLoadException__ctor_m1903359728(L_64, L_63, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_64);
	}

IL_01c3:
	{
		MethodBuilderU5BU5D_t4238041457* L_65 = __this->get_methods_14();
		if (!L_65)
		{
			goto IL_0232;
		}
	}
	{
		bool L_66 = Type_get_IsAbstract_m2532060002(__this, /*hidden argument*/NULL);
		V_5 = (bool)((((int32_t)L_66) == ((int32_t)0))? 1 : 0);
		V_6 = 0;
		goto IL_0225;
	}

IL_01e1:
	{
		MethodBuilderU5BU5D_t4238041457* L_67 = __this->get_methods_14();
		int32_t L_68 = V_6;
		NullCheck(L_67);
		int32_t L_69 = L_68;
		MethodBuilder_t644187984 * L_70 = (L_67)->GetAt(static_cast<il2cpp_array_size_t>(L_69));
		V_7 = L_70;
		bool L_71 = V_5;
		if (!L_71)
		{
			goto IL_0211;
		}
	}
	{
		MethodBuilder_t644187984 * L_72 = V_7;
		NullCheck(L_72);
		bool L_73 = MethodBase_get_IsAbstract_m3521819231(L_72, /*hidden argument*/NULL);
		if (!L_73)
		{
			goto IL_0211;
		}
	}
	{
		MethodBuilder_t644187984 * L_74 = V_7;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_75 = String_Concat_m56707527(NULL /*static, unused*/, _stringLiteral959906687, L_74, /*hidden argument*/NULL);
		InvalidOperationException_t721527559 * L_76 = (InvalidOperationException_t721527559 *)il2cpp_codegen_object_new(InvalidOperationException_t721527559_il2cpp_TypeInfo_var);
		InvalidOperationException__ctor_m2801133788(L_76, L_75, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_76);
	}

IL_0211:
	{
		MethodBuilder_t644187984 * L_77 = V_7;
		NullCheck(L_77);
		MethodBuilder_check_override_m3042345804(L_77, /*hidden argument*/NULL);
		MethodBuilder_t644187984 * L_78 = V_7;
		NullCheck(L_78);
		MethodBuilder_fixup_m4217981161(L_78, /*hidden argument*/NULL);
		int32_t L_79 = V_6;
		V_6 = ((int32_t)((int32_t)L_79+(int32_t)1));
	}

IL_0225:
	{
		int32_t L_80 = V_6;
		int32_t L_81 = __this->get_num_methods_13();
		if ((((int32_t)L_80) < ((int32_t)L_81)))
		{
			goto IL_01e1;
		}
	}

IL_0232:
	{
		bool L_82 = Type_get_IsInterface_m3583817465(__this, /*hidden argument*/NULL);
		if (L_82)
		{
			goto IL_0297;
		}
	}
	{
		bool L_83 = Type_get_IsValueType_m1733572463(__this, /*hidden argument*/NULL);
		if (L_83)
		{
			goto IL_0297;
		}
	}
	{
		ConstructorBuilderU5BU5D_t775814140* L_84 = __this->get_ctors_15();
		if (L_84)
		{
			goto IL_0297;
		}
	}
	{
		String_t* L_85 = __this->get_tname_8();
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_86 = String_op_Inequality_m304203149(NULL /*static, unused*/, L_85, _stringLiteral216645436, /*hidden argument*/NULL);
		if (!L_86)
		{
			goto IL_0297;
		}
	}
	{
		int32_t L_87 = TypeBuilder_GetAttributeFlagsImpl_m2593449699(__this, /*hidden argument*/NULL);
		if ((((int32_t)((int32_t)((int32_t)((int32_t)((int32_t)L_87&(int32_t)((int32_t)128)))|(int32_t)((int32_t)256)))) == ((int32_t)((int32_t)384))))
		{
			goto IL_0297;
		}
	}
	{
		bool L_88 = TypeBuilder_has_ctor_method_m3449702467(__this, /*hidden argument*/NULL);
		if (L_88)
		{
			goto IL_0297;
		}
	}
	{
		TypeBuilder_DefineDefaultConstructor_m2225828699(__this, 6, /*hidden argument*/NULL);
	}

IL_0297:
	{
		ConstructorBuilderU5BU5D_t775814140* L_89 = __this->get_ctors_15();
		if (!L_89)
		{
			goto IL_02d1;
		}
	}
	{
		ConstructorBuilderU5BU5D_t775814140* L_90 = __this->get_ctors_15();
		V_9 = L_90;
		V_10 = 0;
		goto IL_02c6;
	}

IL_02b2:
	{
		ConstructorBuilderU5BU5D_t775814140* L_91 = V_9;
		int32_t L_92 = V_10;
		NullCheck(L_91);
		int32_t L_93 = L_92;
		ConstructorBuilder_t700974433 * L_94 = (L_91)->GetAt(static_cast<il2cpp_array_size_t>(L_93));
		V_8 = L_94;
		ConstructorBuilder_t700974433 * L_95 = V_8;
		NullCheck(L_95);
		ConstructorBuilder_fixup_m836985654(L_95, /*hidden argument*/NULL);
		int32_t L_96 = V_10;
		V_10 = ((int32_t)((int32_t)L_96+(int32_t)1));
	}

IL_02c6:
	{
		int32_t L_97 = V_10;
		ConstructorBuilderU5BU5D_t775814140* L_98 = V_9;
		NullCheck(L_98);
		if ((((int32_t)L_97) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_98)->max_length)))))))
		{
			goto IL_02b2;
		}
	}

IL_02d1:
	{
		__this->set_createTypeCalled_22((bool)1);
		Type_t * L_99 = TypeBuilder_create_runtime_class_m2719530260(__this, __this, /*hidden argument*/NULL);
		__this->set_created_20(L_99);
		Type_t * L_100 = __this->get_created_20();
		if (!L_100)
		{
			goto IL_02f7;
		}
	}
	{
		Type_t * L_101 = __this->get_created_20();
		return L_101;
	}

IL_02f7:
	{
		return __this;
	}
}
// System.Reflection.ConstructorInfo[] System.Reflection.Emit.TypeBuilder::GetConstructors(System.Reflection.BindingFlags)
extern Il2CppClass* NotSupportedException_t1793819818_il2cpp_TypeInfo_var;
extern const uint32_t TypeBuilder_GetConstructors_m774120094_MetadataUsageId;
extern "C"  ConstructorInfoU5BU5D_t1996683371* TypeBuilder_GetConstructors_m774120094 (TypeBuilder_t3308873219 * __this, int32_t ___bindingAttr0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (TypeBuilder_GetConstructors_m774120094_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		bool L_0 = TypeBuilder_get_is_created_m736553860(__this, /*hidden argument*/NULL);
		if (!L_0)
		{
			goto IL_0018;
		}
	}
	{
		Type_t * L_1 = __this->get_created_20();
		int32_t L_2 = ___bindingAttr0;
		NullCheck(L_1);
		ConstructorInfoU5BU5D_t1996683371* L_3 = VirtFuncInvoker1< ConstructorInfoU5BU5D_t1996683371*, int32_t >::Invoke(73 /* System.Reflection.ConstructorInfo[] System.Type::GetConstructors(System.Reflection.BindingFlags) */, L_1, L_2);
		return L_3;
	}

IL_0018:
	{
		bool L_4 = TypeBuilder_get_IsCompilerContext_m3623403919(__this, /*hidden argument*/NULL);
		if (L_4)
		{
			goto IL_0029;
		}
	}
	{
		NotSupportedException_t1793819818 * L_5 = (NotSupportedException_t1793819818 *)il2cpp_codegen_object_new(NotSupportedException_t1793819818_il2cpp_TypeInfo_var);
		NotSupportedException__ctor_m3232764727(L_5, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_5);
	}

IL_0029:
	{
		int32_t L_6 = ___bindingAttr0;
		ConstructorInfoU5BU5D_t1996683371* L_7 = TypeBuilder_GetConstructorsInternal_m2426192231(__this, L_6, /*hidden argument*/NULL);
		return L_7;
	}
}
// System.Reflection.ConstructorInfo[] System.Reflection.Emit.TypeBuilder::GetConstructorsInternal(System.Reflection.BindingFlags)
extern Il2CppClass* ConstructorInfoU5BU5D_t1996683371_il2cpp_TypeInfo_var;
extern Il2CppClass* ArrayList_t4252133567_il2cpp_TypeInfo_var;
extern const uint32_t TypeBuilder_GetConstructorsInternal_m2426192231_MetadataUsageId;
extern "C"  ConstructorInfoU5BU5D_t1996683371* TypeBuilder_GetConstructorsInternal_m2426192231 (TypeBuilder_t3308873219 * __this, int32_t ___bindingAttr0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (TypeBuilder_GetConstructorsInternal_m2426192231_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ArrayList_t4252133567 * V_0 = NULL;
	bool V_1 = false;
	int32_t V_2 = 0;
	ConstructorBuilder_t700974433 * V_3 = NULL;
	ConstructorBuilderU5BU5D_t775814140* V_4 = NULL;
	int32_t V_5 = 0;
	ConstructorInfoU5BU5D_t1996683371* V_6 = NULL;
	{
		ConstructorBuilderU5BU5D_t775814140* L_0 = __this->get_ctors_15();
		if (L_0)
		{
			goto IL_0012;
		}
	}
	{
		return ((ConstructorInfoU5BU5D_t1996683371*)SZArrayNew(ConstructorInfoU5BU5D_t1996683371_il2cpp_TypeInfo_var, (uint32_t)0));
	}

IL_0012:
	{
		ArrayList_t4252133567 * L_1 = (ArrayList_t4252133567 *)il2cpp_codegen_object_new(ArrayList_t4252133567_il2cpp_TypeInfo_var);
		ArrayList__ctor_m4012174379(L_1, /*hidden argument*/NULL);
		V_0 = L_1;
		ConstructorBuilderU5BU5D_t775814140* L_2 = __this->get_ctors_15();
		V_4 = L_2;
		V_5 = 0;
		goto IL_00a3;
	}

IL_0028:
	{
		ConstructorBuilderU5BU5D_t775814140* L_3 = V_4;
		int32_t L_4 = V_5;
		NullCheck(L_3);
		int32_t L_5 = L_4;
		ConstructorBuilder_t700974433 * L_6 = (L_3)->GetAt(static_cast<il2cpp_array_size_t>(L_5));
		V_3 = L_6;
		V_1 = (bool)0;
		ConstructorBuilder_t700974433 * L_7 = V_3;
		NullCheck(L_7);
		int32_t L_8 = ConstructorBuilder_get_Attributes_m2137353707(L_7, /*hidden argument*/NULL);
		V_2 = L_8;
		int32_t L_9 = V_2;
		if ((!(((uint32_t)((int32_t)((int32_t)L_9&(int32_t)7))) == ((uint32_t)6))))
		{
			goto IL_0050;
		}
	}
	{
		int32_t L_10 = ___bindingAttr0;
		if (!((int32_t)((int32_t)L_10&(int32_t)((int32_t)16))))
		{
			goto IL_004b;
		}
	}
	{
		V_1 = (bool)1;
	}

IL_004b:
	{
		goto IL_005b;
	}

IL_0050:
	{
		int32_t L_11 = ___bindingAttr0;
		if (!((int32_t)((int32_t)L_11&(int32_t)((int32_t)32))))
		{
			goto IL_005b;
		}
	}
	{
		V_1 = (bool)1;
	}

IL_005b:
	{
		bool L_12 = V_1;
		if (L_12)
		{
			goto IL_0066;
		}
	}
	{
		goto IL_009d;
	}

IL_0066:
	{
		V_1 = (bool)0;
		int32_t L_13 = V_2;
		if (!((int32_t)((int32_t)L_13&(int32_t)((int32_t)16))))
		{
			goto IL_0080;
		}
	}
	{
		int32_t L_14 = ___bindingAttr0;
		if (!((int32_t)((int32_t)L_14&(int32_t)8)))
		{
			goto IL_007b;
		}
	}
	{
		V_1 = (bool)1;
	}

IL_007b:
	{
		goto IL_008a;
	}

IL_0080:
	{
		int32_t L_15 = ___bindingAttr0;
		if (!((int32_t)((int32_t)L_15&(int32_t)4)))
		{
			goto IL_008a;
		}
	}
	{
		V_1 = (bool)1;
	}

IL_008a:
	{
		bool L_16 = V_1;
		if (L_16)
		{
			goto IL_0095;
		}
	}
	{
		goto IL_009d;
	}

IL_0095:
	{
		ArrayList_t4252133567 * L_17 = V_0;
		ConstructorBuilder_t700974433 * L_18 = V_3;
		NullCheck(L_17);
		VirtFuncInvoker1< int32_t, Il2CppObject * >::Invoke(30 /* System.Int32 System.Collections.ArrayList::Add(System.Object) */, L_17, L_18);
	}

IL_009d:
	{
		int32_t L_19 = V_5;
		V_5 = ((int32_t)((int32_t)L_19+(int32_t)1));
	}

IL_00a3:
	{
		int32_t L_20 = V_5;
		ConstructorBuilderU5BU5D_t775814140* L_21 = V_4;
		NullCheck(L_21);
		if ((((int32_t)L_20) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_21)->max_length)))))))
		{
			goto IL_0028;
		}
	}
	{
		ArrayList_t4252133567 * L_22 = V_0;
		NullCheck(L_22);
		int32_t L_23 = VirtFuncInvoker0< int32_t >::Invoke(23 /* System.Int32 System.Collections.ArrayList::get_Count() */, L_22);
		V_6 = ((ConstructorInfoU5BU5D_t1996683371*)SZArrayNew(ConstructorInfoU5BU5D_t1996683371_il2cpp_TypeInfo_var, (uint32_t)L_23));
		ArrayList_t4252133567 * L_24 = V_0;
		ConstructorInfoU5BU5D_t1996683371* L_25 = V_6;
		NullCheck(L_24);
		VirtActionInvoker1< Il2CppArray * >::Invoke(40 /* System.Void System.Collections.ArrayList::CopyTo(System.Array) */, L_24, (Il2CppArray *)(Il2CppArray *)L_25);
		ConstructorInfoU5BU5D_t1996683371* L_26 = V_6;
		return L_26;
	}
}
// System.Type System.Reflection.Emit.TypeBuilder::GetElementType()
extern Il2CppClass* NotSupportedException_t1793819818_il2cpp_TypeInfo_var;
extern const uint32_t TypeBuilder_GetElementType_m3707448372_MetadataUsageId;
extern "C"  Type_t * TypeBuilder_GetElementType_m3707448372 (TypeBuilder_t3308873219 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (TypeBuilder_GetElementType_m3707448372_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		NotSupportedException_t1793819818 * L_0 = (NotSupportedException_t1793819818 *)il2cpp_codegen_object_new(NotSupportedException_t1793819818_il2cpp_TypeInfo_var);
		NotSupportedException__ctor_m3232764727(L_0, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Reflection.EventInfo System.Reflection.Emit.TypeBuilder::GetEvent(System.String,System.Reflection.BindingFlags)
extern "C"  EventInfo_t * TypeBuilder_GetEvent_m3876348075 (TypeBuilder_t3308873219 * __this, String_t* ___name0, int32_t ___bindingAttr1, const MethodInfo* method)
{
	{
		TypeBuilder_check_created_m2929267877(__this, /*hidden argument*/NULL);
		Type_t * L_0 = __this->get_created_20();
		String_t* L_1 = ___name0;
		int32_t L_2 = ___bindingAttr1;
		NullCheck(L_0);
		EventInfo_t * L_3 = VirtFuncInvoker2< EventInfo_t *, String_t*, int32_t >::Invoke(43 /* System.Reflection.EventInfo System.Type::GetEvent(System.String,System.Reflection.BindingFlags) */, L_0, L_1, L_2);
		return L_3;
	}
}
// System.Reflection.FieldInfo System.Reflection.Emit.TypeBuilder::GetField(System.String,System.Reflection.BindingFlags)
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern const uint32_t TypeBuilder_GetField_m2112455315_MetadataUsageId;
extern "C"  FieldInfo_t * TypeBuilder_GetField_m2112455315 (TypeBuilder_t3308873219 * __this, String_t* ___name0, int32_t ___bindingAttr1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (TypeBuilder_GetField_m2112455315_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	bool V_0 = false;
	int32_t V_1 = 0;
	FieldInfo_t * V_2 = NULL;
	FieldBuilderU5BU5D_t867683112* V_3 = NULL;
	int32_t V_4 = 0;
	{
		Type_t * L_0 = __this->get_created_20();
		if (!L_0)
		{
			goto IL_0019;
		}
	}
	{
		Type_t * L_1 = __this->get_created_20();
		String_t* L_2 = ___name0;
		int32_t L_3 = ___bindingAttr1;
		NullCheck(L_1);
		FieldInfo_t * L_4 = VirtFuncInvoker2< FieldInfo_t *, String_t*, int32_t >::Invoke(45 /* System.Reflection.FieldInfo System.Type::GetField(System.String,System.Reflection.BindingFlags) */, L_1, L_2, L_3);
		return L_4;
	}

IL_0019:
	{
		FieldBuilderU5BU5D_t867683112* L_5 = __this->get_fields_16();
		if (L_5)
		{
			goto IL_0026;
		}
	}
	{
		return (FieldInfo_t *)NULL;
	}

IL_0026:
	{
		FieldBuilderU5BU5D_t867683112* L_6 = __this->get_fields_16();
		V_3 = L_6;
		V_4 = 0;
		goto IL_00ca;
	}

IL_0035:
	{
		FieldBuilderU5BU5D_t867683112* L_7 = V_3;
		int32_t L_8 = V_4;
		NullCheck(L_7);
		int32_t L_9 = L_8;
		FieldBuilder_t2784804005 * L_10 = (L_7)->GetAt(static_cast<il2cpp_array_size_t>(L_9));
		V_2 = L_10;
		FieldInfo_t * L_11 = V_2;
		if (L_11)
		{
			goto IL_0045;
		}
	}
	{
		goto IL_00c4;
	}

IL_0045:
	{
		FieldInfo_t * L_12 = V_2;
		NullCheck(L_12);
		String_t* L_13 = VirtFuncInvoker0< String_t* >::Invoke(8 /* System.String System.Reflection.MemberInfo::get_Name() */, L_12);
		String_t* L_14 = ___name0;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_15 = String_op_Inequality_m304203149(NULL /*static, unused*/, L_13, L_14, /*hidden argument*/NULL);
		if (!L_15)
		{
			goto IL_005b;
		}
	}
	{
		goto IL_00c4;
	}

IL_005b:
	{
		V_0 = (bool)0;
		FieldInfo_t * L_16 = V_2;
		NullCheck(L_16);
		int32_t L_17 = VirtFuncInvoker0< int32_t >::Invoke(14 /* System.Reflection.FieldAttributes System.Reflection.FieldInfo::get_Attributes() */, L_16);
		V_1 = L_17;
		int32_t L_18 = V_1;
		if ((!(((uint32_t)((int32_t)((int32_t)L_18&(int32_t)7))) == ((uint32_t)6))))
		{
			goto IL_007d;
		}
	}
	{
		int32_t L_19 = ___bindingAttr1;
		if (!((int32_t)((int32_t)L_19&(int32_t)((int32_t)16))))
		{
			goto IL_0078;
		}
	}
	{
		V_0 = (bool)1;
	}

IL_0078:
	{
		goto IL_0088;
	}

IL_007d:
	{
		int32_t L_20 = ___bindingAttr1;
		if (!((int32_t)((int32_t)L_20&(int32_t)((int32_t)32))))
		{
			goto IL_0088;
		}
	}
	{
		V_0 = (bool)1;
	}

IL_0088:
	{
		bool L_21 = V_0;
		if (L_21)
		{
			goto IL_0093;
		}
	}
	{
		goto IL_00c4;
	}

IL_0093:
	{
		V_0 = (bool)0;
		int32_t L_22 = V_1;
		if (!((int32_t)((int32_t)L_22&(int32_t)((int32_t)16))))
		{
			goto IL_00ad;
		}
	}
	{
		int32_t L_23 = ___bindingAttr1;
		if (!((int32_t)((int32_t)L_23&(int32_t)8)))
		{
			goto IL_00a8;
		}
	}
	{
		V_0 = (bool)1;
	}

IL_00a8:
	{
		goto IL_00b7;
	}

IL_00ad:
	{
		int32_t L_24 = ___bindingAttr1;
		if (!((int32_t)((int32_t)L_24&(int32_t)4)))
		{
			goto IL_00b7;
		}
	}
	{
		V_0 = (bool)1;
	}

IL_00b7:
	{
		bool L_25 = V_0;
		if (L_25)
		{
			goto IL_00c2;
		}
	}
	{
		goto IL_00c4;
	}

IL_00c2:
	{
		FieldInfo_t * L_26 = V_2;
		return L_26;
	}

IL_00c4:
	{
		int32_t L_27 = V_4;
		V_4 = ((int32_t)((int32_t)L_27+(int32_t)1));
	}

IL_00ca:
	{
		int32_t L_28 = V_4;
		FieldBuilderU5BU5D_t867683112* L_29 = V_3;
		NullCheck(L_29);
		if ((((int32_t)L_28) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_29)->max_length)))))))
		{
			goto IL_0035;
		}
	}
	{
		return (FieldInfo_t *)NULL;
	}
}
// System.Reflection.FieldInfo[] System.Reflection.Emit.TypeBuilder::GetFields(System.Reflection.BindingFlags)
extern Il2CppClass* FieldInfoU5BU5D_t125053523_il2cpp_TypeInfo_var;
extern Il2CppClass* ArrayList_t4252133567_il2cpp_TypeInfo_var;
extern const uint32_t TypeBuilder_GetFields_m3875401338_MetadataUsageId;
extern "C"  FieldInfoU5BU5D_t125053523* TypeBuilder_GetFields_m3875401338 (TypeBuilder_t3308873219 * __this, int32_t ___bindingAttr0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (TypeBuilder_GetFields_m3875401338_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ArrayList_t4252133567 * V_0 = NULL;
	bool V_1 = false;
	int32_t V_2 = 0;
	FieldInfo_t * V_3 = NULL;
	FieldBuilderU5BU5D_t867683112* V_4 = NULL;
	int32_t V_5 = 0;
	FieldInfoU5BU5D_t125053523* V_6 = NULL;
	{
		Type_t * L_0 = __this->get_created_20();
		if (!L_0)
		{
			goto IL_0018;
		}
	}
	{
		Type_t * L_1 = __this->get_created_20();
		int32_t L_2 = ___bindingAttr0;
		NullCheck(L_1);
		FieldInfoU5BU5D_t125053523* L_3 = VirtFuncInvoker1< FieldInfoU5BU5D_t125053523*, int32_t >::Invoke(46 /* System.Reflection.FieldInfo[] System.Type::GetFields(System.Reflection.BindingFlags) */, L_1, L_2);
		return L_3;
	}

IL_0018:
	{
		FieldBuilderU5BU5D_t867683112* L_4 = __this->get_fields_16();
		if (L_4)
		{
			goto IL_002a;
		}
	}
	{
		return ((FieldInfoU5BU5D_t125053523*)SZArrayNew(FieldInfoU5BU5D_t125053523_il2cpp_TypeInfo_var, (uint32_t)0));
	}

IL_002a:
	{
		ArrayList_t4252133567 * L_5 = (ArrayList_t4252133567 *)il2cpp_codegen_object_new(ArrayList_t4252133567_il2cpp_TypeInfo_var);
		ArrayList__ctor_m4012174379(L_5, /*hidden argument*/NULL);
		V_0 = L_5;
		FieldBuilderU5BU5D_t867683112* L_6 = __this->get_fields_16();
		V_4 = L_6;
		V_5 = 0;
		goto IL_00c6;
	}

IL_0040:
	{
		FieldBuilderU5BU5D_t867683112* L_7 = V_4;
		int32_t L_8 = V_5;
		NullCheck(L_7);
		int32_t L_9 = L_8;
		FieldBuilder_t2784804005 * L_10 = (L_7)->GetAt(static_cast<il2cpp_array_size_t>(L_9));
		V_3 = L_10;
		FieldInfo_t * L_11 = V_3;
		if (L_11)
		{
			goto IL_0051;
		}
	}
	{
		goto IL_00c0;
	}

IL_0051:
	{
		V_1 = (bool)0;
		FieldInfo_t * L_12 = V_3;
		NullCheck(L_12);
		int32_t L_13 = VirtFuncInvoker0< int32_t >::Invoke(14 /* System.Reflection.FieldAttributes System.Reflection.FieldInfo::get_Attributes() */, L_12);
		V_2 = L_13;
		int32_t L_14 = V_2;
		if ((!(((uint32_t)((int32_t)((int32_t)L_14&(int32_t)7))) == ((uint32_t)6))))
		{
			goto IL_0073;
		}
	}
	{
		int32_t L_15 = ___bindingAttr0;
		if (!((int32_t)((int32_t)L_15&(int32_t)((int32_t)16))))
		{
			goto IL_006e;
		}
	}
	{
		V_1 = (bool)1;
	}

IL_006e:
	{
		goto IL_007e;
	}

IL_0073:
	{
		int32_t L_16 = ___bindingAttr0;
		if (!((int32_t)((int32_t)L_16&(int32_t)((int32_t)32))))
		{
			goto IL_007e;
		}
	}
	{
		V_1 = (bool)1;
	}

IL_007e:
	{
		bool L_17 = V_1;
		if (L_17)
		{
			goto IL_0089;
		}
	}
	{
		goto IL_00c0;
	}

IL_0089:
	{
		V_1 = (bool)0;
		int32_t L_18 = V_2;
		if (!((int32_t)((int32_t)L_18&(int32_t)((int32_t)16))))
		{
			goto IL_00a3;
		}
	}
	{
		int32_t L_19 = ___bindingAttr0;
		if (!((int32_t)((int32_t)L_19&(int32_t)8)))
		{
			goto IL_009e;
		}
	}
	{
		V_1 = (bool)1;
	}

IL_009e:
	{
		goto IL_00ad;
	}

IL_00a3:
	{
		int32_t L_20 = ___bindingAttr0;
		if (!((int32_t)((int32_t)L_20&(int32_t)4)))
		{
			goto IL_00ad;
		}
	}
	{
		V_1 = (bool)1;
	}

IL_00ad:
	{
		bool L_21 = V_1;
		if (L_21)
		{
			goto IL_00b8;
		}
	}
	{
		goto IL_00c0;
	}

IL_00b8:
	{
		ArrayList_t4252133567 * L_22 = V_0;
		FieldInfo_t * L_23 = V_3;
		NullCheck(L_22);
		VirtFuncInvoker1< int32_t, Il2CppObject * >::Invoke(30 /* System.Int32 System.Collections.ArrayList::Add(System.Object) */, L_22, L_23);
	}

IL_00c0:
	{
		int32_t L_24 = V_5;
		V_5 = ((int32_t)((int32_t)L_24+(int32_t)1));
	}

IL_00c6:
	{
		int32_t L_25 = V_5;
		FieldBuilderU5BU5D_t867683112* L_26 = V_4;
		NullCheck(L_26);
		if ((((int32_t)L_25) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_26)->max_length)))))))
		{
			goto IL_0040;
		}
	}
	{
		ArrayList_t4252133567 * L_27 = V_0;
		NullCheck(L_27);
		int32_t L_28 = VirtFuncInvoker0< int32_t >::Invoke(23 /* System.Int32 System.Collections.ArrayList::get_Count() */, L_27);
		V_6 = ((FieldInfoU5BU5D_t125053523*)SZArrayNew(FieldInfoU5BU5D_t125053523_il2cpp_TypeInfo_var, (uint32_t)L_28));
		ArrayList_t4252133567 * L_29 = V_0;
		FieldInfoU5BU5D_t125053523* L_30 = V_6;
		NullCheck(L_29);
		VirtActionInvoker1< Il2CppArray * >::Invoke(40 /* System.Void System.Collections.ArrayList::CopyTo(System.Array) */, L_29, (Il2CppArray *)(Il2CppArray *)L_30);
		FieldInfoU5BU5D_t125053523* L_31 = V_6;
		return L_31;
	}
}
// System.Type[] System.Reflection.Emit.TypeBuilder::GetInterfaces()
extern Il2CppClass* TypeU5BU5D_t1664964607_il2cpp_TypeInfo_var;
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern const uint32_t TypeBuilder_GetInterfaces_m1818658502_MetadataUsageId;
extern "C"  TypeU5BU5D_t1664964607* TypeBuilder_GetInterfaces_m1818658502 (TypeBuilder_t3308873219 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (TypeBuilder_GetInterfaces_m1818658502_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	TypeU5BU5D_t1664964607* V_0 = NULL;
	{
		bool L_0 = TypeBuilder_get_is_created_m736553860(__this, /*hidden argument*/NULL);
		if (!L_0)
		{
			goto IL_0017;
		}
	}
	{
		Type_t * L_1 = __this->get_created_20();
		NullCheck(L_1);
		TypeU5BU5D_t1664964607* L_2 = VirtFuncInvoker0< TypeU5BU5D_t1664964607* >::Invoke(39 /* System.Type[] System.Type::GetInterfaces() */, L_1);
		return L_2;
	}

IL_0017:
	{
		TypeU5BU5D_t1664964607* L_3 = __this->get_interfaces_12();
		if (!L_3)
		{
			goto IL_003f;
		}
	}
	{
		TypeU5BU5D_t1664964607* L_4 = __this->get_interfaces_12();
		NullCheck(L_4);
		V_0 = ((TypeU5BU5D_t1664964607*)SZArrayNew(TypeU5BU5D_t1664964607_il2cpp_TypeInfo_var, (uint32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_4)->max_length))))));
		TypeU5BU5D_t1664964607* L_5 = __this->get_interfaces_12();
		TypeU5BU5D_t1664964607* L_6 = V_0;
		NullCheck((Il2CppArray *)(Il2CppArray *)L_5);
		Array_CopyTo_m4061033315((Il2CppArray *)(Il2CppArray *)L_5, (Il2CppArray *)(Il2CppArray *)L_6, 0, /*hidden argument*/NULL);
		TypeU5BU5D_t1664964607* L_7 = V_0;
		return L_7;
	}

IL_003f:
	{
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		TypeU5BU5D_t1664964607* L_8 = ((Type_t_StaticFields*)Type_t_il2cpp_TypeInfo_var->static_fields)->get_EmptyTypes_3();
		return L_8;
	}
}
// System.Reflection.MethodInfo[] System.Reflection.Emit.TypeBuilder::GetMethodsByName(System.String,System.Reflection.BindingFlags,System.Boolean,System.Type)
extern Il2CppClass* ArrayList_t4252133567_il2cpp_TypeInfo_var;
extern Il2CppClass* MethodInfoU5BU5D_t152480188_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern const uint32_t TypeBuilder_GetMethodsByName_m229541072_MetadataUsageId;
extern "C"  MethodInfoU5BU5D_t152480188* TypeBuilder_GetMethodsByName_m229541072 (TypeBuilder_t3308873219 * __this, String_t* ___name0, int32_t ___bindingAttr1, bool ___ignoreCase2, Type_t * ___reflected_type3, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (TypeBuilder_GetMethodsByName_m229541072_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	MethodInfoU5BU5D_t152480188* V_0 = NULL;
	bool V_1 = false;
	int32_t V_2 = 0;
	MethodInfoU5BU5D_t152480188* V_3 = NULL;
	ArrayList_t4252133567 * V_4 = NULL;
	bool V_5 = false;
	int32_t V_6 = 0;
	MethodInfo_t * V_7 = NULL;
	ArrayList_t4252133567 * V_8 = NULL;
	MethodInfo_t * V_9 = NULL;
	MethodInfoU5BU5D_t152480188* V_10 = NULL;
	int32_t V_11 = 0;
	MethodInfoU5BU5D_t152480188* V_12 = NULL;
	int32_t V_13 = 0;
	{
		int32_t L_0 = ___bindingAttr1;
		if (((int32_t)((int32_t)L_0&(int32_t)2)))
		{
			goto IL_0142;
		}
	}
	{
		Type_t * L_1 = __this->get_parent_10();
		if (!L_1)
		{
			goto IL_0142;
		}
	}
	{
		Type_t * L_2 = __this->get_parent_10();
		int32_t L_3 = ___bindingAttr1;
		NullCheck(L_2);
		MethodInfoU5BU5D_t152480188* L_4 = VirtFuncInvoker1< MethodInfoU5BU5D_t152480188*, int32_t >::Invoke(53 /* System.Reflection.MethodInfo[] System.Type::GetMethods(System.Reflection.BindingFlags) */, L_2, L_3);
		V_3 = L_4;
		MethodInfoU5BU5D_t152480188* L_5 = V_3;
		NullCheck(L_5);
		ArrayList_t4252133567 * L_6 = (ArrayList_t4252133567 *)il2cpp_codegen_object_new(ArrayList_t4252133567_il2cpp_TypeInfo_var);
		ArrayList__ctor_m1467563650(L_6, (((int32_t)((int32_t)(((Il2CppArray *)L_5)->max_length)))), /*hidden argument*/NULL);
		V_4 = L_6;
		int32_t L_7 = ___bindingAttr1;
		V_5 = (bool)((((int32_t)((((int32_t)((int32_t)((int32_t)L_7&(int32_t)((int32_t)64)))) == ((int32_t)0))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		V_6 = 0;
		goto IL_00dc;
	}

IL_003e:
	{
		MethodInfoU5BU5D_t152480188* L_8 = V_3;
		int32_t L_9 = V_6;
		NullCheck(L_8);
		int32_t L_10 = L_9;
		MethodInfo_t * L_11 = (L_8)->GetAt(static_cast<il2cpp_array_size_t>(L_10));
		V_7 = L_11;
		MethodInfo_t * L_12 = V_7;
		NullCheck(L_12);
		int32_t L_13 = VirtFuncInvoker0< int32_t >::Invoke(19 /* System.Reflection.MethodAttributes System.Reflection.MethodBase::get_Attributes() */, L_12);
		V_2 = L_13;
		MethodInfo_t * L_14 = V_7;
		NullCheck(L_14);
		bool L_15 = MethodBase_get_IsStatic_m1015686807(L_14, /*hidden argument*/NULL);
		if (!L_15)
		{
			goto IL_0064;
		}
	}
	{
		bool L_16 = V_5;
		if (L_16)
		{
			goto IL_0064;
		}
	}
	{
		goto IL_00d6;
	}

IL_0064:
	{
		int32_t L_17 = V_2;
		V_13 = ((int32_t)((int32_t)L_17&(int32_t)7));
		int32_t L_18 = V_13;
		if (((int32_t)((int32_t)L_18-(int32_t)1)) == 0)
		{
			goto IL_00af;
		}
		if (((int32_t)((int32_t)L_18-(int32_t)1)) == 1)
		{
			goto IL_00b6;
		}
		if (((int32_t)((int32_t)L_18-(int32_t)1)) == 2)
		{
			goto IL_009f;
		}
		if (((int32_t)((int32_t)L_18-(int32_t)1)) == 3)
		{
			goto IL_00b6;
		}
		if (((int32_t)((int32_t)L_18-(int32_t)1)) == 4)
		{
			goto IL_00b6;
		}
		if (((int32_t)((int32_t)L_18-(int32_t)1)) == 5)
		{
			goto IL_008f;
		}
	}
	{
		goto IL_00b6;
	}

IL_008f:
	{
		int32_t L_19 = ___bindingAttr1;
		V_1 = (bool)((((int32_t)((((int32_t)((int32_t)((int32_t)L_19&(int32_t)((int32_t)16)))) == ((int32_t)0))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_00c6;
	}

IL_009f:
	{
		int32_t L_20 = ___bindingAttr1;
		V_1 = (bool)((((int32_t)((((int32_t)((int32_t)((int32_t)L_20&(int32_t)((int32_t)32)))) == ((int32_t)0))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_00c6;
	}

IL_00af:
	{
		V_1 = (bool)0;
		goto IL_00c6;
	}

IL_00b6:
	{
		int32_t L_21 = ___bindingAttr1;
		V_1 = (bool)((((int32_t)((((int32_t)((int32_t)((int32_t)L_21&(int32_t)((int32_t)32)))) == ((int32_t)0))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_00c6;
	}

IL_00c6:
	{
		bool L_22 = V_1;
		if (!L_22)
		{
			goto IL_00d6;
		}
	}
	{
		ArrayList_t4252133567 * L_23 = V_4;
		MethodInfo_t * L_24 = V_7;
		NullCheck(L_23);
		VirtFuncInvoker1< int32_t, Il2CppObject * >::Invoke(30 /* System.Int32 System.Collections.ArrayList::Add(System.Object) */, L_23, L_24);
	}

IL_00d6:
	{
		int32_t L_25 = V_6;
		V_6 = ((int32_t)((int32_t)L_25+(int32_t)1));
	}

IL_00dc:
	{
		int32_t L_26 = V_6;
		MethodInfoU5BU5D_t152480188* L_27 = V_3;
		NullCheck(L_27);
		if ((((int32_t)L_26) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_27)->max_length)))))))
		{
			goto IL_003e;
		}
	}
	{
		MethodBuilderU5BU5D_t4238041457* L_28 = __this->get_methods_14();
		if (L_28)
		{
			goto IL_010b;
		}
	}
	{
		ArrayList_t4252133567 * L_29 = V_4;
		NullCheck(L_29);
		int32_t L_30 = VirtFuncInvoker0< int32_t >::Invoke(23 /* System.Int32 System.Collections.ArrayList::get_Count() */, L_29);
		V_0 = ((MethodInfoU5BU5D_t152480188*)SZArrayNew(MethodInfoU5BU5D_t152480188_il2cpp_TypeInfo_var, (uint32_t)L_30));
		ArrayList_t4252133567 * L_31 = V_4;
		MethodInfoU5BU5D_t152480188* L_32 = V_0;
		NullCheck(L_31);
		VirtActionInvoker1< Il2CppArray * >::Invoke(40 /* System.Void System.Collections.ArrayList::CopyTo(System.Array) */, L_31, (Il2CppArray *)(Il2CppArray *)L_32);
		goto IL_013d;
	}

IL_010b:
	{
		MethodBuilderU5BU5D_t4238041457* L_33 = __this->get_methods_14();
		NullCheck(L_33);
		ArrayList_t4252133567 * L_34 = V_4;
		NullCheck(L_34);
		int32_t L_35 = VirtFuncInvoker0< int32_t >::Invoke(23 /* System.Int32 System.Collections.ArrayList::get_Count() */, L_34);
		V_0 = ((MethodInfoU5BU5D_t152480188*)SZArrayNew(MethodInfoU5BU5D_t152480188_il2cpp_TypeInfo_var, (uint32_t)((int32_t)((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_33)->max_length))))+(int32_t)L_35))));
		ArrayList_t4252133567 * L_36 = V_4;
		MethodInfoU5BU5D_t152480188* L_37 = V_0;
		NullCheck(L_36);
		VirtActionInvoker2< Il2CppArray *, int32_t >::Invoke(41 /* System.Void System.Collections.ArrayList::CopyTo(System.Array,System.Int32) */, L_36, (Il2CppArray *)(Il2CppArray *)L_37, 0);
		MethodBuilderU5BU5D_t4238041457* L_38 = __this->get_methods_14();
		MethodInfoU5BU5D_t152480188* L_39 = V_0;
		ArrayList_t4252133567 * L_40 = V_4;
		NullCheck(L_40);
		int32_t L_41 = VirtFuncInvoker0< int32_t >::Invoke(23 /* System.Int32 System.Collections.ArrayList::get_Count() */, L_40);
		NullCheck((Il2CppArray *)(Il2CppArray *)L_38);
		Array_CopyTo_m4061033315((Il2CppArray *)(Il2CppArray *)L_38, (Il2CppArray *)(Il2CppArray *)L_39, L_41, /*hidden argument*/NULL);
	}

IL_013d:
	{
		goto IL_0149;
	}

IL_0142:
	{
		MethodBuilderU5BU5D_t4238041457* L_42 = __this->get_methods_14();
		V_0 = (MethodInfoU5BU5D_t152480188*)L_42;
	}

IL_0149:
	{
		MethodInfoU5BU5D_t152480188* L_43 = V_0;
		if (L_43)
		{
			goto IL_0156;
		}
	}
	{
		return ((MethodInfoU5BU5D_t152480188*)SZArrayNew(MethodInfoU5BU5D_t152480188_il2cpp_TypeInfo_var, (uint32_t)0));
	}

IL_0156:
	{
		ArrayList_t4252133567 * L_44 = (ArrayList_t4252133567 *)il2cpp_codegen_object_new(ArrayList_t4252133567_il2cpp_TypeInfo_var);
		ArrayList__ctor_m4012174379(L_44, /*hidden argument*/NULL);
		V_8 = L_44;
		MethodInfoU5BU5D_t152480188* L_45 = V_0;
		V_10 = L_45;
		V_11 = 0;
		goto IL_0211;
	}

IL_0168:
	{
		MethodInfoU5BU5D_t152480188* L_46 = V_10;
		int32_t L_47 = V_11;
		NullCheck(L_46);
		int32_t L_48 = L_47;
		MethodInfo_t * L_49 = (L_46)->GetAt(static_cast<il2cpp_array_size_t>(L_48));
		V_9 = L_49;
		MethodInfo_t * L_50 = V_9;
		if (L_50)
		{
			goto IL_017b;
		}
	}
	{
		goto IL_020b;
	}

IL_017b:
	{
		String_t* L_51 = ___name0;
		if (!L_51)
		{
			goto IL_0199;
		}
	}
	{
		MethodInfo_t * L_52 = V_9;
		NullCheck(L_52);
		String_t* L_53 = VirtFuncInvoker0< String_t* >::Invoke(8 /* System.String System.Reflection.MemberInfo::get_Name() */, L_52);
		String_t* L_54 = ___name0;
		bool L_55 = ___ignoreCase2;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		int32_t L_56 = String_Compare_m2851607672(NULL /*static, unused*/, L_53, L_54, L_55, /*hidden argument*/NULL);
		if (!L_56)
		{
			goto IL_0199;
		}
	}
	{
		goto IL_020b;
	}

IL_0199:
	{
		V_1 = (bool)0;
		MethodInfo_t * L_57 = V_9;
		NullCheck(L_57);
		int32_t L_58 = VirtFuncInvoker0< int32_t >::Invoke(19 /* System.Reflection.MethodAttributes System.Reflection.MethodBase::get_Attributes() */, L_57);
		V_2 = L_58;
		int32_t L_59 = V_2;
		if ((!(((uint32_t)((int32_t)((int32_t)L_59&(int32_t)7))) == ((uint32_t)6))))
		{
			goto IL_01bc;
		}
	}
	{
		int32_t L_60 = ___bindingAttr1;
		if (!((int32_t)((int32_t)L_60&(int32_t)((int32_t)16))))
		{
			goto IL_01b7;
		}
	}
	{
		V_1 = (bool)1;
	}

IL_01b7:
	{
		goto IL_01c7;
	}

IL_01bc:
	{
		int32_t L_61 = ___bindingAttr1;
		if (!((int32_t)((int32_t)L_61&(int32_t)((int32_t)32))))
		{
			goto IL_01c7;
		}
	}
	{
		V_1 = (bool)1;
	}

IL_01c7:
	{
		bool L_62 = V_1;
		if (L_62)
		{
			goto IL_01d2;
		}
	}
	{
		goto IL_020b;
	}

IL_01d2:
	{
		V_1 = (bool)0;
		int32_t L_63 = V_2;
		if (!((int32_t)((int32_t)L_63&(int32_t)((int32_t)16))))
		{
			goto IL_01ec;
		}
	}
	{
		int32_t L_64 = ___bindingAttr1;
		if (!((int32_t)((int32_t)L_64&(int32_t)8)))
		{
			goto IL_01e7;
		}
	}
	{
		V_1 = (bool)1;
	}

IL_01e7:
	{
		goto IL_01f6;
	}

IL_01ec:
	{
		int32_t L_65 = ___bindingAttr1;
		if (!((int32_t)((int32_t)L_65&(int32_t)4)))
		{
			goto IL_01f6;
		}
	}
	{
		V_1 = (bool)1;
	}

IL_01f6:
	{
		bool L_66 = V_1;
		if (L_66)
		{
			goto IL_0201;
		}
	}
	{
		goto IL_020b;
	}

IL_0201:
	{
		ArrayList_t4252133567 * L_67 = V_8;
		MethodInfo_t * L_68 = V_9;
		NullCheck(L_67);
		VirtFuncInvoker1< int32_t, Il2CppObject * >::Invoke(30 /* System.Int32 System.Collections.ArrayList::Add(System.Object) */, L_67, L_68);
	}

IL_020b:
	{
		int32_t L_69 = V_11;
		V_11 = ((int32_t)((int32_t)L_69+(int32_t)1));
	}

IL_0211:
	{
		int32_t L_70 = V_11;
		MethodInfoU5BU5D_t152480188* L_71 = V_10;
		NullCheck(L_71);
		if ((((int32_t)L_70) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_71)->max_length)))))))
		{
			goto IL_0168;
		}
	}
	{
		ArrayList_t4252133567 * L_72 = V_8;
		NullCheck(L_72);
		int32_t L_73 = VirtFuncInvoker0< int32_t >::Invoke(23 /* System.Int32 System.Collections.ArrayList::get_Count() */, L_72);
		V_12 = ((MethodInfoU5BU5D_t152480188*)SZArrayNew(MethodInfoU5BU5D_t152480188_il2cpp_TypeInfo_var, (uint32_t)L_73));
		ArrayList_t4252133567 * L_74 = V_8;
		MethodInfoU5BU5D_t152480188* L_75 = V_12;
		NullCheck(L_74);
		VirtActionInvoker1< Il2CppArray * >::Invoke(40 /* System.Void System.Collections.ArrayList::CopyTo(System.Array) */, L_74, (Il2CppArray *)(Il2CppArray *)L_75);
		MethodInfoU5BU5D_t152480188* L_76 = V_12;
		return L_76;
	}
}
// System.Reflection.MethodInfo[] System.Reflection.Emit.TypeBuilder::GetMethods(System.Reflection.BindingFlags)
extern "C"  MethodInfoU5BU5D_t152480188* TypeBuilder_GetMethods_m4196862738 (TypeBuilder_t3308873219 * __this, int32_t ___bindingAttr0, const MethodInfo* method)
{
	{
		int32_t L_0 = ___bindingAttr0;
		MethodInfoU5BU5D_t152480188* L_1 = TypeBuilder_GetMethodsByName_m229541072(__this, (String_t*)NULL, L_0, (bool)0, __this, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Reflection.MethodInfo System.Reflection.Emit.TypeBuilder::GetMethodImpl(System.String,System.Reflection.BindingFlags,System.Reflection.Binder,System.Reflection.CallingConventions,System.Type[],System.Reflection.ParameterModifier[])
extern Il2CppClass* MethodBaseU5BU5D_t2597254495_il2cpp_TypeInfo_var;
extern Il2CppClass* Binder_t3404612058_il2cpp_TypeInfo_var;
extern Il2CppClass* MethodInfo_t_il2cpp_TypeInfo_var;
extern const uint32_t TypeBuilder_GetMethodImpl_m1443640538_MetadataUsageId;
extern "C"  MethodInfo_t * TypeBuilder_GetMethodImpl_m1443640538 (TypeBuilder_t3308873219 * __this, String_t* ___name0, int32_t ___bindingAttr1, Binder_t3404612058 * ___binder2, int32_t ___callConvention3, TypeU5BU5D_t1664964607* ___types4, ParameterModifierU5BU5D_t963192633* ___modifiers5, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (TypeBuilder_GetMethodImpl_m1443640538_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	bool V_0 = false;
	MethodInfoU5BU5D_t152480188* V_1 = NULL;
	MethodInfo_t * V_2 = NULL;
	MethodBaseU5BU5D_t2597254495* V_3 = NULL;
	int32_t V_4 = 0;
	int32_t V_5 = 0;
	MethodInfo_t * V_6 = NULL;
	MethodInfoU5BU5D_t152480188* V_7 = NULL;
	int32_t V_8 = 0;
	MethodInfo_t * V_9 = NULL;
	MethodInfoU5BU5D_t152480188* V_10 = NULL;
	int32_t V_11 = 0;
	int32_t G_B3_0 = 0;
	{
		TypeBuilder_check_created_m2929267877(__this, /*hidden argument*/NULL);
		int32_t L_0 = ___bindingAttr1;
		V_0 = (bool)((((int32_t)((((int32_t)((int32_t)((int32_t)L_0&(int32_t)1))) == ((int32_t)0))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		String_t* L_1 = ___name0;
		int32_t L_2 = ___bindingAttr1;
		bool L_3 = V_0;
		MethodInfoU5BU5D_t152480188* L_4 = TypeBuilder_GetMethodsByName_m229541072(__this, L_1, L_2, L_3, __this, /*hidden argument*/NULL);
		V_1 = L_4;
		V_2 = (MethodInfo_t *)NULL;
		TypeU5BU5D_t1664964607* L_5 = ___types4;
		if (!L_5)
		{
			goto IL_002d;
		}
	}
	{
		TypeU5BU5D_t1664964607* L_6 = ___types4;
		NullCheck(L_6);
		G_B3_0 = (((int32_t)((int32_t)(((Il2CppArray *)L_6)->max_length))));
		goto IL_002e;
	}

IL_002d:
	{
		G_B3_0 = 0;
	}

IL_002e:
	{
		V_4 = G_B3_0;
		V_5 = 0;
		MethodInfoU5BU5D_t152480188* L_7 = V_1;
		V_7 = L_7;
		V_8 = 0;
		goto IL_0072;
	}

IL_003e:
	{
		MethodInfoU5BU5D_t152480188* L_8 = V_7;
		int32_t L_9 = V_8;
		NullCheck(L_8);
		int32_t L_10 = L_9;
		MethodInfo_t * L_11 = (L_8)->GetAt(static_cast<il2cpp_array_size_t>(L_10));
		V_6 = L_11;
		int32_t L_12 = ___callConvention3;
		if ((((int32_t)L_12) == ((int32_t)3)))
		{
			goto IL_0063;
		}
	}
	{
		MethodInfo_t * L_13 = V_6;
		NullCheck(L_13);
		int32_t L_14 = VirtFuncInvoker0< int32_t >::Invoke(20 /* System.Reflection.CallingConventions System.Reflection.MethodBase::get_CallingConvention() */, L_13);
		int32_t L_15 = ___callConvention3;
		int32_t L_16 = ___callConvention3;
		if ((((int32_t)((int32_t)((int32_t)L_14&(int32_t)L_15))) == ((int32_t)L_16)))
		{
			goto IL_0063;
		}
	}
	{
		goto IL_006c;
	}

IL_0063:
	{
		MethodInfo_t * L_17 = V_6;
		V_2 = L_17;
		int32_t L_18 = V_5;
		V_5 = ((int32_t)((int32_t)L_18+(int32_t)1));
	}

IL_006c:
	{
		int32_t L_19 = V_8;
		V_8 = ((int32_t)((int32_t)L_19+(int32_t)1));
	}

IL_0072:
	{
		int32_t L_20 = V_8;
		MethodInfoU5BU5D_t152480188* L_21 = V_7;
		NullCheck(L_21);
		if ((((int32_t)L_20) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_21)->max_length)))))))
		{
			goto IL_003e;
		}
	}
	{
		int32_t L_22 = V_5;
		if (L_22)
		{
			goto IL_0086;
		}
	}
	{
		return (MethodInfo_t *)NULL;
	}

IL_0086:
	{
		int32_t L_23 = V_5;
		if ((!(((uint32_t)L_23) == ((uint32_t)1))))
		{
			goto IL_0097;
		}
	}
	{
		int32_t L_24 = V_4;
		if (L_24)
		{
			goto IL_0097;
		}
	}
	{
		MethodInfo_t * L_25 = V_2;
		return L_25;
	}

IL_0097:
	{
		int32_t L_26 = V_5;
		V_3 = ((MethodBaseU5BU5D_t2597254495*)SZArrayNew(MethodBaseU5BU5D_t2597254495_il2cpp_TypeInfo_var, (uint32_t)L_26));
		int32_t L_27 = V_5;
		if ((!(((uint32_t)L_27) == ((uint32_t)1))))
		{
			goto IL_00b0;
		}
	}
	{
		MethodBaseU5BU5D_t2597254495* L_28 = V_3;
		MethodInfo_t * L_29 = V_2;
		NullCheck(L_28);
		ArrayElementTypeCheck (L_28, L_29);
		(L_28)->SetAt(static_cast<il2cpp_array_size_t>(0), (MethodBase_t904190842 *)L_29);
		goto IL_00ff;
	}

IL_00b0:
	{
		V_5 = 0;
		MethodInfoU5BU5D_t152480188* L_30 = V_1;
		V_10 = L_30;
		V_11 = 0;
		goto IL_00f4;
	}

IL_00be:
	{
		MethodInfoU5BU5D_t152480188* L_31 = V_10;
		int32_t L_32 = V_11;
		NullCheck(L_31);
		int32_t L_33 = L_32;
		MethodInfo_t * L_34 = (L_31)->GetAt(static_cast<il2cpp_array_size_t>(L_33));
		V_9 = L_34;
		int32_t L_35 = ___callConvention3;
		if ((((int32_t)L_35) == ((int32_t)3)))
		{
			goto IL_00e3;
		}
	}
	{
		MethodInfo_t * L_36 = V_9;
		NullCheck(L_36);
		int32_t L_37 = VirtFuncInvoker0< int32_t >::Invoke(20 /* System.Reflection.CallingConventions System.Reflection.MethodBase::get_CallingConvention() */, L_36);
		int32_t L_38 = ___callConvention3;
		int32_t L_39 = ___callConvention3;
		if ((((int32_t)((int32_t)((int32_t)L_37&(int32_t)L_38))) == ((int32_t)L_39)))
		{
			goto IL_00e3;
		}
	}
	{
		goto IL_00ee;
	}

IL_00e3:
	{
		MethodBaseU5BU5D_t2597254495* L_40 = V_3;
		int32_t L_41 = V_5;
		int32_t L_42 = L_41;
		V_5 = ((int32_t)((int32_t)L_42+(int32_t)1));
		MethodInfo_t * L_43 = V_9;
		NullCheck(L_40);
		ArrayElementTypeCheck (L_40, L_43);
		(L_40)->SetAt(static_cast<il2cpp_array_size_t>(L_42), (MethodBase_t904190842 *)L_43);
	}

IL_00ee:
	{
		int32_t L_44 = V_11;
		V_11 = ((int32_t)((int32_t)L_44+(int32_t)1));
	}

IL_00f4:
	{
		int32_t L_45 = V_11;
		MethodInfoU5BU5D_t152480188* L_46 = V_10;
		NullCheck(L_46);
		if ((((int32_t)L_45) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_46)->max_length)))))))
		{
			goto IL_00be;
		}
	}

IL_00ff:
	{
		TypeU5BU5D_t1664964607* L_47 = ___types4;
		if (L_47)
		{
			goto IL_0112;
		}
	}
	{
		MethodBaseU5BU5D_t2597254495* L_48 = V_3;
		IL2CPP_RUNTIME_CLASS_INIT(Binder_t3404612058_il2cpp_TypeInfo_var);
		MethodBase_t904190842 * L_49 = Binder_FindMostDerivedMatch_m2621831847(NULL /*static, unused*/, L_48, /*hidden argument*/NULL);
		return ((MethodInfo_t *)CastclassClass(L_49, MethodInfo_t_il2cpp_TypeInfo_var));
	}

IL_0112:
	{
		Binder_t3404612058 * L_50 = ___binder2;
		if (L_50)
		{
			goto IL_011f;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(Binder_t3404612058_il2cpp_TypeInfo_var);
		Binder_t3404612058 * L_51 = Binder_get_DefaultBinder_m965620943(NULL /*static, unused*/, /*hidden argument*/NULL);
		___binder2 = L_51;
	}

IL_011f:
	{
		Binder_t3404612058 * L_52 = ___binder2;
		int32_t L_53 = ___bindingAttr1;
		MethodBaseU5BU5D_t2597254495* L_54 = V_3;
		TypeU5BU5D_t1664964607* L_55 = ___types4;
		ParameterModifierU5BU5D_t963192633* L_56 = ___modifiers5;
		NullCheck(L_52);
		MethodBase_t904190842 * L_57 = VirtFuncInvoker4< MethodBase_t904190842 *, int32_t, MethodBaseU5BU5D_t2597254495*, TypeU5BU5D_t1664964607*, ParameterModifierU5BU5D_t963192633* >::Invoke(7 /* System.Reflection.MethodBase System.Reflection.Binder::SelectMethod(System.Reflection.BindingFlags,System.Reflection.MethodBase[],System.Type[],System.Reflection.ParameterModifier[]) */, L_52, L_53, L_54, L_55, L_56);
		return ((MethodInfo_t *)CastclassClass(L_57, MethodInfo_t_il2cpp_TypeInfo_var));
	}
}
// System.Reflection.PropertyInfo System.Reflection.Emit.TypeBuilder::GetPropertyImpl(System.String,System.Reflection.BindingFlags,System.Reflection.Binder,System.Type,System.Type[],System.Reflection.ParameterModifier[])
extern "C"  PropertyInfo_t * TypeBuilder_GetPropertyImpl_m1854119335 (TypeBuilder_t3308873219 * __this, String_t* ___name0, int32_t ___bindingAttr1, Binder_t3404612058 * ___binder2, Type_t * ___returnType3, TypeU5BU5D_t1664964607* ___types4, ParameterModifierU5BU5D_t963192633* ___modifiers5, const MethodInfo* method)
{
	{
		Exception_t1927440687 * L_0 = TypeBuilder_not_supported_m3178173643(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Boolean System.Reflection.Emit.TypeBuilder::HasElementTypeImpl()
extern "C"  bool TypeBuilder_HasElementTypeImpl_m3160520656 (TypeBuilder_t3308873219 * __this, const MethodInfo* method)
{
	{
		bool L_0 = TypeBuilder_get_is_created_m736553860(__this, /*hidden argument*/NULL);
		if (L_0)
		{
			goto IL_000d;
		}
	}
	{
		return (bool)0;
	}

IL_000d:
	{
		Type_t * L_1 = __this->get_created_20();
		NullCheck(L_1);
		bool L_2 = Type_get_HasElementType_m3319917896(L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.Object System.Reflection.Emit.TypeBuilder::InvokeMember(System.String,System.Reflection.BindingFlags,System.Reflection.Binder,System.Object,System.Object[],System.Reflection.ParameterModifier[],System.Globalization.CultureInfo,System.String[])
extern "C"  Il2CppObject * TypeBuilder_InvokeMember_m1992906893 (TypeBuilder_t3308873219 * __this, String_t* ___name0, int32_t ___invokeAttr1, Binder_t3404612058 * ___binder2, Il2CppObject * ___target3, ObjectU5BU5D_t3614634134* ___args4, ParameterModifierU5BU5D_t963192633* ___modifiers5, CultureInfo_t3500843524 * ___culture6, StringU5BU5D_t1642385972* ___namedParameters7, const MethodInfo* method)
{
	{
		TypeBuilder_check_created_m2929267877(__this, /*hidden argument*/NULL);
		Type_t * L_0 = __this->get_created_20();
		String_t* L_1 = ___name0;
		int32_t L_2 = ___invokeAttr1;
		Binder_t3404612058 * L_3 = ___binder2;
		Il2CppObject * L_4 = ___target3;
		ObjectU5BU5D_t3614634134* L_5 = ___args4;
		ParameterModifierU5BU5D_t963192633* L_6 = ___modifiers5;
		CultureInfo_t3500843524 * L_7 = ___culture6;
		StringU5BU5D_t1642385972* L_8 = ___namedParameters7;
		NullCheck(L_0);
		Il2CppObject * L_9 = VirtFuncInvoker8< Il2CppObject *, String_t*, int32_t, Binder_t3404612058 *, Il2CppObject *, ObjectU5BU5D_t3614634134*, ParameterModifierU5BU5D_t963192633*, CultureInfo_t3500843524 *, StringU5BU5D_t1642385972* >::Invoke(74 /* System.Object System.Type::InvokeMember(System.String,System.Reflection.BindingFlags,System.Reflection.Binder,System.Object,System.Object[],System.Reflection.ParameterModifier[],System.Globalization.CultureInfo,System.String[]) */, L_0, L_1, L_2, L_3, L_4, L_5, L_6, L_7, L_8);
		return L_9;
	}
}
// System.Boolean System.Reflection.Emit.TypeBuilder::IsArrayImpl()
extern "C"  bool TypeBuilder_IsArrayImpl_m1932432187 (TypeBuilder_t3308873219 * __this, const MethodInfo* method)
{
	{
		return (bool)0;
	}
}
// System.Boolean System.Reflection.Emit.TypeBuilder::IsByRefImpl()
extern "C"  bool TypeBuilder_IsByRefImpl_m3716138128 (TypeBuilder_t3308873219 * __this, const MethodInfo* method)
{
	{
		return (bool)0;
	}
}
// System.Boolean System.Reflection.Emit.TypeBuilder::IsPointerImpl()
extern "C"  bool TypeBuilder_IsPointerImpl_m3046705585 (TypeBuilder_t3308873219 * __this, const MethodInfo* method)
{
	{
		return (bool)0;
	}
}
// System.Boolean System.Reflection.Emit.TypeBuilder::IsPrimitiveImpl()
extern "C"  bool TypeBuilder_IsPrimitiveImpl_m3315689435 (TypeBuilder_t3308873219 * __this, const MethodInfo* method)
{
	{
		return (bool)0;
	}
}
// System.Boolean System.Reflection.Emit.TypeBuilder::IsValueTypeImpl()
extern const Il2CppType* ValueType_t3507792607_0_0_0_var;
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern const uint32_t TypeBuilder_IsValueTypeImpl_m1499671481_MetadataUsageId;
extern "C"  bool TypeBuilder_IsValueTypeImpl_m1499671481 (TypeBuilder_t3308873219 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (TypeBuilder_IsValueTypeImpl_m1499671481_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t G_B5_0 = 0;
	{
		ModuleBuilder_t4156028127 * L_0 = __this->get_pmodule_18();
		NullCheck(L_0);
		AssemblyBuilder_t1646117627 * L_1 = L_0->get_assemblyb_12();
		NullCheck(L_1);
		Type_t * L_2 = L_1->get_corlib_value_type_13();
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		bool L_3 = Type_type_is_subtype_of_m312896768(NULL /*static, unused*/, __this, L_2, (bool)0, /*hidden argument*/NULL);
		if (L_3)
		{
			goto IL_0032;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_4 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(ValueType_t3507792607_0_0_0_var), /*hidden argument*/NULL);
		bool L_5 = Type_type_is_subtype_of_m312896768(NULL /*static, unused*/, __this, L_4, (bool)0, /*hidden argument*/NULL);
		if (!L_5)
		{
			goto IL_0060;
		}
	}

IL_0032:
	{
		ModuleBuilder_t4156028127 * L_6 = __this->get_pmodule_18();
		NullCheck(L_6);
		AssemblyBuilder_t1646117627 * L_7 = L_6->get_assemblyb_12();
		NullCheck(L_7);
		Type_t * L_8 = L_7->get_corlib_value_type_13();
		if ((((Il2CppObject*)(TypeBuilder_t3308873219 *)__this) == ((Il2CppObject*)(Type_t *)L_8)))
		{
			goto IL_0060;
		}
	}
	{
		ModuleBuilder_t4156028127 * L_9 = __this->get_pmodule_18();
		NullCheck(L_9);
		AssemblyBuilder_t1646117627 * L_10 = L_9->get_assemblyb_12();
		NullCheck(L_10);
		Type_t * L_11 = L_10->get_corlib_enum_type_14();
		G_B5_0 = ((((int32_t)((((Il2CppObject*)(TypeBuilder_t3308873219 *)__this) == ((Il2CppObject*)(Type_t *)L_11))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_0061;
	}

IL_0060:
	{
		G_B5_0 = 0;
	}

IL_0061:
	{
		return (bool)G_B5_0;
	}
}
// System.Type System.Reflection.Emit.TypeBuilder::MakeByRefType()
extern Il2CppClass* ByRefType_t1587086384_il2cpp_TypeInfo_var;
extern const uint32_t TypeBuilder_MakeByRefType_m2042877922_MetadataUsageId;
extern "C"  Type_t * TypeBuilder_MakeByRefType_m2042877922 (TypeBuilder_t3308873219 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (TypeBuilder_MakeByRefType_m2042877922_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ByRefType_t1587086384 * L_0 = (ByRefType_t1587086384 *)il2cpp_codegen_object_new(ByRefType_t1587086384_il2cpp_TypeInfo_var);
		ByRefType__ctor_m2068210324(L_0, __this, /*hidden argument*/NULL);
		return L_0;
	}
}
// System.Type System.Reflection.Emit.TypeBuilder::MakeGenericType(System.Type[])
extern "C"  Type_t * TypeBuilder_MakeGenericType_m4282022646 (TypeBuilder_t3308873219 * __this, TypeU5BU5D_t1664964607* ___typeArguments0, const MethodInfo* method)
{
	{
		TypeU5BU5D_t1664964607* L_0 = ___typeArguments0;
		Type_t * L_1 = Type_MakeGenericType_m2765875033(__this, L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.RuntimeTypeHandle System.Reflection.Emit.TypeBuilder::get_TypeHandle()
extern "C"  RuntimeTypeHandle_t2330101084  TypeBuilder_get_TypeHandle_m922348781 (TypeBuilder_t3308873219 * __this, const MethodInfo* method)
{
	{
		TypeBuilder_check_created_m2929267877(__this, /*hidden argument*/NULL);
		Type_t * L_0 = __this->get_created_20();
		NullCheck(L_0);
		RuntimeTypeHandle_t2330101084  L_1 = VirtFuncInvoker0< RuntimeTypeHandle_t2330101084  >::Invoke(35 /* System.RuntimeTypeHandle System.Type::get_TypeHandle() */, L_0);
		return L_1;
	}
}
// System.Void System.Reflection.Emit.TypeBuilder::SetParent(System.Type)
extern const Il2CppType* Il2CppObject_0_0_0_var;
extern Il2CppClass* InvalidOperationException_t721527559_il2cpp_TypeInfo_var;
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral3528128599;
extern const uint32_t TypeBuilder_SetParent_m387557893_MetadataUsageId;
extern "C"  void TypeBuilder_SetParent_m387557893 (TypeBuilder_t3308873219 * __this, Type_t * ___parent0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (TypeBuilder_SetParent_m387557893_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		TypeBuilder_check_not_created_m2785532739(__this, /*hidden argument*/NULL);
		Type_t * L_0 = ___parent0;
		if (L_0)
		{
			goto IL_0057;
		}
	}
	{
		int32_t L_1 = __this->get_attrs_17();
		if (!((int32_t)((int32_t)L_1&(int32_t)((int32_t)32))))
		{
			goto IL_0042;
		}
	}
	{
		int32_t L_2 = __this->get_attrs_17();
		if (((int32_t)((int32_t)L_2&(int32_t)((int32_t)128))))
		{
			goto IL_0036;
		}
	}
	{
		InvalidOperationException_t721527559 * L_3 = (InvalidOperationException_t721527559 *)il2cpp_codegen_object_new(InvalidOperationException_t721527559_il2cpp_TypeInfo_var);
		InvalidOperationException__ctor_m2801133788(L_3, _stringLiteral3528128599, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_3);
	}

IL_0036:
	{
		__this->set_parent_10((Type_t *)NULL);
		goto IL_0052;
	}

IL_0042:
	{
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_4 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Il2CppObject_0_0_0_var), /*hidden argument*/NULL);
		__this->set_parent_10(L_4);
	}

IL_0052:
	{
		goto IL_005e;
	}

IL_0057:
	{
		Type_t * L_5 = ___parent0;
		__this->set_parent_10(L_5);
	}

IL_005e:
	{
		TypeBuilder_setup_internal_class_m235812026(__this, __this, /*hidden argument*/NULL);
		return;
	}
}
// System.Int32 System.Reflection.Emit.TypeBuilder::get_next_table_index(System.Object,System.Int32,System.Boolean)
extern "C"  int32_t TypeBuilder_get_next_table_index_m1415870184 (TypeBuilder_t3308873219 * __this, Il2CppObject * ___obj0, int32_t ___table1, bool ___inc2, const MethodInfo* method)
{
	{
		ModuleBuilder_t4156028127 * L_0 = __this->get_pmodule_18();
		Il2CppObject * L_1 = ___obj0;
		int32_t L_2 = ___table1;
		bool L_3 = ___inc2;
		NullCheck(L_0);
		int32_t L_4 = ModuleBuilder_get_next_table_index_m1552645388(L_0, L_1, L_2, L_3, /*hidden argument*/NULL);
		return L_4;
	}
}
// System.Boolean System.Reflection.Emit.TypeBuilder::get_IsCompilerContext()
extern "C"  bool TypeBuilder_get_IsCompilerContext_m3623403919 (TypeBuilder_t3308873219 * __this, const MethodInfo* method)
{
	{
		ModuleBuilder_t4156028127 * L_0 = __this->get_pmodule_18();
		NullCheck(L_0);
		AssemblyBuilder_t1646117627 * L_1 = L_0->get_assemblyb_12();
		NullCheck(L_1);
		bool L_2 = AssemblyBuilder_get_IsCompilerContext_m2864230005(L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.Boolean System.Reflection.Emit.TypeBuilder::get_is_created()
extern "C"  bool TypeBuilder_get_is_created_m736553860 (TypeBuilder_t3308873219 * __this, const MethodInfo* method)
{
	{
		Type_t * L_0 = __this->get_created_20();
		return (bool)((((int32_t)((((Il2CppObject*)(Type_t *)L_0) == ((Il2CppObject*)(Il2CppObject *)NULL))? 1 : 0)) == ((int32_t)0))? 1 : 0);
	}
}
// System.Exception System.Reflection.Emit.TypeBuilder::not_supported()
extern Il2CppClass* NotSupportedException_t1793819818_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral4087454587;
extern const uint32_t TypeBuilder_not_supported_m3178173643_MetadataUsageId;
extern "C"  Exception_t1927440687 * TypeBuilder_not_supported_m3178173643 (TypeBuilder_t3308873219 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (TypeBuilder_not_supported_m3178173643_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		NotSupportedException_t1793819818 * L_0 = (NotSupportedException_t1793819818 *)il2cpp_codegen_object_new(NotSupportedException_t1793819818_il2cpp_TypeInfo_var);
		NotSupportedException__ctor_m836173213(L_0, _stringLiteral4087454587, /*hidden argument*/NULL);
		return L_0;
	}
}
// System.Void System.Reflection.Emit.TypeBuilder::check_not_created()
extern Il2CppClass* InvalidOperationException_t721527559_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral2822774848;
extern const uint32_t TypeBuilder_check_not_created_m2785532739_MetadataUsageId;
extern "C"  void TypeBuilder_check_not_created_m2785532739 (TypeBuilder_t3308873219 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (TypeBuilder_check_not_created_m2785532739_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		bool L_0 = TypeBuilder_get_is_created_m736553860(__this, /*hidden argument*/NULL);
		if (!L_0)
		{
			goto IL_0016;
		}
	}
	{
		InvalidOperationException_t721527559 * L_1 = (InvalidOperationException_t721527559 *)il2cpp_codegen_object_new(InvalidOperationException_t721527559_il2cpp_TypeInfo_var);
		InvalidOperationException__ctor_m2801133788(L_1, _stringLiteral2822774848, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_1);
	}

IL_0016:
	{
		return;
	}
}
// System.Void System.Reflection.Emit.TypeBuilder::check_created()
extern "C"  void TypeBuilder_check_created_m2929267877 (TypeBuilder_t3308873219 * __this, const MethodInfo* method)
{
	{
		bool L_0 = TypeBuilder_get_is_created_m736553860(__this, /*hidden argument*/NULL);
		if (L_0)
		{
			goto IL_0012;
		}
	}
	{
		Exception_t1927440687 * L_1 = TypeBuilder_not_supported_m3178173643(__this, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_1);
	}

IL_0012:
	{
		return;
	}
}
// System.String System.Reflection.Emit.TypeBuilder::ToString()
extern "C"  String_t* TypeBuilder_ToString_m1952363535 (TypeBuilder_t3308873219 * __this, const MethodInfo* method)
{
	{
		String_t* L_0 = TypeBuilder_get_FullName_m1626507516(__this, /*hidden argument*/NULL);
		return L_0;
	}
}
// System.Boolean System.Reflection.Emit.TypeBuilder::IsAssignableFrom(System.Type)
extern "C"  bool TypeBuilder_IsAssignableFrom_m212977480 (TypeBuilder_t3308873219 * __this, Type_t * ___c0, const MethodInfo* method)
{
	{
		Type_t * L_0 = ___c0;
		bool L_1 = Type_IsAssignableFrom_m907986231(__this, L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Boolean System.Reflection.Emit.TypeBuilder::IsSubclassOf(System.Type)
extern "C"  bool TypeBuilder_IsSubclassOf_m428846622 (TypeBuilder_t3308873219 * __this, Type_t * ___c0, const MethodInfo* method)
{
	{
		Type_t * L_0 = ___c0;
		bool L_1 = Type_IsSubclassOf_m2450899481(__this, L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Boolean System.Reflection.Emit.TypeBuilder::IsAssignableTo(System.Type)
extern const Il2CppType* Il2CppObject_0_0_0_var;
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern const uint32_t TypeBuilder_IsAssignableTo_m3210661829_MetadataUsageId;
extern "C"  bool TypeBuilder_IsAssignableTo_m3210661829 (TypeBuilder_t3308873219 * __this, Type_t * ___c0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (TypeBuilder_IsAssignableTo_m3210661829_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Type_t * V_0 = NULL;
	TypeU5BU5D_t1664964607* V_1 = NULL;
	int32_t V_2 = 0;
	{
		Type_t * L_0 = ___c0;
		if ((!(((Il2CppObject*)(Type_t *)L_0) == ((Il2CppObject*)(TypeBuilder_t3308873219 *)__this))))
		{
			goto IL_0009;
		}
	}
	{
		return (bool)1;
	}

IL_0009:
	{
		Type_t * L_1 = ___c0;
		NullCheck(L_1);
		bool L_2 = Type_get_IsInterface_m3583817465(L_1, /*hidden argument*/NULL);
		if (!L_2)
		{
			goto IL_0084;
		}
	}
	{
		Type_t * L_3 = __this->get_parent_10();
		if (!L_3)
		{
			goto IL_003d;
		}
	}
	{
		bool L_4 = TypeBuilder_get_is_created_m736553860(__this, /*hidden argument*/NULL);
		if (!L_4)
		{
			goto IL_003d;
		}
	}
	{
		Type_t * L_5 = ___c0;
		Type_t * L_6 = __this->get_parent_10();
		NullCheck(L_5);
		bool L_7 = VirtFuncInvoker1< bool, Type_t * >::Invoke(40 /* System.Boolean System.Type::IsAssignableFrom(System.Type) */, L_5, L_6);
		if (!L_7)
		{
			goto IL_003d;
		}
	}
	{
		return (bool)1;
	}

IL_003d:
	{
		TypeU5BU5D_t1664964607* L_8 = __this->get_interfaces_12();
		if (L_8)
		{
			goto IL_004a;
		}
	}
	{
		return (bool)0;
	}

IL_004a:
	{
		TypeU5BU5D_t1664964607* L_9 = __this->get_interfaces_12();
		V_1 = L_9;
		V_2 = 0;
		goto IL_006e;
	}

IL_0058:
	{
		TypeU5BU5D_t1664964607* L_10 = V_1;
		int32_t L_11 = V_2;
		NullCheck(L_10);
		int32_t L_12 = L_11;
		Type_t * L_13 = (L_10)->GetAt(static_cast<il2cpp_array_size_t>(L_12));
		V_0 = L_13;
		Type_t * L_14 = ___c0;
		Type_t * L_15 = V_0;
		NullCheck(L_14);
		bool L_16 = VirtFuncInvoker1< bool, Type_t * >::Invoke(40 /* System.Boolean System.Type::IsAssignableFrom(System.Type) */, L_14, L_15);
		if (!L_16)
		{
			goto IL_006a;
		}
	}
	{
		return (bool)1;
	}

IL_006a:
	{
		int32_t L_17 = V_2;
		V_2 = ((int32_t)((int32_t)L_17+(int32_t)1));
	}

IL_006e:
	{
		int32_t L_18 = V_2;
		TypeU5BU5D_t1664964607* L_19 = V_1;
		NullCheck(L_19);
		if ((((int32_t)L_18) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_19)->max_length)))))))
		{
			goto IL_0058;
		}
	}
	{
		bool L_20 = TypeBuilder_get_is_created_m736553860(__this, /*hidden argument*/NULL);
		if (L_20)
		{
			goto IL_0084;
		}
	}
	{
		return (bool)0;
	}

IL_0084:
	{
		Type_t * L_21 = __this->get_parent_10();
		if (L_21)
		{
			goto IL_009d;
		}
	}
	{
		Type_t * L_22 = ___c0;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_23 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Il2CppObject_0_0_0_var), /*hidden argument*/NULL);
		return (bool)((((Il2CppObject*)(Type_t *)L_22) == ((Il2CppObject*)(Type_t *)L_23))? 1 : 0);
	}

IL_009d:
	{
		Type_t * L_24 = ___c0;
		Type_t * L_25 = __this->get_parent_10();
		NullCheck(L_24);
		bool L_26 = VirtFuncInvoker1< bool, Type_t * >::Invoke(40 /* System.Boolean System.Type::IsAssignableFrom(System.Type) */, L_24, L_25);
		return L_26;
	}
}
// System.Type[] System.Reflection.Emit.TypeBuilder::GetGenericArguments()
extern Il2CppClass* TypeU5BU5D_t1664964607_il2cpp_TypeInfo_var;
extern const uint32_t TypeBuilder_GetGenericArguments_m3241780469_MetadataUsageId;
extern "C"  TypeU5BU5D_t1664964607* TypeBuilder_GetGenericArguments_m3241780469 (TypeBuilder_t3308873219 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (TypeBuilder_GetGenericArguments_m3241780469_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	TypeU5BU5D_t1664964607* V_0 = NULL;
	{
		GenericTypeParameterBuilderU5BU5D_t358971386* L_0 = __this->get_generic_params_19();
		if (L_0)
		{
			goto IL_000d;
		}
	}
	{
		return (TypeU5BU5D_t1664964607*)NULL;
	}

IL_000d:
	{
		GenericTypeParameterBuilderU5BU5D_t358971386* L_1 = __this->get_generic_params_19();
		NullCheck(L_1);
		V_0 = ((TypeU5BU5D_t1664964607*)SZArrayNew(TypeU5BU5D_t1664964607_il2cpp_TypeInfo_var, (uint32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_1)->max_length))))));
		GenericTypeParameterBuilderU5BU5D_t358971386* L_2 = __this->get_generic_params_19();
		TypeU5BU5D_t1664964607* L_3 = V_0;
		NullCheck((Il2CppArray *)(Il2CppArray *)L_2);
		Array_CopyTo_m4061033315((Il2CppArray *)(Il2CppArray *)L_2, (Il2CppArray *)(Il2CppArray *)L_3, 0, /*hidden argument*/NULL);
		TypeU5BU5D_t1664964607* L_4 = V_0;
		return L_4;
	}
}
// System.Type System.Reflection.Emit.TypeBuilder::GetGenericTypeDefinition()
extern Il2CppClass* InvalidOperationException_t721527559_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral2633815678;
extern const uint32_t TypeBuilder_GetGenericTypeDefinition_m3813000816_MetadataUsageId;
extern "C"  Type_t * TypeBuilder_GetGenericTypeDefinition_m3813000816 (TypeBuilder_t3308873219 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (TypeBuilder_GetGenericTypeDefinition_m3813000816_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		GenericTypeParameterBuilderU5BU5D_t358971386* L_0 = __this->get_generic_params_19();
		if (L_0)
		{
			goto IL_0016;
		}
	}
	{
		InvalidOperationException_t721527559 * L_1 = (InvalidOperationException_t721527559 *)il2cpp_codegen_object_new(InvalidOperationException_t721527559_il2cpp_TypeInfo_var);
		InvalidOperationException__ctor_m2801133788(L_1, _stringLiteral2633815678, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_1);
	}

IL_0016:
	{
		return __this;
	}
}
// System.Boolean System.Reflection.Emit.TypeBuilder::get_ContainsGenericParameters()
extern "C"  bool TypeBuilder_get_ContainsGenericParameters_m493137229 (TypeBuilder_t3308873219 * __this, const MethodInfo* method)
{
	{
		GenericTypeParameterBuilderU5BU5D_t358971386* L_0 = __this->get_generic_params_19();
		return (bool)((((int32_t)((((Il2CppObject*)(GenericTypeParameterBuilderU5BU5D_t358971386*)L_0) == ((Il2CppObject*)(Il2CppObject *)NULL))? 1 : 0)) == ((int32_t)0))? 1 : 0);
	}
}
// System.Boolean System.Reflection.Emit.TypeBuilder::get_IsGenericParameter()
extern "C"  bool TypeBuilder_get_IsGenericParameter_m2604628295 (TypeBuilder_t3308873219 * __this, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef bool (*TypeBuilder_get_IsGenericParameter_m2604628295_ftn) (TypeBuilder_t3308873219 *);
	return  ((TypeBuilder_get_IsGenericParameter_m2604628295_ftn)mscorlib::System::Reflection::Emit::TypeBuilder::get_IsGenericParameter) (__this);
}
// System.Boolean System.Reflection.Emit.TypeBuilder::get_IsGenericTypeDefinition()
extern "C"  bool TypeBuilder_get_IsGenericTypeDefinition_m1652226431 (TypeBuilder_t3308873219 * __this, const MethodInfo* method)
{
	{
		GenericTypeParameterBuilderU5BU5D_t358971386* L_0 = __this->get_generic_params_19();
		return (bool)((((int32_t)((((Il2CppObject*)(GenericTypeParameterBuilderU5BU5D_t358971386*)L_0) == ((Il2CppObject*)(Il2CppObject *)NULL))? 1 : 0)) == ((int32_t)0))? 1 : 0);
	}
}
// System.Boolean System.Reflection.Emit.TypeBuilder::get_IsGenericType()
extern "C"  bool TypeBuilder_get_IsGenericType_m1475565622 (TypeBuilder_t3308873219 * __this, const MethodInfo* method)
{
	{
		bool L_0 = TypeBuilder_get_IsGenericTypeDefinition_m1652226431(__this, /*hidden argument*/NULL);
		return L_0;
	}
}
// System.Runtime.InteropServices.MarshalAsAttribute System.Reflection.Emit.UnmanagedMarshal::ToMarshalAsAttribute()
extern Il2CppClass* MarshalAsAttribute_t2900773360_il2cpp_TypeInfo_var;
extern const uint32_t UnmanagedMarshal_ToMarshalAsAttribute_m3695569337_MetadataUsageId;
extern "C"  MarshalAsAttribute_t2900773360 * UnmanagedMarshal_ToMarshalAsAttribute_m3695569337 (UnmanagedMarshal_t4270021860 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (UnmanagedMarshal_ToMarshalAsAttribute_m3695569337_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	MarshalAsAttribute_t2900773360 * V_0 = NULL;
	{
		int32_t L_0 = __this->get_t_1();
		MarshalAsAttribute_t2900773360 * L_1 = (MarshalAsAttribute_t2900773360 *)il2cpp_codegen_object_new(MarshalAsAttribute_t2900773360_il2cpp_TypeInfo_var);
		MarshalAsAttribute__ctor_m1892084128(L_1, L_0, /*hidden argument*/NULL);
		V_0 = L_1;
		MarshalAsAttribute_t2900773360 * L_2 = V_0;
		int32_t L_3 = __this->get_tbase_2();
		NullCheck(L_2);
		L_2->set_ArraySubType_1(L_3);
		MarshalAsAttribute_t2900773360 * L_4 = V_0;
		String_t* L_5 = __this->get_mcookie_4();
		NullCheck(L_4);
		L_4->set_MarshalCookie_2(L_5);
		MarshalAsAttribute_t2900773360 * L_6 = V_0;
		String_t* L_7 = __this->get_marshaltype_5();
		NullCheck(L_6);
		L_6->set_MarshalType_3(L_7);
		MarshalAsAttribute_t2900773360 * L_8 = V_0;
		Type_t * L_9 = __this->get_marshaltyperef_6();
		NullCheck(L_8);
		L_8->set_MarshalTypeRef_4(L_9);
		int32_t L_10 = __this->get_count_0();
		if ((!(((uint32_t)L_10) == ((uint32_t)(-1)))))
		{
			goto IL_0054;
		}
	}
	{
		MarshalAsAttribute_t2900773360 * L_11 = V_0;
		NullCheck(L_11);
		L_11->set_SizeConst_5(0);
		goto IL_0060;
	}

IL_0054:
	{
		MarshalAsAttribute_t2900773360 * L_12 = V_0;
		int32_t L_13 = __this->get_count_0();
		NullCheck(L_12);
		L_12->set_SizeConst_5(L_13);
	}

IL_0060:
	{
		int32_t L_14 = __this->get_param_num_7();
		if ((!(((uint32_t)L_14) == ((uint32_t)(-1)))))
		{
			goto IL_0078;
		}
	}
	{
		MarshalAsAttribute_t2900773360 * L_15 = V_0;
		NullCheck(L_15);
		L_15->set_SizeParamIndex_6(0);
		goto IL_0085;
	}

IL_0078:
	{
		MarshalAsAttribute_t2900773360 * L_16 = V_0;
		int32_t L_17 = __this->get_param_num_7();
		NullCheck(L_16);
		L_16->set_SizeParamIndex_6((((int16_t)((int16_t)L_17))));
	}

IL_0085:
	{
		MarshalAsAttribute_t2900773360 * L_18 = V_0;
		return L_18;
	}
}
// System.Void System.Reflection.EventInfo::.ctor()
extern "C"  void EventInfo__ctor_m1190141300 (EventInfo_t * __this, const MethodInfo* method)
{
	{
		MemberInfo__ctor_m2808577188(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Type System.Reflection.EventInfo::get_EventHandlerType()
extern "C"  Type_t * EventInfo_get_EventHandlerType_m2787680849 (EventInfo_t * __this, const MethodInfo* method)
{
	ParameterInfoU5BU5D_t2275869610* V_0 = NULL;
	MethodInfo_t * V_1 = NULL;
	Type_t * V_2 = NULL;
	{
		MethodInfo_t * L_0 = VirtFuncInvoker1< MethodInfo_t *, bool >::Invoke(16 /* System.Reflection.MethodInfo System.Reflection.EventInfo::GetAddMethod(System.Boolean) */, __this, (bool)1);
		V_1 = L_0;
		MethodInfo_t * L_1 = V_1;
		NullCheck(L_1);
		ParameterInfoU5BU5D_t2275869610* L_2 = VirtFuncInvoker0< ParameterInfoU5BU5D_t2275869610* >::Invoke(14 /* System.Reflection.ParameterInfo[] System.Reflection.MethodBase::GetParameters() */, L_1);
		V_0 = L_2;
		ParameterInfoU5BU5D_t2275869610* L_3 = V_0;
		NullCheck(L_3);
		if ((((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_3)->max_length))))) <= ((int32_t)0)))
		{
			goto IL_0023;
		}
	}
	{
		ParameterInfoU5BU5D_t2275869610* L_4 = V_0;
		NullCheck(L_4);
		int32_t L_5 = 0;
		ParameterInfo_t2249040075 * L_6 = (L_4)->GetAt(static_cast<il2cpp_array_size_t>(L_5));
		NullCheck(L_6);
		Type_t * L_7 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.ParameterInfo::get_ParameterType() */, L_6);
		V_2 = L_7;
		Type_t * L_8 = V_2;
		return L_8;
	}

IL_0023:
	{
		return (Type_t *)NULL;
	}
}
// System.Reflection.MemberTypes System.Reflection.EventInfo::get_MemberType()
extern "C"  int32_t EventInfo_get_MemberType_m3337516651 (EventInfo_t * __this, const MethodInfo* method)
{
	{
		return (int32_t)(2);
	}
}
// System.Void System.Reflection.EventInfo/AddEventAdapter::.ctor(System.Object,System.IntPtr)
extern "C"  void AddEventAdapter__ctor_m4122716273 (AddEventAdapter_t1766862959 * __this, Il2CppObject * ___object0, IntPtr_t ___method1, const MethodInfo* method)
{
	__this->set_method_ptr_0((Il2CppMethodPointer)((MethodInfo*)___method1.get_m_value_0())->methodPointer);
	__this->set_method_3(___method1);
	__this->set_m_target_2(___object0);
}
// System.Void System.Reflection.EventInfo/AddEventAdapter::Invoke(System.Object,System.Delegate)
extern "C"  void AddEventAdapter_Invoke_m3970567975 (AddEventAdapter_t1766862959 * __this, Il2CppObject * ____this0, Delegate_t3022476291 * ___dele1, const MethodInfo* method)
{
	if(__this->get_prev_9() != NULL)
	{
		AddEventAdapter_Invoke_m3970567975((AddEventAdapter_t1766862959 *)__this->get_prev_9(),____this0, ___dele1, method);
	}
	il2cpp_codegen_raise_execution_engine_exception_if_method_is_not_found((MethodInfo*)(__this->get_method_3().get_m_value_0()));
	bool ___methodIsStatic = MethodIsStatic((MethodInfo*)(__this->get_method_3().get_m_value_0()));
	if (__this->get_m_target_2() != NULL && ___methodIsStatic)
	{
		typedef void (*FunctionPointerType) (Il2CppObject *, void* __this, Il2CppObject * ____this0, Delegate_t3022476291 * ___dele1, const MethodInfo* method);
		((FunctionPointerType)__this->get_method_ptr_0())(NULL,__this->get_m_target_2(),____this0, ___dele1,(MethodInfo*)(__this->get_method_3().get_m_value_0()));
	}
	else if (__this->get_m_target_2() != NULL || ___methodIsStatic)
	{
		typedef void (*FunctionPointerType) (void* __this, Il2CppObject * ____this0, Delegate_t3022476291 * ___dele1, const MethodInfo* method);
		((FunctionPointerType)__this->get_method_ptr_0())(__this->get_m_target_2(),____this0, ___dele1,(MethodInfo*)(__this->get_method_3().get_m_value_0()));
	}
	else
	{
		typedef void (*FunctionPointerType) (void* __this, Delegate_t3022476291 * ___dele1, const MethodInfo* method);
		((FunctionPointerType)__this->get_method_ptr_0())(____this0, ___dele1,(MethodInfo*)(__this->get_method_3().get_m_value_0()));
	}
}
// System.IAsyncResult System.Reflection.EventInfo/AddEventAdapter::BeginInvoke(System.Object,System.Delegate,System.AsyncCallback,System.Object)
extern "C"  Il2CppObject * AddEventAdapter_BeginInvoke_m3628937824 (AddEventAdapter_t1766862959 * __this, Il2CppObject * ____this0, Delegate_t3022476291 * ___dele1, AsyncCallback_t163412349 * ___callback2, Il2CppObject * ___object3, const MethodInfo* method)
{
	void *__d_args[3] = {0};
	__d_args[0] = ____this0;
	__d_args[1] = ___dele1;
	return (Il2CppObject *)il2cpp_codegen_delegate_begin_invoke((Il2CppDelegate*)__this, __d_args, (Il2CppDelegate*)___callback2, (Il2CppObject*)___object3);
}
// System.Void System.Reflection.EventInfo/AddEventAdapter::EndInvoke(System.IAsyncResult)
extern "C"  void AddEventAdapter_EndInvoke_m1884114191 (AddEventAdapter_t1766862959 * __this, Il2CppObject * ___result0, const MethodInfo* method)
{
	il2cpp_codegen_delegate_end_invoke((Il2CppAsyncResult*) ___result0, 0);
}
// System.Void System.Reflection.FieldInfo::.ctor()
extern "C"  void FieldInfo__ctor_m1952545900 (FieldInfo_t * __this, const MethodInfo* method)
{
	{
		MemberInfo__ctor_m2808577188(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Reflection.MemberTypes System.Reflection.FieldInfo::get_MemberType()
extern "C"  int32_t FieldInfo_get_MemberType_m4190511717 (FieldInfo_t * __this, const MethodInfo* method)
{
	{
		return (int32_t)(4);
	}
}
// System.Boolean System.Reflection.FieldInfo::get_IsLiteral()
extern "C"  bool FieldInfo_get_IsLiteral_m267898096 (FieldInfo_t * __this, const MethodInfo* method)
{
	{
		int32_t L_0 = VirtFuncInvoker0< int32_t >::Invoke(14 /* System.Reflection.FieldAttributes System.Reflection.FieldInfo::get_Attributes() */, __this);
		return (bool)((((int32_t)((((int32_t)((int32_t)((int32_t)L_0&(int32_t)((int32_t)64)))) == ((int32_t)0))? 1 : 0)) == ((int32_t)0))? 1 : 0);
	}
}
// System.Boolean System.Reflection.FieldInfo::get_IsStatic()
extern "C"  bool FieldInfo_get_IsStatic_m1411173225 (FieldInfo_t * __this, const MethodInfo* method)
{
	{
		int32_t L_0 = VirtFuncInvoker0< int32_t >::Invoke(14 /* System.Reflection.FieldAttributes System.Reflection.FieldInfo::get_Attributes() */, __this);
		return (bool)((((int32_t)((((int32_t)((int32_t)((int32_t)L_0&(int32_t)((int32_t)16)))) == ((int32_t)0))? 1 : 0)) == ((int32_t)0))? 1 : 0);
	}
}
// System.Boolean System.Reflection.FieldInfo::get_IsNotSerialized()
extern "C"  bool FieldInfo_get_IsNotSerialized_m2322769148 (FieldInfo_t * __this, const MethodInfo* method)
{
	{
		int32_t L_0 = VirtFuncInvoker0< int32_t >::Invoke(14 /* System.Reflection.FieldAttributes System.Reflection.FieldInfo::get_Attributes() */, __this);
		return (bool)((((int32_t)((int32_t)((int32_t)L_0&(int32_t)((int32_t)128)))) == ((int32_t)((int32_t)128)))? 1 : 0);
	}
}
// System.Void System.Reflection.FieldInfo::SetValue(System.Object,System.Object)
extern "C"  void FieldInfo_SetValue_m2504255891 (FieldInfo_t * __this, Il2CppObject * ___obj0, Il2CppObject * ___value1, const MethodInfo* method)
{
	{
		Il2CppObject * L_0 = ___obj0;
		Il2CppObject * L_1 = ___value1;
		VirtActionInvoker5< Il2CppObject *, Il2CppObject *, int32_t, Binder_t3404612058 *, CultureInfo_t3500843524 * >::Invoke(21 /* System.Void System.Reflection.FieldInfo::SetValue(System.Object,System.Object,System.Reflection.BindingFlags,System.Reflection.Binder,System.Globalization.CultureInfo) */, __this, L_0, L_1, 0, (Binder_t3404612058 *)NULL, (CultureInfo_t3500843524 *)NULL);
		return;
	}
}
// System.Reflection.FieldInfo System.Reflection.FieldInfo::internal_from_handle_type(System.IntPtr,System.IntPtr)
extern "C"  FieldInfo_t * FieldInfo_internal_from_handle_type_m3419926447 (Il2CppObject * __this /* static, unused */, IntPtr_t ___field_handle0, IntPtr_t ___type_handle1, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef FieldInfo_t * (*FieldInfo_internal_from_handle_type_m3419926447_ftn) (IntPtr_t, IntPtr_t);
	return  ((FieldInfo_internal_from_handle_type_m3419926447_ftn)mscorlib::System::Reflection::FieldInfo::internal_from_handle_type) (___field_handle0, ___type_handle1);
}
// System.Reflection.FieldInfo System.Reflection.FieldInfo::GetFieldFromHandle(System.RuntimeFieldHandle)
extern Il2CppClass* IntPtr_t_il2cpp_TypeInfo_var;
extern Il2CppClass* ArgumentException_t3259014390_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral382420726;
extern const uint32_t FieldInfo_GetFieldFromHandle_m1587354836_MetadataUsageId;
extern "C"  FieldInfo_t * FieldInfo_GetFieldFromHandle_m1587354836 (Il2CppObject * __this /* static, unused */, RuntimeFieldHandle_t2331729674  ___handle0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (FieldInfo_GetFieldFromHandle_m1587354836_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		IntPtr_t L_0 = RuntimeFieldHandle_get_Value_m3963757144((&___handle0), /*hidden argument*/NULL);
		IntPtr_t L_1 = ((IntPtr_t_StaticFields*)IntPtr_t_il2cpp_TypeInfo_var->static_fields)->get_Zero_1();
		bool L_2 = IntPtr_op_Equality_m1573482188(NULL /*static, unused*/, L_0, L_1, /*hidden argument*/NULL);
		if (!L_2)
		{
			goto IL_0021;
		}
	}
	{
		ArgumentException_t3259014390 * L_3 = (ArgumentException_t3259014390 *)il2cpp_codegen_object_new(ArgumentException_t3259014390_il2cpp_TypeInfo_var);
		ArgumentException__ctor_m3739475201(L_3, _stringLiteral382420726, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_3);
	}

IL_0021:
	{
		IntPtr_t L_4 = RuntimeFieldHandle_get_Value_m3963757144((&___handle0), /*hidden argument*/NULL);
		IntPtr_t L_5 = ((IntPtr_t_StaticFields*)IntPtr_t_il2cpp_TypeInfo_var->static_fields)->get_Zero_1();
		FieldInfo_t * L_6 = FieldInfo_internal_from_handle_type_m3419926447(NULL /*static, unused*/, L_4, L_5, /*hidden argument*/NULL);
		return L_6;
	}
}
// System.Int32 System.Reflection.FieldInfo::GetFieldOffset()
extern Il2CppClass* SystemException_t3877406272_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral3975950849;
extern const uint32_t FieldInfo_GetFieldOffset_m375239709_MetadataUsageId;
extern "C"  int32_t FieldInfo_GetFieldOffset_m375239709 (FieldInfo_t * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (FieldInfo_GetFieldOffset_m375239709_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		SystemException_t3877406272 * L_0 = (SystemException_t3877406272 *)il2cpp_codegen_object_new(SystemException_t3877406272_il2cpp_TypeInfo_var);
		SystemException__ctor_m4001391027(L_0, _stringLiteral3975950849, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Reflection.Emit.UnmanagedMarshal System.Reflection.FieldInfo::GetUnmanagedMarshal()
extern "C"  UnmanagedMarshal_t4270021860 * FieldInfo_GetUnmanagedMarshal_m3869098058 (FieldInfo_t * __this, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef UnmanagedMarshal_t4270021860 * (*FieldInfo_GetUnmanagedMarshal_m3869098058_ftn) (FieldInfo_t *);
	return  ((FieldInfo_GetUnmanagedMarshal_m3869098058_ftn)mscorlib::System::Reflection::FieldInfo::GetUnmanagedMarshal) (__this);
}
// System.Reflection.Emit.UnmanagedMarshal System.Reflection.FieldInfo::get_UMarshal()
extern "C"  UnmanagedMarshal_t4270021860 * FieldInfo_get_UMarshal_m1934544188 (FieldInfo_t * __this, const MethodInfo* method)
{
	{
		UnmanagedMarshal_t4270021860 * L_0 = FieldInfo_GetUnmanagedMarshal_m3869098058(__this, /*hidden argument*/NULL);
		return L_0;
	}
}
// System.Object[] System.Reflection.FieldInfo::GetPseudoCustomAttributes()
extern Il2CppClass* ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var;
extern Il2CppClass* NonSerializedAttribute_t399263003_il2cpp_TypeInfo_var;
extern Il2CppClass* FieldOffsetAttribute_t1553145711_il2cpp_TypeInfo_var;
extern const uint32_t FieldInfo_GetPseudoCustomAttributes_m2500972355_MetadataUsageId;
extern "C"  ObjectU5BU5D_t3614634134* FieldInfo_GetPseudoCustomAttributes_m2500972355 (FieldInfo_t * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (FieldInfo_GetPseudoCustomAttributes_m2500972355_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	UnmanagedMarshal_t4270021860 * V_1 = NULL;
	ObjectU5BU5D_t3614634134* V_2 = NULL;
	{
		V_0 = 0;
		bool L_0 = FieldInfo_get_IsNotSerialized_m2322769148(__this, /*hidden argument*/NULL);
		if (!L_0)
		{
			goto IL_0011;
		}
	}
	{
		int32_t L_1 = V_0;
		V_0 = ((int32_t)((int32_t)L_1+(int32_t)1));
	}

IL_0011:
	{
		Type_t * L_2 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.MemberInfo::get_DeclaringType() */, __this);
		NullCheck(L_2);
		bool L_3 = Type_get_IsExplicitLayout_m1489853866(L_2, /*hidden argument*/NULL);
		if (!L_3)
		{
			goto IL_0025;
		}
	}
	{
		int32_t L_4 = V_0;
		V_0 = ((int32_t)((int32_t)L_4+(int32_t)1));
	}

IL_0025:
	{
		UnmanagedMarshal_t4270021860 * L_5 = VirtFuncInvoker0< UnmanagedMarshal_t4270021860 * >::Invoke(24 /* System.Reflection.Emit.UnmanagedMarshal System.Reflection.FieldInfo::get_UMarshal() */, __this);
		V_1 = L_5;
		UnmanagedMarshal_t4270021860 * L_6 = V_1;
		if (!L_6)
		{
			goto IL_0036;
		}
	}
	{
		int32_t L_7 = V_0;
		V_0 = ((int32_t)((int32_t)L_7+(int32_t)1));
	}

IL_0036:
	{
		int32_t L_8 = V_0;
		if (L_8)
		{
			goto IL_003e;
		}
	}
	{
		return (ObjectU5BU5D_t3614634134*)NULL;
	}

IL_003e:
	{
		int32_t L_9 = V_0;
		V_2 = ((ObjectU5BU5D_t3614634134*)SZArrayNew(ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var, (uint32_t)L_9));
		V_0 = 0;
		bool L_10 = FieldInfo_get_IsNotSerialized_m2322769148(__this, /*hidden argument*/NULL);
		if (!L_10)
		{
			goto IL_005e;
		}
	}
	{
		ObjectU5BU5D_t3614634134* L_11 = V_2;
		int32_t L_12 = V_0;
		int32_t L_13 = L_12;
		V_0 = ((int32_t)((int32_t)L_13+(int32_t)1));
		NonSerializedAttribute_t399263003 * L_14 = (NonSerializedAttribute_t399263003 *)il2cpp_codegen_object_new(NonSerializedAttribute_t399263003_il2cpp_TypeInfo_var);
		NonSerializedAttribute__ctor_m1638643584(L_14, /*hidden argument*/NULL);
		NullCheck(L_11);
		ArrayElementTypeCheck (L_11, L_14);
		(L_11)->SetAt(static_cast<il2cpp_array_size_t>(L_13), (Il2CppObject *)L_14);
	}

IL_005e:
	{
		Type_t * L_15 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.MemberInfo::get_DeclaringType() */, __this);
		NullCheck(L_15);
		bool L_16 = Type_get_IsExplicitLayout_m1489853866(L_15, /*hidden argument*/NULL);
		if (!L_16)
		{
			goto IL_0080;
		}
	}
	{
		ObjectU5BU5D_t3614634134* L_17 = V_2;
		int32_t L_18 = V_0;
		int32_t L_19 = L_18;
		V_0 = ((int32_t)((int32_t)L_19+(int32_t)1));
		int32_t L_20 = VirtFuncInvoker0< int32_t >::Invoke(23 /* System.Int32 System.Reflection.FieldInfo::GetFieldOffset() */, __this);
		FieldOffsetAttribute_t1553145711 * L_21 = (FieldOffsetAttribute_t1553145711 *)il2cpp_codegen_object_new(FieldOffsetAttribute_t1553145711_il2cpp_TypeInfo_var);
		FieldOffsetAttribute__ctor_m3347191262(L_21, L_20, /*hidden argument*/NULL);
		NullCheck(L_17);
		ArrayElementTypeCheck (L_17, L_21);
		(L_17)->SetAt(static_cast<il2cpp_array_size_t>(L_19), (Il2CppObject *)L_21);
	}

IL_0080:
	{
		UnmanagedMarshal_t4270021860 * L_22 = V_1;
		if (!L_22)
		{
			goto IL_0093;
		}
	}
	{
		ObjectU5BU5D_t3614634134* L_23 = V_2;
		int32_t L_24 = V_0;
		int32_t L_25 = L_24;
		V_0 = ((int32_t)((int32_t)L_25+(int32_t)1));
		UnmanagedMarshal_t4270021860 * L_26 = V_1;
		NullCheck(L_26);
		MarshalAsAttribute_t2900773360 * L_27 = UnmanagedMarshal_ToMarshalAsAttribute_m3695569337(L_26, /*hidden argument*/NULL);
		NullCheck(L_23);
		ArrayElementTypeCheck (L_23, L_27);
		(L_23)->SetAt(static_cast<il2cpp_array_size_t>(L_25), (Il2CppObject *)L_27);
	}

IL_0093:
	{
		ObjectU5BU5D_t3614634134* L_28 = V_2;
		return L_28;
	}
}
// System.Void System.Reflection.MemberFilter::.ctor(System.Object,System.IntPtr)
extern "C"  void MemberFilter__ctor_m1775909550 (MemberFilter_t3405857066 * __this, Il2CppObject * ___object0, IntPtr_t ___method1, const MethodInfo* method)
{
	__this->set_method_ptr_0((Il2CppMethodPointer)((MethodInfo*)___method1.get_m_value_0())->methodPointer);
	__this->set_method_3(___method1);
	__this->set_m_target_2(___object0);
}
// System.Boolean System.Reflection.MemberFilter::Invoke(System.Reflection.MemberInfo,System.Object)
extern "C"  bool MemberFilter_Invoke_m2927312774 (MemberFilter_t3405857066 * __this, MemberInfo_t * ___m0, Il2CppObject * ___filterCriteria1, const MethodInfo* method)
{
	if(__this->get_prev_9() != NULL)
	{
		MemberFilter_Invoke_m2927312774((MemberFilter_t3405857066 *)__this->get_prev_9(),___m0, ___filterCriteria1, method);
	}
	il2cpp_codegen_raise_execution_engine_exception_if_method_is_not_found((MethodInfo*)(__this->get_method_3().get_m_value_0()));
	bool ___methodIsStatic = MethodIsStatic((MethodInfo*)(__this->get_method_3().get_m_value_0()));
	if (__this->get_m_target_2() != NULL && ___methodIsStatic)
	{
		typedef bool (*FunctionPointerType) (Il2CppObject *, void* __this, MemberInfo_t * ___m0, Il2CppObject * ___filterCriteria1, const MethodInfo* method);
		return ((FunctionPointerType)__this->get_method_ptr_0())(NULL,__this->get_m_target_2(),___m0, ___filterCriteria1,(MethodInfo*)(__this->get_method_3().get_m_value_0()));
	}
	else if (__this->get_m_target_2() != NULL || ___methodIsStatic)
	{
		typedef bool (*FunctionPointerType) (void* __this, MemberInfo_t * ___m0, Il2CppObject * ___filterCriteria1, const MethodInfo* method);
		return ((FunctionPointerType)__this->get_method_ptr_0())(__this->get_m_target_2(),___m0, ___filterCriteria1,(MethodInfo*)(__this->get_method_3().get_m_value_0()));
	}
	else
	{
		typedef bool (*FunctionPointerType) (void* __this, Il2CppObject * ___filterCriteria1, const MethodInfo* method);
		return ((FunctionPointerType)__this->get_method_ptr_0())(___m0, ___filterCriteria1,(MethodInfo*)(__this->get_method_3().get_m_value_0()));
	}
}
// System.IAsyncResult System.Reflection.MemberFilter::BeginInvoke(System.Reflection.MemberInfo,System.Object,System.AsyncCallback,System.Object)
extern "C"  Il2CppObject * MemberFilter_BeginInvoke_m149662271 (MemberFilter_t3405857066 * __this, MemberInfo_t * ___m0, Il2CppObject * ___filterCriteria1, AsyncCallback_t163412349 * ___callback2, Il2CppObject * ___object3, const MethodInfo* method)
{
	void *__d_args[3] = {0};
	__d_args[0] = ___m0;
	__d_args[1] = ___filterCriteria1;
	return (Il2CppObject *)il2cpp_codegen_delegate_begin_invoke((Il2CppDelegate*)__this, __d_args, (Il2CppDelegate*)___callback2, (Il2CppObject*)___object3);
}
// System.Boolean System.Reflection.MemberFilter::EndInvoke(System.IAsyncResult)
extern "C"  bool MemberFilter_EndInvoke_m3642216476 (MemberFilter_t3405857066 * __this, Il2CppObject * ___result0, const MethodInfo* method)
{
	Il2CppObject *__result = il2cpp_codegen_delegate_end_invoke((Il2CppAsyncResult*) ___result0, 0);
	return *(bool*)UnBox ((Il2CppCodeGenObject*)__result);
}
// System.Void System.Reflection.MemberInfo::.ctor()
extern "C"  void MemberInfo__ctor_m2808577188 (MemberInfo_t * __this, const MethodInfo* method)
{
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Reflection.Module System.Reflection.MemberInfo::get_Module()
extern "C"  Module_t4282841206 * MemberInfo_get_Module_m3957426656 (MemberInfo_t * __this, const MethodInfo* method)
{
	{
		Type_t * L_0 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.MemberInfo::get_DeclaringType() */, __this);
		NullCheck(L_0);
		Module_t4282841206 * L_1 = VirtFuncInvoker0< Module_t4282841206 * >::Invoke(10 /* System.Reflection.Module System.Type::get_Module() */, L_0);
		return L_1;
	}
}
// System.Void System.Reflection.MemberInfoSerializationHolder::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern Il2CppClass* SerializationException_t753258759_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral3484720401;
extern Il2CppCodeGenString* _stringLiteral2809705325;
extern Il2CppCodeGenString* _stringLiteral2328219947;
extern Il2CppCodeGenString* _stringLiteral3902976916;
extern Il2CppCodeGenString* _stringLiteral1068945792;
extern const uint32_t MemberInfoSerializationHolder__ctor_m1297860825_MetadataUsageId;
extern "C"  void MemberInfoSerializationHolder__ctor_m1297860825 (MemberInfoSerializationHolder_t2799051170 * __this, SerializationInfo_t228987430 * ___info0, StreamingContext_t1417235061  ___ctx1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MemberInfoSerializationHolder__ctor_m1297860825_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	String_t* V_0 = NULL;
	String_t* V_1 = NULL;
	Assembly_t4268412390 * V_2 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		SerializationInfo_t228987430 * L_0 = ___info0;
		NullCheck(L_0);
		String_t* L_1 = SerializationInfo_GetString_m547109409(L_0, _stringLiteral3484720401, /*hidden argument*/NULL);
		V_0 = L_1;
		SerializationInfo_t228987430 * L_2 = ___info0;
		NullCheck(L_2);
		String_t* L_3 = SerializationInfo_GetString_m547109409(L_2, _stringLiteral2809705325, /*hidden argument*/NULL);
		V_1 = L_3;
		SerializationInfo_t228987430 * L_4 = ___info0;
		NullCheck(L_4);
		String_t* L_5 = SerializationInfo_GetString_m547109409(L_4, _stringLiteral2328219947, /*hidden argument*/NULL);
		__this->set__memberName_0(L_5);
		SerializationInfo_t228987430 * L_6 = ___info0;
		NullCheck(L_6);
		String_t* L_7 = SerializationInfo_GetString_m547109409(L_6, _stringLiteral3902976916, /*hidden argument*/NULL);
		__this->set__memberSignature_1(L_7);
		SerializationInfo_t228987430 * L_8 = ___info0;
		NullCheck(L_8);
		int32_t L_9 = SerializationInfo_GetInt32_m4039439501(L_8, _stringLiteral1068945792, /*hidden argument*/NULL);
		__this->set__memberType_2(L_9);
	}

IL_0051:
	try
	{ // begin try (depth: 1)
		__this->set__genericArguments_4((TypeU5BU5D_t1664964607*)NULL);
		goto IL_0063;
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__exception_local = (Exception_t1927440687 *)e.ex;
		if(il2cpp_codegen_class_is_assignable_from (SerializationException_t753258759_il2cpp_TypeInfo_var, e.ex->object.klass))
			goto CATCH_005d;
		throw e;
	}

CATCH_005d:
	{ // begin catch(System.Runtime.Serialization.SerializationException)
		goto IL_0063;
	} // end catch (depth: 1)

IL_0063:
	{
		String_t* L_10 = V_0;
		Assembly_t4268412390 * L_11 = Assembly_Load_m902205655(NULL /*static, unused*/, L_10, /*hidden argument*/NULL);
		V_2 = L_11;
		Assembly_t4268412390 * L_12 = V_2;
		String_t* L_13 = V_1;
		NullCheck(L_12);
		Type_t * L_14 = Assembly_GetType_m2765594712(L_12, L_13, (bool)1, (bool)1, /*hidden argument*/NULL);
		__this->set__reflectedType_3(L_14);
		return;
	}
}
// System.Void System.Reflection.MemberInfoSerializationHolder::Serialize(System.Runtime.Serialization.SerializationInfo,System.String,System.Type,System.String,System.Reflection.MemberTypes)
extern "C"  void MemberInfoSerializationHolder_Serialize_m1949812823 (Il2CppObject * __this /* static, unused */, SerializationInfo_t228987430 * ___info0, String_t* ___name1, Type_t * ___klass2, String_t* ___signature3, int32_t ___type4, const MethodInfo* method)
{
	{
		SerializationInfo_t228987430 * L_0 = ___info0;
		String_t* L_1 = ___name1;
		Type_t * L_2 = ___klass2;
		String_t* L_3 = ___signature3;
		int32_t L_4 = ___type4;
		MemberInfoSerializationHolder_Serialize_m4243060728(NULL /*static, unused*/, L_0, L_1, L_2, L_3, L_4, (TypeU5BU5D_t1664964607*)(TypeU5BU5D_t1664964607*)NULL, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Reflection.MemberInfoSerializationHolder::Serialize(System.Runtime.Serialization.SerializationInfo,System.String,System.Type,System.String,System.Reflection.MemberTypes,System.Type[])
extern const Il2CppType* MemberInfoSerializationHolder_t2799051170_0_0_0_var;
extern const Il2CppType* String_t_0_0_0_var;
extern const Il2CppType* TypeU5BU5D_t1664964607_0_0_0_var;
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral3484720401;
extern Il2CppCodeGenString* _stringLiteral2809705325;
extern Il2CppCodeGenString* _stringLiteral2328219947;
extern Il2CppCodeGenString* _stringLiteral3902976916;
extern Il2CppCodeGenString* _stringLiteral1068945792;
extern Il2CppCodeGenString* _stringLiteral3962342765;
extern const uint32_t MemberInfoSerializationHolder_Serialize_m4243060728_MetadataUsageId;
extern "C"  void MemberInfoSerializationHolder_Serialize_m4243060728 (Il2CppObject * __this /* static, unused */, SerializationInfo_t228987430 * ___info0, String_t* ___name1, Type_t * ___klass2, String_t* ___signature3, int32_t ___type4, TypeU5BU5D_t1664964607* ___genericArguments5, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MemberInfoSerializationHolder_Serialize_m4243060728_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		SerializationInfo_t228987430 * L_0 = ___info0;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_1 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(MemberInfoSerializationHolder_t2799051170_0_0_0_var), /*hidden argument*/NULL);
		NullCheck(L_0);
		SerializationInfo_SetType_m499725474(L_0, L_1, /*hidden argument*/NULL);
		SerializationInfo_t228987430 * L_2 = ___info0;
		Type_t * L_3 = ___klass2;
		NullCheck(L_3);
		Module_t4282841206 * L_4 = VirtFuncInvoker0< Module_t4282841206 * >::Invoke(10 /* System.Reflection.Module System.Type::get_Module() */, L_3);
		NullCheck(L_4);
		Assembly_t4268412390 * L_5 = Module_get_Assembly_m3690289982(L_4, /*hidden argument*/NULL);
		NullCheck(L_5);
		String_t* L_6 = VirtFuncInvoker0< String_t* >::Invoke(6 /* System.String System.Reflection.Assembly::get_FullName() */, L_5);
		Type_t * L_7 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(String_t_0_0_0_var), /*hidden argument*/NULL);
		NullCheck(L_2);
		SerializationInfo_AddValue_m1781549036(L_2, _stringLiteral3484720401, L_6, L_7, /*hidden argument*/NULL);
		SerializationInfo_t228987430 * L_8 = ___info0;
		Type_t * L_9 = ___klass2;
		NullCheck(L_9);
		String_t* L_10 = VirtFuncInvoker0< String_t* >::Invoke(18 /* System.String System.Type::get_FullName() */, L_9);
		Type_t * L_11 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(String_t_0_0_0_var), /*hidden argument*/NULL);
		NullCheck(L_8);
		SerializationInfo_AddValue_m1781549036(L_8, _stringLiteral2809705325, L_10, L_11, /*hidden argument*/NULL);
		SerializationInfo_t228987430 * L_12 = ___info0;
		String_t* L_13 = ___name1;
		Type_t * L_14 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(String_t_0_0_0_var), /*hidden argument*/NULL);
		NullCheck(L_12);
		SerializationInfo_AddValue_m1781549036(L_12, _stringLiteral2328219947, L_13, L_14, /*hidden argument*/NULL);
		SerializationInfo_t228987430 * L_15 = ___info0;
		String_t* L_16 = ___signature3;
		Type_t * L_17 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(String_t_0_0_0_var), /*hidden argument*/NULL);
		NullCheck(L_15);
		SerializationInfo_AddValue_m1781549036(L_15, _stringLiteral3902976916, L_16, L_17, /*hidden argument*/NULL);
		SerializationInfo_t228987430 * L_18 = ___info0;
		int32_t L_19 = ___type4;
		NullCheck(L_18);
		SerializationInfo_AddValue_m902275108(L_18, _stringLiteral1068945792, L_19, /*hidden argument*/NULL);
		SerializationInfo_t228987430 * L_20 = ___info0;
		TypeU5BU5D_t1664964607* L_21 = ___genericArguments5;
		Type_t * L_22 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(TypeU5BU5D_t1664964607_0_0_0_var), /*hidden argument*/NULL);
		NullCheck(L_20);
		SerializationInfo_AddValue_m1781549036(L_20, _stringLiteral3962342765, (Il2CppObject *)(Il2CppObject *)L_21, L_22, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Reflection.MemberInfoSerializationHolder::GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern Il2CppClass* NotSupportedException_t1793819818_il2cpp_TypeInfo_var;
extern const uint32_t MemberInfoSerializationHolder_GetObjectData_m1760456120_MetadataUsageId;
extern "C"  void MemberInfoSerializationHolder_GetObjectData_m1760456120 (MemberInfoSerializationHolder_t2799051170 * __this, SerializationInfo_t228987430 * ___info0, StreamingContext_t1417235061  ___context1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MemberInfoSerializationHolder_GetObjectData_m1760456120_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		NotSupportedException_t1793819818 * L_0 = (NotSupportedException_t1793819818 *)il2cpp_codegen_object_new(NotSupportedException_t1793819818_il2cpp_TypeInfo_var);
		NotSupportedException__ctor_m3232764727(L_0, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Object System.Reflection.MemberInfoSerializationHolder::GetRealObject(System.Runtime.Serialization.StreamingContext)
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* SerializationException_t753258759_il2cpp_TypeInfo_var;
extern Il2CppClass* MemberTypes_t3343038963_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral948459439;
extern Il2CppCodeGenString* _stringLiteral3230290608;
extern Il2CppCodeGenString* _stringLiteral2962078205;
extern Il2CppCodeGenString* _stringLiteral2138058808;
extern Il2CppCodeGenString* _stringLiteral3237053035;
extern Il2CppCodeGenString* _stringLiteral2011492163;
extern const uint32_t MemberInfoSerializationHolder_GetRealObject_m3643310964_MetadataUsageId;
extern "C"  Il2CppObject * MemberInfoSerializationHolder_GetRealObject_m3643310964 (MemberInfoSerializationHolder_t2799051170 * __this, StreamingContext_t1417235061  ___context0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MemberInfoSerializationHolder_GetRealObject_m3643310964_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ConstructorInfoU5BU5D_t1996683371* V_0 = NULL;
	int32_t V_1 = 0;
	MethodInfoU5BU5D_t152480188* V_2 = NULL;
	int32_t V_3 = 0;
	MethodInfo_t * V_4 = NULL;
	FieldInfo_t * V_5 = NULL;
	PropertyInfo_t * V_6 = NULL;
	EventInfo_t * V_7 = NULL;
	int32_t V_8 = 0;
	{
		int32_t L_0 = __this->get__memberType_2();
		V_8 = L_0;
		int32_t L_1 = V_8;
		if (((int32_t)((int32_t)L_1-(int32_t)1)) == 0)
		{
			goto IL_003f;
		}
		if (((int32_t)((int32_t)L_1-(int32_t)1)) == 1)
		{
			goto IL_01c2;
		}
		if (((int32_t)((int32_t)L_1-(int32_t)1)) == 2)
		{
			goto IL_0031;
		}
		if (((int32_t)((int32_t)L_1-(int32_t)1)) == 3)
		{
			goto IL_014c;
		}
		if (((int32_t)((int32_t)L_1-(int32_t)1)) == 4)
		{
			goto IL_0031;
		}
		if (((int32_t)((int32_t)L_1-(int32_t)1)) == 5)
		{
			goto IL_0031;
		}
		if (((int32_t)((int32_t)L_1-(int32_t)1)) == 6)
		{
			goto IL_0031;
		}
		if (((int32_t)((int32_t)L_1-(int32_t)1)) == 7)
		{
			goto IL_0099;
		}
	}

IL_0031:
	{
		int32_t L_2 = V_8;
		if ((((int32_t)L_2) == ((int32_t)((int32_t)16))))
		{
			goto IL_0187;
		}
	}
	{
		goto IL_01fd;
	}

IL_003f:
	{
		Type_t * L_3 = __this->get__reflectedType_3();
		NullCheck(L_3);
		ConstructorInfoU5BU5D_t1996683371* L_4 = VirtFuncInvoker1< ConstructorInfoU5BU5D_t1996683371*, int32_t >::Invoke(73 /* System.Reflection.ConstructorInfo[] System.Type::GetConstructors(System.Reflection.BindingFlags) */, L_3, ((int32_t)60));
		V_0 = L_4;
		V_1 = 0;
		goto IL_0074;
	}

IL_0054:
	{
		ConstructorInfoU5BU5D_t1996683371* L_5 = V_0;
		int32_t L_6 = V_1;
		NullCheck(L_5);
		int32_t L_7 = L_6;
		ConstructorInfo_t2851816542 * L_8 = (L_5)->GetAt(static_cast<il2cpp_array_size_t>(L_7));
		NullCheck(L_8);
		String_t* L_9 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Object::ToString() */, L_8);
		String_t* L_10 = __this->get__memberSignature_1();
		NullCheck(L_9);
		bool L_11 = String_Equals_m2633592423(L_9, L_10, /*hidden argument*/NULL);
		if (!L_11)
		{
			goto IL_0070;
		}
	}
	{
		ConstructorInfoU5BU5D_t1996683371* L_12 = V_0;
		int32_t L_13 = V_1;
		NullCheck(L_12);
		int32_t L_14 = L_13;
		ConstructorInfo_t2851816542 * L_15 = (L_12)->GetAt(static_cast<il2cpp_array_size_t>(L_14));
		return L_15;
	}

IL_0070:
	{
		int32_t L_16 = V_1;
		V_1 = ((int32_t)((int32_t)L_16+(int32_t)1));
	}

IL_0074:
	{
		int32_t L_17 = V_1;
		ConstructorInfoU5BU5D_t1996683371* L_18 = V_0;
		NullCheck(L_18);
		if ((((int32_t)L_17) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_18)->max_length)))))))
		{
			goto IL_0054;
		}
	}
	{
		String_t* L_19 = __this->get__memberSignature_1();
		Type_t * L_20 = __this->get__reflectedType_3();
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_21 = String_Format_m1811873526(NULL /*static, unused*/, _stringLiteral948459439, L_19, L_20, /*hidden argument*/NULL);
		SerializationException_t753258759 * L_22 = (SerializationException_t753258759 *)il2cpp_codegen_object_new(SerializationException_t753258759_il2cpp_TypeInfo_var);
		SerializationException__ctor_m1019897788(L_22, L_21, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_22);
	}

IL_0099:
	{
		Type_t * L_23 = __this->get__reflectedType_3();
		NullCheck(L_23);
		MethodInfoU5BU5D_t152480188* L_24 = VirtFuncInvoker1< MethodInfoU5BU5D_t152480188*, int32_t >::Invoke(53 /* System.Reflection.MethodInfo[] System.Type::GetMethods(System.Reflection.BindingFlags) */, L_23, ((int32_t)60));
		V_2 = L_24;
		V_3 = 0;
		goto IL_0127;
	}

IL_00ae:
	{
		MethodInfoU5BU5D_t152480188* L_25 = V_2;
		int32_t L_26 = V_3;
		NullCheck(L_25);
		int32_t L_27 = L_26;
		MethodInfo_t * L_28 = (L_25)->GetAt(static_cast<il2cpp_array_size_t>(L_27));
		NullCheck(L_28);
		String_t* L_29 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Object::ToString() */, L_28);
		String_t* L_30 = __this->get__memberSignature_1();
		NullCheck(L_29);
		bool L_31 = String_Equals_m2633592423(L_29, L_30, /*hidden argument*/NULL);
		if (!L_31)
		{
			goto IL_00ca;
		}
	}
	{
		MethodInfoU5BU5D_t152480188* L_32 = V_2;
		int32_t L_33 = V_3;
		NullCheck(L_32);
		int32_t L_34 = L_33;
		MethodInfo_t * L_35 = (L_32)->GetAt(static_cast<il2cpp_array_size_t>(L_34));
		return L_35;
	}

IL_00ca:
	{
		TypeU5BU5D_t1664964607* L_36 = __this->get__genericArguments_4();
		if (!L_36)
		{
			goto IL_0123;
		}
	}
	{
		MethodInfoU5BU5D_t152480188* L_37 = V_2;
		int32_t L_38 = V_3;
		NullCheck(L_37);
		int32_t L_39 = L_38;
		MethodInfo_t * L_40 = (L_37)->GetAt(static_cast<il2cpp_array_size_t>(L_39));
		NullCheck(L_40);
		bool L_41 = VirtFuncInvoker0< bool >::Invoke(29 /* System.Boolean System.Reflection.MethodInfo::get_IsGenericMethod() */, L_40);
		if (!L_41)
		{
			goto IL_0123;
		}
	}
	{
		MethodInfoU5BU5D_t152480188* L_42 = V_2;
		int32_t L_43 = V_3;
		NullCheck(L_42);
		int32_t L_44 = L_43;
		MethodInfo_t * L_45 = (L_42)->GetAt(static_cast<il2cpp_array_size_t>(L_44));
		NullCheck(L_45);
		TypeU5BU5D_t1664964607* L_46 = VirtFuncInvoker0< TypeU5BU5D_t1664964607* >::Invoke(26 /* System.Type[] System.Reflection.MethodInfo::GetGenericArguments() */, L_45);
		NullCheck(L_46);
		TypeU5BU5D_t1664964607* L_47 = __this->get__genericArguments_4();
		NullCheck(L_47);
		if ((!(((uint32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_46)->max_length))))) == ((uint32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_47)->max_length))))))))
		{
			goto IL_0123;
		}
	}
	{
		MethodInfoU5BU5D_t152480188* L_48 = V_2;
		int32_t L_49 = V_3;
		NullCheck(L_48);
		int32_t L_50 = L_49;
		MethodInfo_t * L_51 = (L_48)->GetAt(static_cast<il2cpp_array_size_t>(L_50));
		TypeU5BU5D_t1664964607* L_52 = __this->get__genericArguments_4();
		NullCheck(L_51);
		MethodInfo_t * L_53 = VirtFuncInvoker1< MethodInfo_t *, TypeU5BU5D_t1664964607* >::Invoke(32 /* System.Reflection.MethodInfo System.Reflection.MethodInfo::MakeGenericMethod(System.Type[]) */, L_51, L_52);
		V_4 = L_53;
		MethodInfo_t * L_54 = V_4;
		NullCheck(L_54);
		String_t* L_55 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Object::ToString() */, L_54);
		String_t* L_56 = __this->get__memberSignature_1();
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_57 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_55, L_56, /*hidden argument*/NULL);
		if (!L_57)
		{
			goto IL_0123;
		}
	}
	{
		MethodInfo_t * L_58 = V_4;
		return L_58;
	}

IL_0123:
	{
		int32_t L_59 = V_3;
		V_3 = ((int32_t)((int32_t)L_59+(int32_t)1));
	}

IL_0127:
	{
		int32_t L_60 = V_3;
		MethodInfoU5BU5D_t152480188* L_61 = V_2;
		NullCheck(L_61);
		if ((((int32_t)L_60) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_61)->max_length)))))))
		{
			goto IL_00ae;
		}
	}
	{
		String_t* L_62 = __this->get__memberSignature_1();
		Type_t * L_63 = __this->get__reflectedType_3();
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_64 = String_Format_m1811873526(NULL /*static, unused*/, _stringLiteral3230290608, L_62, L_63, /*hidden argument*/NULL);
		SerializationException_t753258759 * L_65 = (SerializationException_t753258759 *)il2cpp_codegen_object_new(SerializationException_t753258759_il2cpp_TypeInfo_var);
		SerializationException__ctor_m1019897788(L_65, L_64, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_65);
	}

IL_014c:
	{
		Type_t * L_66 = __this->get__reflectedType_3();
		String_t* L_67 = __this->get__memberName_0();
		NullCheck(L_66);
		FieldInfo_t * L_68 = VirtFuncInvoker2< FieldInfo_t *, String_t*, int32_t >::Invoke(45 /* System.Reflection.FieldInfo System.Type::GetField(System.String,System.Reflection.BindingFlags) */, L_66, L_67, ((int32_t)60));
		V_5 = L_68;
		FieldInfo_t * L_69 = V_5;
		if (!L_69)
		{
			goto IL_016b;
		}
	}
	{
		FieldInfo_t * L_70 = V_5;
		return L_70;
	}

IL_016b:
	{
		String_t* L_71 = __this->get__memberName_0();
		Type_t * L_72 = __this->get__reflectedType_3();
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_73 = String_Format_m1811873526(NULL /*static, unused*/, _stringLiteral2962078205, L_71, L_72, /*hidden argument*/NULL);
		SerializationException_t753258759 * L_74 = (SerializationException_t753258759 *)il2cpp_codegen_object_new(SerializationException_t753258759_il2cpp_TypeInfo_var);
		SerializationException__ctor_m1019897788(L_74, L_73, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_74);
	}

IL_0187:
	{
		Type_t * L_75 = __this->get__reflectedType_3();
		String_t* L_76 = __this->get__memberName_0();
		NullCheck(L_75);
		PropertyInfo_t * L_77 = Type_GetProperty_m1510204374(L_75, L_76, ((int32_t)60), /*hidden argument*/NULL);
		V_6 = L_77;
		PropertyInfo_t * L_78 = V_6;
		if (!L_78)
		{
			goto IL_01a6;
		}
	}
	{
		PropertyInfo_t * L_79 = V_6;
		return L_79;
	}

IL_01a6:
	{
		String_t* L_80 = __this->get__memberName_0();
		Type_t * L_81 = __this->get__reflectedType_3();
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_82 = String_Format_m1811873526(NULL /*static, unused*/, _stringLiteral2138058808, L_80, L_81, /*hidden argument*/NULL);
		SerializationException_t753258759 * L_83 = (SerializationException_t753258759 *)il2cpp_codegen_object_new(SerializationException_t753258759_il2cpp_TypeInfo_var);
		SerializationException__ctor_m1019897788(L_83, L_82, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_83);
	}

IL_01c2:
	{
		Type_t * L_84 = __this->get__reflectedType_3();
		String_t* L_85 = __this->get__memberName_0();
		NullCheck(L_84);
		EventInfo_t * L_86 = VirtFuncInvoker2< EventInfo_t *, String_t*, int32_t >::Invoke(43 /* System.Reflection.EventInfo System.Type::GetEvent(System.String,System.Reflection.BindingFlags) */, L_84, L_85, ((int32_t)60));
		V_7 = L_86;
		EventInfo_t * L_87 = V_7;
		if (!L_87)
		{
			goto IL_01e1;
		}
	}
	{
		EventInfo_t * L_88 = V_7;
		return L_88;
	}

IL_01e1:
	{
		String_t* L_89 = __this->get__memberName_0();
		Type_t * L_90 = __this->get__reflectedType_3();
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_91 = String_Format_m1811873526(NULL /*static, unused*/, _stringLiteral3237053035, L_89, L_90, /*hidden argument*/NULL);
		SerializationException_t753258759 * L_92 = (SerializationException_t753258759 *)il2cpp_codegen_object_new(SerializationException_t753258759_il2cpp_TypeInfo_var);
		SerializationException__ctor_m1019897788(L_92, L_91, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_92);
	}

IL_01fd:
	{
		int32_t L_93 = __this->get__memberType_2();
		int32_t L_94 = L_93;
		Il2CppObject * L_95 = Box(MemberTypes_t3343038963_il2cpp_TypeInfo_var, &L_94);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_96 = String_Format_m2024975688(NULL /*static, unused*/, _stringLiteral2011492163, L_95, /*hidden argument*/NULL);
		SerializationException_t753258759 * L_97 = (SerializationException_t753258759 *)il2cpp_codegen_object_new(SerializationException_t753258759_il2cpp_TypeInfo_var);
		SerializationException__ctor_m1019897788(L_97, L_96, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_97);
	}
}
// System.Void System.Reflection.MethodBase::.ctor()
extern "C"  void MethodBase__ctor_m3951051358 (MethodBase_t904190842 * __this, const MethodInfo* method)
{
	{
		MemberInfo__ctor_m2808577188(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Reflection.MethodBase System.Reflection.MethodBase::GetMethodFromHandleNoGenericCheck(System.RuntimeMethodHandle)
extern Il2CppClass* IntPtr_t_il2cpp_TypeInfo_var;
extern const uint32_t MethodBase_GetMethodFromHandleNoGenericCheck_m4274264088_MetadataUsageId;
extern "C"  MethodBase_t904190842 * MethodBase_GetMethodFromHandleNoGenericCheck_m4274264088 (Il2CppObject * __this /* static, unused */, RuntimeMethodHandle_t894824333  ___handle0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MethodBase_GetMethodFromHandleNoGenericCheck_m4274264088_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		IntPtr_t L_0 = RuntimeMethodHandle_get_Value_m333629197((&___handle0), /*hidden argument*/NULL);
		IntPtr_t L_1 = ((IntPtr_t_StaticFields*)IntPtr_t_il2cpp_TypeInfo_var->static_fields)->get_Zero_1();
		MethodBase_t904190842 * L_2 = MethodBase_GetMethodFromIntPtr_m1014299957(NULL /*static, unused*/, L_0, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.Reflection.MethodBase System.Reflection.MethodBase::GetMethodFromIntPtr(System.IntPtr,System.IntPtr)
extern Il2CppClass* IntPtr_t_il2cpp_TypeInfo_var;
extern Il2CppClass* ArgumentException_t3259014390_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral382420726;
extern const uint32_t MethodBase_GetMethodFromIntPtr_m1014299957_MetadataUsageId;
extern "C"  MethodBase_t904190842 * MethodBase_GetMethodFromIntPtr_m1014299957 (Il2CppObject * __this /* static, unused */, IntPtr_t ___handle0, IntPtr_t ___declaringType1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MethodBase_GetMethodFromIntPtr_m1014299957_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	MethodBase_t904190842 * V_0 = NULL;
	{
		IntPtr_t L_0 = ___handle0;
		IntPtr_t L_1 = ((IntPtr_t_StaticFields*)IntPtr_t_il2cpp_TypeInfo_var->static_fields)->get_Zero_1();
		bool L_2 = IntPtr_op_Equality_m1573482188(NULL /*static, unused*/, L_0, L_1, /*hidden argument*/NULL);
		if (!L_2)
		{
			goto IL_001b;
		}
	}
	{
		ArgumentException_t3259014390 * L_3 = (ArgumentException_t3259014390 *)il2cpp_codegen_object_new(ArgumentException_t3259014390_il2cpp_TypeInfo_var);
		ArgumentException__ctor_m3739475201(L_3, _stringLiteral382420726, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_3);
	}

IL_001b:
	{
		IntPtr_t L_4 = ___handle0;
		IntPtr_t L_5 = ___declaringType1;
		MethodBase_t904190842 * L_6 = MethodBase_GetMethodFromHandleInternalType_m570034609(NULL /*static, unused*/, L_4, L_5, /*hidden argument*/NULL);
		V_0 = L_6;
		MethodBase_t904190842 * L_7 = V_0;
		if (L_7)
		{
			goto IL_0034;
		}
	}
	{
		ArgumentException_t3259014390 * L_8 = (ArgumentException_t3259014390 *)il2cpp_codegen_object_new(ArgumentException_t3259014390_il2cpp_TypeInfo_var);
		ArgumentException__ctor_m3739475201(L_8, _stringLiteral382420726, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_8);
	}

IL_0034:
	{
		MethodBase_t904190842 * L_9 = V_0;
		return L_9;
	}
}
// System.Reflection.MethodBase System.Reflection.MethodBase::GetMethodFromHandle(System.RuntimeMethodHandle)
extern Il2CppClass* IntPtr_t_il2cpp_TypeInfo_var;
extern Il2CppClass* ArgumentException_t3259014390_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral1596710604;
extern const uint32_t MethodBase_GetMethodFromHandle_m3983882276_MetadataUsageId;
extern "C"  MethodBase_t904190842 * MethodBase_GetMethodFromHandle_m3983882276 (Il2CppObject * __this /* static, unused */, RuntimeMethodHandle_t894824333  ___handle0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MethodBase_GetMethodFromHandle_m3983882276_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	MethodBase_t904190842 * V_0 = NULL;
	Type_t * V_1 = NULL;
	{
		IntPtr_t L_0 = RuntimeMethodHandle_get_Value_m333629197((&___handle0), /*hidden argument*/NULL);
		IntPtr_t L_1 = ((IntPtr_t_StaticFields*)IntPtr_t_il2cpp_TypeInfo_var->static_fields)->get_Zero_1();
		MethodBase_t904190842 * L_2 = MethodBase_GetMethodFromIntPtr_m1014299957(NULL /*static, unused*/, L_0, L_1, /*hidden argument*/NULL);
		V_0 = L_2;
		MethodBase_t904190842 * L_3 = V_0;
		NullCheck(L_3);
		Type_t * L_4 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.MemberInfo::get_DeclaringType() */, L_3);
		V_1 = L_4;
		Type_t * L_5 = V_1;
		NullCheck(L_5);
		bool L_6 = VirtFuncInvoker0< bool >::Invoke(79 /* System.Boolean System.Type::get_IsGenericType() */, L_5);
		if (L_6)
		{
			goto IL_002f;
		}
	}
	{
		Type_t * L_7 = V_1;
		NullCheck(L_7);
		bool L_8 = VirtFuncInvoker0< bool >::Invoke(77 /* System.Boolean System.Type::get_IsGenericTypeDefinition() */, L_7);
		if (!L_8)
		{
			goto IL_003a;
		}
	}

IL_002f:
	{
		ArgumentException_t3259014390 * L_9 = (ArgumentException_t3259014390 *)il2cpp_codegen_object_new(ArgumentException_t3259014390_il2cpp_TypeInfo_var);
		ArgumentException__ctor_m3739475201(L_9, _stringLiteral1596710604, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_9);
	}

IL_003a:
	{
		MethodBase_t904190842 * L_10 = V_0;
		return L_10;
	}
}
// System.Reflection.MethodBase System.Reflection.MethodBase::GetMethodFromHandleInternalType(System.IntPtr,System.IntPtr)
extern "C"  MethodBase_t904190842 * MethodBase_GetMethodFromHandleInternalType_m570034609 (Il2CppObject * __this /* static, unused */, IntPtr_t ___method_handle0, IntPtr_t ___type_handle1, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef MethodBase_t904190842 * (*MethodBase_GetMethodFromHandleInternalType_m570034609_ftn) (IntPtr_t, IntPtr_t);
	return  ((MethodBase_GetMethodFromHandleInternalType_m570034609_ftn)mscorlib::System::Reflection::MethodBase::GetMethodFromHandleInternalType) (___method_handle0, ___type_handle1);
}
// System.Int32 System.Reflection.MethodBase::GetParameterCount()
extern "C"  int32_t MethodBase_GetParameterCount_m3877953436 (MethodBase_t904190842 * __this, const MethodInfo* method)
{
	ParameterInfoU5BU5D_t2275869610* V_0 = NULL;
	{
		ParameterInfoU5BU5D_t2275869610* L_0 = VirtFuncInvoker0< ParameterInfoU5BU5D_t2275869610* >::Invoke(14 /* System.Reflection.ParameterInfo[] System.Reflection.MethodBase::GetParameters() */, __this);
		V_0 = L_0;
		ParameterInfoU5BU5D_t2275869610* L_1 = V_0;
		if (L_1)
		{
			goto IL_000f;
		}
	}
	{
		return 0;
	}

IL_000f:
	{
		ParameterInfoU5BU5D_t2275869610* L_2 = V_0;
		NullCheck(L_2);
		return (((int32_t)((int32_t)(((Il2CppArray *)L_2)->max_length))));
	}
}
// System.Object System.Reflection.MethodBase::Invoke(System.Object,System.Object[])
extern "C"  Il2CppObject * MethodBase_Invoke_m1075809207 (MethodBase_t904190842 * __this, Il2CppObject * ___obj0, ObjectU5BU5D_t3614634134* ___parameters1, const MethodInfo* method)
{
	{
		Il2CppObject * L_0 = ___obj0;
		ObjectU5BU5D_t3614634134* L_1 = ___parameters1;
		Il2CppObject * L_2 = VirtFuncInvoker5< Il2CppObject *, Il2CppObject *, int32_t, Binder_t3404612058 *, ObjectU5BU5D_t3614634134*, CultureInfo_t3500843524 * >::Invoke(17 /* System.Object System.Reflection.MethodBase::Invoke(System.Object,System.Reflection.BindingFlags,System.Reflection.Binder,System.Object[],System.Globalization.CultureInfo) */, __this, L_0, 0, (Binder_t3404612058 *)NULL, L_1, (CultureInfo_t3500843524 *)NULL);
		return L_2;
	}
}
// System.Reflection.CallingConventions System.Reflection.MethodBase::get_CallingConvention()
extern "C"  int32_t MethodBase_get_CallingConvention_m2817807351 (MethodBase_t904190842 * __this, const MethodInfo* method)
{
	{
		return (int32_t)(1);
	}
}
// System.Boolean System.Reflection.MethodBase::get_IsPublic()
extern "C"  bool MethodBase_get_IsPublic_m479656180 (MethodBase_t904190842 * __this, const MethodInfo* method)
{
	{
		int32_t L_0 = VirtFuncInvoker0< int32_t >::Invoke(19 /* System.Reflection.MethodAttributes System.Reflection.MethodBase::get_Attributes() */, __this);
		return (bool)((((int32_t)((int32_t)((int32_t)L_0&(int32_t)7))) == ((int32_t)6))? 1 : 0);
	}
}
// System.Boolean System.Reflection.MethodBase::get_IsStatic()
extern "C"  bool MethodBase_get_IsStatic_m1015686807 (MethodBase_t904190842 * __this, const MethodInfo* method)
{
	{
		int32_t L_0 = VirtFuncInvoker0< int32_t >::Invoke(19 /* System.Reflection.MethodAttributes System.Reflection.MethodBase::get_Attributes() */, __this);
		return (bool)((((int32_t)((((int32_t)((int32_t)((int32_t)L_0&(int32_t)((int32_t)16)))) == ((int32_t)0))? 1 : 0)) == ((int32_t)0))? 1 : 0);
	}
}
// System.Boolean System.Reflection.MethodBase::get_IsVirtual()
extern "C"  bool MethodBase_get_IsVirtual_m1107721718 (MethodBase_t904190842 * __this, const MethodInfo* method)
{
	{
		int32_t L_0 = VirtFuncInvoker0< int32_t >::Invoke(19 /* System.Reflection.MethodAttributes System.Reflection.MethodBase::get_Attributes() */, __this);
		return (bool)((((int32_t)((((int32_t)((int32_t)((int32_t)L_0&(int32_t)((int32_t)64)))) == ((int32_t)0))? 1 : 0)) == ((int32_t)0))? 1 : 0);
	}
}
// System.Boolean System.Reflection.MethodBase::get_IsAbstract()
extern "C"  bool MethodBase_get_IsAbstract_m3521819231 (MethodBase_t904190842 * __this, const MethodInfo* method)
{
	{
		int32_t L_0 = VirtFuncInvoker0< int32_t >::Invoke(19 /* System.Reflection.MethodAttributes System.Reflection.MethodBase::get_Attributes() */, __this);
		return (bool)((((int32_t)((((int32_t)((int32_t)((int32_t)L_0&(int32_t)((int32_t)1024)))) == ((int32_t)0))? 1 : 0)) == ((int32_t)0))? 1 : 0);
	}
}
// System.Int32 System.Reflection.MethodBase::get_next_table_index(System.Object,System.Int32,System.Boolean)
extern Il2CppClass* MethodBuilder_t644187984_il2cpp_TypeInfo_var;
extern Il2CppClass* ConstructorBuilder_t700974433_il2cpp_TypeInfo_var;
extern Il2CppClass* Exception_t1927440687_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral4028768107;
extern const uint32_t MethodBase_get_next_table_index_m3185673846_MetadataUsageId;
extern "C"  int32_t MethodBase_get_next_table_index_m3185673846 (MethodBase_t904190842 * __this, Il2CppObject * ___obj0, int32_t ___table1, bool ___inc2, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MethodBase_get_next_table_index_m3185673846_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	MethodBuilder_t644187984 * V_0 = NULL;
	ConstructorBuilder_t700974433 * V_1 = NULL;
	{
		if (!((MethodBuilder_t644187984 *)IsInstSealed(__this, MethodBuilder_t644187984_il2cpp_TypeInfo_var)))
		{
			goto IL_001c;
		}
	}
	{
		V_0 = ((MethodBuilder_t644187984 *)CastclassSealed(__this, MethodBuilder_t644187984_il2cpp_TypeInfo_var));
		MethodBuilder_t644187984 * L_0 = V_0;
		Il2CppObject * L_1 = ___obj0;
		int32_t L_2 = ___table1;
		bool L_3 = ___inc2;
		NullCheck(L_0);
		int32_t L_4 = MethodBuilder_get_next_table_index_m683309027(L_0, L_1, L_2, L_3, /*hidden argument*/NULL);
		return L_4;
	}

IL_001c:
	{
		if (!((ConstructorBuilder_t700974433 *)IsInstSealed(__this, ConstructorBuilder_t700974433_il2cpp_TypeInfo_var)))
		{
			goto IL_0038;
		}
	}
	{
		V_1 = ((ConstructorBuilder_t700974433 *)CastclassSealed(__this, ConstructorBuilder_t700974433_il2cpp_TypeInfo_var));
		ConstructorBuilder_t700974433 * L_5 = V_1;
		Il2CppObject * L_6 = ___obj0;
		int32_t L_7 = ___table1;
		bool L_8 = ___inc2;
		NullCheck(L_5);
		int32_t L_9 = ConstructorBuilder_get_next_table_index_m932085784(L_5, L_6, L_7, L_8, /*hidden argument*/NULL);
		return L_9;
	}

IL_0038:
	{
		Exception_t1927440687 * L_10 = (Exception_t1927440687 *)il2cpp_codegen_object_new(Exception_t1927440687_il2cpp_TypeInfo_var);
		Exception__ctor_m485833136(L_10, _stringLiteral4028768107, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_10);
	}
}
// System.Type[] System.Reflection.MethodBase::GetGenericArguments()
extern Il2CppClass* NotSupportedException_t1793819818_il2cpp_TypeInfo_var;
extern const uint32_t MethodBase_GetGenericArguments_m1277035033_MetadataUsageId;
extern "C"  TypeU5BU5D_t1664964607* MethodBase_GetGenericArguments_m1277035033 (MethodBase_t904190842 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MethodBase_GetGenericArguments_m1277035033_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		NotSupportedException_t1793819818 * L_0 = (NotSupportedException_t1793819818 *)il2cpp_codegen_object_new(NotSupportedException_t1793819818_il2cpp_TypeInfo_var);
		NotSupportedException__ctor_m3232764727(L_0, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Boolean System.Reflection.MethodBase::get_ContainsGenericParameters()
extern "C"  bool MethodBase_get_ContainsGenericParameters_m1185248753 (MethodBase_t904190842 * __this, const MethodInfo* method)
{
	{
		return (bool)0;
	}
}
// System.Boolean System.Reflection.MethodBase::get_IsGenericMethodDefinition()
extern "C"  bool MethodBase_get_IsGenericMethodDefinition_m324279468 (MethodBase_t904190842 * __this, const MethodInfo* method)
{
	{
		return (bool)0;
	}
}
// System.Boolean System.Reflection.MethodBase::get_IsGenericMethod()
extern "C"  bool MethodBase_get_IsGenericMethod_m2492617497 (MethodBase_t904190842 * __this, const MethodInfo* method)
{
	{
		return (bool)0;
	}
}
// System.Void System.Reflection.MethodInfo::.ctor()
extern "C"  void MethodInfo__ctor_m1853540423 (MethodInfo_t * __this, const MethodInfo* method)
{
	{
		MethodBase__ctor_m3951051358(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Reflection.MemberTypes System.Reflection.MethodInfo::get_MemberType()
extern "C"  int32_t MethodInfo_get_MemberType_m103695984 (MethodInfo_t * __this, const MethodInfo* method)
{
	{
		return (int32_t)(8);
	}
}
// System.Type System.Reflection.MethodInfo::get_ReturnType()
extern "C"  Type_t * MethodInfo_get_ReturnType_m1038770764 (MethodInfo_t * __this, const MethodInfo* method)
{
	{
		return (Type_t *)NULL;
	}
}
// System.Reflection.MethodInfo System.Reflection.MethodInfo::MakeGenericMethod(System.Type[])
extern Il2CppClass* NotSupportedException_t1793819818_il2cpp_TypeInfo_var;
extern const uint32_t MethodInfo_MakeGenericMethod_m3327556920_MetadataUsageId;
extern "C"  MethodInfo_t * MethodInfo_MakeGenericMethod_m3327556920 (MethodInfo_t * __this, TypeU5BU5D_t1664964607* ___typeArguments0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MethodInfo_MakeGenericMethod_m3327556920_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Type_t * L_0 = Object_GetType_m191970594(__this, /*hidden argument*/NULL);
		NullCheck(L_0);
		String_t* L_1 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Type::ToString() */, L_0);
		NotSupportedException_t1793819818 * L_2 = (NotSupportedException_t1793819818 *)il2cpp_codegen_object_new(NotSupportedException_t1793819818_il2cpp_TypeInfo_var);
		NotSupportedException__ctor_m836173213(L_2, L_1, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_2);
	}
}
// System.Type[] System.Reflection.MethodInfo::GetGenericArguments()
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern const uint32_t MethodInfo_GetGenericArguments_m3393347888_MetadataUsageId;
extern "C"  TypeU5BU5D_t1664964607* MethodInfo_GetGenericArguments_m3393347888 (MethodInfo_t * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MethodInfo_GetGenericArguments_m3393347888_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		TypeU5BU5D_t1664964607* L_0 = ((Type_t_StaticFields*)Type_t_il2cpp_TypeInfo_var->static_fields)->get_EmptyTypes_3();
		return L_0;
	}
}
// System.Boolean System.Reflection.MethodInfo::get_IsGenericMethod()
extern "C"  bool MethodInfo_get_IsGenericMethod_m861531298 (MethodInfo_t * __this, const MethodInfo* method)
{
	{
		return (bool)0;
	}
}
// System.Boolean System.Reflection.MethodInfo::get_IsGenericMethodDefinition()
extern "C"  bool MethodInfo_get_IsGenericMethodDefinition_m647461435 (MethodInfo_t * __this, const MethodInfo* method)
{
	{
		return (bool)0;
	}
}
// System.Boolean System.Reflection.MethodInfo::get_ContainsGenericParameters()
extern "C"  bool MethodInfo_get_ContainsGenericParameters_m572340060 (MethodInfo_t * __this, const MethodInfo* method)
{
	{
		return (bool)0;
	}
}
// System.Void System.Reflection.Missing::.ctor()
extern "C"  void Missing__ctor_m4227264620 (Missing_t1033855606 * __this, const MethodInfo* method)
{
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Reflection.Missing::.cctor()
extern Il2CppClass* Missing_t1033855606_il2cpp_TypeInfo_var;
extern const uint32_t Missing__cctor_m1775889133_MetadataUsageId;
extern "C"  void Missing__cctor_m1775889133 (Il2CppObject * __this /* static, unused */, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Missing__cctor_m1775889133_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Missing_t1033855606 * L_0 = (Missing_t1033855606 *)il2cpp_codegen_object_new(Missing_t1033855606_il2cpp_TypeInfo_var);
		Missing__ctor_m4227264620(L_0, /*hidden argument*/NULL);
		((Missing_t1033855606_StaticFields*)Missing_t1033855606_il2cpp_TypeInfo_var->static_fields)->set_Value_0(L_0);
		return;
	}
}
// System.Void System.Reflection.Missing::System.Runtime.Serialization.ISerializable.GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern "C"  void Missing_System_Runtime_Serialization_ISerializable_GetObjectData_m3092937593 (Missing_t1033855606 * __this, SerializationInfo_t228987430 * ___info0, StreamingContext_t1417235061  ___context1, const MethodInfo* method)
{
	{
		return;
	}
}
// System.Void System.Reflection.Module::.ctor()
extern "C"  void Module__ctor_m3853650010 (Module_t4282841206 * __this, const MethodInfo* method)
{
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Reflection.Module::.cctor()
extern Il2CppClass* TypeFilter_t2905709404_il2cpp_TypeInfo_var;
extern Il2CppClass* Module_t4282841206_il2cpp_TypeInfo_var;
extern const MethodInfo* Module_filter_by_type_name_m2283758100_MethodInfo_var;
extern const MethodInfo* Module_filter_by_type_name_ignore_case_m3574895736_MethodInfo_var;
extern const uint32_t Module__cctor_m2698817211_MetadataUsageId;
extern "C"  void Module__cctor_m2698817211 (Il2CppObject * __this /* static, unused */, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Module__cctor_m2698817211_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		IntPtr_t L_0;
		L_0.set_m_value_0((void*)(void*)Module_filter_by_type_name_m2283758100_MethodInfo_var);
		TypeFilter_t2905709404 * L_1 = (TypeFilter_t2905709404 *)il2cpp_codegen_object_new(TypeFilter_t2905709404_il2cpp_TypeInfo_var);
		TypeFilter__ctor_m1798016172(L_1, NULL, L_0, /*hidden argument*/NULL);
		((Module_t4282841206_StaticFields*)Module_t4282841206_il2cpp_TypeInfo_var->static_fields)->set_FilterTypeName_1(L_1);
		IntPtr_t L_2;
		L_2.set_m_value_0((void*)(void*)Module_filter_by_type_name_ignore_case_m3574895736_MethodInfo_var);
		TypeFilter_t2905709404 * L_3 = (TypeFilter_t2905709404 *)il2cpp_codegen_object_new(TypeFilter_t2905709404_il2cpp_TypeInfo_var);
		TypeFilter__ctor_m1798016172(L_3, NULL, L_2, /*hidden argument*/NULL);
		((Module_t4282841206_StaticFields*)Module_t4282841206_il2cpp_TypeInfo_var->static_fields)->set_FilterTypeNameIgnoreCase_2(L_3);
		return;
	}
}
// System.Reflection.Assembly System.Reflection.Module::get_Assembly()
extern "C"  Assembly_t4268412390 * Module_get_Assembly_m3690289982 (Module_t4282841206 * __this, const MethodInfo* method)
{
	{
		Assembly_t4268412390 * L_0 = __this->get_assembly_4();
		return L_0;
	}
}
// System.String System.Reflection.Module::get_ScopeName()
extern "C"  String_t* Module_get_ScopeName_m207704721 (Module_t4282841206 * __this, const MethodInfo* method)
{
	{
		String_t* L_0 = __this->get_scopename_7();
		return L_0;
	}
}
// System.Object[] System.Reflection.Module::GetCustomAttributes(System.Type,System.Boolean)
extern Il2CppClass* MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var;
extern const uint32_t Module_GetCustomAttributes_m3581287913_MetadataUsageId;
extern "C"  ObjectU5BU5D_t3614634134* Module_GetCustomAttributes_m3581287913 (Module_t4282841206 * __this, Type_t * ___attributeType0, bool ___inherit1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Module_GetCustomAttributes_m3581287913_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Type_t * L_0 = ___attributeType0;
		bool L_1 = ___inherit1;
		IL2CPP_RUNTIME_CLASS_INIT(MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var);
		ObjectU5BU5D_t3614634134* L_2 = MonoCustomAttrs_GetCustomAttributes_m939426263(NULL /*static, unused*/, __this, L_0, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.Void System.Reflection.Module::GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern Il2CppClass* ArgumentNullException_t628810857_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral2792112382;
extern const uint32_t Module_GetObjectData_m3106234990_MetadataUsageId;
extern "C"  void Module_GetObjectData_m3106234990 (Module_t4282841206 * __this, SerializationInfo_t228987430 * ___info0, StreamingContext_t1417235061  ___context1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Module_GetObjectData_m3106234990_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		SerializationInfo_t228987430 * L_0 = ___info0;
		if (L_0)
		{
			goto IL_0011;
		}
	}
	{
		ArgumentNullException_t628810857 * L_1 = (ArgumentNullException_t628810857 *)il2cpp_codegen_object_new(ArgumentNullException_t628810857_il2cpp_TypeInfo_var);
		ArgumentNullException__ctor_m3380712306(L_1, _stringLiteral2792112382, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_1);
	}

IL_0011:
	{
		SerializationInfo_t228987430 * L_2 = ___info0;
		StreamingContext_t1417235061  L_3 = ___context1;
		UnitySerializationHolder_GetModuleData_m2945403213(NULL /*static, unused*/, __this, L_2, L_3, /*hidden argument*/NULL);
		return;
	}
}
// System.Type[] System.Reflection.Module::InternalGetTypes()
extern "C"  TypeU5BU5D_t1664964607* Module_InternalGetTypes_m4286760634 (Module_t4282841206 * __this, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef TypeU5BU5D_t1664964607* (*Module_InternalGetTypes_m4286760634_ftn) (Module_t4282841206 *);
	return  ((Module_InternalGetTypes_m4286760634_ftn)mscorlib::System::Reflection::Module::InternalGetTypes) (__this);
}
// System.Type[] System.Reflection.Module::GetTypes()
extern "C"  TypeU5BU5D_t1664964607* Module_GetTypes_m736359871 (Module_t4282841206 * __this, const MethodInfo* method)
{
	{
		TypeU5BU5D_t1664964607* L_0 = Module_InternalGetTypes_m4286760634(__this, /*hidden argument*/NULL);
		return L_0;
	}
}
// System.Boolean System.Reflection.Module::IsDefined(System.Type,System.Boolean)
extern Il2CppClass* MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var;
extern const uint32_t Module_IsDefined_m3561426235_MetadataUsageId;
extern "C"  bool Module_IsDefined_m3561426235 (Module_t4282841206 * __this, Type_t * ___attributeType0, bool ___inherit1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Module_IsDefined_m3561426235_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Type_t * L_0 = ___attributeType0;
		bool L_1 = ___inherit1;
		IL2CPP_RUNTIME_CLASS_INIT(MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var);
		bool L_2 = MonoCustomAttrs_IsDefined_m3820363041(NULL /*static, unused*/, __this, L_0, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.Boolean System.Reflection.Module::IsResource()
extern "C"  bool Module_IsResource_m663979284 (Module_t4282841206 * __this, const MethodInfo* method)
{
	{
		bool L_0 = __this->get_is_resource_8();
		return L_0;
	}
}
// System.String System.Reflection.Module::ToString()
extern "C"  String_t* Module_ToString_m2343839315 (Module_t4282841206 * __this, const MethodInfo* method)
{
	{
		String_t* L_0 = __this->get_name_6();
		return L_0;
	}
}
// System.Boolean System.Reflection.Module::filter_by_type_name(System.Type,System.Object)
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral372029320;
extern const uint32_t Module_filter_by_type_name_m2283758100_MetadataUsageId;
extern "C"  bool Module_filter_by_type_name_m2283758100 (Il2CppObject * __this /* static, unused */, Type_t * ___m0, Il2CppObject * ___filterCriteria1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Module_filter_by_type_name_m2283758100_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	String_t* V_0 = NULL;
	{
		Il2CppObject * L_0 = ___filterCriteria1;
		V_0 = ((String_t*)CastclassSealed(L_0, String_t_il2cpp_TypeInfo_var));
		String_t* L_1 = V_0;
		NullCheck(L_1);
		bool L_2 = String_EndsWith_m568509976(L_1, _stringLiteral372029320, /*hidden argument*/NULL);
		if (!L_2)
		{
			goto IL_0032;
		}
	}
	{
		Type_t * L_3 = ___m0;
		NullCheck(L_3);
		String_t* L_4 = VirtFuncInvoker0< String_t* >::Invoke(8 /* System.String System.Reflection.MemberInfo::get_Name() */, L_3);
		String_t* L_5 = V_0;
		String_t* L_6 = V_0;
		NullCheck(L_6);
		int32_t L_7 = String_get_Length_m1606060069(L_6, /*hidden argument*/NULL);
		NullCheck(L_5);
		String_t* L_8 = String_Substring_m12482732(L_5, 0, ((int32_t)((int32_t)L_7-(int32_t)1)), /*hidden argument*/NULL);
		NullCheck(L_4);
		bool L_9 = String_StartsWith_m1841920685(L_4, L_8, /*hidden argument*/NULL);
		return L_9;
	}

IL_0032:
	{
		Type_t * L_10 = ___m0;
		NullCheck(L_10);
		String_t* L_11 = VirtFuncInvoker0< String_t* >::Invoke(8 /* System.String System.Reflection.MemberInfo::get_Name() */, L_10);
		String_t* L_12 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_13 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_11, L_12, /*hidden argument*/NULL);
		return L_13;
	}
}
// System.Boolean System.Reflection.Module::filter_by_type_name_ignore_case(System.Type,System.Object)
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral372029320;
extern const uint32_t Module_filter_by_type_name_ignore_case_m3574895736_MetadataUsageId;
extern "C"  bool Module_filter_by_type_name_ignore_case_m3574895736 (Il2CppObject * __this /* static, unused */, Type_t * ___m0, Il2CppObject * ___filterCriteria1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Module_filter_by_type_name_ignore_case_m3574895736_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	String_t* V_0 = NULL;
	{
		Il2CppObject * L_0 = ___filterCriteria1;
		V_0 = ((String_t*)CastclassSealed(L_0, String_t_il2cpp_TypeInfo_var));
		String_t* L_1 = V_0;
		NullCheck(L_1);
		bool L_2 = String_EndsWith_m568509976(L_1, _stringLiteral372029320, /*hidden argument*/NULL);
		if (!L_2)
		{
			goto IL_003c;
		}
	}
	{
		Type_t * L_3 = ___m0;
		NullCheck(L_3);
		String_t* L_4 = VirtFuncInvoker0< String_t* >::Invoke(8 /* System.String System.Reflection.MemberInfo::get_Name() */, L_3);
		NullCheck(L_4);
		String_t* L_5 = String_ToLower_m2994460523(L_4, /*hidden argument*/NULL);
		String_t* L_6 = V_0;
		String_t* L_7 = V_0;
		NullCheck(L_7);
		int32_t L_8 = String_get_Length_m1606060069(L_7, /*hidden argument*/NULL);
		NullCheck(L_6);
		String_t* L_9 = String_Substring_m12482732(L_6, 0, ((int32_t)((int32_t)L_8-(int32_t)1)), /*hidden argument*/NULL);
		NullCheck(L_9);
		String_t* L_10 = String_ToLower_m2994460523(L_9, /*hidden argument*/NULL);
		NullCheck(L_5);
		bool L_11 = String_StartsWith_m1841920685(L_5, L_10, /*hidden argument*/NULL);
		return L_11;
	}

IL_003c:
	{
		Type_t * L_12 = ___m0;
		NullCheck(L_12);
		String_t* L_13 = VirtFuncInvoker0< String_t* >::Invoke(8 /* System.String System.Reflection.MemberInfo::get_Name() */, L_12);
		String_t* L_14 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		int32_t L_15 = String_Compare_m2851607672(NULL /*static, unused*/, L_13, L_14, (bool)1, /*hidden argument*/NULL);
		return (bool)((((int32_t)L_15) == ((int32_t)0))? 1 : 0);
	}
}
// System.Void System.Reflection.MonoCMethod::.ctor()
extern Il2CppClass* ConstructorInfo_t2851816542_il2cpp_TypeInfo_var;
extern const uint32_t MonoCMethod__ctor_m2473049889_MetadataUsageId;
extern "C"  void MonoCMethod__ctor_m2473049889 (MonoCMethod_t611352247 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MonoCMethod__ctor_m2473049889_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(ConstructorInfo_t2851816542_il2cpp_TypeInfo_var);
		ConstructorInfo__ctor_m3847352284(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Reflection.ParameterInfo[] System.Reflection.MonoCMethod::GetParameters()
extern "C"  ParameterInfoU5BU5D_t2275869610* MonoCMethod_GetParameters_m2658773133 (MonoCMethod_t611352247 * __this, const MethodInfo* method)
{
	{
		IntPtr_t L_0 = __this->get_mhandle_2();
		ParameterInfoU5BU5D_t2275869610* L_1 = MonoMethodInfo_GetParametersInfo_m3456861922(NULL /*static, unused*/, L_0, __this, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Object System.Reflection.MonoCMethod::InternalInvoke(System.Object,System.Object[],System.Exception&)
extern "C"  Il2CppObject * MonoCMethod_InternalInvoke_m2816771359 (MonoCMethod_t611352247 * __this, Il2CppObject * ___obj0, ObjectU5BU5D_t3614634134* ___parameters1, Exception_t1927440687 ** ___exc2, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef Il2CppObject * (*MonoCMethod_InternalInvoke_m2816771359_ftn) (MonoCMethod_t611352247 *, Il2CppObject *, ObjectU5BU5D_t3614634134*, Exception_t1927440687 **);
	return  ((MonoCMethod_InternalInvoke_m2816771359_ftn)mscorlib::System::Reflection::MonoMethod::InternalInvoke) (__this, ___obj0, ___parameters1, ___exc2);
}
// System.Object System.Reflection.MonoCMethod::Invoke(System.Object,System.Reflection.BindingFlags,System.Reflection.Binder,System.Object[],System.Globalization.CultureInfo)
extern Il2CppClass* Binder_t3404612058_il2cpp_TypeInfo_var;
extern Il2CppClass* TargetParameterCountException_t1554451430_il2cpp_TypeInfo_var;
extern Il2CppClass* ArgumentException_t3259014390_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* MemberAccessException_t2005094827_il2cpp_TypeInfo_var;
extern Il2CppClass* MethodAccessException_t4093255254_il2cpp_TypeInfo_var;
extern Il2CppClass* Exception_t1927440687_il2cpp_TypeInfo_var;
extern Il2CppClass* TargetInvocationException_t4098620458_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral3569083427;
extern Il2CppCodeGenString* _stringLiteral404785397;
extern Il2CppCodeGenString* _stringLiteral2903444890;
extern Il2CppCodeGenString* _stringLiteral1065211720;
extern Il2CppCodeGenString* _stringLiteral1582284496;
extern const uint32_t MonoCMethod_Invoke_m264177196_MetadataUsageId;
extern "C"  Il2CppObject * MonoCMethod_Invoke_m264177196 (MonoCMethod_t611352247 * __this, Il2CppObject * ___obj0, int32_t ___invokeAttr1, Binder_t3404612058 * ___binder2, ObjectU5BU5D_t3614634134* ___parameters3, CultureInfo_t3500843524 * ___culture4, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MonoCMethod_Invoke_m264177196_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ParameterInfoU5BU5D_t2275869610* V_0 = NULL;
	int32_t V_1 = 0;
	Exception_t1927440687 * V_2 = NULL;
	Il2CppObject * V_3 = NULL;
	Exception_t1927440687 * V_4 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	Il2CppObject * G_B33_0 = NULL;
	{
		Binder_t3404612058 * L_0 = ___binder2;
		if (L_0)
		{
			goto IL_000d;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(Binder_t3404612058_il2cpp_TypeInfo_var);
		Binder_t3404612058 * L_1 = Binder_get_DefaultBinder_m965620943(NULL /*static, unused*/, /*hidden argument*/NULL);
		___binder2 = L_1;
	}

IL_000d:
	{
		ParameterInfoU5BU5D_t2275869610* L_2 = VirtFuncInvoker0< ParameterInfoU5BU5D_t2275869610* >::Invoke(14 /* System.Reflection.ParameterInfo[] System.Reflection.MonoCMethod::GetParameters() */, __this);
		V_0 = L_2;
		ObjectU5BU5D_t3614634134* L_3 = ___parameters3;
		if (L_3)
		{
			goto IL_0023;
		}
	}
	{
		ParameterInfoU5BU5D_t2275869610* L_4 = V_0;
		NullCheck(L_4);
		if ((((int32_t)((int32_t)(((Il2CppArray *)L_4)->max_length)))))
		{
			goto IL_0036;
		}
	}

IL_0023:
	{
		ObjectU5BU5D_t3614634134* L_5 = ___parameters3;
		if (!L_5)
		{
			goto IL_0041;
		}
	}
	{
		ObjectU5BU5D_t3614634134* L_6 = ___parameters3;
		NullCheck(L_6);
		ParameterInfoU5BU5D_t2275869610* L_7 = V_0;
		NullCheck(L_7);
		if ((((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_6)->max_length))))) == ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_7)->max_length)))))))
		{
			goto IL_0041;
		}
	}

IL_0036:
	{
		TargetParameterCountException_t1554451430 * L_8 = (TargetParameterCountException_t1554451430 *)il2cpp_codegen_object_new(TargetParameterCountException_t1554451430_il2cpp_TypeInfo_var);
		TargetParameterCountException__ctor_m2760108938(L_8, _stringLiteral3569083427, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_8);
	}

IL_0041:
	{
		int32_t L_9 = ___invokeAttr1;
		if (((int32_t)((int32_t)L_9&(int32_t)((int32_t)65536))))
		{
			goto IL_006d;
		}
	}
	{
		Binder_t3404612058 * L_10 = ___binder2;
		ObjectU5BU5D_t3614634134* L_11 = ___parameters3;
		ParameterInfoU5BU5D_t2275869610* L_12 = V_0;
		CultureInfo_t3500843524 * L_13 = ___culture4;
		IL2CPP_RUNTIME_CLASS_INIT(Binder_t3404612058_il2cpp_TypeInfo_var);
		bool L_14 = Binder_ConvertArgs_m2999223281(NULL /*static, unused*/, L_10, L_11, L_12, L_13, /*hidden argument*/NULL);
		if (L_14)
		{
			goto IL_0068;
		}
	}
	{
		ArgumentException_t3259014390 * L_15 = (ArgumentException_t3259014390 *)il2cpp_codegen_object_new(ArgumentException_t3259014390_il2cpp_TypeInfo_var);
		ArgumentException__ctor_m3739475201(L_15, _stringLiteral404785397, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_15);
	}

IL_0068:
	{
		goto IL_00a2;
	}

IL_006d:
	{
		V_1 = 0;
		goto IL_0099;
	}

IL_0074:
	{
		ObjectU5BU5D_t3614634134* L_16 = ___parameters3;
		int32_t L_17 = V_1;
		NullCheck(L_16);
		int32_t L_18 = L_17;
		Il2CppObject * L_19 = (L_16)->GetAt(static_cast<il2cpp_array_size_t>(L_18));
		NullCheck(L_19);
		Type_t * L_20 = Object_GetType_m191970594(L_19, /*hidden argument*/NULL);
		ParameterInfoU5BU5D_t2275869610* L_21 = V_0;
		int32_t L_22 = V_1;
		NullCheck(L_21);
		int32_t L_23 = L_22;
		ParameterInfo_t2249040075 * L_24 = (L_21)->GetAt(static_cast<il2cpp_array_size_t>(L_23));
		NullCheck(L_24);
		Type_t * L_25 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.ParameterInfo::get_ParameterType() */, L_24);
		if ((((Il2CppObject*)(Type_t *)L_20) == ((Il2CppObject*)(Type_t *)L_25)))
		{
			goto IL_0095;
		}
	}
	{
		ArgumentException_t3259014390 * L_26 = (ArgumentException_t3259014390 *)il2cpp_codegen_object_new(ArgumentException_t3259014390_il2cpp_TypeInfo_var);
		ArgumentException__ctor_m3739475201(L_26, _stringLiteral3569083427, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_26);
	}

IL_0095:
	{
		int32_t L_27 = V_1;
		V_1 = ((int32_t)((int32_t)L_27+(int32_t)1));
	}

IL_0099:
	{
		int32_t L_28 = V_1;
		ParameterInfoU5BU5D_t2275869610* L_29 = V_0;
		NullCheck(L_29);
		if ((((int32_t)L_28) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_29)->max_length)))))))
		{
			goto IL_0074;
		}
	}

IL_00a2:
	{
		Il2CppObject * L_30 = ___obj0;
		if (L_30)
		{
			goto IL_00d3;
		}
	}
	{
		Type_t * L_31 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.MonoCMethod::get_DeclaringType() */, __this);
		NullCheck(L_31);
		bool L_32 = VirtFuncInvoker0< bool >::Invoke(76 /* System.Boolean System.Type::get_ContainsGenericParameters() */, L_31);
		if (!L_32)
		{
			goto IL_00d3;
		}
	}
	{
		Type_t * L_33 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.MonoCMethod::get_DeclaringType() */, __this);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_34 = String_Concat_m2000667605(NULL /*static, unused*/, _stringLiteral2903444890, L_33, _stringLiteral1065211720, /*hidden argument*/NULL);
		MemberAccessException_t2005094827 * L_35 = (MemberAccessException_t2005094827 *)il2cpp_codegen_object_new(MemberAccessException_t2005094827_il2cpp_TypeInfo_var);
		MemberAccessException__ctor_m111743236(L_35, L_34, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_35);
	}

IL_00d3:
	{
		int32_t L_36 = ___invokeAttr1;
		if (!((int32_t)((int32_t)L_36&(int32_t)((int32_t)512))))
		{
			goto IL_0105;
		}
	}
	{
		Type_t * L_37 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.MonoCMethod::get_DeclaringType() */, __this);
		NullCheck(L_37);
		bool L_38 = Type_get_IsAbstract_m2532060002(L_37, /*hidden argument*/NULL);
		if (!L_38)
		{
			goto IL_0105;
		}
	}
	{
		Type_t * L_39 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.MonoCMethod::get_DeclaringType() */, __this);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_40 = String_Format_m2024975688(NULL /*static, unused*/, _stringLiteral1582284496, L_39, /*hidden argument*/NULL);
		MemberAccessException_t2005094827 * L_41 = (MemberAccessException_t2005094827 *)il2cpp_codegen_object_new(MemberAccessException_t2005094827_il2cpp_TypeInfo_var);
		MemberAccessException__ctor_m111743236(L_41, L_40, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_41);
	}

IL_0105:
	{
		V_2 = (Exception_t1927440687 *)NULL;
		V_3 = NULL;
	}

IL_0109:
	try
	{ // begin try (depth: 1)
		Il2CppObject * L_42 = ___obj0;
		ObjectU5BU5D_t3614634134* L_43 = ___parameters3;
		Il2CppObject * L_44 = MonoCMethod_InternalInvoke_m2816771359(__this, L_42, L_43, (&V_2), /*hidden argument*/NULL);
		V_3 = L_44;
		goto IL_0131;
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__exception_local = (Exception_t1927440687 *)e.ex;
		if(il2cpp_codegen_class_is_assignable_from (MethodAccessException_t4093255254_il2cpp_TypeInfo_var, e.ex->object.klass))
			goto CATCH_011a;
		if(il2cpp_codegen_class_is_assignable_from (Exception_t1927440687_il2cpp_TypeInfo_var, e.ex->object.klass))
			goto CATCH_0122;
		throw e;
	}

CATCH_011a:
	{ // begin catch(System.MethodAccessException)
		{
			IL2CPP_RAISE_MANAGED_EXCEPTION(__exception_local);
		}

IL_011d:
		{
			goto IL_0131;
		}
	} // end catch (depth: 1)

CATCH_0122:
	{ // begin catch(System.Exception)
		{
			V_4 = ((Exception_t1927440687 *)__exception_local);
			Exception_t1927440687 * L_45 = V_4;
			TargetInvocationException_t4098620458 * L_46 = (TargetInvocationException_t4098620458 *)il2cpp_codegen_object_new(TargetInvocationException_t4098620458_il2cpp_TypeInfo_var);
			TargetInvocationException__ctor_m1059845570(L_46, L_45, /*hidden argument*/NULL);
			IL2CPP_RAISE_MANAGED_EXCEPTION(L_46);
		}

IL_012c:
		{
			goto IL_0131;
		}
	} // end catch (depth: 1)

IL_0131:
	{
		Exception_t1927440687 * L_47 = V_2;
		if (!L_47)
		{
			goto IL_0139;
		}
	}
	{
		Exception_t1927440687 * L_48 = V_2;
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_48);
	}

IL_0139:
	{
		Il2CppObject * L_49 = ___obj0;
		if (L_49)
		{
			goto IL_0145;
		}
	}
	{
		Il2CppObject * L_50 = V_3;
		G_B33_0 = L_50;
		goto IL_0146;
	}

IL_0145:
	{
		G_B33_0 = NULL;
	}

IL_0146:
	{
		return G_B33_0;
	}
}
// System.Object System.Reflection.MonoCMethod::Invoke(System.Reflection.BindingFlags,System.Reflection.Binder,System.Object[],System.Globalization.CultureInfo)
extern "C"  Il2CppObject * MonoCMethod_Invoke_m931478014 (MonoCMethod_t611352247 * __this, int32_t ___invokeAttr0, Binder_t3404612058 * ___binder1, ObjectU5BU5D_t3614634134* ___parameters2, CultureInfo_t3500843524 * ___culture3, const MethodInfo* method)
{
	{
		int32_t L_0 = ___invokeAttr0;
		Binder_t3404612058 * L_1 = ___binder1;
		ObjectU5BU5D_t3614634134* L_2 = ___parameters2;
		CultureInfo_t3500843524 * L_3 = ___culture3;
		Il2CppObject * L_4 = VirtFuncInvoker5< Il2CppObject *, Il2CppObject *, int32_t, Binder_t3404612058 *, ObjectU5BU5D_t3614634134*, CultureInfo_t3500843524 * >::Invoke(17 /* System.Object System.Reflection.MonoCMethod::Invoke(System.Object,System.Reflection.BindingFlags,System.Reflection.Binder,System.Object[],System.Globalization.CultureInfo) */, __this, NULL, L_0, L_1, L_2, L_3);
		return L_4;
	}
}
// System.RuntimeMethodHandle System.Reflection.MonoCMethod::get_MethodHandle()
extern "C"  RuntimeMethodHandle_t894824333  MonoCMethod_get_MethodHandle_m3394506066 (MonoCMethod_t611352247 * __this, const MethodInfo* method)
{
	{
		IntPtr_t L_0 = __this->get_mhandle_2();
		RuntimeMethodHandle_t894824333  L_1;
		memset(&L_1, 0, sizeof(L_1));
		RuntimeMethodHandle__ctor_m1162528746(&L_1, L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Reflection.MethodAttributes System.Reflection.MonoCMethod::get_Attributes()
extern "C"  int32_t MonoCMethod_get_Attributes_m3914742834 (MonoCMethod_t611352247 * __this, const MethodInfo* method)
{
	{
		IntPtr_t L_0 = __this->get_mhandle_2();
		int32_t L_1 = MonoMethodInfo_GetAttributes_m2535493430(NULL /*static, unused*/, L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Reflection.CallingConventions System.Reflection.MonoCMethod::get_CallingConvention()
extern "C"  int32_t MonoCMethod_get_CallingConvention_m3356441108 (MonoCMethod_t611352247 * __this, const MethodInfo* method)
{
	{
		IntPtr_t L_0 = __this->get_mhandle_2();
		int32_t L_1 = MonoMethodInfo_GetCallingConvention_m3095860872(NULL /*static, unused*/, L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Type System.Reflection.MonoCMethod::get_ReflectedType()
extern "C"  Type_t * MonoCMethod_get_ReflectedType_m3611546138 (MonoCMethod_t611352247 * __this, const MethodInfo* method)
{
	{
		Type_t * L_0 = __this->get_reftype_4();
		return L_0;
	}
}
// System.Type System.Reflection.MonoCMethod::get_DeclaringType()
extern "C"  Type_t * MonoCMethod_get_DeclaringType_m4147430117 (MonoCMethod_t611352247 * __this, const MethodInfo* method)
{
	{
		IntPtr_t L_0 = __this->get_mhandle_2();
		Type_t * L_1 = MonoMethodInfo_GetDeclaringType_m4186531677(NULL /*static, unused*/, L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.String System.Reflection.MonoCMethod::get_Name()
extern "C"  String_t* MonoCMethod_get_Name_m764669486 (MonoCMethod_t611352247 * __this, const MethodInfo* method)
{
	{
		String_t* L_0 = __this->get_name_3();
		if (!L_0)
		{
			goto IL_0012;
		}
	}
	{
		String_t* L_1 = __this->get_name_3();
		return L_1;
	}

IL_0012:
	{
		String_t* L_2 = MonoMethod_get_name_m1503581873(NULL /*static, unused*/, __this, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.Boolean System.Reflection.MonoCMethod::IsDefined(System.Type,System.Boolean)
extern Il2CppClass* MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var;
extern const uint32_t MonoCMethod_IsDefined_m3686883242_MetadataUsageId;
extern "C"  bool MonoCMethod_IsDefined_m3686883242 (MonoCMethod_t611352247 * __this, Type_t * ___attributeType0, bool ___inherit1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MonoCMethod_IsDefined_m3686883242_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Type_t * L_0 = ___attributeType0;
		bool L_1 = ___inherit1;
		IL2CPP_RUNTIME_CLASS_INIT(MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var);
		bool L_2 = MonoCustomAttrs_IsDefined_m3820363041(NULL /*static, unused*/, __this, L_0, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.Object[] System.Reflection.MonoCMethod::GetCustomAttributes(System.Boolean)
extern Il2CppClass* MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var;
extern const uint32_t MonoCMethod_GetCustomAttributes_m2886701175_MetadataUsageId;
extern "C"  ObjectU5BU5D_t3614634134* MonoCMethod_GetCustomAttributes_m2886701175 (MonoCMethod_t611352247 * __this, bool ___inherit0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MonoCMethod_GetCustomAttributes_m2886701175_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		bool L_0 = ___inherit0;
		IL2CPP_RUNTIME_CLASS_INIT(MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var);
		ObjectU5BU5D_t3614634134* L_1 = MonoCustomAttrs_GetCustomAttributes_m3069779582(NULL /*static, unused*/, __this, L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Object[] System.Reflection.MonoCMethod::GetCustomAttributes(System.Type,System.Boolean)
extern Il2CppClass* MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var;
extern const uint32_t MonoCMethod_GetCustomAttributes_m1110360782_MetadataUsageId;
extern "C"  ObjectU5BU5D_t3614634134* MonoCMethod_GetCustomAttributes_m1110360782 (MonoCMethod_t611352247 * __this, Type_t * ___attributeType0, bool ___inherit1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MonoCMethod_GetCustomAttributes_m1110360782_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Type_t * L_0 = ___attributeType0;
		bool L_1 = ___inherit1;
		IL2CPP_RUNTIME_CLASS_INIT(MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var);
		ObjectU5BU5D_t3614634134* L_2 = MonoCustomAttrs_GetCustomAttributes_m939426263(NULL /*static, unused*/, __this, L_0, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.String System.Reflection.MonoCMethod::ToString()
extern Il2CppClass* StringBuilder_t1221177846_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral35761088;
extern Il2CppCodeGenString* _stringLiteral372029318;
extern Il2CppCodeGenString* _stringLiteral811305474;
extern Il2CppCodeGenString* _stringLiteral3422253728;
extern Il2CppCodeGenString* _stringLiteral372029317;
extern const uint32_t MonoCMethod_ToString_m607787036_MetadataUsageId;
extern "C"  String_t* MonoCMethod_ToString_m607787036 (MonoCMethod_t611352247 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MonoCMethod_ToString_m607787036_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	StringBuilder_t1221177846 * V_0 = NULL;
	ParameterInfoU5BU5D_t2275869610* V_1 = NULL;
	int32_t V_2 = 0;
	{
		StringBuilder_t1221177846 * L_0 = (StringBuilder_t1221177846 *)il2cpp_codegen_object_new(StringBuilder_t1221177846_il2cpp_TypeInfo_var);
		StringBuilder__ctor_m3946851802(L_0, /*hidden argument*/NULL);
		V_0 = L_0;
		StringBuilder_t1221177846 * L_1 = V_0;
		NullCheck(L_1);
		StringBuilder_Append_m3636508479(L_1, _stringLiteral35761088, /*hidden argument*/NULL);
		StringBuilder_t1221177846 * L_2 = V_0;
		String_t* L_3 = VirtFuncInvoker0< String_t* >::Invoke(8 /* System.String System.Reflection.MonoCMethod::get_Name() */, __this);
		NullCheck(L_2);
		StringBuilder_Append_m3636508479(L_2, L_3, /*hidden argument*/NULL);
		StringBuilder_t1221177846 * L_4 = V_0;
		NullCheck(L_4);
		StringBuilder_Append_m3636508479(L_4, _stringLiteral372029318, /*hidden argument*/NULL);
		ParameterInfoU5BU5D_t2275869610* L_5 = VirtFuncInvoker0< ParameterInfoU5BU5D_t2275869610* >::Invoke(14 /* System.Reflection.ParameterInfo[] System.Reflection.MonoCMethod::GetParameters() */, __this);
		V_1 = L_5;
		V_2 = 0;
		goto IL_0064;
	}

IL_0039:
	{
		int32_t L_6 = V_2;
		if ((((int32_t)L_6) <= ((int32_t)0)))
		{
			goto IL_004c;
		}
	}
	{
		StringBuilder_t1221177846 * L_7 = V_0;
		NullCheck(L_7);
		StringBuilder_Append_m3636508479(L_7, _stringLiteral811305474, /*hidden argument*/NULL);
	}

IL_004c:
	{
		StringBuilder_t1221177846 * L_8 = V_0;
		ParameterInfoU5BU5D_t2275869610* L_9 = V_1;
		int32_t L_10 = V_2;
		NullCheck(L_9);
		int32_t L_11 = L_10;
		ParameterInfo_t2249040075 * L_12 = (L_9)->GetAt(static_cast<il2cpp_array_size_t>(L_11));
		NullCheck(L_12);
		Type_t * L_13 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.ParameterInfo::get_ParameterType() */, L_12);
		NullCheck(L_13);
		String_t* L_14 = VirtFuncInvoker0< String_t* >::Invoke(8 /* System.String System.Reflection.MemberInfo::get_Name() */, L_13);
		NullCheck(L_8);
		StringBuilder_Append_m3636508479(L_8, L_14, /*hidden argument*/NULL);
		int32_t L_15 = V_2;
		V_2 = ((int32_t)((int32_t)L_15+(int32_t)1));
	}

IL_0064:
	{
		int32_t L_16 = V_2;
		ParameterInfoU5BU5D_t2275869610* L_17 = V_1;
		NullCheck(L_17);
		if ((((int32_t)L_16) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_17)->max_length)))))))
		{
			goto IL_0039;
		}
	}
	{
		int32_t L_18 = VirtFuncInvoker0< int32_t >::Invoke(20 /* System.Reflection.CallingConventions System.Reflection.MonoCMethod::get_CallingConvention() */, __this);
		if ((!(((uint32_t)L_18) == ((uint32_t)3))))
		{
			goto IL_0085;
		}
	}
	{
		StringBuilder_t1221177846 * L_19 = V_0;
		NullCheck(L_19);
		StringBuilder_Append_m3636508479(L_19, _stringLiteral3422253728, /*hidden argument*/NULL);
	}

IL_0085:
	{
		StringBuilder_t1221177846 * L_20 = V_0;
		NullCheck(L_20);
		StringBuilder_Append_m3636508479(L_20, _stringLiteral372029317, /*hidden argument*/NULL);
		StringBuilder_t1221177846 * L_21 = V_0;
		NullCheck(L_21);
		String_t* L_22 = StringBuilder_ToString_m1507807375(L_21, /*hidden argument*/NULL);
		return L_22;
	}
}
// System.Void System.Reflection.MonoCMethod::GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern "C"  void MonoCMethod_GetObjectData_m2435596845 (MonoCMethod_t611352247 * __this, SerializationInfo_t228987430 * ___info0, StreamingContext_t1417235061  ___context1, const MethodInfo* method)
{
	{
		SerializationInfo_t228987430 * L_0 = ___info0;
		String_t* L_1 = VirtFuncInvoker0< String_t* >::Invoke(8 /* System.String System.Reflection.MonoCMethod::get_Name() */, __this);
		Type_t * L_2 = VirtFuncInvoker0< Type_t * >::Invoke(9 /* System.Type System.Reflection.MonoCMethod::get_ReflectedType() */, __this);
		String_t* L_3 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Reflection.MonoCMethod::ToString() */, __this);
		MemberInfoSerializationHolder_Serialize_m1949812823(NULL /*static, unused*/, L_0, L_1, L_2, L_3, 1, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Reflection.MonoEvent::.ctor()
extern "C"  void MonoEvent__ctor_m1430144453 (MonoEvent_t * __this, const MethodInfo* method)
{
	{
		EventInfo__ctor_m1190141300(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Reflection.EventAttributes System.Reflection.MonoEvent::get_Attributes()
extern "C"  int32_t MonoEvent_get_Attributes_m2985233365 (MonoEvent_t * __this, const MethodInfo* method)
{
	MonoEventInfo_t2190036573  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		MonoEventInfo_t2190036573  L_0 = MonoEventInfo_GetEventInfo_m2331957186(NULL /*static, unused*/, __this, /*hidden argument*/NULL);
		V_0 = L_0;
		int32_t L_1 = (&V_0)->get_attrs_6();
		return L_1;
	}
}
// System.Reflection.MethodInfo System.Reflection.MonoEvent::GetAddMethod(System.Boolean)
extern "C"  MethodInfo_t * MonoEvent_GetAddMethod_m4289563120 (MonoEvent_t * __this, bool ___nonPublic0, const MethodInfo* method)
{
	MonoEventInfo_t2190036573  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		MonoEventInfo_t2190036573  L_0 = MonoEventInfo_GetEventInfo_m2331957186(NULL /*static, unused*/, __this, /*hidden argument*/NULL);
		V_0 = L_0;
		bool L_1 = ___nonPublic0;
		if (L_1)
		{
			goto IL_002a;
		}
	}
	{
		MethodInfo_t * L_2 = (&V_0)->get_add_method_3();
		if (!L_2)
		{
			goto IL_0032;
		}
	}
	{
		MethodInfo_t * L_3 = (&V_0)->get_add_method_3();
		NullCheck(L_3);
		bool L_4 = MethodBase_get_IsPublic_m479656180(L_3, /*hidden argument*/NULL);
		if (!L_4)
		{
			goto IL_0032;
		}
	}

IL_002a:
	{
		MethodInfo_t * L_5 = (&V_0)->get_add_method_3();
		return L_5;
	}

IL_0032:
	{
		return (MethodInfo_t *)NULL;
	}
}
// System.Type System.Reflection.MonoEvent::get_DeclaringType()
extern "C"  Type_t * MonoEvent_get_DeclaringType_m2319125729 (MonoEvent_t * __this, const MethodInfo* method)
{
	MonoEventInfo_t2190036573  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		MonoEventInfo_t2190036573  L_0 = MonoEventInfo_GetEventInfo_m2331957186(NULL /*static, unused*/, __this, /*hidden argument*/NULL);
		V_0 = L_0;
		Type_t * L_1 = (&V_0)->get_declaring_type_0();
		return L_1;
	}
}
// System.Type System.Reflection.MonoEvent::get_ReflectedType()
extern "C"  Type_t * MonoEvent_get_ReflectedType_m434281898 (MonoEvent_t * __this, const MethodInfo* method)
{
	MonoEventInfo_t2190036573  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		MonoEventInfo_t2190036573  L_0 = MonoEventInfo_GetEventInfo_m2331957186(NULL /*static, unused*/, __this, /*hidden argument*/NULL);
		V_0 = L_0;
		Type_t * L_1 = (&V_0)->get_reflected_type_1();
		return L_1;
	}
}
// System.String System.Reflection.MonoEvent::get_Name()
extern "C"  String_t* MonoEvent_get_Name_m2796714646 (MonoEvent_t * __this, const MethodInfo* method)
{
	MonoEventInfo_t2190036573  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		MonoEventInfo_t2190036573  L_0 = MonoEventInfo_GetEventInfo_m2331957186(NULL /*static, unused*/, __this, /*hidden argument*/NULL);
		V_0 = L_0;
		String_t* L_1 = (&V_0)->get_name_2();
		return L_1;
	}
}
// System.String System.Reflection.MonoEvent::ToString()
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral372029310;
extern const uint32_t MonoEvent_ToString_m386956596_MetadataUsageId;
extern "C"  String_t* MonoEvent_ToString_m386956596 (MonoEvent_t * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MonoEvent_ToString_m386956596_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Type_t * L_0 = EventInfo_get_EventHandlerType_m2787680849(__this, /*hidden argument*/NULL);
		String_t* L_1 = MonoEvent_get_Name_m2796714646(__this, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_2 = String_Concat_m2000667605(NULL /*static, unused*/, L_0, _stringLiteral372029310, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.Boolean System.Reflection.MonoEvent::IsDefined(System.Type,System.Boolean)
extern Il2CppClass* MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var;
extern const uint32_t MonoEvent_IsDefined_m3151861274_MetadataUsageId;
extern "C"  bool MonoEvent_IsDefined_m3151861274 (MonoEvent_t * __this, Type_t * ___attributeType0, bool ___inherit1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MonoEvent_IsDefined_m3151861274_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Type_t * L_0 = ___attributeType0;
		bool L_1 = ___inherit1;
		IL2CPP_RUNTIME_CLASS_INIT(MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var);
		bool L_2 = MonoCustomAttrs_IsDefined_m3820363041(NULL /*static, unused*/, __this, L_0, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.Object[] System.Reflection.MonoEvent::GetCustomAttributes(System.Boolean)
extern Il2CppClass* MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var;
extern const uint32_t MonoEvent_GetCustomAttributes_m2349471159_MetadataUsageId;
extern "C"  ObjectU5BU5D_t3614634134* MonoEvent_GetCustomAttributes_m2349471159 (MonoEvent_t * __this, bool ___inherit0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MonoEvent_GetCustomAttributes_m2349471159_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		bool L_0 = ___inherit0;
		IL2CPP_RUNTIME_CLASS_INIT(MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var);
		ObjectU5BU5D_t3614634134* L_1 = MonoCustomAttrs_GetCustomAttributes_m3069779582(NULL /*static, unused*/, __this, L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Object[] System.Reflection.MonoEvent::GetCustomAttributes(System.Type,System.Boolean)
extern Il2CppClass* MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var;
extern const uint32_t MonoEvent_GetCustomAttributes_m3899596098_MetadataUsageId;
extern "C"  ObjectU5BU5D_t3614634134* MonoEvent_GetCustomAttributes_m3899596098 (MonoEvent_t * __this, Type_t * ___attributeType0, bool ___inherit1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MonoEvent_GetCustomAttributes_m3899596098_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Type_t * L_0 = ___attributeType0;
		bool L_1 = ___inherit1;
		IL2CPP_RUNTIME_CLASS_INIT(MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var);
		ObjectU5BU5D_t3614634134* L_2 = MonoCustomAttrs_GetCustomAttributes_m939426263(NULL /*static, unused*/, __this, L_0, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.Void System.Reflection.MonoEvent::GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern "C"  void MonoEvent_GetObjectData_m4084431065 (MonoEvent_t * __this, SerializationInfo_t228987430 * ___info0, StreamingContext_t1417235061  ___context1, const MethodInfo* method)
{
	{
		SerializationInfo_t228987430 * L_0 = ___info0;
		String_t* L_1 = MonoEvent_get_Name_m2796714646(__this, /*hidden argument*/NULL);
		Type_t * L_2 = MonoEvent_get_ReflectedType_m434281898(__this, /*hidden argument*/NULL);
		String_t* L_3 = MonoEvent_ToString_m386956596(__this, /*hidden argument*/NULL);
		MemberInfoSerializationHolder_Serialize_m1949812823(NULL /*static, unused*/, L_0, L_1, L_2, L_3, 2, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Reflection.MonoEventInfo::get_event_info(System.Reflection.MonoEvent,System.Reflection.MonoEventInfo&)
extern "C"  void MonoEventInfo_get_event_info_m781402243 (Il2CppObject * __this /* static, unused */, MonoEvent_t * ___ev0, MonoEventInfo_t2190036573 * ___info1, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef void (*MonoEventInfo_get_event_info_m781402243_ftn) (MonoEvent_t *, MonoEventInfo_t2190036573 *);
	 ((MonoEventInfo_get_event_info_m781402243_ftn)mscorlib::System::Reflection::MonoEventInfo::get_event_info) (___ev0, ___info1);
}
// System.Reflection.MonoEventInfo System.Reflection.MonoEventInfo::GetEventInfo(System.Reflection.MonoEvent)
extern "C"  MonoEventInfo_t2190036573  MonoEventInfo_GetEventInfo_m2331957186 (Il2CppObject * __this /* static, unused */, MonoEvent_t * ___ev0, const MethodInfo* method)
{
	MonoEventInfo_t2190036573  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		MonoEvent_t * L_0 = ___ev0;
		MonoEventInfo_get_event_info_m781402243(NULL /*static, unused*/, L_0, (&V_0), /*hidden argument*/NULL);
		MonoEventInfo_t2190036573  L_1 = V_0;
		return L_1;
	}
}
// Conversion methods for marshalling of: System.Reflection.MonoEventInfo
extern "C" void MonoEventInfo_t2190036573_marshal_pinvoke(const MonoEventInfo_t2190036573& unmarshaled, MonoEventInfo_t2190036573_marshaled_pinvoke& marshaled)
{
	Il2CppCodeGenException* ___declaring_type_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'declaring_type' of type 'MonoEventInfo': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___declaring_type_0Exception);
}
extern "C" void MonoEventInfo_t2190036573_marshal_pinvoke_back(const MonoEventInfo_t2190036573_marshaled_pinvoke& marshaled, MonoEventInfo_t2190036573& unmarshaled)
{
	Il2CppCodeGenException* ___declaring_type_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'declaring_type' of type 'MonoEventInfo': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___declaring_type_0Exception);
}
// Conversion method for clean up from marshalling of: System.Reflection.MonoEventInfo
extern "C" void MonoEventInfo_t2190036573_marshal_pinvoke_cleanup(MonoEventInfo_t2190036573_marshaled_pinvoke& marshaled)
{
}
// Conversion methods for marshalling of: System.Reflection.MonoEventInfo
extern "C" void MonoEventInfo_t2190036573_marshal_com(const MonoEventInfo_t2190036573& unmarshaled, MonoEventInfo_t2190036573_marshaled_com& marshaled)
{
	Il2CppCodeGenException* ___declaring_type_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'declaring_type' of type 'MonoEventInfo': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___declaring_type_0Exception);
}
extern "C" void MonoEventInfo_t2190036573_marshal_com_back(const MonoEventInfo_t2190036573_marshaled_com& marshaled, MonoEventInfo_t2190036573& unmarshaled)
{
	Il2CppCodeGenException* ___declaring_type_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'declaring_type' of type 'MonoEventInfo': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___declaring_type_0Exception);
}
// Conversion method for clean up from marshalling of: System.Reflection.MonoEventInfo
extern "C" void MonoEventInfo_t2190036573_marshal_com_cleanup(MonoEventInfo_t2190036573_marshaled_com& marshaled)
{
}
// System.Void System.Reflection.MonoField::.ctor()
extern "C"  void MonoField__ctor_m494557655 (MonoField_t * __this, const MethodInfo* method)
{
	{
		FieldInfo__ctor_m1952545900(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Reflection.FieldAttributes System.Reflection.MonoField::get_Attributes()
extern "C"  int32_t MonoField_get_Attributes_m4138688533 (MonoField_t * __this, const MethodInfo* method)
{
	{
		int32_t L_0 = __this->get_attrs_4();
		return L_0;
	}
}
// System.RuntimeFieldHandle System.Reflection.MonoField::get_FieldHandle()
extern "C"  RuntimeFieldHandle_t2331729674  MonoField_get_FieldHandle_m4221523254 (MonoField_t * __this, const MethodInfo* method)
{
	{
		RuntimeFieldHandle_t2331729674  L_0 = __this->get_fhandle_1();
		return L_0;
	}
}
// System.Type System.Reflection.MonoField::get_FieldType()
extern "C"  Type_t * MonoField_get_FieldType_m598011426 (MonoField_t * __this, const MethodInfo* method)
{
	{
		Type_t * L_0 = __this->get_type_3();
		return L_0;
	}
}
// System.Type System.Reflection.MonoField::GetParentType(System.Boolean)
extern "C"  Type_t * MonoField_GetParentType_m2074626828 (MonoField_t * __this, bool ___declaring0, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef Type_t * (*MonoField_GetParentType_m2074626828_ftn) (MonoField_t *, bool);
	return  ((MonoField_GetParentType_m2074626828_ftn)mscorlib::System::Reflection::MonoField::GetParentType) (__this, ___declaring0);
}
// System.Type System.Reflection.MonoField::get_ReflectedType()
extern "C"  Type_t * MonoField_get_ReflectedType_m2228561986 (MonoField_t * __this, const MethodInfo* method)
{
	{
		Type_t * L_0 = MonoField_GetParentType_m2074626828(__this, (bool)0, /*hidden argument*/NULL);
		return L_0;
	}
}
// System.Type System.Reflection.MonoField::get_DeclaringType()
extern "C"  Type_t * MonoField_get_DeclaringType_m1591666235 (MonoField_t * __this, const MethodInfo* method)
{
	{
		Type_t * L_0 = MonoField_GetParentType_m2074626828(__this, (bool)1, /*hidden argument*/NULL);
		return L_0;
	}
}
// System.String System.Reflection.MonoField::get_Name()
extern "C"  String_t* MonoField_get_Name_m3761030246 (MonoField_t * __this, const MethodInfo* method)
{
	{
		String_t* L_0 = __this->get_name_2();
		return L_0;
	}
}
// System.Boolean System.Reflection.MonoField::IsDefined(System.Type,System.Boolean)
extern Il2CppClass* MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var;
extern const uint32_t MonoField_IsDefined_m1871511958_MetadataUsageId;
extern "C"  bool MonoField_IsDefined_m1871511958 (MonoField_t * __this, Type_t * ___attributeType0, bool ___inherit1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MonoField_IsDefined_m1871511958_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Type_t * L_0 = ___attributeType0;
		bool L_1 = ___inherit1;
		IL2CPP_RUNTIME_CLASS_INIT(MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var);
		bool L_2 = MonoCustomAttrs_IsDefined_m3820363041(NULL /*static, unused*/, __this, L_0, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.Object[] System.Reflection.MonoField::GetCustomAttributes(System.Boolean)
extern Il2CppClass* MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var;
extern const uint32_t MonoField_GetCustomAttributes_m4168545977_MetadataUsageId;
extern "C"  ObjectU5BU5D_t3614634134* MonoField_GetCustomAttributes_m4168545977 (MonoField_t * __this, bool ___inherit0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MonoField_GetCustomAttributes_m4168545977_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		bool L_0 = ___inherit0;
		IL2CPP_RUNTIME_CLASS_INIT(MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var);
		ObjectU5BU5D_t3614634134* L_1 = MonoCustomAttrs_GetCustomAttributes_m3069779582(NULL /*static, unused*/, __this, L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Object[] System.Reflection.MonoField::GetCustomAttributes(System.Type,System.Boolean)
extern Il2CppClass* MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var;
extern const uint32_t MonoField_GetCustomAttributes_m1051163738_MetadataUsageId;
extern "C"  ObjectU5BU5D_t3614634134* MonoField_GetCustomAttributes_m1051163738 (MonoField_t * __this, Type_t * ___attributeType0, bool ___inherit1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MonoField_GetCustomAttributes_m1051163738_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Type_t * L_0 = ___attributeType0;
		bool L_1 = ___inherit1;
		IL2CPP_RUNTIME_CLASS_INIT(MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var);
		ObjectU5BU5D_t3614634134* L_2 = MonoCustomAttrs_GetCustomAttributes_m939426263(NULL /*static, unused*/, __this, L_0, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.Int32 System.Reflection.MonoField::GetFieldOffset()
extern "C"  int32_t MonoField_GetFieldOffset_m3584238032 (MonoField_t * __this, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef int32_t (*MonoField_GetFieldOffset_m3584238032_ftn) (MonoField_t *);
	return  ((MonoField_GetFieldOffset_m3584238032_ftn)mscorlib::System::Reflection::MonoField::GetFieldOffset) (__this);
}
// System.Object System.Reflection.MonoField::GetValueInternal(System.Object)
extern "C"  Il2CppObject * MonoField_GetValueInternal_m1909282050 (MonoField_t * __this, Il2CppObject * ___obj0, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef Il2CppObject * (*MonoField_GetValueInternal_m1909282050_ftn) (MonoField_t *, Il2CppObject *);
	return  ((MonoField_GetValueInternal_m1909282050_ftn)mscorlib::System::Reflection::MonoField::GetValueInternal) (__this, ___obj0);
}
// System.Object System.Reflection.MonoField::GetValue(System.Object)
extern Il2CppClass* TargetException_t1572104820_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* ArgumentException_t3259014390_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral2752958494;
extern Il2CppCodeGenString* _stringLiteral3735664915;
extern Il2CppCodeGenString* _stringLiteral1099314147;
extern const uint32_t MonoField_GetValue_m1386935585_MetadataUsageId;
extern "C"  Il2CppObject * MonoField_GetValue_m1386935585 (MonoField_t * __this, Il2CppObject * ___obj0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MonoField_GetValue_m1386935585_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		bool L_0 = FieldInfo_get_IsStatic_m1411173225(__this, /*hidden argument*/NULL);
		if (L_0)
		{
			goto IL_0059;
		}
	}
	{
		Il2CppObject * L_1 = ___obj0;
		if (L_1)
		{
			goto IL_001c;
		}
	}
	{
		TargetException_t1572104820 * L_2 = (TargetException_t1572104820 *)il2cpp_codegen_object_new(TargetException_t1572104820_il2cpp_TypeInfo_var);
		TargetException__ctor_m3228808416(L_2, _stringLiteral2752958494, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_2);
	}

IL_001c:
	{
		Type_t * L_3 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.MonoField::get_DeclaringType() */, __this);
		Il2CppObject * L_4 = ___obj0;
		NullCheck(L_4);
		Type_t * L_5 = Object_GetType_m191970594(L_4, /*hidden argument*/NULL);
		NullCheck(L_3);
		bool L_6 = VirtFuncInvoker1< bool, Type_t * >::Invoke(40 /* System.Boolean System.Type::IsAssignableFrom(System.Type) */, L_3, L_5);
		if (L_6)
		{
			goto IL_0059;
		}
	}
	{
		String_t* L_7 = VirtFuncInvoker0< String_t* >::Invoke(8 /* System.String System.Reflection.MonoField::get_Name() */, __this);
		Type_t * L_8 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.MonoField::get_DeclaringType() */, __this);
		Il2CppObject * L_9 = ___obj0;
		NullCheck(L_9);
		Type_t * L_10 = Object_GetType_m191970594(L_9, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_11 = String_Format_m4262916296(NULL /*static, unused*/, _stringLiteral3735664915, L_7, L_8, L_10, /*hidden argument*/NULL);
		ArgumentException_t3259014390 * L_12 = (ArgumentException_t3259014390 *)il2cpp_codegen_object_new(ArgumentException_t3259014390_il2cpp_TypeInfo_var);
		ArgumentException__ctor_m544251339(L_12, L_11, _stringLiteral1099314147, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_12);
	}

IL_0059:
	{
		bool L_13 = FieldInfo_get_IsLiteral_m267898096(__this, /*hidden argument*/NULL);
		if (L_13)
		{
			goto IL_006a;
		}
	}
	{
		MonoField_CheckGeneric_m1527550038(__this, /*hidden argument*/NULL);
	}

IL_006a:
	{
		Il2CppObject * L_14 = ___obj0;
		Il2CppObject * L_15 = MonoField_GetValueInternal_m1909282050(__this, L_14, /*hidden argument*/NULL);
		return L_15;
	}
}
// System.String System.Reflection.MonoField::ToString()
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral2512070489;
extern const uint32_t MonoField_ToString_m517029212_MetadataUsageId;
extern "C"  String_t* MonoField_ToString_m517029212 (MonoField_t * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MonoField_ToString_m517029212_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Type_t * L_0 = __this->get_type_3();
		String_t* L_1 = __this->get_name_2();
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_2 = String_Format_m1811873526(NULL /*static, unused*/, _stringLiteral2512070489, L_0, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.Void System.Reflection.MonoField::SetValueInternal(System.Reflection.FieldInfo,System.Object,System.Object)
extern "C"  void MonoField_SetValueInternal_m762249951 (Il2CppObject * __this /* static, unused */, FieldInfo_t * ___fi0, Il2CppObject * ___obj1, Il2CppObject * ___value2, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef void (*MonoField_SetValueInternal_m762249951_ftn) (FieldInfo_t *, Il2CppObject *, Il2CppObject *);
	 ((MonoField_SetValueInternal_m762249951_ftn)mscorlib::System::Reflection::MonoField::SetValueInternal) (___fi0, ___obj1, ___value2);
}
// System.Void System.Reflection.MonoField::SetValue(System.Object,System.Object,System.Reflection.BindingFlags,System.Reflection.Binder,System.Globalization.CultureInfo)
extern Il2CppClass* TargetException_t1572104820_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* ArgumentException_t3259014390_il2cpp_TypeInfo_var;
extern Il2CppClass* FieldAccessException_t1797813379_il2cpp_TypeInfo_var;
extern Il2CppClass* Binder_t3404612058_il2cpp_TypeInfo_var;
extern Il2CppClass* ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral2752958494;
extern Il2CppCodeGenString* _stringLiteral3735664915;
extern Il2CppCodeGenString* _stringLiteral1099314147;
extern Il2CppCodeGenString* _stringLiteral4043003486;
extern Il2CppCodeGenString* _stringLiteral2614084089;
extern Il2CppCodeGenString* _stringLiteral3234870220;
extern Il2CppCodeGenString* _stringLiteral696029875;
extern const uint32_t MonoField_SetValue_m1849281384_MetadataUsageId;
extern "C"  void MonoField_SetValue_m1849281384 (MonoField_t * __this, Il2CppObject * ___obj0, Il2CppObject * ___val1, int32_t ___invokeAttr2, Binder_t3404612058 * ___binder3, CultureInfo_t3500843524 * ___culture4, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MonoField_SetValue_m1849281384_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Il2CppObject * V_0 = NULL;
	{
		bool L_0 = FieldInfo_get_IsStatic_m1411173225(__this, /*hidden argument*/NULL);
		if (L_0)
		{
			goto IL_0059;
		}
	}
	{
		Il2CppObject * L_1 = ___obj0;
		if (L_1)
		{
			goto IL_001c;
		}
	}
	{
		TargetException_t1572104820 * L_2 = (TargetException_t1572104820 *)il2cpp_codegen_object_new(TargetException_t1572104820_il2cpp_TypeInfo_var);
		TargetException__ctor_m3228808416(L_2, _stringLiteral2752958494, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_2);
	}

IL_001c:
	{
		Type_t * L_3 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.MonoField::get_DeclaringType() */, __this);
		Il2CppObject * L_4 = ___obj0;
		NullCheck(L_4);
		Type_t * L_5 = Object_GetType_m191970594(L_4, /*hidden argument*/NULL);
		NullCheck(L_3);
		bool L_6 = VirtFuncInvoker1< bool, Type_t * >::Invoke(40 /* System.Boolean System.Type::IsAssignableFrom(System.Type) */, L_3, L_5);
		if (L_6)
		{
			goto IL_0059;
		}
	}
	{
		String_t* L_7 = VirtFuncInvoker0< String_t* >::Invoke(8 /* System.String System.Reflection.MonoField::get_Name() */, __this);
		Type_t * L_8 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.MonoField::get_DeclaringType() */, __this);
		Il2CppObject * L_9 = ___obj0;
		NullCheck(L_9);
		Type_t * L_10 = Object_GetType_m191970594(L_9, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_11 = String_Format_m4262916296(NULL /*static, unused*/, _stringLiteral3735664915, L_7, L_8, L_10, /*hidden argument*/NULL);
		ArgumentException_t3259014390 * L_12 = (ArgumentException_t3259014390 *)il2cpp_codegen_object_new(ArgumentException_t3259014390_il2cpp_TypeInfo_var);
		ArgumentException__ctor_m544251339(L_12, L_11, _stringLiteral1099314147, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_12);
	}

IL_0059:
	{
		bool L_13 = FieldInfo_get_IsLiteral_m267898096(__this, /*hidden argument*/NULL);
		if (!L_13)
		{
			goto IL_006f;
		}
	}
	{
		FieldAccessException_t1797813379 * L_14 = (FieldAccessException_t1797813379 *)il2cpp_codegen_object_new(FieldAccessException_t1797813379_il2cpp_TypeInfo_var);
		FieldAccessException__ctor_m3893881490(L_14, _stringLiteral4043003486, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_14);
	}

IL_006f:
	{
		Binder_t3404612058 * L_15 = ___binder3;
		if (L_15)
		{
			goto IL_007d;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(Binder_t3404612058_il2cpp_TypeInfo_var);
		Binder_t3404612058 * L_16 = Binder_get_DefaultBinder_m965620943(NULL /*static, unused*/, /*hidden argument*/NULL);
		___binder3 = L_16;
	}

IL_007d:
	{
		MonoField_CheckGeneric_m1527550038(__this, /*hidden argument*/NULL);
		Il2CppObject * L_17 = ___val1;
		if (!L_17)
		{
			goto IL_00db;
		}
	}
	{
		Binder_t3404612058 * L_18 = ___binder3;
		Il2CppObject * L_19 = ___val1;
		Type_t * L_20 = __this->get_type_3();
		CultureInfo_t3500843524 * L_21 = ___culture4;
		NullCheck(L_18);
		Il2CppObject * L_22 = VirtFuncInvoker3< Il2CppObject *, Il2CppObject *, Type_t *, CultureInfo_t3500843524 * >::Invoke(5 /* System.Object System.Reflection.Binder::ChangeType(System.Object,System.Type,System.Globalization.CultureInfo) */, L_18, L_19, L_20, L_21);
		V_0 = L_22;
		Il2CppObject * L_23 = V_0;
		if (L_23)
		{
			goto IL_00d8;
		}
	}
	{
		ObjectU5BU5D_t3614634134* L_24 = ((ObjectU5BU5D_t3614634134*)SZArrayNew(ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var, (uint32_t)4));
		NullCheck(L_24);
		ArrayElementTypeCheck (L_24, _stringLiteral2614084089);
		(L_24)->SetAt(static_cast<il2cpp_array_size_t>(0), (Il2CppObject *)_stringLiteral2614084089);
		ObjectU5BU5D_t3614634134* L_25 = L_24;
		Il2CppObject * L_26 = ___val1;
		NullCheck(L_26);
		Type_t * L_27 = Object_GetType_m191970594(L_26, /*hidden argument*/NULL);
		NullCheck(L_25);
		ArrayElementTypeCheck (L_25, L_27);
		(L_25)->SetAt(static_cast<il2cpp_array_size_t>(1), (Il2CppObject *)L_27);
		ObjectU5BU5D_t3614634134* L_28 = L_25;
		NullCheck(L_28);
		ArrayElementTypeCheck (L_28, _stringLiteral3234870220);
		(L_28)->SetAt(static_cast<il2cpp_array_size_t>(2), (Il2CppObject *)_stringLiteral3234870220);
		ObjectU5BU5D_t3614634134* L_29 = L_28;
		Type_t * L_30 = __this->get_type_3();
		NullCheck(L_29);
		ArrayElementTypeCheck (L_29, L_30);
		(L_29)->SetAt(static_cast<il2cpp_array_size_t>(3), (Il2CppObject *)L_30);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_31 = String_Concat_m3881798623(NULL /*static, unused*/, L_29, /*hidden argument*/NULL);
		ArgumentException_t3259014390 * L_32 = (ArgumentException_t3259014390 *)il2cpp_codegen_object_new(ArgumentException_t3259014390_il2cpp_TypeInfo_var);
		ArgumentException__ctor_m544251339(L_32, L_31, _stringLiteral696029875, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_32);
	}

IL_00d8:
	{
		Il2CppObject * L_33 = V_0;
		___val1 = L_33;
	}

IL_00db:
	{
		Il2CppObject * L_34 = ___obj0;
		Il2CppObject * L_35 = ___val1;
		MonoField_SetValueInternal_m762249951(NULL /*static, unused*/, __this, L_34, L_35, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Reflection.MonoField::GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern "C"  void MonoField_GetObjectData_m3571455087 (MonoField_t * __this, SerializationInfo_t228987430 * ___info0, StreamingContext_t1417235061  ___context1, const MethodInfo* method)
{
	{
		SerializationInfo_t228987430 * L_0 = ___info0;
		String_t* L_1 = VirtFuncInvoker0< String_t* >::Invoke(8 /* System.String System.Reflection.MonoField::get_Name() */, __this);
		Type_t * L_2 = VirtFuncInvoker0< Type_t * >::Invoke(9 /* System.Type System.Reflection.MonoField::get_ReflectedType() */, __this);
		String_t* L_3 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Reflection.MonoField::ToString() */, __this);
		MemberInfoSerializationHolder_Serialize_m1949812823(NULL /*static, unused*/, L_0, L_1, L_2, L_3, 4, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Reflection.MonoField::CheckGeneric()
extern Il2CppClass* InvalidOperationException_t721527559_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral2139378969;
extern const uint32_t MonoField_CheckGeneric_m1527550038_MetadataUsageId;
extern "C"  void MonoField_CheckGeneric_m1527550038 (MonoField_t * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MonoField_CheckGeneric_m1527550038_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Type_t * L_0 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.MonoField::get_DeclaringType() */, __this);
		NullCheck(L_0);
		bool L_1 = VirtFuncInvoker0< bool >::Invoke(76 /* System.Boolean System.Type::get_ContainsGenericParameters() */, L_0);
		if (!L_1)
		{
			goto IL_001b;
		}
	}
	{
		InvalidOperationException_t721527559 * L_2 = (InvalidOperationException_t721527559 *)il2cpp_codegen_object_new(InvalidOperationException_t721527559_il2cpp_TypeInfo_var);
		InvalidOperationException__ctor_m2801133788(L_2, _stringLiteral2139378969, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_2);
	}

IL_001b:
	{
		return;
	}
}
// System.Void System.Reflection.MonoGenericCMethod::.ctor()
extern Il2CppClass* InvalidOperationException_t721527559_il2cpp_TypeInfo_var;
extern const uint32_t MonoGenericCMethod__ctor_m2520666358_MetadataUsageId;
extern "C"  void MonoGenericCMethod__ctor_m2520666358 (MonoGenericCMethod_t2923423538 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MonoGenericCMethod__ctor_m2520666358_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		MonoCMethod__ctor_m2473049889(__this, /*hidden argument*/NULL);
		InvalidOperationException_t721527559 * L_0 = (InvalidOperationException_t721527559 *)il2cpp_codegen_object_new(InvalidOperationException_t721527559_il2cpp_TypeInfo_var);
		InvalidOperationException__ctor_m102359810(L_0, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Type System.Reflection.MonoGenericCMethod::get_ReflectedType()
extern "C"  Type_t * MonoGenericCMethod_get_ReflectedType_m2689239043 (MonoGenericCMethod_t2923423538 * __this, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef Type_t * (*MonoGenericCMethod_get_ReflectedType_m2689239043_ftn) (MonoGenericCMethod_t2923423538 *);
	return  ((MonoGenericCMethod_get_ReflectedType_m2689239043_ftn)mscorlib::System::Reflection::MonoGenericCMethod::get_ReflectedType) (__this);
}
// System.Void System.Reflection.MonoGenericMethod::.ctor()
extern Il2CppClass* InvalidOperationException_t721527559_il2cpp_TypeInfo_var;
extern const uint32_t MonoGenericMethod__ctor_m2255621499_MetadataUsageId;
extern "C"  void MonoGenericMethod__ctor_m2255621499 (MonoGenericMethod_t * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MonoGenericMethod__ctor_m2255621499_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		MonoMethod__ctor_m4091684020(__this, /*hidden argument*/NULL);
		InvalidOperationException_t721527559 * L_0 = (InvalidOperationException_t721527559 *)il2cpp_codegen_object_new(InvalidOperationException_t721527559_il2cpp_TypeInfo_var);
		InvalidOperationException__ctor_m102359810(L_0, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Type System.Reflection.MonoGenericMethod::get_ReflectedType()
extern "C"  Type_t * MonoGenericMethod_get_ReflectedType_m3194343466 (MonoGenericMethod_t * __this, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef Type_t * (*MonoGenericMethod_get_ReflectedType_m3194343466_ftn) (MonoGenericMethod_t *);
	return  ((MonoGenericMethod_get_ReflectedType_m3194343466_ftn)mscorlib::System::Reflection::MonoGenericMethod::get_ReflectedType) (__this);
}
// System.Void System.Reflection.MonoMethod::.ctor()
extern "C"  void MonoMethod__ctor_m4091684020 (MonoMethod_t * __this, const MethodInfo* method)
{
	{
		MethodInfo__ctor_m1853540423(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.String System.Reflection.MonoMethod::get_name(System.Reflection.MethodBase)
extern "C"  String_t* MonoMethod_get_name_m1503581873 (Il2CppObject * __this /* static, unused */, MethodBase_t904190842 * ___method0, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef String_t* (*MonoMethod_get_name_m1503581873_ftn) (MethodBase_t904190842 *);
	return  ((MonoMethod_get_name_m1503581873_ftn)mscorlib::System::Reflection::MonoMethod::get_name) (___method0);
}
// System.Reflection.MonoMethod System.Reflection.MonoMethod::get_base_definition(System.Reflection.MonoMethod)
extern "C"  MonoMethod_t * MonoMethod_get_base_definition_m1625237055 (Il2CppObject * __this /* static, unused */, MonoMethod_t * ___method0, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef MonoMethod_t * (*MonoMethod_get_base_definition_m1625237055_ftn) (MonoMethod_t *);
	return  ((MonoMethod_get_base_definition_m1625237055_ftn)mscorlib::System::Reflection::MonoMethod::get_base_definition) (___method0);
}
// System.Reflection.MethodInfo System.Reflection.MonoMethod::GetBaseDefinition()
extern "C"  MethodInfo_t * MonoMethod_GetBaseDefinition_m1738989472 (MonoMethod_t * __this, const MethodInfo* method)
{
	{
		MonoMethod_t * L_0 = MonoMethod_get_base_definition_m1625237055(NULL /*static, unused*/, __this, /*hidden argument*/NULL);
		return L_0;
	}
}
// System.Type System.Reflection.MonoMethod::get_ReturnType()
extern "C"  Type_t * MonoMethod_get_ReturnType_m4218706049 (MonoMethod_t * __this, const MethodInfo* method)
{
	{
		IntPtr_t L_0 = __this->get_mhandle_0();
		Type_t * L_1 = MonoMethodInfo_GetReturnType_m2864247130(NULL /*static, unused*/, L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Reflection.ParameterInfo[] System.Reflection.MonoMethod::GetParameters()
extern Il2CppClass* ParameterInfoU5BU5D_t2275869610_il2cpp_TypeInfo_var;
extern const uint32_t MonoMethod_GetParameters_m1240674378_MetadataUsageId;
extern "C"  ParameterInfoU5BU5D_t2275869610* MonoMethod_GetParameters_m1240674378 (MonoMethod_t * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MonoMethod_GetParameters_m1240674378_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ParameterInfoU5BU5D_t2275869610* V_0 = NULL;
	ParameterInfoU5BU5D_t2275869610* V_1 = NULL;
	{
		IntPtr_t L_0 = __this->get_mhandle_0();
		ParameterInfoU5BU5D_t2275869610* L_1 = MonoMethodInfo_GetParametersInfo_m3456861922(NULL /*static, unused*/, L_0, __this, /*hidden argument*/NULL);
		V_0 = L_1;
		ParameterInfoU5BU5D_t2275869610* L_2 = V_0;
		NullCheck(L_2);
		V_1 = ((ParameterInfoU5BU5D_t2275869610*)SZArrayNew(ParameterInfoU5BU5D_t2275869610_il2cpp_TypeInfo_var, (uint32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_2)->max_length))))));
		ParameterInfoU5BU5D_t2275869610* L_3 = V_0;
		ParameterInfoU5BU5D_t2275869610* L_4 = V_1;
		NullCheck((Il2CppArray *)(Il2CppArray *)L_3);
		Array_CopyTo_m4061033315((Il2CppArray *)(Il2CppArray *)L_3, (Il2CppArray *)(Il2CppArray *)L_4, 0, /*hidden argument*/NULL);
		ParameterInfoU5BU5D_t2275869610* L_5 = V_1;
		return L_5;
	}
}
// System.Object System.Reflection.MonoMethod::InternalInvoke(System.Object,System.Object[],System.Exception&)
extern "C"  Il2CppObject * MonoMethod_InternalInvoke_m4055929538 (MonoMethod_t * __this, Il2CppObject * ___obj0, ObjectU5BU5D_t3614634134* ___parameters1, Exception_t1927440687 ** ___exc2, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef Il2CppObject * (*MonoMethod_InternalInvoke_m4055929538_ftn) (MonoMethod_t *, Il2CppObject *, ObjectU5BU5D_t3614634134*, Exception_t1927440687 **);
	return  ((MonoMethod_InternalInvoke_m4055929538_ftn)mscorlib::System::Reflection::MonoMethod::InternalInvoke) (__this, ___obj0, ___parameters1, ___exc2);
}
// System.Object System.Reflection.MonoMethod::Invoke(System.Object,System.Reflection.BindingFlags,System.Reflection.Binder,System.Object[],System.Globalization.CultureInfo)
extern Il2CppClass* Binder_t3404612058_il2cpp_TypeInfo_var;
extern Il2CppClass* TargetParameterCountException_t1554451430_il2cpp_TypeInfo_var;
extern Il2CppClass* ArgumentException_t3259014390_il2cpp_TypeInfo_var;
extern Il2CppClass* InvalidOperationException_t721527559_il2cpp_TypeInfo_var;
extern Il2CppClass* ThreadAbortException_t1150575753_il2cpp_TypeInfo_var;
extern Il2CppClass* MethodAccessException_t4093255254_il2cpp_TypeInfo_var;
extern Il2CppClass* Exception_t1927440687_il2cpp_TypeInfo_var;
extern Il2CppClass* TargetInvocationException_t4098620458_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral3569083427;
extern Il2CppCodeGenString* _stringLiteral404785397;
extern Il2CppCodeGenString* _stringLiteral68020717;
extern const uint32_t MonoMethod_Invoke_m3376991795_MetadataUsageId;
extern "C"  Il2CppObject * MonoMethod_Invoke_m3376991795 (MonoMethod_t * __this, Il2CppObject * ___obj0, int32_t ___invokeAttr1, Binder_t3404612058 * ___binder2, ObjectU5BU5D_t3614634134* ___parameters3, CultureInfo_t3500843524 * ___culture4, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MonoMethod_Invoke_m3376991795_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ParameterInfoU5BU5D_t2275869610* V_0 = NULL;
	int32_t V_1 = 0;
	Exception_t1927440687 * V_2 = NULL;
	Il2CppObject * V_3 = NULL;
	Exception_t1927440687 * V_4 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		Binder_t3404612058 * L_0 = ___binder2;
		if (L_0)
		{
			goto IL_000d;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(Binder_t3404612058_il2cpp_TypeInfo_var);
		Binder_t3404612058 * L_1 = Binder_get_DefaultBinder_m965620943(NULL /*static, unused*/, /*hidden argument*/NULL);
		___binder2 = L_1;
	}

IL_000d:
	{
		IntPtr_t L_2 = __this->get_mhandle_0();
		ParameterInfoU5BU5D_t2275869610* L_3 = MonoMethodInfo_GetParametersInfo_m3456861922(NULL /*static, unused*/, L_2, __this, /*hidden argument*/NULL);
		V_0 = L_3;
		ObjectU5BU5D_t3614634134* L_4 = ___parameters3;
		if (L_4)
		{
			goto IL_0029;
		}
	}
	{
		ParameterInfoU5BU5D_t2275869610* L_5 = V_0;
		NullCheck(L_5);
		if ((((int32_t)((int32_t)(((Il2CppArray *)L_5)->max_length)))))
		{
			goto IL_003c;
		}
	}

IL_0029:
	{
		ObjectU5BU5D_t3614634134* L_6 = ___parameters3;
		if (!L_6)
		{
			goto IL_0047;
		}
	}
	{
		ObjectU5BU5D_t3614634134* L_7 = ___parameters3;
		NullCheck(L_7);
		ParameterInfoU5BU5D_t2275869610* L_8 = V_0;
		NullCheck(L_8);
		if ((((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_7)->max_length))))) == ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_8)->max_length)))))))
		{
			goto IL_0047;
		}
	}

IL_003c:
	{
		TargetParameterCountException_t1554451430 * L_9 = (TargetParameterCountException_t1554451430 *)il2cpp_codegen_object_new(TargetParameterCountException_t1554451430_il2cpp_TypeInfo_var);
		TargetParameterCountException__ctor_m2760108938(L_9, _stringLiteral3569083427, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_9);
	}

IL_0047:
	{
		int32_t L_10 = ___invokeAttr1;
		if (((int32_t)((int32_t)L_10&(int32_t)((int32_t)65536))))
		{
			goto IL_0073;
		}
	}
	{
		Binder_t3404612058 * L_11 = ___binder2;
		ObjectU5BU5D_t3614634134* L_12 = ___parameters3;
		ParameterInfoU5BU5D_t2275869610* L_13 = V_0;
		CultureInfo_t3500843524 * L_14 = ___culture4;
		IL2CPP_RUNTIME_CLASS_INIT(Binder_t3404612058_il2cpp_TypeInfo_var);
		bool L_15 = Binder_ConvertArgs_m2999223281(NULL /*static, unused*/, L_11, L_12, L_13, L_14, /*hidden argument*/NULL);
		if (L_15)
		{
			goto IL_006e;
		}
	}
	{
		ArgumentException_t3259014390 * L_16 = (ArgumentException_t3259014390 *)il2cpp_codegen_object_new(ArgumentException_t3259014390_il2cpp_TypeInfo_var);
		ArgumentException__ctor_m3739475201(L_16, _stringLiteral404785397, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_16);
	}

IL_006e:
	{
		goto IL_00a8;
	}

IL_0073:
	{
		V_1 = 0;
		goto IL_009f;
	}

IL_007a:
	{
		ObjectU5BU5D_t3614634134* L_17 = ___parameters3;
		int32_t L_18 = V_1;
		NullCheck(L_17);
		int32_t L_19 = L_18;
		Il2CppObject * L_20 = (L_17)->GetAt(static_cast<il2cpp_array_size_t>(L_19));
		NullCheck(L_20);
		Type_t * L_21 = Object_GetType_m191970594(L_20, /*hidden argument*/NULL);
		ParameterInfoU5BU5D_t2275869610* L_22 = V_0;
		int32_t L_23 = V_1;
		NullCheck(L_22);
		int32_t L_24 = L_23;
		ParameterInfo_t2249040075 * L_25 = (L_22)->GetAt(static_cast<il2cpp_array_size_t>(L_24));
		NullCheck(L_25);
		Type_t * L_26 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.ParameterInfo::get_ParameterType() */, L_25);
		if ((((Il2CppObject*)(Type_t *)L_21) == ((Il2CppObject*)(Type_t *)L_26)))
		{
			goto IL_009b;
		}
	}
	{
		ArgumentException_t3259014390 * L_27 = (ArgumentException_t3259014390 *)il2cpp_codegen_object_new(ArgumentException_t3259014390_il2cpp_TypeInfo_var);
		ArgumentException__ctor_m3739475201(L_27, _stringLiteral3569083427, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_27);
	}

IL_009b:
	{
		int32_t L_28 = V_1;
		V_1 = ((int32_t)((int32_t)L_28+(int32_t)1));
	}

IL_009f:
	{
		int32_t L_29 = V_1;
		ParameterInfoU5BU5D_t2275869610* L_30 = V_0;
		NullCheck(L_30);
		if ((((int32_t)L_29) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_30)->max_length)))))))
		{
			goto IL_007a;
		}
	}

IL_00a8:
	{
		bool L_31 = VirtFuncInvoker0< bool >::Invoke(27 /* System.Boolean System.Reflection.MonoMethod::get_ContainsGenericParameters() */, __this);
		if (!L_31)
		{
			goto IL_00be;
		}
	}
	{
		InvalidOperationException_t721527559 * L_32 = (InvalidOperationException_t721527559 *)il2cpp_codegen_object_new(InvalidOperationException_t721527559_il2cpp_TypeInfo_var);
		InvalidOperationException__ctor_m2801133788(L_32, _stringLiteral68020717, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_32);
	}

IL_00be:
	{
		V_3 = NULL;
	}

IL_00c0:
	try
	{ // begin try (depth: 1)
		Il2CppObject * L_33 = ___obj0;
		ObjectU5BU5D_t3614634134* L_34 = ___parameters3;
		Il2CppObject * L_35 = MonoMethod_InternalInvoke_m4055929538(__this, L_33, L_34, (&V_2), /*hidden argument*/NULL);
		V_3 = L_35;
		goto IL_00f0;
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__exception_local = (Exception_t1927440687 *)e.ex;
		if(il2cpp_codegen_class_is_assignable_from (ThreadAbortException_t1150575753_il2cpp_TypeInfo_var, e.ex->object.klass))
			goto CATCH_00d1;
		if(il2cpp_codegen_class_is_assignable_from (MethodAccessException_t4093255254_il2cpp_TypeInfo_var, e.ex->object.klass))
			goto CATCH_00d9;
		if(il2cpp_codegen_class_is_assignable_from (Exception_t1927440687_il2cpp_TypeInfo_var, e.ex->object.klass))
			goto CATCH_00e1;
		throw e;
	}

CATCH_00d1:
	{ // begin catch(System.Threading.ThreadAbortException)
		{
			IL2CPP_RAISE_MANAGED_EXCEPTION(__exception_local);
		}

IL_00d4:
		{
			goto IL_00f0;
		}
	} // end catch (depth: 1)

CATCH_00d9:
	{ // begin catch(System.MethodAccessException)
		{
			IL2CPP_RAISE_MANAGED_EXCEPTION(__exception_local);
		}

IL_00dc:
		{
			goto IL_00f0;
		}
	} // end catch (depth: 1)

CATCH_00e1:
	{ // begin catch(System.Exception)
		{
			V_4 = ((Exception_t1927440687 *)__exception_local);
			Exception_t1927440687 * L_36 = V_4;
			TargetInvocationException_t4098620458 * L_37 = (TargetInvocationException_t4098620458 *)il2cpp_codegen_object_new(TargetInvocationException_t4098620458_il2cpp_TypeInfo_var);
			TargetInvocationException__ctor_m1059845570(L_37, L_36, /*hidden argument*/NULL);
			IL2CPP_RAISE_MANAGED_EXCEPTION(L_37);
		}

IL_00eb:
		{
			goto IL_00f0;
		}
	} // end catch (depth: 1)

IL_00f0:
	{
		Exception_t1927440687 * L_38 = V_2;
		if (!L_38)
		{
			goto IL_00f8;
		}
	}
	{
		Exception_t1927440687 * L_39 = V_2;
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_39);
	}

IL_00f8:
	{
		Il2CppObject * L_40 = V_3;
		return L_40;
	}
}
// System.RuntimeMethodHandle System.Reflection.MonoMethod::get_MethodHandle()
extern "C"  RuntimeMethodHandle_t894824333  MonoMethod_get_MethodHandle_m1882915015 (MonoMethod_t * __this, const MethodInfo* method)
{
	{
		IntPtr_t L_0 = __this->get_mhandle_0();
		RuntimeMethodHandle_t894824333  L_1;
		memset(&L_1, 0, sizeof(L_1));
		RuntimeMethodHandle__ctor_m1162528746(&L_1, L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Reflection.MethodAttributes System.Reflection.MonoMethod::get_Attributes()
extern "C"  int32_t MonoMethod_get_Attributes_m4038185617 (MonoMethod_t * __this, const MethodInfo* method)
{
	{
		IntPtr_t L_0 = __this->get_mhandle_0();
		int32_t L_1 = MonoMethodInfo_GetAttributes_m2535493430(NULL /*static, unused*/, L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Reflection.CallingConventions System.Reflection.MonoMethod::get_CallingConvention()
extern "C"  int32_t MonoMethod_get_CallingConvention_m2978714873 (MonoMethod_t * __this, const MethodInfo* method)
{
	{
		IntPtr_t L_0 = __this->get_mhandle_0();
		int32_t L_1 = MonoMethodInfo_GetCallingConvention_m3095860872(NULL /*static, unused*/, L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Type System.Reflection.MonoMethod::get_ReflectedType()
extern "C"  Type_t * MonoMethod_get_ReflectedType_m3966408549 (MonoMethod_t * __this, const MethodInfo* method)
{
	{
		Type_t * L_0 = __this->get_reftype_2();
		return L_0;
	}
}
// System.Type System.Reflection.MonoMethod::get_DeclaringType()
extern "C"  Type_t * MonoMethod_get_DeclaringType_m4119916616 (MonoMethod_t * __this, const MethodInfo* method)
{
	{
		IntPtr_t L_0 = __this->get_mhandle_0();
		Type_t * L_1 = MonoMethodInfo_GetDeclaringType_m4186531677(NULL /*static, unused*/, L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.String System.Reflection.MonoMethod::get_Name()
extern "C"  String_t* MonoMethod_get_Name_m1650258269 (MonoMethod_t * __this, const MethodInfo* method)
{
	{
		String_t* L_0 = __this->get_name_1();
		if (!L_0)
		{
			goto IL_0012;
		}
	}
	{
		String_t* L_1 = __this->get_name_1();
		return L_1;
	}

IL_0012:
	{
		String_t* L_2 = MonoMethod_get_name_m1503581873(NULL /*static, unused*/, __this, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.Boolean System.Reflection.MonoMethod::IsDefined(System.Type,System.Boolean)
extern Il2CppClass* MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var;
extern const uint32_t MonoMethod_IsDefined_m2322670981_MetadataUsageId;
extern "C"  bool MonoMethod_IsDefined_m2322670981 (MonoMethod_t * __this, Type_t * ___attributeType0, bool ___inherit1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MonoMethod_IsDefined_m2322670981_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Type_t * L_0 = ___attributeType0;
		bool L_1 = ___inherit1;
		IL2CPP_RUNTIME_CLASS_INIT(MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var);
		bool L_2 = MonoCustomAttrs_IsDefined_m3820363041(NULL /*static, unused*/, __this, L_0, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.Object[] System.Reflection.MonoMethod::GetCustomAttributes(System.Boolean)
extern Il2CppClass* MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var;
extern const uint32_t MonoMethod_GetCustomAttributes_m2493833930_MetadataUsageId;
extern "C"  ObjectU5BU5D_t3614634134* MonoMethod_GetCustomAttributes_m2493833930 (MonoMethod_t * __this, bool ___inherit0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MonoMethod_GetCustomAttributes_m2493833930_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		bool L_0 = ___inherit0;
		IL2CPP_RUNTIME_CLASS_INIT(MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var);
		ObjectU5BU5D_t3614634134* L_1 = MonoCustomAttrs_GetCustomAttributes_m3069779582(NULL /*static, unused*/, __this, L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Object[] System.Reflection.MonoMethod::GetCustomAttributes(System.Type,System.Boolean)
extern Il2CppClass* MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var;
extern const uint32_t MonoMethod_GetCustomAttributes_m3212448303_MetadataUsageId;
extern "C"  ObjectU5BU5D_t3614634134* MonoMethod_GetCustomAttributes_m3212448303 (MonoMethod_t * __this, Type_t * ___attributeType0, bool ___inherit1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MonoMethod_GetCustomAttributes_m3212448303_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Type_t * L_0 = ___attributeType0;
		bool L_1 = ___inherit1;
		IL2CPP_RUNTIME_CLASS_INIT(MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var);
		ObjectU5BU5D_t3614634134* L_2 = MonoCustomAttrs_GetCustomAttributes_m939426263(NULL /*static, unused*/, __this, L_0, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.Runtime.InteropServices.DllImportAttribute System.Reflection.MonoMethod::GetDllImportAttribute(System.IntPtr)
extern "C"  DllImportAttribute_t3000813225 * MonoMethod_GetDllImportAttribute_m2757463479 (Il2CppObject * __this /* static, unused */, IntPtr_t ___mhandle0, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef DllImportAttribute_t3000813225 * (*MonoMethod_GetDllImportAttribute_m2757463479_ftn) (IntPtr_t);
	return  ((MonoMethod_GetDllImportAttribute_m2757463479_ftn)mscorlib::System::Reflection::MonoMethod::GetDllImportAttribute) (___mhandle0);
}
// System.Object[] System.Reflection.MonoMethod::GetPseudoCustomAttributes()
extern Il2CppClass* ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var;
extern Il2CppClass* PreserveSigAttribute_t1564965109_il2cpp_TypeInfo_var;
extern const uint32_t MonoMethod_GetPseudoCustomAttributes_m466965107_MetadataUsageId;
extern "C"  ObjectU5BU5D_t3614634134* MonoMethod_GetPseudoCustomAttributes_m466965107 (MonoMethod_t * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MonoMethod_GetPseudoCustomAttributes_m466965107_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	MonoMethodInfo_t3646562144  V_1;
	memset(&V_1, 0, sizeof(V_1));
	ObjectU5BU5D_t3614634134* V_2 = NULL;
	DllImportAttribute_t3000813225 * V_3 = NULL;
	{
		V_0 = 0;
		IntPtr_t L_0 = __this->get_mhandle_0();
		MonoMethodInfo_t3646562144  L_1 = MonoMethodInfo_GetMethodInfo_m3298558752(NULL /*static, unused*/, L_0, /*hidden argument*/NULL);
		V_1 = L_1;
		int32_t L_2 = (&V_1)->get_iattrs_3();
		if (!((int32_t)((int32_t)L_2&(int32_t)((int32_t)128))))
		{
			goto IL_0024;
		}
	}
	{
		int32_t L_3 = V_0;
		V_0 = ((int32_t)((int32_t)L_3+(int32_t)1));
	}

IL_0024:
	{
		int32_t L_4 = (&V_1)->get_attrs_2();
		if (!((int32_t)((int32_t)L_4&(int32_t)((int32_t)8192))))
		{
			goto IL_003a;
		}
	}
	{
		int32_t L_5 = V_0;
		V_0 = ((int32_t)((int32_t)L_5+(int32_t)1));
	}

IL_003a:
	{
		int32_t L_6 = V_0;
		if (L_6)
		{
			goto IL_0042;
		}
	}
	{
		return (ObjectU5BU5D_t3614634134*)NULL;
	}

IL_0042:
	{
		int32_t L_7 = V_0;
		V_2 = ((ObjectU5BU5D_t3614634134*)SZArrayNew(ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var, (uint32_t)L_7));
		V_0 = 0;
		int32_t L_8 = (&V_1)->get_iattrs_3();
		if (!((int32_t)((int32_t)L_8&(int32_t)((int32_t)128))))
		{
			goto IL_0069;
		}
	}
	{
		ObjectU5BU5D_t3614634134* L_9 = V_2;
		int32_t L_10 = V_0;
		int32_t L_11 = L_10;
		V_0 = ((int32_t)((int32_t)L_11+(int32_t)1));
		PreserveSigAttribute_t1564965109 * L_12 = (PreserveSigAttribute_t1564965109 *)il2cpp_codegen_object_new(PreserveSigAttribute_t1564965109_il2cpp_TypeInfo_var);
		PreserveSigAttribute__ctor_m3423226067(L_12, /*hidden argument*/NULL);
		NullCheck(L_9);
		ArrayElementTypeCheck (L_9, L_12);
		(L_9)->SetAt(static_cast<il2cpp_array_size_t>(L_11), (Il2CppObject *)L_12);
	}

IL_0069:
	{
		int32_t L_13 = (&V_1)->get_attrs_2();
		if (!((int32_t)((int32_t)L_13&(int32_t)((int32_t)8192))))
		{
			goto IL_00a8;
		}
	}
	{
		IntPtr_t L_14 = __this->get_mhandle_0();
		DllImportAttribute_t3000813225 * L_15 = MonoMethod_GetDllImportAttribute_m2757463479(NULL /*static, unused*/, L_14, /*hidden argument*/NULL);
		V_3 = L_15;
		int32_t L_16 = (&V_1)->get_iattrs_3();
		if (!((int32_t)((int32_t)L_16&(int32_t)((int32_t)128))))
		{
			goto IL_00a0;
		}
	}
	{
		DllImportAttribute_t3000813225 * L_17 = V_3;
		NullCheck(L_17);
		L_17->set_PreserveSig_5((bool)1);
	}

IL_00a0:
	{
		ObjectU5BU5D_t3614634134* L_18 = V_2;
		int32_t L_19 = V_0;
		int32_t L_20 = L_19;
		V_0 = ((int32_t)((int32_t)L_20+(int32_t)1));
		DllImportAttribute_t3000813225 * L_21 = V_3;
		NullCheck(L_18);
		ArrayElementTypeCheck (L_18, L_21);
		(L_18)->SetAt(static_cast<il2cpp_array_size_t>(L_20), (Il2CppObject *)L_21);
	}

IL_00a8:
	{
		ObjectU5BU5D_t3614634134* L_22 = V_2;
		return L_22;
	}
}
// System.Boolean System.Reflection.MonoMethod::ShouldPrintFullName(System.Type)
extern "C"  bool MonoMethod_ShouldPrintFullName_m2343680861 (Il2CppObject * __this /* static, unused */, Type_t * ___type0, const MethodInfo* method)
{
	int32_t G_B5_0 = 0;
	int32_t G_B7_0 = 0;
	int32_t G_B9_0 = 0;
	{
		Type_t * L_0 = ___type0;
		NullCheck(L_0);
		bool L_1 = Type_get_IsClass_m2968663946(L_0, /*hidden argument*/NULL);
		if (!L_1)
		{
			goto IL_003c;
		}
	}
	{
		Type_t * L_2 = ___type0;
		NullCheck(L_2);
		bool L_3 = Type_get_IsPointer_m3832342327(L_2, /*hidden argument*/NULL);
		if (!L_3)
		{
			goto IL_0039;
		}
	}
	{
		Type_t * L_4 = ___type0;
		NullCheck(L_4);
		Type_t * L_5 = VirtFuncInvoker0< Type_t * >::Invoke(42 /* System.Type System.Type::GetElementType() */, L_4);
		NullCheck(L_5);
		bool L_6 = Type_get_IsPrimitive_m1522841565(L_5, /*hidden argument*/NULL);
		if (L_6)
		{
			goto IL_0036;
		}
	}
	{
		Type_t * L_7 = ___type0;
		NullCheck(L_7);
		Type_t * L_8 = VirtFuncInvoker0< Type_t * >::Invoke(42 /* System.Type System.Type::GetElementType() */, L_7);
		NullCheck(L_8);
		bool L_9 = Type_get_IsNested_m3671396733(L_8, /*hidden argument*/NULL);
		G_B5_0 = ((((int32_t)L_9) == ((int32_t)0))? 1 : 0);
		goto IL_0037;
	}

IL_0036:
	{
		G_B5_0 = 0;
	}

IL_0037:
	{
		G_B7_0 = G_B5_0;
		goto IL_003a;
	}

IL_0039:
	{
		G_B7_0 = 1;
	}

IL_003a:
	{
		G_B9_0 = G_B7_0;
		goto IL_003d;
	}

IL_003c:
	{
		G_B9_0 = 0;
	}

IL_003d:
	{
		return (bool)G_B9_0;
	}
}
// System.String System.Reflection.MonoMethod::ToString()
extern Il2CppClass* StringBuilder_t1221177846_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral372029310;
extern Il2CppCodeGenString* _stringLiteral372029431;
extern Il2CppCodeGenString* _stringLiteral372029314;
extern Il2CppCodeGenString* _stringLiteral372029425;
extern Il2CppCodeGenString* _stringLiteral372029318;
extern Il2CppCodeGenString* _stringLiteral811305474;
extern Il2CppCodeGenString* _stringLiteral1271078008;
extern Il2CppCodeGenString* _stringLiteral1623555996;
extern Il2CppCodeGenString* _stringLiteral372029317;
extern const uint32_t MonoMethod_ToString_m1014895917_MetadataUsageId;
extern "C"  String_t* MonoMethod_ToString_m1014895917 (MonoMethod_t * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MonoMethod_ToString_m1014895917_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	StringBuilder_t1221177846 * V_0 = NULL;
	Type_t * V_1 = NULL;
	TypeU5BU5D_t1664964607* V_2 = NULL;
	int32_t V_3 = 0;
	ParameterInfoU5BU5D_t2275869610* V_4 = NULL;
	int32_t V_5 = 0;
	Type_t * V_6 = NULL;
	bool V_7 = false;
	{
		StringBuilder_t1221177846 * L_0 = (StringBuilder_t1221177846 *)il2cpp_codegen_object_new(StringBuilder_t1221177846_il2cpp_TypeInfo_var);
		StringBuilder__ctor_m3946851802(L_0, /*hidden argument*/NULL);
		V_0 = L_0;
		Type_t * L_1 = VirtFuncInvoker0< Type_t * >::Invoke(31 /* System.Type System.Reflection.MonoMethod::get_ReturnType() */, __this);
		V_1 = L_1;
		Type_t * L_2 = V_1;
		bool L_3 = MonoMethod_ShouldPrintFullName_m2343680861(NULL /*static, unused*/, L_2, /*hidden argument*/NULL);
		if (!L_3)
		{
			goto IL_002a;
		}
	}
	{
		StringBuilder_t1221177846 * L_4 = V_0;
		Type_t * L_5 = V_1;
		NullCheck(L_5);
		String_t* L_6 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Type::ToString() */, L_5);
		NullCheck(L_4);
		StringBuilder_Append_m3636508479(L_4, L_6, /*hidden argument*/NULL);
		goto IL_0037;
	}

IL_002a:
	{
		StringBuilder_t1221177846 * L_7 = V_0;
		Type_t * L_8 = V_1;
		NullCheck(L_8);
		String_t* L_9 = VirtFuncInvoker0< String_t* >::Invoke(8 /* System.String System.Reflection.MemberInfo::get_Name() */, L_8);
		NullCheck(L_7);
		StringBuilder_Append_m3636508479(L_7, L_9, /*hidden argument*/NULL);
	}

IL_0037:
	{
		StringBuilder_t1221177846 * L_10 = V_0;
		NullCheck(L_10);
		StringBuilder_Append_m3636508479(L_10, _stringLiteral372029310, /*hidden argument*/NULL);
		StringBuilder_t1221177846 * L_11 = V_0;
		String_t* L_12 = VirtFuncInvoker0< String_t* >::Invoke(8 /* System.String System.Reflection.MonoMethod::get_Name() */, __this);
		NullCheck(L_11);
		StringBuilder_Append_m3636508479(L_11, L_12, /*hidden argument*/NULL);
		bool L_13 = VirtFuncInvoker0< bool >::Invoke(29 /* System.Boolean System.Reflection.MonoMethod::get_IsGenericMethod() */, __this);
		if (!L_13)
		{
			goto IL_00b0;
		}
	}
	{
		TypeU5BU5D_t1664964607* L_14 = VirtFuncInvoker0< TypeU5BU5D_t1664964607* >::Invoke(26 /* System.Type[] System.Reflection.MonoMethod::GetGenericArguments() */, __this);
		V_2 = L_14;
		StringBuilder_t1221177846 * L_15 = V_0;
		NullCheck(L_15);
		StringBuilder_Append_m3636508479(L_15, _stringLiteral372029431, /*hidden argument*/NULL);
		V_3 = 0;
		goto IL_009b;
	}

IL_0075:
	{
		int32_t L_16 = V_3;
		if ((((int32_t)L_16) <= ((int32_t)0)))
		{
			goto IL_0088;
		}
	}
	{
		StringBuilder_t1221177846 * L_17 = V_0;
		NullCheck(L_17);
		StringBuilder_Append_m3636508479(L_17, _stringLiteral372029314, /*hidden argument*/NULL);
	}

IL_0088:
	{
		StringBuilder_t1221177846 * L_18 = V_0;
		TypeU5BU5D_t1664964607* L_19 = V_2;
		int32_t L_20 = V_3;
		NullCheck(L_19);
		int32_t L_21 = L_20;
		Type_t * L_22 = (L_19)->GetAt(static_cast<il2cpp_array_size_t>(L_21));
		NullCheck(L_22);
		String_t* L_23 = VirtFuncInvoker0< String_t* >::Invoke(8 /* System.String System.Reflection.MemberInfo::get_Name() */, L_22);
		NullCheck(L_18);
		StringBuilder_Append_m3636508479(L_18, L_23, /*hidden argument*/NULL);
		int32_t L_24 = V_3;
		V_3 = ((int32_t)((int32_t)L_24+(int32_t)1));
	}

IL_009b:
	{
		int32_t L_25 = V_3;
		TypeU5BU5D_t1664964607* L_26 = V_2;
		NullCheck(L_26);
		if ((((int32_t)L_25) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_26)->max_length)))))))
		{
			goto IL_0075;
		}
	}
	{
		StringBuilder_t1221177846 * L_27 = V_0;
		NullCheck(L_27);
		StringBuilder_Append_m3636508479(L_27, _stringLiteral372029425, /*hidden argument*/NULL);
	}

IL_00b0:
	{
		StringBuilder_t1221177846 * L_28 = V_0;
		NullCheck(L_28);
		StringBuilder_Append_m3636508479(L_28, _stringLiteral372029318, /*hidden argument*/NULL);
		ParameterInfoU5BU5D_t2275869610* L_29 = VirtFuncInvoker0< ParameterInfoU5BU5D_t2275869610* >::Invoke(14 /* System.Reflection.ParameterInfo[] System.Reflection.MonoMethod::GetParameters() */, __this);
		V_4 = L_29;
		V_5 = 0;
		goto IL_014b;
	}

IL_00cc:
	{
		int32_t L_30 = V_5;
		if ((((int32_t)L_30) <= ((int32_t)0)))
		{
			goto IL_00e0;
		}
	}
	{
		StringBuilder_t1221177846 * L_31 = V_0;
		NullCheck(L_31);
		StringBuilder_Append_m3636508479(L_31, _stringLiteral811305474, /*hidden argument*/NULL);
	}

IL_00e0:
	{
		ParameterInfoU5BU5D_t2275869610* L_32 = V_4;
		int32_t L_33 = V_5;
		NullCheck(L_32);
		int32_t L_34 = L_33;
		ParameterInfo_t2249040075 * L_35 = (L_32)->GetAt(static_cast<il2cpp_array_size_t>(L_34));
		NullCheck(L_35);
		Type_t * L_36 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.ParameterInfo::get_ParameterType() */, L_35);
		V_6 = L_36;
		Type_t * L_37 = V_6;
		NullCheck(L_37);
		bool L_38 = Type_get_IsByRef_m3523465500(L_37, /*hidden argument*/NULL);
		V_7 = L_38;
		bool L_39 = V_7;
		if (!L_39)
		{
			goto IL_0105;
		}
	}
	{
		Type_t * L_40 = V_6;
		NullCheck(L_40);
		Type_t * L_41 = VirtFuncInvoker0< Type_t * >::Invoke(42 /* System.Type System.Type::GetElementType() */, L_40);
		V_6 = L_41;
	}

IL_0105:
	{
		Type_t * L_42 = V_6;
		bool L_43 = MonoMethod_ShouldPrintFullName_m2343680861(NULL /*static, unused*/, L_42, /*hidden argument*/NULL);
		if (!L_43)
		{
			goto IL_0124;
		}
	}
	{
		StringBuilder_t1221177846 * L_44 = V_0;
		Type_t * L_45 = V_6;
		NullCheck(L_45);
		String_t* L_46 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Type::ToString() */, L_45);
		NullCheck(L_44);
		StringBuilder_Append_m3636508479(L_44, L_46, /*hidden argument*/NULL);
		goto IL_0132;
	}

IL_0124:
	{
		StringBuilder_t1221177846 * L_47 = V_0;
		Type_t * L_48 = V_6;
		NullCheck(L_48);
		String_t* L_49 = VirtFuncInvoker0< String_t* >::Invoke(8 /* System.String System.Reflection.MemberInfo::get_Name() */, L_48);
		NullCheck(L_47);
		StringBuilder_Append_m3636508479(L_47, L_49, /*hidden argument*/NULL);
	}

IL_0132:
	{
		bool L_50 = V_7;
		if (!L_50)
		{
			goto IL_0145;
		}
	}
	{
		StringBuilder_t1221177846 * L_51 = V_0;
		NullCheck(L_51);
		StringBuilder_Append_m3636508479(L_51, _stringLiteral1271078008, /*hidden argument*/NULL);
	}

IL_0145:
	{
		int32_t L_52 = V_5;
		V_5 = ((int32_t)((int32_t)L_52+(int32_t)1));
	}

IL_014b:
	{
		int32_t L_53 = V_5;
		ParameterInfoU5BU5D_t2275869610* L_54 = V_4;
		NullCheck(L_54);
		if ((((int32_t)L_53) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_54)->max_length)))))))
		{
			goto IL_00cc;
		}
	}
	{
		int32_t L_55 = VirtFuncInvoker0< int32_t >::Invoke(20 /* System.Reflection.CallingConventions System.Reflection.MonoMethod::get_CallingConvention() */, __this);
		if (!((int32_t)((int32_t)L_55&(int32_t)2)))
		{
			goto IL_0185;
		}
	}
	{
		ParameterInfoU5BU5D_t2275869610* L_56 = V_4;
		NullCheck(L_56);
		if ((((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_56)->max_length))))) <= ((int32_t)0)))
		{
			goto IL_0179;
		}
	}
	{
		StringBuilder_t1221177846 * L_57 = V_0;
		NullCheck(L_57);
		StringBuilder_Append_m3636508479(L_57, _stringLiteral811305474, /*hidden argument*/NULL);
	}

IL_0179:
	{
		StringBuilder_t1221177846 * L_58 = V_0;
		NullCheck(L_58);
		StringBuilder_Append_m3636508479(L_58, _stringLiteral1623555996, /*hidden argument*/NULL);
	}

IL_0185:
	{
		StringBuilder_t1221177846 * L_59 = V_0;
		NullCheck(L_59);
		StringBuilder_Append_m3636508479(L_59, _stringLiteral372029317, /*hidden argument*/NULL);
		StringBuilder_t1221177846 * L_60 = V_0;
		NullCheck(L_60);
		String_t* L_61 = StringBuilder_ToString_m1507807375(L_60, /*hidden argument*/NULL);
		return L_61;
	}
}
// System.Void System.Reflection.MonoMethod::GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern "C"  void MonoMethod_GetObjectData_m3146497844 (MonoMethod_t * __this, SerializationInfo_t228987430 * ___info0, StreamingContext_t1417235061  ___context1, const MethodInfo* method)
{
	TypeU5BU5D_t1664964607* V_0 = NULL;
	TypeU5BU5D_t1664964607* G_B4_0 = NULL;
	{
		bool L_0 = VirtFuncInvoker0< bool >::Invoke(29 /* System.Boolean System.Reflection.MonoMethod::get_IsGenericMethod() */, __this);
		if (!L_0)
		{
			goto IL_0021;
		}
	}
	{
		bool L_1 = VirtFuncInvoker0< bool >::Invoke(28 /* System.Boolean System.Reflection.MonoMethod::get_IsGenericMethodDefinition() */, __this);
		if (L_1)
		{
			goto IL_0021;
		}
	}
	{
		TypeU5BU5D_t1664964607* L_2 = VirtFuncInvoker0< TypeU5BU5D_t1664964607* >::Invoke(26 /* System.Type[] System.Reflection.MonoMethod::GetGenericArguments() */, __this);
		G_B4_0 = L_2;
		goto IL_0022;
	}

IL_0021:
	{
		G_B4_0 = ((TypeU5BU5D_t1664964607*)(NULL));
	}

IL_0022:
	{
		V_0 = G_B4_0;
		SerializationInfo_t228987430 * L_3 = ___info0;
		String_t* L_4 = VirtFuncInvoker0< String_t* >::Invoke(8 /* System.String System.Reflection.MonoMethod::get_Name() */, __this);
		Type_t * L_5 = VirtFuncInvoker0< Type_t * >::Invoke(9 /* System.Type System.Reflection.MonoMethod::get_ReflectedType() */, __this);
		String_t* L_6 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Reflection.MonoMethod::ToString() */, __this);
		TypeU5BU5D_t1664964607* L_7 = V_0;
		MemberInfoSerializationHolder_Serialize_m4243060728(NULL /*static, unused*/, L_3, L_4, L_5, L_6, 8, L_7, /*hidden argument*/NULL);
		return;
	}
}
// System.Reflection.MethodInfo System.Reflection.MonoMethod::MakeGenericMethod(System.Type[])
extern Il2CppClass* ArgumentNullException_t628810857_il2cpp_TypeInfo_var;
extern Il2CppClass* Int32_t2071877448_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* ArgumentException_t3259014390_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral56518380;
extern Il2CppCodeGenString* _stringLiteral2401257820;
extern const uint32_t MonoMethod_MakeGenericMethod_m3628255919_MetadataUsageId;
extern "C"  MethodInfo_t * MonoMethod_MakeGenericMethod_m3628255919 (MonoMethod_t * __this, TypeU5BU5D_t1664964607* ___methodInstantiation0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MonoMethod_MakeGenericMethod_m3628255919_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Type_t * V_0 = NULL;
	TypeU5BU5D_t1664964607* V_1 = NULL;
	int32_t V_2 = 0;
	MethodInfo_t * V_3 = NULL;
	{
		TypeU5BU5D_t1664964607* L_0 = ___methodInstantiation0;
		if (L_0)
		{
			goto IL_0011;
		}
	}
	{
		ArgumentNullException_t628810857 * L_1 = (ArgumentNullException_t628810857 *)il2cpp_codegen_object_new(ArgumentNullException_t628810857_il2cpp_TypeInfo_var);
		ArgumentNullException__ctor_m3380712306(L_1, _stringLiteral56518380, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_1);
	}

IL_0011:
	{
		TypeU5BU5D_t1664964607* L_2 = ___methodInstantiation0;
		V_1 = L_2;
		V_2 = 0;
		goto IL_002e;
	}

IL_001a:
	{
		TypeU5BU5D_t1664964607* L_3 = V_1;
		int32_t L_4 = V_2;
		NullCheck(L_3);
		int32_t L_5 = L_4;
		Type_t * L_6 = (L_3)->GetAt(static_cast<il2cpp_array_size_t>(L_5));
		V_0 = L_6;
		Type_t * L_7 = V_0;
		if (L_7)
		{
			goto IL_002a;
		}
	}
	{
		ArgumentNullException_t628810857 * L_8 = (ArgumentNullException_t628810857 *)il2cpp_codegen_object_new(ArgumentNullException_t628810857_il2cpp_TypeInfo_var);
		ArgumentNullException__ctor_m911049464(L_8, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_8);
	}

IL_002a:
	{
		int32_t L_9 = V_2;
		V_2 = ((int32_t)((int32_t)L_9+(int32_t)1));
	}

IL_002e:
	{
		int32_t L_10 = V_2;
		TypeU5BU5D_t1664964607* L_11 = V_1;
		NullCheck(L_11);
		if ((((int32_t)L_10) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_11)->max_length)))))))
		{
			goto IL_001a;
		}
	}
	{
		TypeU5BU5D_t1664964607* L_12 = ___methodInstantiation0;
		MethodInfo_t * L_13 = MonoMethod_MakeGenericMethod_impl_m2063853616(__this, L_12, /*hidden argument*/NULL);
		V_3 = L_13;
		MethodInfo_t * L_14 = V_3;
		if (L_14)
		{
			goto IL_006a;
		}
	}
	{
		TypeU5BU5D_t1664964607* L_15 = VirtFuncInvoker0< TypeU5BU5D_t1664964607* >::Invoke(26 /* System.Type[] System.Reflection.MonoMethod::GetGenericArguments() */, __this);
		NullCheck(L_15);
		int32_t L_16 = (((int32_t)((int32_t)(((Il2CppArray *)L_15)->max_length))));
		Il2CppObject * L_17 = Box(Int32_t2071877448_il2cpp_TypeInfo_var, &L_16);
		TypeU5BU5D_t1664964607* L_18 = ___methodInstantiation0;
		NullCheck(L_18);
		int32_t L_19 = (((int32_t)((int32_t)(((Il2CppArray *)L_18)->max_length))));
		Il2CppObject * L_20 = Box(Int32_t2071877448_il2cpp_TypeInfo_var, &L_19);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_21 = String_Format_m1811873526(NULL /*static, unused*/, _stringLiteral2401257820, L_17, L_20, /*hidden argument*/NULL);
		ArgumentException_t3259014390 * L_22 = (ArgumentException_t3259014390 *)il2cpp_codegen_object_new(ArgumentException_t3259014390_il2cpp_TypeInfo_var);
		ArgumentException__ctor_m3739475201(L_22, L_21, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_22);
	}

IL_006a:
	{
		MethodInfo_t * L_23 = V_3;
		return L_23;
	}
}
// System.Reflection.MethodInfo System.Reflection.MonoMethod::MakeGenericMethod_impl(System.Type[])
extern "C"  MethodInfo_t * MonoMethod_MakeGenericMethod_impl_m2063853616 (MonoMethod_t * __this, TypeU5BU5D_t1664964607* ___types0, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef MethodInfo_t * (*MonoMethod_MakeGenericMethod_impl_m2063853616_ftn) (MonoMethod_t *, TypeU5BU5D_t1664964607*);
	return  ((MonoMethod_MakeGenericMethod_impl_m2063853616_ftn)mscorlib::System::Reflection::MonoMethod::MakeGenericMethod_impl) (__this, ___types0);
}
// System.Type[] System.Reflection.MonoMethod::GetGenericArguments()
extern "C"  TypeU5BU5D_t1664964607* MonoMethod_GetGenericArguments_m1043327523 (MonoMethod_t * __this, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef TypeU5BU5D_t1664964607* (*MonoMethod_GetGenericArguments_m1043327523_ftn) (MonoMethod_t *);
	return  ((MonoMethod_GetGenericArguments_m1043327523_ftn)mscorlib::System::Reflection::MonoMethod::GetGenericArguments) (__this);
}
// System.Boolean System.Reflection.MonoMethod::get_IsGenericMethodDefinition()
extern "C"  bool MonoMethod_get_IsGenericMethodDefinition_m2424433610 (MonoMethod_t * __this, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef bool (*MonoMethod_get_IsGenericMethodDefinition_m2424433610_ftn) (MonoMethod_t *);
	return  ((MonoMethod_get_IsGenericMethodDefinition_m2424433610_ftn)mscorlib::System::Reflection::MonoMethod::get_IsGenericMethodDefinition) (__this);
}
// System.Boolean System.Reflection.MonoMethod::get_IsGenericMethod()
extern "C"  bool MonoMethod_get_IsGenericMethod_m4276550811 (MonoMethod_t * __this, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef bool (*MonoMethod_get_IsGenericMethod_m4276550811_ftn) (MonoMethod_t *);
	return  ((MonoMethod_get_IsGenericMethod_m4276550811_ftn)mscorlib::System::Reflection::MonoMethod::get_IsGenericMethod) (__this);
}
// System.Boolean System.Reflection.MonoMethod::get_ContainsGenericParameters()
extern "C"  bool MonoMethod_get_ContainsGenericParameters_m2891719083 (MonoMethod_t * __this, const MethodInfo* method)
{
	Type_t * V_0 = NULL;
	TypeU5BU5D_t1664964607* V_1 = NULL;
	int32_t V_2 = 0;
	{
		bool L_0 = VirtFuncInvoker0< bool >::Invoke(29 /* System.Boolean System.Reflection.MonoMethod::get_IsGenericMethod() */, __this);
		if (!L_0)
		{
			goto IL_0037;
		}
	}
	{
		TypeU5BU5D_t1664964607* L_1 = VirtFuncInvoker0< TypeU5BU5D_t1664964607* >::Invoke(26 /* System.Type[] System.Reflection.MonoMethod::GetGenericArguments() */, __this);
		V_1 = L_1;
		V_2 = 0;
		goto IL_002e;
	}

IL_0019:
	{
		TypeU5BU5D_t1664964607* L_2 = V_1;
		int32_t L_3 = V_2;
		NullCheck(L_2);
		int32_t L_4 = L_3;
		Type_t * L_5 = (L_2)->GetAt(static_cast<il2cpp_array_size_t>(L_4));
		V_0 = L_5;
		Type_t * L_6 = V_0;
		NullCheck(L_6);
		bool L_7 = VirtFuncInvoker0< bool >::Invoke(76 /* System.Boolean System.Type::get_ContainsGenericParameters() */, L_6);
		if (!L_7)
		{
			goto IL_002a;
		}
	}
	{
		return (bool)1;
	}

IL_002a:
	{
		int32_t L_8 = V_2;
		V_2 = ((int32_t)((int32_t)L_8+(int32_t)1));
	}

IL_002e:
	{
		int32_t L_9 = V_2;
		TypeU5BU5D_t1664964607* L_10 = V_1;
		NullCheck(L_10);
		if ((((int32_t)L_9) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_10)->max_length)))))))
		{
			goto IL_0019;
		}
	}

IL_0037:
	{
		Type_t * L_11 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.MonoMethod::get_DeclaringType() */, __this);
		NullCheck(L_11);
		bool L_12 = VirtFuncInvoker0< bool >::Invoke(76 /* System.Boolean System.Type::get_ContainsGenericParameters() */, L_11);
		return L_12;
	}
}
// System.Void System.Reflection.MonoMethodInfo::get_method_info(System.IntPtr,System.Reflection.MonoMethodInfo&)
extern "C"  void MonoMethodInfo_get_method_info_m3630911979 (Il2CppObject * __this /* static, unused */, IntPtr_t ___handle0, MonoMethodInfo_t3646562144 * ___info1, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef void (*MonoMethodInfo_get_method_info_m3630911979_ftn) (IntPtr_t, MonoMethodInfo_t3646562144 *);
	 ((MonoMethodInfo_get_method_info_m3630911979_ftn)mscorlib::System::Reflection::MonoMethodInfo::get_method_info) (___handle0, ___info1);
}
// System.Reflection.MonoMethodInfo System.Reflection.MonoMethodInfo::GetMethodInfo(System.IntPtr)
extern "C"  MonoMethodInfo_t3646562144  MonoMethodInfo_GetMethodInfo_m3298558752 (Il2CppObject * __this /* static, unused */, IntPtr_t ___handle0, const MethodInfo* method)
{
	MonoMethodInfo_t3646562144  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		IntPtr_t L_0 = ___handle0;
		MonoMethodInfo_get_method_info_m3630911979(NULL /*static, unused*/, L_0, (&V_0), /*hidden argument*/NULL);
		MonoMethodInfo_t3646562144  L_1 = V_0;
		return L_1;
	}
}
// System.Type System.Reflection.MonoMethodInfo::GetDeclaringType(System.IntPtr)
extern "C"  Type_t * MonoMethodInfo_GetDeclaringType_m4186531677 (Il2CppObject * __this /* static, unused */, IntPtr_t ___handle0, const MethodInfo* method)
{
	MonoMethodInfo_t3646562144  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		IntPtr_t L_0 = ___handle0;
		MonoMethodInfo_t3646562144  L_1 = MonoMethodInfo_GetMethodInfo_m3298558752(NULL /*static, unused*/, L_0, /*hidden argument*/NULL);
		V_0 = L_1;
		Type_t * L_2 = (&V_0)->get_parent_0();
		return L_2;
	}
}
// System.Type System.Reflection.MonoMethodInfo::GetReturnType(System.IntPtr)
extern "C"  Type_t * MonoMethodInfo_GetReturnType_m2864247130 (Il2CppObject * __this /* static, unused */, IntPtr_t ___handle0, const MethodInfo* method)
{
	MonoMethodInfo_t3646562144  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		IntPtr_t L_0 = ___handle0;
		MonoMethodInfo_t3646562144  L_1 = MonoMethodInfo_GetMethodInfo_m3298558752(NULL /*static, unused*/, L_0, /*hidden argument*/NULL);
		V_0 = L_1;
		Type_t * L_2 = (&V_0)->get_ret_1();
		return L_2;
	}
}
// System.Reflection.MethodAttributes System.Reflection.MonoMethodInfo::GetAttributes(System.IntPtr)
extern "C"  int32_t MonoMethodInfo_GetAttributes_m2535493430 (Il2CppObject * __this /* static, unused */, IntPtr_t ___handle0, const MethodInfo* method)
{
	MonoMethodInfo_t3646562144  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		IntPtr_t L_0 = ___handle0;
		MonoMethodInfo_t3646562144  L_1 = MonoMethodInfo_GetMethodInfo_m3298558752(NULL /*static, unused*/, L_0, /*hidden argument*/NULL);
		V_0 = L_1;
		int32_t L_2 = (&V_0)->get_attrs_2();
		return L_2;
	}
}
// System.Reflection.CallingConventions System.Reflection.MonoMethodInfo::GetCallingConvention(System.IntPtr)
extern "C"  int32_t MonoMethodInfo_GetCallingConvention_m3095860872 (Il2CppObject * __this /* static, unused */, IntPtr_t ___handle0, const MethodInfo* method)
{
	MonoMethodInfo_t3646562144  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		IntPtr_t L_0 = ___handle0;
		MonoMethodInfo_t3646562144  L_1 = MonoMethodInfo_GetMethodInfo_m3298558752(NULL /*static, unused*/, L_0, /*hidden argument*/NULL);
		V_0 = L_1;
		int32_t L_2 = (&V_0)->get_callconv_4();
		return L_2;
	}
}
// System.Reflection.ParameterInfo[] System.Reflection.MonoMethodInfo::get_parameter_info(System.IntPtr,System.Reflection.MemberInfo)
extern "C"  ParameterInfoU5BU5D_t2275869610* MonoMethodInfo_get_parameter_info_m3554140855 (Il2CppObject * __this /* static, unused */, IntPtr_t ___handle0, MemberInfo_t * ___member1, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef ParameterInfoU5BU5D_t2275869610* (*MonoMethodInfo_get_parameter_info_m3554140855_ftn) (IntPtr_t, MemberInfo_t *);
	return  ((MonoMethodInfo_get_parameter_info_m3554140855_ftn)mscorlib::System::Reflection::MonoMethodInfo::get_parameter_info) (___handle0, ___member1);
}
// System.Reflection.ParameterInfo[] System.Reflection.MonoMethodInfo::GetParametersInfo(System.IntPtr,System.Reflection.MemberInfo)
extern "C"  ParameterInfoU5BU5D_t2275869610* MonoMethodInfo_GetParametersInfo_m3456861922 (Il2CppObject * __this /* static, unused */, IntPtr_t ___handle0, MemberInfo_t * ___member1, const MethodInfo* method)
{
	{
		IntPtr_t L_0 = ___handle0;
		MemberInfo_t * L_1 = ___member1;
		ParameterInfoU5BU5D_t2275869610* L_2 = MonoMethodInfo_get_parameter_info_m3554140855(NULL /*static, unused*/, L_0, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// Conversion methods for marshalling of: System.Reflection.MonoMethodInfo
extern "C" void MonoMethodInfo_t3646562144_marshal_pinvoke(const MonoMethodInfo_t3646562144& unmarshaled, MonoMethodInfo_t3646562144_marshaled_pinvoke& marshaled)
{
	Il2CppCodeGenException* ___parent_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'parent' of type 'MonoMethodInfo': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___parent_0Exception);
}
extern "C" void MonoMethodInfo_t3646562144_marshal_pinvoke_back(const MonoMethodInfo_t3646562144_marshaled_pinvoke& marshaled, MonoMethodInfo_t3646562144& unmarshaled)
{
	Il2CppCodeGenException* ___parent_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'parent' of type 'MonoMethodInfo': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___parent_0Exception);
}
// Conversion method for clean up from marshalling of: System.Reflection.MonoMethodInfo
extern "C" void MonoMethodInfo_t3646562144_marshal_pinvoke_cleanup(MonoMethodInfo_t3646562144_marshaled_pinvoke& marshaled)
{
}
// Conversion methods for marshalling of: System.Reflection.MonoMethodInfo
extern "C" void MonoMethodInfo_t3646562144_marshal_com(const MonoMethodInfo_t3646562144& unmarshaled, MonoMethodInfo_t3646562144_marshaled_com& marshaled)
{
	Il2CppCodeGenException* ___parent_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'parent' of type 'MonoMethodInfo': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___parent_0Exception);
}
extern "C" void MonoMethodInfo_t3646562144_marshal_com_back(const MonoMethodInfo_t3646562144_marshaled_com& marshaled, MonoMethodInfo_t3646562144& unmarshaled)
{
	Il2CppCodeGenException* ___parent_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'parent' of type 'MonoMethodInfo': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___parent_0Exception);
}
// Conversion method for clean up from marshalling of: System.Reflection.MonoMethodInfo
extern "C" void MonoMethodInfo_t3646562144_marshal_com_cleanup(MonoMethodInfo_t3646562144_marshaled_com& marshaled)
{
}
// System.Void System.Reflection.MonoProperty::.ctor()
extern "C"  void MonoProperty__ctor_m945517100 (MonoProperty_t * __this, const MethodInfo* method)
{
	{
		PropertyInfo__ctor_m1808219471(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Reflection.MonoProperty::CachePropertyInfo(System.Reflection.PInfo)
extern "C"  void MonoProperty_CachePropertyInfo_m1437316683 (MonoProperty_t * __this, int32_t ___flags0, const MethodInfo* method)
{
	{
		int32_t L_0 = __this->get_cached_3();
		int32_t L_1 = ___flags0;
		int32_t L_2 = ___flags0;
		if ((((int32_t)((int32_t)((int32_t)L_0&(int32_t)L_1))) == ((int32_t)L_2)))
		{
			goto IL_0029;
		}
	}
	{
		MonoPropertyInfo_t486106184 * L_3 = __this->get_address_of_info_2();
		int32_t L_4 = ___flags0;
		MonoPropertyInfo_get_property_info_m556498347(NULL /*static, unused*/, __this, L_3, L_4, /*hidden argument*/NULL);
		int32_t L_5 = __this->get_cached_3();
		int32_t L_6 = ___flags0;
		__this->set_cached_3(((int32_t)((int32_t)L_5|(int32_t)L_6)));
	}

IL_0029:
	{
		return;
	}
}
// System.Reflection.PropertyAttributes System.Reflection.MonoProperty::get_Attributes()
extern "C"  int32_t MonoProperty_get_Attributes_m2589593297 (MonoProperty_t * __this, const MethodInfo* method)
{
	{
		MonoProperty_CachePropertyInfo_m1437316683(__this, 1, /*hidden argument*/NULL);
		MonoPropertyInfo_t486106184 * L_0 = __this->get_address_of_info_2();
		int32_t L_1 = L_0->get_attrs_4();
		return L_1;
	}
}
// System.Boolean System.Reflection.MonoProperty::get_CanRead()
extern "C"  bool MonoProperty_get_CanRead_m1173212369 (MonoProperty_t * __this, const MethodInfo* method)
{
	{
		MonoProperty_CachePropertyInfo_m1437316683(__this, 2, /*hidden argument*/NULL);
		MonoPropertyInfo_t486106184 * L_0 = __this->get_address_of_info_2();
		MethodInfo_t * L_1 = L_0->get_get_method_2();
		return (bool)((((int32_t)((((Il2CppObject*)(MethodInfo_t *)L_1) == ((Il2CppObject*)(Il2CppObject *)NULL))? 1 : 0)) == ((int32_t)0))? 1 : 0);
	}
}
// System.Boolean System.Reflection.MonoProperty::get_CanWrite()
extern "C"  bool MonoProperty_get_CanWrite_m2124922514 (MonoProperty_t * __this, const MethodInfo* method)
{
	{
		MonoProperty_CachePropertyInfo_m1437316683(__this, 4, /*hidden argument*/NULL);
		MonoPropertyInfo_t486106184 * L_0 = __this->get_address_of_info_2();
		MethodInfo_t * L_1 = L_0->get_set_method_3();
		return (bool)((((int32_t)((((Il2CppObject*)(MethodInfo_t *)L_1) == ((Il2CppObject*)(Il2CppObject *)NULL))? 1 : 0)) == ((int32_t)0))? 1 : 0);
	}
}
// System.Type System.Reflection.MonoProperty::get_PropertyType()
extern "C"  Type_t * MonoProperty_get_PropertyType_m1921201152 (MonoProperty_t * __this, const MethodInfo* method)
{
	ParameterInfoU5BU5D_t2275869610* V_0 = NULL;
	{
		MonoProperty_CachePropertyInfo_m1437316683(__this, 6, /*hidden argument*/NULL);
		MonoPropertyInfo_t486106184 * L_0 = __this->get_address_of_info_2();
		MethodInfo_t * L_1 = L_0->get_get_method_2();
		if (!L_1)
		{
			goto IL_0028;
		}
	}
	{
		MonoPropertyInfo_t486106184 * L_2 = __this->get_address_of_info_2();
		MethodInfo_t * L_3 = L_2->get_get_method_2();
		NullCheck(L_3);
		Type_t * L_4 = VirtFuncInvoker0< Type_t * >::Invoke(31 /* System.Type System.Reflection.MethodInfo::get_ReturnType() */, L_3);
		return L_4;
	}

IL_0028:
	{
		MonoPropertyInfo_t486106184 * L_5 = __this->get_address_of_info_2();
		MethodInfo_t * L_6 = L_5->get_set_method_3();
		NullCheck(L_6);
		ParameterInfoU5BU5D_t2275869610* L_7 = VirtFuncInvoker0< ParameterInfoU5BU5D_t2275869610* >::Invoke(14 /* System.Reflection.ParameterInfo[] System.Reflection.MethodBase::GetParameters() */, L_6);
		V_0 = L_7;
		ParameterInfoU5BU5D_t2275869610* L_8 = V_0;
		ParameterInfoU5BU5D_t2275869610* L_9 = V_0;
		NullCheck(L_9);
		NullCheck(L_8);
		int32_t L_10 = ((int32_t)((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_9)->max_length))))-(int32_t)1));
		ParameterInfo_t2249040075 * L_11 = (L_8)->GetAt(static_cast<il2cpp_array_size_t>(L_10));
		NullCheck(L_11);
		Type_t * L_12 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.ParameterInfo::get_ParameterType() */, L_11);
		return L_12;
	}
}
// System.Type System.Reflection.MonoProperty::get_ReflectedType()
extern "C"  Type_t * MonoProperty_get_ReflectedType_m903353661 (MonoProperty_t * __this, const MethodInfo* method)
{
	{
		MonoProperty_CachePropertyInfo_m1437316683(__this, 8, /*hidden argument*/NULL);
		MonoPropertyInfo_t486106184 * L_0 = __this->get_address_of_info_2();
		Type_t * L_1 = L_0->get_parent_0();
		return L_1;
	}
}
// System.Type System.Reflection.MonoProperty::get_DeclaringType()
extern "C"  Type_t * MonoProperty_get_DeclaringType_m4236036432 (MonoProperty_t * __this, const MethodInfo* method)
{
	{
		MonoProperty_CachePropertyInfo_m1437316683(__this, ((int32_t)16), /*hidden argument*/NULL);
		MonoPropertyInfo_t486106184 * L_0 = __this->get_address_of_info_2();
		Type_t * L_1 = L_0->get_parent_0();
		return L_1;
	}
}
// System.String System.Reflection.MonoProperty::get_Name()
extern "C"  String_t* MonoProperty_get_Name_m1248249317 (MonoProperty_t * __this, const MethodInfo* method)
{
	{
		MonoProperty_CachePropertyInfo_m1437316683(__this, ((int32_t)32), /*hidden argument*/NULL);
		MonoPropertyInfo_t486106184 * L_0 = __this->get_address_of_info_2();
		String_t* L_1 = L_0->get_name_1();
		return L_1;
	}
}
// System.Reflection.MethodInfo[] System.Reflection.MonoProperty::GetAccessors(System.Boolean)
extern Il2CppClass* MethodInfoU5BU5D_t152480188_il2cpp_TypeInfo_var;
extern const uint32_t MonoProperty_GetAccessors_m3704698731_MetadataUsageId;
extern "C"  MethodInfoU5BU5D_t152480188* MonoProperty_GetAccessors_m3704698731 (MonoProperty_t * __this, bool ___nonPublic0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MonoProperty_GetAccessors_m3704698731_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	MethodInfoU5BU5D_t152480188* V_2 = NULL;
	int32_t V_3 = 0;
	{
		V_0 = 0;
		V_1 = 0;
		MonoProperty_CachePropertyInfo_m1437316683(__this, 6, /*hidden argument*/NULL);
		MonoPropertyInfo_t486106184 * L_0 = __this->get_address_of_info_2();
		MethodInfo_t * L_1 = L_0->get_set_method_3();
		if (!L_1)
		{
			goto IL_0038;
		}
	}
	{
		bool L_2 = ___nonPublic0;
		if (L_2)
		{
			goto IL_0036;
		}
	}
	{
		MonoPropertyInfo_t486106184 * L_3 = __this->get_address_of_info_2();
		MethodInfo_t * L_4 = L_3->get_set_method_3();
		NullCheck(L_4);
		bool L_5 = MethodBase_get_IsPublic_m479656180(L_4, /*hidden argument*/NULL);
		if (!L_5)
		{
			goto IL_0038;
		}
	}

IL_0036:
	{
		V_1 = 1;
	}

IL_0038:
	{
		MonoPropertyInfo_t486106184 * L_6 = __this->get_address_of_info_2();
		MethodInfo_t * L_7 = L_6->get_get_method_2();
		if (!L_7)
		{
			goto IL_0065;
		}
	}
	{
		bool L_8 = ___nonPublic0;
		if (L_8)
		{
			goto IL_0063;
		}
	}
	{
		MonoPropertyInfo_t486106184 * L_9 = __this->get_address_of_info_2();
		MethodInfo_t * L_10 = L_9->get_get_method_2();
		NullCheck(L_10);
		bool L_11 = MethodBase_get_IsPublic_m479656180(L_10, /*hidden argument*/NULL);
		if (!L_11)
		{
			goto IL_0065;
		}
	}

IL_0063:
	{
		V_0 = 1;
	}

IL_0065:
	{
		int32_t L_12 = V_0;
		int32_t L_13 = V_1;
		V_2 = ((MethodInfoU5BU5D_t152480188*)SZArrayNew(MethodInfoU5BU5D_t152480188_il2cpp_TypeInfo_var, (uint32_t)((int32_t)((int32_t)L_12+(int32_t)L_13))));
		V_3 = 0;
		int32_t L_14 = V_1;
		if (!L_14)
		{
			goto IL_0088;
		}
	}
	{
		MethodInfoU5BU5D_t152480188* L_15 = V_2;
		int32_t L_16 = V_3;
		int32_t L_17 = L_16;
		V_3 = ((int32_t)((int32_t)L_17+(int32_t)1));
		MonoPropertyInfo_t486106184 * L_18 = __this->get_address_of_info_2();
		MethodInfo_t * L_19 = L_18->get_set_method_3();
		NullCheck(L_15);
		ArrayElementTypeCheck (L_15, L_19);
		(L_15)->SetAt(static_cast<il2cpp_array_size_t>(L_17), (MethodInfo_t *)L_19);
	}

IL_0088:
	{
		int32_t L_20 = V_0;
		if (!L_20)
		{
			goto IL_00a0;
		}
	}
	{
		MethodInfoU5BU5D_t152480188* L_21 = V_2;
		int32_t L_22 = V_3;
		int32_t L_23 = L_22;
		V_3 = ((int32_t)((int32_t)L_23+(int32_t)1));
		MonoPropertyInfo_t486106184 * L_24 = __this->get_address_of_info_2();
		MethodInfo_t * L_25 = L_24->get_get_method_2();
		NullCheck(L_21);
		ArrayElementTypeCheck (L_21, L_25);
		(L_21)->SetAt(static_cast<il2cpp_array_size_t>(L_23), (MethodInfo_t *)L_25);
	}

IL_00a0:
	{
		MethodInfoU5BU5D_t152480188* L_26 = V_2;
		return L_26;
	}
}
// System.Reflection.MethodInfo System.Reflection.MonoProperty::GetGetMethod(System.Boolean)
extern "C"  MethodInfo_t * MonoProperty_GetGetMethod_m1100580870 (MonoProperty_t * __this, bool ___nonPublic0, const MethodInfo* method)
{
	{
		MonoProperty_CachePropertyInfo_m1437316683(__this, 2, /*hidden argument*/NULL);
		MonoPropertyInfo_t486106184 * L_0 = __this->get_address_of_info_2();
		MethodInfo_t * L_1 = L_0->get_get_method_2();
		if (!L_1)
		{
			goto IL_003e;
		}
	}
	{
		bool L_2 = ___nonPublic0;
		if (L_2)
		{
			goto IL_0032;
		}
	}
	{
		MonoPropertyInfo_t486106184 * L_3 = __this->get_address_of_info_2();
		MethodInfo_t * L_4 = L_3->get_get_method_2();
		NullCheck(L_4);
		bool L_5 = MethodBase_get_IsPublic_m479656180(L_4, /*hidden argument*/NULL);
		if (!L_5)
		{
			goto IL_003e;
		}
	}

IL_0032:
	{
		MonoPropertyInfo_t486106184 * L_6 = __this->get_address_of_info_2();
		MethodInfo_t * L_7 = L_6->get_get_method_2();
		return L_7;
	}

IL_003e:
	{
		return (MethodInfo_t *)NULL;
	}
}
// System.Reflection.ParameterInfo[] System.Reflection.MonoProperty::GetIndexParameters()
extern Il2CppClass* ParameterInfoU5BU5D_t2275869610_il2cpp_TypeInfo_var;
extern Il2CppClass* ParameterInfo_t2249040075_il2cpp_TypeInfo_var;
extern const uint32_t MonoProperty_GetIndexParameters_m832800404_MetadataUsageId;
extern "C"  ParameterInfoU5BU5D_t2275869610* MonoProperty_GetIndexParameters_m832800404 (MonoProperty_t * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MonoProperty_GetIndexParameters_m832800404_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ParameterInfoU5BU5D_t2275869610* V_0 = NULL;
	ParameterInfoU5BU5D_t2275869610* V_1 = NULL;
	int32_t V_2 = 0;
	ParameterInfo_t2249040075 * V_3 = NULL;
	{
		MonoProperty_CachePropertyInfo_m1437316683(__this, 6, /*hidden argument*/NULL);
		MonoPropertyInfo_t486106184 * L_0 = __this->get_address_of_info_2();
		MethodInfo_t * L_1 = L_0->get_get_method_2();
		if (!L_1)
		{
			goto IL_002d;
		}
	}
	{
		MonoPropertyInfo_t486106184 * L_2 = __this->get_address_of_info_2();
		MethodInfo_t * L_3 = L_2->get_get_method_2();
		NullCheck(L_3);
		ParameterInfoU5BU5D_t2275869610* L_4 = VirtFuncInvoker0< ParameterInfoU5BU5D_t2275869610* >::Invoke(14 /* System.Reflection.ParameterInfo[] System.Reflection.MethodBase::GetParameters() */, L_3);
		V_0 = L_4;
		goto IL_006f;
	}

IL_002d:
	{
		MonoPropertyInfo_t486106184 * L_5 = __this->get_address_of_info_2();
		MethodInfo_t * L_6 = L_5->get_set_method_3();
		if (!L_6)
		{
			goto IL_0068;
		}
	}
	{
		MonoPropertyInfo_t486106184 * L_7 = __this->get_address_of_info_2();
		MethodInfo_t * L_8 = L_7->get_set_method_3();
		NullCheck(L_8);
		ParameterInfoU5BU5D_t2275869610* L_9 = VirtFuncInvoker0< ParameterInfoU5BU5D_t2275869610* >::Invoke(14 /* System.Reflection.ParameterInfo[] System.Reflection.MethodBase::GetParameters() */, L_8);
		V_1 = L_9;
		ParameterInfoU5BU5D_t2275869610* L_10 = V_1;
		NullCheck(L_10);
		V_0 = ((ParameterInfoU5BU5D_t2275869610*)SZArrayNew(ParameterInfoU5BU5D_t2275869610_il2cpp_TypeInfo_var, (uint32_t)((int32_t)((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_10)->max_length))))-(int32_t)1))));
		ParameterInfoU5BU5D_t2275869610* L_11 = V_1;
		ParameterInfoU5BU5D_t2275869610* L_12 = V_0;
		ParameterInfoU5BU5D_t2275869610* L_13 = V_0;
		NullCheck(L_13);
		Array_Copy_m2363740072(NULL /*static, unused*/, (Il2CppArray *)(Il2CppArray *)L_11, (Il2CppArray *)(Il2CppArray *)L_12, (((int32_t)((int32_t)(((Il2CppArray *)L_13)->max_length)))), /*hidden argument*/NULL);
		goto IL_006f;
	}

IL_0068:
	{
		return ((ParameterInfoU5BU5D_t2275869610*)SZArrayNew(ParameterInfoU5BU5D_t2275869610_il2cpp_TypeInfo_var, (uint32_t)0));
	}

IL_006f:
	{
		V_2 = 0;
		goto IL_0088;
	}

IL_0076:
	{
		ParameterInfoU5BU5D_t2275869610* L_14 = V_0;
		int32_t L_15 = V_2;
		NullCheck(L_14);
		int32_t L_16 = L_15;
		ParameterInfo_t2249040075 * L_17 = (L_14)->GetAt(static_cast<il2cpp_array_size_t>(L_16));
		V_3 = L_17;
		ParameterInfoU5BU5D_t2275869610* L_18 = V_0;
		int32_t L_19 = V_2;
		ParameterInfo_t2249040075 * L_20 = V_3;
		ParameterInfo_t2249040075 * L_21 = (ParameterInfo_t2249040075 *)il2cpp_codegen_object_new(ParameterInfo_t2249040075_il2cpp_TypeInfo_var);
		ParameterInfo__ctor_m3204994840(L_21, L_20, __this, /*hidden argument*/NULL);
		NullCheck(L_18);
		ArrayElementTypeCheck (L_18, L_21);
		(L_18)->SetAt(static_cast<il2cpp_array_size_t>(L_19), (ParameterInfo_t2249040075 *)L_21);
		int32_t L_22 = V_2;
		V_2 = ((int32_t)((int32_t)L_22+(int32_t)1));
	}

IL_0088:
	{
		int32_t L_23 = V_2;
		ParameterInfoU5BU5D_t2275869610* L_24 = V_0;
		NullCheck(L_24);
		if ((((int32_t)L_23) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_24)->max_length)))))))
		{
			goto IL_0076;
		}
	}
	{
		ParameterInfoU5BU5D_t2275869610* L_25 = V_0;
		return L_25;
	}
}
// System.Reflection.MethodInfo System.Reflection.MonoProperty::GetSetMethod(System.Boolean)
extern "C"  MethodInfo_t * MonoProperty_GetSetMethod_m436306154 (MonoProperty_t * __this, bool ___nonPublic0, const MethodInfo* method)
{
	{
		MonoProperty_CachePropertyInfo_m1437316683(__this, 4, /*hidden argument*/NULL);
		MonoPropertyInfo_t486106184 * L_0 = __this->get_address_of_info_2();
		MethodInfo_t * L_1 = L_0->get_set_method_3();
		if (!L_1)
		{
			goto IL_003e;
		}
	}
	{
		bool L_2 = ___nonPublic0;
		if (L_2)
		{
			goto IL_0032;
		}
	}
	{
		MonoPropertyInfo_t486106184 * L_3 = __this->get_address_of_info_2();
		MethodInfo_t * L_4 = L_3->get_set_method_3();
		NullCheck(L_4);
		bool L_5 = MethodBase_get_IsPublic_m479656180(L_4, /*hidden argument*/NULL);
		if (!L_5)
		{
			goto IL_003e;
		}
	}

IL_0032:
	{
		MonoPropertyInfo_t486106184 * L_6 = __this->get_address_of_info_2();
		MethodInfo_t * L_7 = L_6->get_set_method_3();
		return L_7;
	}

IL_003e:
	{
		return (MethodInfo_t *)NULL;
	}
}
// System.Boolean System.Reflection.MonoProperty::IsDefined(System.Type,System.Boolean)
extern Il2CppClass* MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var;
extern const uint32_t MonoProperty_IsDefined_m2473061021_MetadataUsageId;
extern "C"  bool MonoProperty_IsDefined_m2473061021 (MonoProperty_t * __this, Type_t * ___attributeType0, bool ___inherit1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MonoProperty_IsDefined_m2473061021_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Type_t * L_0 = ___attributeType0;
		IL2CPP_RUNTIME_CLASS_INIT(MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var);
		bool L_1 = MonoCustomAttrs_IsDefined_m3820363041(NULL /*static, unused*/, __this, L_0, (bool)0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Object[] System.Reflection.MonoProperty::GetCustomAttributes(System.Boolean)
extern Il2CppClass* MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var;
extern const uint32_t MonoProperty_GetCustomAttributes_m1497967922_MetadataUsageId;
extern "C"  ObjectU5BU5D_t3614634134* MonoProperty_GetCustomAttributes_m1497967922 (MonoProperty_t * __this, bool ___inherit0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MonoProperty_GetCustomAttributes_m1497967922_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var);
		ObjectU5BU5D_t3614634134* L_0 = MonoCustomAttrs_GetCustomAttributes_m3069779582(NULL /*static, unused*/, __this, (bool)0, /*hidden argument*/NULL);
		return L_0;
	}
}
// System.Object[] System.Reflection.MonoProperty::GetCustomAttributes(System.Type,System.Boolean)
extern Il2CppClass* MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var;
extern const uint32_t MonoProperty_GetCustomAttributes_m1756234231_MetadataUsageId;
extern "C"  ObjectU5BU5D_t3614634134* MonoProperty_GetCustomAttributes_m1756234231 (MonoProperty_t * __this, Type_t * ___attributeType0, bool ___inherit1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MonoProperty_GetCustomAttributes_m1756234231_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Type_t * L_0 = ___attributeType0;
		IL2CPP_RUNTIME_CLASS_INIT(MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var);
		ObjectU5BU5D_t3614634134* L_1 = MonoCustomAttrs_GetCustomAttributes_m939426263(NULL /*static, unused*/, __this, L_0, (bool)0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Reflection.MonoProperty/GetterAdapter System.Reflection.MonoProperty::CreateGetterDelegate(System.Reflection.MethodInfo)
extern const Il2CppType* StaticGetter_1_t2308823731_0_0_0_var;
extern const Il2CppType* Getter_2_t3970651952_0_0_0_var;
extern const Il2CppType* MonoProperty_t_0_0_0_var;
extern const Il2CppType* GetterAdapter_t1423755509_0_0_0_var;
extern Il2CppClass* TypeU5BU5D_t1664964607_il2cpp_TypeInfo_var;
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern Il2CppClass* MethodAccessException_t4093255254_il2cpp_TypeInfo_var;
extern Il2CppClass* GetterAdapter_t1423755509_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral984599999;
extern Il2CppCodeGenString* _stringLiteral3063456723;
extern const uint32_t MonoProperty_CreateGetterDelegate_m2961258839_MetadataUsageId;
extern "C"  GetterAdapter_t1423755509 * MonoProperty_CreateGetterDelegate_m2961258839 (Il2CppObject * __this /* static, unused */, MethodInfo_t * ___method0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MonoProperty_CreateGetterDelegate_m2961258839_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	TypeU5BU5D_t1664964607* V_0 = NULL;
	Type_t * V_1 = NULL;
	Il2CppObject * V_2 = NULL;
	MethodInfo_t * V_3 = NULL;
	Type_t * V_4 = NULL;
	String_t* V_5 = NULL;
	{
		MethodInfo_t * L_0 = ___method0;
		NullCheck(L_0);
		bool L_1 = MethodBase_get_IsStatic_m1015686807(L_0, /*hidden argument*/NULL);
		if (!L_1)
		{
			goto IL_0033;
		}
	}
	{
		TypeU5BU5D_t1664964607* L_2 = ((TypeU5BU5D_t1664964607*)SZArrayNew(TypeU5BU5D_t1664964607_il2cpp_TypeInfo_var, (uint32_t)1));
		MethodInfo_t * L_3 = ___method0;
		NullCheck(L_3);
		Type_t * L_4 = VirtFuncInvoker0< Type_t * >::Invoke(31 /* System.Type System.Reflection.MethodInfo::get_ReturnType() */, L_3);
		NullCheck(L_2);
		ArrayElementTypeCheck (L_2, L_4);
		(L_2)->SetAt(static_cast<il2cpp_array_size_t>(0), (Type_t *)L_4);
		V_0 = L_2;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_5 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(StaticGetter_1_t2308823731_0_0_0_var), /*hidden argument*/NULL);
		V_4 = L_5;
		V_5 = _stringLiteral984599999;
		goto IL_005f;
	}

IL_0033:
	{
		TypeU5BU5D_t1664964607* L_6 = ((TypeU5BU5D_t1664964607*)SZArrayNew(TypeU5BU5D_t1664964607_il2cpp_TypeInfo_var, (uint32_t)2));
		MethodInfo_t * L_7 = ___method0;
		NullCheck(L_7);
		Type_t * L_8 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.MemberInfo::get_DeclaringType() */, L_7);
		NullCheck(L_6);
		ArrayElementTypeCheck (L_6, L_8);
		(L_6)->SetAt(static_cast<il2cpp_array_size_t>(0), (Type_t *)L_8);
		TypeU5BU5D_t1664964607* L_9 = L_6;
		MethodInfo_t * L_10 = ___method0;
		NullCheck(L_10);
		Type_t * L_11 = VirtFuncInvoker0< Type_t * >::Invoke(31 /* System.Type System.Reflection.MethodInfo::get_ReturnType() */, L_10);
		NullCheck(L_9);
		ArrayElementTypeCheck (L_9, L_11);
		(L_9)->SetAt(static_cast<il2cpp_array_size_t>(1), (Type_t *)L_11);
		V_0 = L_9;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_12 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Getter_2_t3970651952_0_0_0_var), /*hidden argument*/NULL);
		V_4 = L_12;
		V_5 = _stringLiteral3063456723;
	}

IL_005f:
	{
		Type_t * L_13 = V_4;
		TypeU5BU5D_t1664964607* L_14 = V_0;
		NullCheck(L_13);
		Type_t * L_15 = VirtFuncInvoker1< Type_t *, TypeU5BU5D_t1664964607* >::Invoke(80 /* System.Type System.Type::MakeGenericType(System.Type[]) */, L_13, L_14);
		V_1 = L_15;
		Type_t * L_16 = V_1;
		MethodInfo_t * L_17 = ___method0;
		Delegate_t3022476291 * L_18 = Delegate_CreateDelegate_m3813023227(NULL /*static, unused*/, L_16, L_17, (bool)0, /*hidden argument*/NULL);
		V_2 = L_18;
		Il2CppObject * L_19 = V_2;
		if (L_19)
		{
			goto IL_007d;
		}
	}
	{
		MethodAccessException_t4093255254 * L_20 = (MethodAccessException_t4093255254 *)il2cpp_codegen_object_new(MethodAccessException_t4093255254_il2cpp_TypeInfo_var);
		MethodAccessException__ctor_m3450464547(L_20, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_20);
	}

IL_007d:
	{
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_21 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(MonoProperty_t_0_0_0_var), /*hidden argument*/NULL);
		String_t* L_22 = V_5;
		NullCheck(L_21);
		MethodInfo_t * L_23 = Type_GetMethod_m475234662(L_21, L_22, ((int32_t)40), /*hidden argument*/NULL);
		V_3 = L_23;
		MethodInfo_t * L_24 = V_3;
		TypeU5BU5D_t1664964607* L_25 = V_0;
		NullCheck(L_24);
		MethodInfo_t * L_26 = VirtFuncInvoker1< MethodInfo_t *, TypeU5BU5D_t1664964607* >::Invoke(32 /* System.Reflection.MethodInfo System.Reflection.MethodInfo::MakeGenericMethod(System.Type[]) */, L_24, L_25);
		V_3 = L_26;
		Type_t * L_27 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(GetterAdapter_t1423755509_0_0_0_var), /*hidden argument*/NULL);
		Il2CppObject * L_28 = V_2;
		MethodInfo_t * L_29 = V_3;
		Delegate_t3022476291 * L_30 = Delegate_CreateDelegate_m3052767705(NULL /*static, unused*/, L_27, L_28, L_29, (bool)1, /*hidden argument*/NULL);
		return ((GetterAdapter_t1423755509 *)CastclassSealed(L_30, GetterAdapter_t1423755509_il2cpp_TypeInfo_var));
	}
}
// System.Object System.Reflection.MonoProperty::GetValue(System.Object,System.Object[])
extern "C"  Il2CppObject * MonoProperty_GetValue_m3088777694 (MonoProperty_t * __this, Il2CppObject * ___obj0, ObjectU5BU5D_t3614634134* ___index1, const MethodInfo* method)
{
	{
		Il2CppObject * L_0 = ___obj0;
		ObjectU5BU5D_t3614634134* L_1 = ___index1;
		Il2CppObject * L_2 = VirtFuncInvoker5< Il2CppObject *, Il2CppObject *, int32_t, Binder_t3404612058 *, ObjectU5BU5D_t3614634134*, CultureInfo_t3500843524 * >::Invoke(23 /* System.Object System.Reflection.MonoProperty::GetValue(System.Object,System.Reflection.BindingFlags,System.Reflection.Binder,System.Object[],System.Globalization.CultureInfo) */, __this, L_0, 0, (Binder_t3404612058 *)NULL, L_1, (CultureInfo_t3500843524 *)NULL);
		return L_2;
	}
}
// System.Object System.Reflection.MonoProperty::GetValue(System.Object,System.Reflection.BindingFlags,System.Reflection.Binder,System.Object[],System.Globalization.CultureInfo)
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* ArgumentException_t3259014390_il2cpp_TypeInfo_var;
extern Il2CppClass* SecurityException_t887327375_il2cpp_TypeInfo_var;
extern Il2CppClass* TargetInvocationException_t4098620458_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral3303126324;
extern Il2CppCodeGenString* _stringLiteral372029307;
extern const uint32_t MonoProperty_GetValue_m2150318626_MetadataUsageId;
extern "C"  Il2CppObject * MonoProperty_GetValue_m2150318626 (MonoProperty_t * __this, Il2CppObject * ___obj0, int32_t ___invokeAttr1, Binder_t3404612058 * ___binder2, ObjectU5BU5D_t3614634134* ___index3, CultureInfo_t3500843524 * ___culture4, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MonoProperty_GetValue_m2150318626_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Il2CppObject * V_0 = NULL;
	MethodInfo_t * V_1 = NULL;
	SecurityException_t887327375 * V_2 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		V_0 = NULL;
		MethodInfo_t * L_0 = VirtFuncInvoker1< MethodInfo_t *, bool >::Invoke(19 /* System.Reflection.MethodInfo System.Reflection.MonoProperty::GetGetMethod(System.Boolean) */, __this, (bool)1);
		V_1 = L_0;
		MethodInfo_t * L_1 = V_1;
		if (L_1)
		{
			goto IL_002b;
		}
	}
	{
		String_t* L_2 = VirtFuncInvoker0< String_t* >::Invoke(8 /* System.String System.Reflection.MonoProperty::get_Name() */, __this);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_3 = String_Concat_m612901809(NULL /*static, unused*/, _stringLiteral3303126324, L_2, _stringLiteral372029307, /*hidden argument*/NULL);
		ArgumentException_t3259014390 * L_4 = (ArgumentException_t3259014390 *)il2cpp_codegen_object_new(ArgumentException_t3259014390_il2cpp_TypeInfo_var);
		ArgumentException__ctor_m3739475201(L_4, L_3, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_4);
	}

IL_002b:
	try
	{ // begin try (depth: 1)
		{
			ObjectU5BU5D_t3614634134* L_5 = ___index3;
			if (!L_5)
			{
				goto IL_003b;
			}
		}

IL_0032:
		{
			ObjectU5BU5D_t3614634134* L_6 = ___index3;
			NullCheck(L_6);
			if ((((int32_t)((int32_t)(((Il2CppArray *)L_6)->max_length)))))
			{
				goto IL_004d;
			}
		}

IL_003b:
		{
			MethodInfo_t * L_7 = V_1;
			Il2CppObject * L_8 = ___obj0;
			int32_t L_9 = ___invokeAttr1;
			Binder_t3404612058 * L_10 = ___binder2;
			CultureInfo_t3500843524 * L_11 = ___culture4;
			NullCheck(L_7);
			Il2CppObject * L_12 = VirtFuncInvoker5< Il2CppObject *, Il2CppObject *, int32_t, Binder_t3404612058 *, ObjectU5BU5D_t3614634134*, CultureInfo_t3500843524 * >::Invoke(17 /* System.Object System.Reflection.MethodBase::Invoke(System.Object,System.Reflection.BindingFlags,System.Reflection.Binder,System.Object[],System.Globalization.CultureInfo) */, L_7, L_8, L_9, L_10, (ObjectU5BU5D_t3614634134*)(ObjectU5BU5D_t3614634134*)NULL, L_11);
			V_0 = L_12;
			goto IL_005b;
		}

IL_004d:
		{
			MethodInfo_t * L_13 = V_1;
			Il2CppObject * L_14 = ___obj0;
			int32_t L_15 = ___invokeAttr1;
			Binder_t3404612058 * L_16 = ___binder2;
			ObjectU5BU5D_t3614634134* L_17 = ___index3;
			CultureInfo_t3500843524 * L_18 = ___culture4;
			NullCheck(L_13);
			Il2CppObject * L_19 = VirtFuncInvoker5< Il2CppObject *, Il2CppObject *, int32_t, Binder_t3404612058 *, ObjectU5BU5D_t3614634134*, CultureInfo_t3500843524 * >::Invoke(17 /* System.Object System.Reflection.MethodBase::Invoke(System.Object,System.Reflection.BindingFlags,System.Reflection.Binder,System.Object[],System.Globalization.CultureInfo) */, L_13, L_14, L_15, L_16, L_17, L_18);
			V_0 = L_19;
		}

IL_005b:
		{
			goto IL_006d;
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__exception_local = (Exception_t1927440687 *)e.ex;
		if(il2cpp_codegen_class_is_assignable_from (SecurityException_t887327375_il2cpp_TypeInfo_var, e.ex->object.klass))
			goto CATCH_0060;
		throw e;
	}

CATCH_0060:
	{ // begin catch(System.Security.SecurityException)
		{
			V_2 = ((SecurityException_t887327375 *)__exception_local);
			SecurityException_t887327375 * L_20 = V_2;
			TargetInvocationException_t4098620458 * L_21 = (TargetInvocationException_t4098620458 *)il2cpp_codegen_object_new(TargetInvocationException_t4098620458_il2cpp_TypeInfo_var);
			TargetInvocationException__ctor_m1059845570(L_21, L_20, /*hidden argument*/NULL);
			IL2CPP_RAISE_MANAGED_EXCEPTION(L_21);
		}

IL_0068:
		{
			goto IL_006d;
		}
	} // end catch (depth: 1)

IL_006d:
	{
		Il2CppObject * L_22 = V_0;
		return L_22;
	}
}
// System.Void System.Reflection.MonoProperty::SetValue(System.Object,System.Object,System.Reflection.BindingFlags,System.Reflection.Binder,System.Object[],System.Globalization.CultureInfo)
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* ArgumentException_t3259014390_il2cpp_TypeInfo_var;
extern Il2CppClass* ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral449389896;
extern Il2CppCodeGenString* _stringLiteral372029307;
extern const uint32_t MonoProperty_SetValue_m1423050605_MetadataUsageId;
extern "C"  void MonoProperty_SetValue_m1423050605 (MonoProperty_t * __this, Il2CppObject * ___obj0, Il2CppObject * ___value1, int32_t ___invokeAttr2, Binder_t3404612058 * ___binder3, ObjectU5BU5D_t3614634134* ___index4, CultureInfo_t3500843524 * ___culture5, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MonoProperty_SetValue_m1423050605_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	MethodInfo_t * V_0 = NULL;
	ObjectU5BU5D_t3614634134* V_1 = NULL;
	int32_t V_2 = 0;
	{
		MethodInfo_t * L_0 = VirtFuncInvoker1< MethodInfo_t *, bool >::Invoke(21 /* System.Reflection.MethodInfo System.Reflection.MonoProperty::GetSetMethod(System.Boolean) */, __this, (bool)1);
		V_0 = L_0;
		MethodInfo_t * L_1 = V_0;
		if (L_1)
		{
			goto IL_0029;
		}
	}
	{
		String_t* L_2 = VirtFuncInvoker0< String_t* >::Invoke(8 /* System.String System.Reflection.MonoProperty::get_Name() */, __this);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_3 = String_Concat_m612901809(NULL /*static, unused*/, _stringLiteral449389896, L_2, _stringLiteral372029307, /*hidden argument*/NULL);
		ArgumentException_t3259014390 * L_4 = (ArgumentException_t3259014390 *)il2cpp_codegen_object_new(ArgumentException_t3259014390_il2cpp_TypeInfo_var);
		ArgumentException__ctor_m3739475201(L_4, L_3, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_4);
	}

IL_0029:
	{
		ObjectU5BU5D_t3614634134* L_5 = ___index4;
		if (!L_5)
		{
			goto IL_0039;
		}
	}
	{
		ObjectU5BU5D_t3614634134* L_6 = ___index4;
		NullCheck(L_6);
		if ((((int32_t)((int32_t)(((Il2CppArray *)L_6)->max_length)))))
		{
			goto IL_0049;
		}
	}

IL_0039:
	{
		ObjectU5BU5D_t3614634134* L_7 = ((ObjectU5BU5D_t3614634134*)SZArrayNew(ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var, (uint32_t)1));
		Il2CppObject * L_8 = ___value1;
		NullCheck(L_7);
		ArrayElementTypeCheck (L_7, L_8);
		(L_7)->SetAt(static_cast<il2cpp_array_size_t>(0), (Il2CppObject *)L_8);
		V_1 = L_7;
		goto IL_0064;
	}

IL_0049:
	{
		ObjectU5BU5D_t3614634134* L_9 = ___index4;
		NullCheck(L_9);
		V_2 = (((int32_t)((int32_t)(((Il2CppArray *)L_9)->max_length))));
		int32_t L_10 = V_2;
		V_1 = ((ObjectU5BU5D_t3614634134*)SZArrayNew(ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var, (uint32_t)((int32_t)((int32_t)L_10+(int32_t)1))));
		ObjectU5BU5D_t3614634134* L_11 = ___index4;
		ObjectU5BU5D_t3614634134* L_12 = V_1;
		NullCheck((Il2CppArray *)(Il2CppArray *)L_11);
		Array_CopyTo_m4061033315((Il2CppArray *)(Il2CppArray *)L_11, (Il2CppArray *)(Il2CppArray *)L_12, 0, /*hidden argument*/NULL);
		ObjectU5BU5D_t3614634134* L_13 = V_1;
		int32_t L_14 = V_2;
		Il2CppObject * L_15 = ___value1;
		NullCheck(L_13);
		ArrayElementTypeCheck (L_13, L_15);
		(L_13)->SetAt(static_cast<il2cpp_array_size_t>(L_14), (Il2CppObject *)L_15);
	}

IL_0064:
	{
		MethodInfo_t * L_16 = V_0;
		Il2CppObject * L_17 = ___obj0;
		int32_t L_18 = ___invokeAttr2;
		Binder_t3404612058 * L_19 = ___binder3;
		ObjectU5BU5D_t3614634134* L_20 = V_1;
		CultureInfo_t3500843524 * L_21 = ___culture5;
		NullCheck(L_16);
		VirtFuncInvoker5< Il2CppObject *, Il2CppObject *, int32_t, Binder_t3404612058 *, ObjectU5BU5D_t3614634134*, CultureInfo_t3500843524 * >::Invoke(17 /* System.Object System.Reflection.MethodBase::Invoke(System.Object,System.Reflection.BindingFlags,System.Reflection.Binder,System.Object[],System.Globalization.CultureInfo) */, L_16, L_17, L_18, L_19, L_20, L_21);
		return;
	}
}
// System.String System.Reflection.MonoProperty::ToString()
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral372029310;
extern const uint32_t MonoProperty_ToString_m1379465861_MetadataUsageId;
extern "C"  String_t* MonoProperty_ToString_m1379465861 (MonoProperty_t * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MonoProperty_ToString_m1379465861_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Type_t * L_0 = VirtFuncInvoker0< Type_t * >::Invoke(17 /* System.Type System.Reflection.MonoProperty::get_PropertyType() */, __this);
		NullCheck(L_0);
		String_t* L_1 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Type::ToString() */, L_0);
		String_t* L_2 = VirtFuncInvoker0< String_t* >::Invoke(8 /* System.String System.Reflection.MonoProperty::get_Name() */, __this);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_3 = String_Concat_m612901809(NULL /*static, unused*/, L_1, _stringLiteral372029310, L_2, /*hidden argument*/NULL);
		return L_3;
	}
}
// System.Type[] System.Reflection.MonoProperty::GetOptionalCustomModifiers()
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern const uint32_t MonoProperty_GetOptionalCustomModifiers_m3827844355_MetadataUsageId;
extern "C"  TypeU5BU5D_t1664964607* MonoProperty_GetOptionalCustomModifiers_m3827844355 (MonoProperty_t * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MonoProperty_GetOptionalCustomModifiers_m3827844355_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	TypeU5BU5D_t1664964607* V_0 = NULL;
	{
		TypeU5BU5D_t1664964607* L_0 = MonoPropertyInfo_GetTypeModifiers_m184537257(NULL /*static, unused*/, __this, (bool)1, /*hidden argument*/NULL);
		V_0 = L_0;
		TypeU5BU5D_t1664964607* L_1 = V_0;
		if (L_1)
		{
			goto IL_0014;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		TypeU5BU5D_t1664964607* L_2 = ((Type_t_StaticFields*)Type_t_il2cpp_TypeInfo_var->static_fields)->get_EmptyTypes_3();
		return L_2;
	}

IL_0014:
	{
		TypeU5BU5D_t1664964607* L_3 = V_0;
		return L_3;
	}
}
// System.Type[] System.Reflection.MonoProperty::GetRequiredCustomModifiers()
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern const uint32_t MonoProperty_GetRequiredCustomModifiers_m576853384_MetadataUsageId;
extern "C"  TypeU5BU5D_t1664964607* MonoProperty_GetRequiredCustomModifiers_m576853384 (MonoProperty_t * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MonoProperty_GetRequiredCustomModifiers_m576853384_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	TypeU5BU5D_t1664964607* V_0 = NULL;
	{
		TypeU5BU5D_t1664964607* L_0 = MonoPropertyInfo_GetTypeModifiers_m184537257(NULL /*static, unused*/, __this, (bool)0, /*hidden argument*/NULL);
		V_0 = L_0;
		TypeU5BU5D_t1664964607* L_1 = V_0;
		if (L_1)
		{
			goto IL_0014;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		TypeU5BU5D_t1664964607* L_2 = ((Type_t_StaticFields*)Type_t_il2cpp_TypeInfo_var->static_fields)->get_EmptyTypes_3();
		return L_2;
	}

IL_0014:
	{
		TypeU5BU5D_t1664964607* L_3 = V_0;
		return L_3;
	}
}
// System.Void System.Reflection.MonoProperty::GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern "C"  void MonoProperty_GetObjectData_m2540252220 (MonoProperty_t * __this, SerializationInfo_t228987430 * ___info0, StreamingContext_t1417235061  ___context1, const MethodInfo* method)
{
	{
		SerializationInfo_t228987430 * L_0 = ___info0;
		String_t* L_1 = VirtFuncInvoker0< String_t* >::Invoke(8 /* System.String System.Reflection.MonoProperty::get_Name() */, __this);
		Type_t * L_2 = VirtFuncInvoker0< Type_t * >::Invoke(9 /* System.Type System.Reflection.MonoProperty::get_ReflectedType() */, __this);
		String_t* L_3 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Reflection.MonoProperty::ToString() */, __this);
		MemberInfoSerializationHolder_Serialize_m1949812823(NULL /*static, unused*/, L_0, L_1, L_2, L_3, ((int32_t)16), /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Reflection.MonoProperty/GetterAdapter::.ctor(System.Object,System.IntPtr)
extern "C"  void GetterAdapter__ctor_m4231828815 (GetterAdapter_t1423755509 * __this, Il2CppObject * ___object0, IntPtr_t ___method1, const MethodInfo* method)
{
	__this->set_method_ptr_0((Il2CppMethodPointer)((MethodInfo*)___method1.get_m_value_0())->methodPointer);
	__this->set_method_3(___method1);
	__this->set_m_target_2(___object0);
}
// System.Object System.Reflection.MonoProperty/GetterAdapter::Invoke(System.Object)
extern "C"  Il2CppObject * GetterAdapter_Invoke_m2777461448 (GetterAdapter_t1423755509 * __this, Il2CppObject * ____this0, const MethodInfo* method)
{
	if(__this->get_prev_9() != NULL)
	{
		GetterAdapter_Invoke_m2777461448((GetterAdapter_t1423755509 *)__this->get_prev_9(),____this0, method);
	}
	il2cpp_codegen_raise_execution_engine_exception_if_method_is_not_found((MethodInfo*)(__this->get_method_3().get_m_value_0()));
	bool ___methodIsStatic = MethodIsStatic((MethodInfo*)(__this->get_method_3().get_m_value_0()));
	if (__this->get_m_target_2() != NULL && ___methodIsStatic)
	{
		typedef Il2CppObject * (*FunctionPointerType) (Il2CppObject *, void* __this, Il2CppObject * ____this0, const MethodInfo* method);
		return ((FunctionPointerType)__this->get_method_ptr_0())(NULL,__this->get_m_target_2(),____this0,(MethodInfo*)(__this->get_method_3().get_m_value_0()));
	}
	else if (__this->get_m_target_2() != NULL || ___methodIsStatic)
	{
		typedef Il2CppObject * (*FunctionPointerType) (void* __this, Il2CppObject * ____this0, const MethodInfo* method);
		return ((FunctionPointerType)__this->get_method_ptr_0())(__this->get_m_target_2(),____this0,(MethodInfo*)(__this->get_method_3().get_m_value_0()));
	}
	else
	{
		typedef Il2CppObject * (*FunctionPointerType) (void* __this, const MethodInfo* method);
		return ((FunctionPointerType)__this->get_method_ptr_0())(____this0,(MethodInfo*)(__this->get_method_3().get_m_value_0()));
	}
}
// System.IAsyncResult System.Reflection.MonoProperty/GetterAdapter::BeginInvoke(System.Object,System.AsyncCallback,System.Object)
extern "C"  Il2CppObject * GetterAdapter_BeginInvoke_m3760926500 (GetterAdapter_t1423755509 * __this, Il2CppObject * ____this0, AsyncCallback_t163412349 * ___callback1, Il2CppObject * ___object2, const MethodInfo* method)
{
	void *__d_args[2] = {0};
	__d_args[0] = ____this0;
	return (Il2CppObject *)il2cpp_codegen_delegate_begin_invoke((Il2CppDelegate*)__this, __d_args, (Il2CppDelegate*)___callback1, (Il2CppObject*)___object2);
}
// System.Object System.Reflection.MonoProperty/GetterAdapter::EndInvoke(System.IAsyncResult)
extern "C"  Il2CppObject * GetterAdapter_EndInvoke_m1928570128 (GetterAdapter_t1423755509 * __this, Il2CppObject * ___result0, const MethodInfo* method)
{
	Il2CppObject *__result = il2cpp_codegen_delegate_end_invoke((Il2CppAsyncResult*) ___result0, 0);
	return (Il2CppObject *)__result;
}
// System.Void System.Reflection.MonoPropertyInfo::get_property_info(System.Reflection.MonoProperty,System.Reflection.MonoPropertyInfo&,System.Reflection.PInfo)
extern "C"  void MonoPropertyInfo_get_property_info_m556498347 (Il2CppObject * __this /* static, unused */, MonoProperty_t * ___prop0, MonoPropertyInfo_t486106184 * ___info1, int32_t ___req_info2, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef void (*MonoPropertyInfo_get_property_info_m556498347_ftn) (MonoProperty_t *, MonoPropertyInfo_t486106184 *, int32_t);
	 ((MonoPropertyInfo_get_property_info_m556498347_ftn)mscorlib::System::Reflection::MonoPropertyInfo::get_property_info) (___prop0, ___info1, ___req_info2);
}
// System.Type[] System.Reflection.MonoPropertyInfo::GetTypeModifiers(System.Reflection.MonoProperty,System.Boolean)
extern "C"  TypeU5BU5D_t1664964607* MonoPropertyInfo_GetTypeModifiers_m184537257 (Il2CppObject * __this /* static, unused */, MonoProperty_t * ___prop0, bool ___optional1, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef TypeU5BU5D_t1664964607* (*MonoPropertyInfo_GetTypeModifiers_m184537257_ftn) (MonoProperty_t *, bool);
	return  ((MonoPropertyInfo_GetTypeModifiers_m184537257_ftn)mscorlib::System::Reflection::MonoPropertyInfo::GetTypeModifiers) (___prop0, ___optional1);
}
// Conversion methods for marshalling of: System.Reflection.MonoPropertyInfo
extern "C" void MonoPropertyInfo_t486106184_marshal_pinvoke(const MonoPropertyInfo_t486106184& unmarshaled, MonoPropertyInfo_t486106184_marshaled_pinvoke& marshaled)
{
	Il2CppCodeGenException* ___parent_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'parent' of type 'MonoPropertyInfo': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___parent_0Exception);
}
extern "C" void MonoPropertyInfo_t486106184_marshal_pinvoke_back(const MonoPropertyInfo_t486106184_marshaled_pinvoke& marshaled, MonoPropertyInfo_t486106184& unmarshaled)
{
	Il2CppCodeGenException* ___parent_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'parent' of type 'MonoPropertyInfo': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___parent_0Exception);
}
// Conversion method for clean up from marshalling of: System.Reflection.MonoPropertyInfo
extern "C" void MonoPropertyInfo_t486106184_marshal_pinvoke_cleanup(MonoPropertyInfo_t486106184_marshaled_pinvoke& marshaled)
{
}
// Conversion methods for marshalling of: System.Reflection.MonoPropertyInfo
extern "C" void MonoPropertyInfo_t486106184_marshal_com(const MonoPropertyInfo_t486106184& unmarshaled, MonoPropertyInfo_t486106184_marshaled_com& marshaled)
{
	Il2CppCodeGenException* ___parent_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'parent' of type 'MonoPropertyInfo': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___parent_0Exception);
}
extern "C" void MonoPropertyInfo_t486106184_marshal_com_back(const MonoPropertyInfo_t486106184_marshaled_com& marshaled, MonoPropertyInfo_t486106184& unmarshaled)
{
	Il2CppCodeGenException* ___parent_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'parent' of type 'MonoPropertyInfo': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___parent_0Exception);
}
// Conversion method for clean up from marshalling of: System.Reflection.MonoPropertyInfo
extern "C" void MonoPropertyInfo_t486106184_marshal_com_cleanup(MonoPropertyInfo_t486106184_marshaled_com& marshaled)
{
}
// System.Void System.Reflection.ParameterInfo::.ctor()
extern "C"  void ParameterInfo__ctor_m1986388557 (ParameterInfo_t2249040075 * __this, const MethodInfo* method)
{
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Reflection.ParameterInfo::.ctor(System.Reflection.Emit.ParameterBuilder,System.Type,System.Reflection.MemberInfo,System.Int32)
extern "C"  void ParameterInfo__ctor_m2149157062 (ParameterInfo_t2249040075 * __this, ParameterBuilder_t3344728474 * ___pb0, Type_t * ___type1, MemberInfo_t * ___member2, int32_t ___position3, const MethodInfo* method)
{
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		Type_t * L_0 = ___type1;
		__this->set_ClassImpl_0(L_0);
		MemberInfo_t * L_1 = ___member2;
		__this->set_MemberImpl_2(L_1);
		ParameterBuilder_t3344728474 * L_2 = ___pb0;
		if (!L_2)
		{
			goto IL_0045;
		}
	}
	{
		ParameterBuilder_t3344728474 * L_3 = ___pb0;
		NullCheck(L_3);
		String_t* L_4 = VirtFuncInvoker0< String_t* >::Invoke(5 /* System.String System.Reflection.Emit.ParameterBuilder::get_Name() */, L_3);
		__this->set_NameImpl_3(L_4);
		ParameterBuilder_t3344728474 * L_5 = ___pb0;
		NullCheck(L_5);
		int32_t L_6 = VirtFuncInvoker0< int32_t >::Invoke(6 /* System.Int32 System.Reflection.Emit.ParameterBuilder::get_Position() */, L_5);
		__this->set_PositionImpl_4(((int32_t)((int32_t)L_6-(int32_t)1)));
		ParameterBuilder_t3344728474 * L_7 = ___pb0;
		NullCheck(L_7);
		int32_t L_8 = VirtFuncInvoker0< int32_t >::Invoke(4 /* System.Int32 System.Reflection.Emit.ParameterBuilder::get_Attributes() */, L_7);
		__this->set_AttrsImpl_5(L_8);
		goto IL_005d;
	}

IL_0045:
	{
		__this->set_NameImpl_3((String_t*)NULL);
		int32_t L_9 = ___position3;
		__this->set_PositionImpl_4(((int32_t)((int32_t)L_9-(int32_t)1)));
		__this->set_AttrsImpl_5(0);
	}

IL_005d:
	{
		return;
	}
}
// System.Void System.Reflection.ParameterInfo::.ctor(System.Reflection.ParameterInfo,System.Reflection.MemberInfo)
extern "C"  void ParameterInfo__ctor_m3204994840 (ParameterInfo_t2249040075 * __this, ParameterInfo_t2249040075 * ___pinfo0, MemberInfo_t * ___member1, const MethodInfo* method)
{
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		ParameterInfo_t2249040075 * L_0 = ___pinfo0;
		NullCheck(L_0);
		Type_t * L_1 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.ParameterInfo::get_ParameterType() */, L_0);
		__this->set_ClassImpl_0(L_1);
		MemberInfo_t * L_2 = ___member1;
		__this->set_MemberImpl_2(L_2);
		ParameterInfo_t2249040075 * L_3 = ___pinfo0;
		NullCheck(L_3);
		String_t* L_4 = VirtFuncInvoker0< String_t* >::Invoke(9 /* System.String System.Reflection.ParameterInfo::get_Name() */, L_3);
		__this->set_NameImpl_3(L_4);
		ParameterInfo_t2249040075 * L_5 = ___pinfo0;
		NullCheck(L_5);
		int32_t L_6 = VirtFuncInvoker0< int32_t >::Invoke(10 /* System.Int32 System.Reflection.ParameterInfo::get_Position() */, L_5);
		__this->set_PositionImpl_4(L_6);
		ParameterInfo_t2249040075 * L_7 = ___pinfo0;
		NullCheck(L_7);
		int32_t L_8 = VirtFuncInvoker0< int32_t >::Invoke(7 /* System.Reflection.ParameterAttributes System.Reflection.ParameterInfo::get_Attributes() */, L_7);
		__this->set_AttrsImpl_5(L_8);
		return;
	}
}
// System.String System.Reflection.ParameterInfo::ToString()
extern const Il2CppType* Void_t1841601450_0_0_0_var;
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* Char_t3454481338_il2cpp_TypeInfo_var;
extern const uint32_t ParameterInfo_ToString_m1722229694_MetadataUsageId;
extern "C"  String_t* ParameterInfo_ToString_m1722229694 (ParameterInfo_t2249040075 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ParameterInfo_ToString_m1722229694_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Type_t * V_0 = NULL;
	bool V_1 = false;
	String_t* V_2 = NULL;
	int32_t G_B7_0 = 0;
	String_t* G_B10_0 = NULL;
	{
		Type_t * L_0 = __this->get_ClassImpl_0();
		V_0 = L_0;
		goto IL_0013;
	}

IL_000c:
	{
		Type_t * L_1 = V_0;
		NullCheck(L_1);
		Type_t * L_2 = VirtFuncInvoker0< Type_t * >::Invoke(42 /* System.Type System.Type::GetElementType() */, L_1);
		V_0 = L_2;
	}

IL_0013:
	{
		Type_t * L_3 = V_0;
		NullCheck(L_3);
		bool L_4 = Type_get_HasElementType_m3319917896(L_3, /*hidden argument*/NULL);
		if (L_4)
		{
			goto IL_000c;
		}
	}
	{
		Type_t * L_5 = V_0;
		NullCheck(L_5);
		bool L_6 = Type_get_IsPrimitive_m1522841565(L_5, /*hidden argument*/NULL);
		if (L_6)
		{
			goto IL_0060;
		}
	}
	{
		Type_t * L_7 = __this->get_ClassImpl_0();
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_8 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Void_t1841601450_0_0_0_var), /*hidden argument*/NULL);
		if ((((Il2CppObject*)(Type_t *)L_7) == ((Il2CppObject*)(Type_t *)L_8)))
		{
			goto IL_0060;
		}
	}
	{
		Type_t * L_9 = __this->get_ClassImpl_0();
		NullCheck(L_9);
		String_t* L_10 = VirtFuncInvoker0< String_t* >::Invoke(34 /* System.String System.Type::get_Namespace() */, L_9);
		MemberInfo_t * L_11 = __this->get_MemberImpl_2();
		NullCheck(L_11);
		Type_t * L_12 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.MemberInfo::get_DeclaringType() */, L_11);
		NullCheck(L_12);
		String_t* L_13 = VirtFuncInvoker0< String_t* >::Invoke(34 /* System.String System.Type::get_Namespace() */, L_12);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_14 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_10, L_13, /*hidden argument*/NULL);
		G_B7_0 = ((int32_t)(L_14));
		goto IL_0061;
	}

IL_0060:
	{
		G_B7_0 = 1;
	}

IL_0061:
	{
		V_1 = (bool)G_B7_0;
		bool L_15 = V_1;
		if (!L_15)
		{
			goto IL_0078;
		}
	}
	{
		Type_t * L_16 = __this->get_ClassImpl_0();
		NullCheck(L_16);
		String_t* L_17 = VirtFuncInvoker0< String_t* >::Invoke(8 /* System.String System.Reflection.MemberInfo::get_Name() */, L_16);
		G_B10_0 = L_17;
		goto IL_0083;
	}

IL_0078:
	{
		Type_t * L_18 = __this->get_ClassImpl_0();
		NullCheck(L_18);
		String_t* L_19 = VirtFuncInvoker0< String_t* >::Invoke(18 /* System.String System.Type::get_FullName() */, L_18);
		G_B10_0 = L_19;
	}

IL_0083:
	{
		V_2 = G_B10_0;
		bool L_20 = ParameterInfo_get_IsRetval_m1881464570(__this, /*hidden argument*/NULL);
		if (L_20)
		{
			goto IL_00aa;
		}
	}
	{
		String_t* L_21 = V_2;
		Il2CppChar L_22 = ((Il2CppChar)((int32_t)32));
		Il2CppObject * L_23 = Box(Char_t3454481338_il2cpp_TypeInfo_var, &L_22);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_24 = String_Concat_m56707527(NULL /*static, unused*/, L_21, L_23, /*hidden argument*/NULL);
		V_2 = L_24;
		String_t* L_25 = V_2;
		String_t* L_26 = __this->get_NameImpl_3();
		String_t* L_27 = String_Concat_m2596409543(NULL /*static, unused*/, L_25, L_26, /*hidden argument*/NULL);
		V_2 = L_27;
	}

IL_00aa:
	{
		String_t* L_28 = V_2;
		return L_28;
	}
}
// System.Type System.Reflection.ParameterInfo::get_ParameterType()
extern "C"  Type_t * ParameterInfo_get_ParameterType_m1441012169 (ParameterInfo_t2249040075 * __this, const MethodInfo* method)
{
	{
		Type_t * L_0 = __this->get_ClassImpl_0();
		return L_0;
	}
}
// System.Reflection.ParameterAttributes System.Reflection.ParameterInfo::get_Attributes()
extern "C"  int32_t ParameterInfo_get_Attributes_m407887446 (ParameterInfo_t2249040075 * __this, const MethodInfo* method)
{
	{
		int32_t L_0 = __this->get_AttrsImpl_5();
		return L_0;
	}
}
// System.Boolean System.Reflection.ParameterInfo::get_IsIn()
extern "C"  bool ParameterInfo_get_IsIn_m1357865245 (ParameterInfo_t2249040075 * __this, const MethodInfo* method)
{
	{
		int32_t L_0 = VirtFuncInvoker0< int32_t >::Invoke(7 /* System.Reflection.ParameterAttributes System.Reflection.ParameterInfo::get_Attributes() */, __this);
		return (bool)((((int32_t)((((int32_t)((int32_t)((int32_t)L_0&(int32_t)1))) == ((int32_t)0))? 1 : 0)) == ((int32_t)0))? 1 : 0);
	}
}
// System.Boolean System.Reflection.ParameterInfo::get_IsOptional()
extern "C"  bool ParameterInfo_get_IsOptional_m2877290948 (ParameterInfo_t2249040075 * __this, const MethodInfo* method)
{
	{
		int32_t L_0 = VirtFuncInvoker0< int32_t >::Invoke(7 /* System.Reflection.ParameterAttributes System.Reflection.ParameterInfo::get_Attributes() */, __this);
		return (bool)((((int32_t)((((int32_t)((int32_t)((int32_t)L_0&(int32_t)((int32_t)16)))) == ((int32_t)0))? 1 : 0)) == ((int32_t)0))? 1 : 0);
	}
}
// System.Boolean System.Reflection.ParameterInfo::get_IsOut()
extern "C"  bool ParameterInfo_get_IsOut_m3097675062 (ParameterInfo_t2249040075 * __this, const MethodInfo* method)
{
	{
		int32_t L_0 = VirtFuncInvoker0< int32_t >::Invoke(7 /* System.Reflection.ParameterAttributes System.Reflection.ParameterInfo::get_Attributes() */, __this);
		return (bool)((((int32_t)((((int32_t)((int32_t)((int32_t)L_0&(int32_t)2))) == ((int32_t)0))? 1 : 0)) == ((int32_t)0))? 1 : 0);
	}
}
// System.Boolean System.Reflection.ParameterInfo::get_IsRetval()
extern "C"  bool ParameterInfo_get_IsRetval_m1881464570 (ParameterInfo_t2249040075 * __this, const MethodInfo* method)
{
	{
		int32_t L_0 = VirtFuncInvoker0< int32_t >::Invoke(7 /* System.Reflection.ParameterAttributes System.Reflection.ParameterInfo::get_Attributes() */, __this);
		return (bool)((((int32_t)((((int32_t)((int32_t)((int32_t)L_0&(int32_t)8))) == ((int32_t)0))? 1 : 0)) == ((int32_t)0))? 1 : 0);
	}
}
// System.Reflection.MemberInfo System.Reflection.ParameterInfo::get_Member()
extern "C"  MemberInfo_t * ParameterInfo_get_Member_m4111292219 (ParameterInfo_t2249040075 * __this, const MethodInfo* method)
{
	{
		MemberInfo_t * L_0 = __this->get_MemberImpl_2();
		return L_0;
	}
}
// System.String System.Reflection.ParameterInfo::get_Name()
extern "C"  String_t* ParameterInfo_get_Name_m149251884 (ParameterInfo_t2249040075 * __this, const MethodInfo* method)
{
	{
		String_t* L_0 = __this->get_NameImpl_3();
		return L_0;
	}
}
// System.Int32 System.Reflection.ParameterInfo::get_Position()
extern "C"  int32_t ParameterInfo_get_Position_m2135360011 (ParameterInfo_t2249040075 * __this, const MethodInfo* method)
{
	{
		int32_t L_0 = __this->get_PositionImpl_4();
		return L_0;
	}
}
// System.Object[] System.Reflection.ParameterInfo::GetCustomAttributes(System.Type,System.Boolean)
extern Il2CppClass* MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var;
extern const uint32_t ParameterInfo_GetCustomAttributes_m2985072480_MetadataUsageId;
extern "C"  ObjectU5BU5D_t3614634134* ParameterInfo_GetCustomAttributes_m2985072480 (ParameterInfo_t2249040075 * __this, Type_t * ___attributeType0, bool ___inherit1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ParameterInfo_GetCustomAttributes_m2985072480_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Type_t * L_0 = ___attributeType0;
		bool L_1 = ___inherit1;
		IL2CPP_RUNTIME_CLASS_INIT(MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var);
		ObjectU5BU5D_t3614634134* L_2 = MonoCustomAttrs_GetCustomAttributes_m939426263(NULL /*static, unused*/, __this, L_0, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.Boolean System.Reflection.ParameterInfo::IsDefined(System.Type,System.Boolean)
extern Il2CppClass* MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var;
extern const uint32_t ParameterInfo_IsDefined_m2412925144_MetadataUsageId;
extern "C"  bool ParameterInfo_IsDefined_m2412925144 (ParameterInfo_t2249040075 * __this, Type_t * ___attributeType0, bool ___inherit1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ParameterInfo_IsDefined_m2412925144_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Type_t * L_0 = ___attributeType0;
		bool L_1 = ___inherit1;
		IL2CPP_RUNTIME_CLASS_INIT(MonoCustomAttrs_t2976585698_il2cpp_TypeInfo_var);
		bool L_2 = MonoCustomAttrs_IsDefined_m3820363041(NULL /*static, unused*/, __this, L_0, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.Object[] System.Reflection.ParameterInfo::GetPseudoCustomAttributes()
extern Il2CppClass* ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var;
extern Il2CppClass* InAttribute_t1394050551_il2cpp_TypeInfo_var;
extern Il2CppClass* OptionalAttribute_t827982902_il2cpp_TypeInfo_var;
extern Il2CppClass* OutAttribute_t1539424546_il2cpp_TypeInfo_var;
extern const uint32_t ParameterInfo_GetPseudoCustomAttributes_m2952359394_MetadataUsageId;
extern "C"  ObjectU5BU5D_t3614634134* ParameterInfo_GetPseudoCustomAttributes_m2952359394 (ParameterInfo_t2249040075 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ParameterInfo_GetPseudoCustomAttributes_m2952359394_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	ObjectU5BU5D_t3614634134* V_1 = NULL;
	{
		V_0 = 0;
		bool L_0 = ParameterInfo_get_IsIn_m1357865245(__this, /*hidden argument*/NULL);
		if (!L_0)
		{
			goto IL_0011;
		}
	}
	{
		int32_t L_1 = V_0;
		V_0 = ((int32_t)((int32_t)L_1+(int32_t)1));
	}

IL_0011:
	{
		bool L_2 = ParameterInfo_get_IsOut_m3097675062(__this, /*hidden argument*/NULL);
		if (!L_2)
		{
			goto IL_0020;
		}
	}
	{
		int32_t L_3 = V_0;
		V_0 = ((int32_t)((int32_t)L_3+(int32_t)1));
	}

IL_0020:
	{
		bool L_4 = ParameterInfo_get_IsOptional_m2877290948(__this, /*hidden argument*/NULL);
		if (!L_4)
		{
			goto IL_002f;
		}
	}
	{
		int32_t L_5 = V_0;
		V_0 = ((int32_t)((int32_t)L_5+(int32_t)1));
	}

IL_002f:
	{
		UnmanagedMarshal_t4270021860 * L_6 = __this->get_marshalAs_6();
		if (!L_6)
		{
			goto IL_003e;
		}
	}
	{
		int32_t L_7 = V_0;
		V_0 = ((int32_t)((int32_t)L_7+(int32_t)1));
	}

IL_003e:
	{
		int32_t L_8 = V_0;
		if (L_8)
		{
			goto IL_0046;
		}
	}
	{
		return (ObjectU5BU5D_t3614634134*)NULL;
	}

IL_0046:
	{
		int32_t L_9 = V_0;
		V_1 = ((ObjectU5BU5D_t3614634134*)SZArrayNew(ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var, (uint32_t)L_9));
		V_0 = 0;
		bool L_10 = ParameterInfo_get_IsIn_m1357865245(__this, /*hidden argument*/NULL);
		if (!L_10)
		{
			goto IL_0066;
		}
	}
	{
		ObjectU5BU5D_t3614634134* L_11 = V_1;
		int32_t L_12 = V_0;
		int32_t L_13 = L_12;
		V_0 = ((int32_t)((int32_t)L_13+(int32_t)1));
		InAttribute_t1394050551 * L_14 = (InAttribute_t1394050551 *)il2cpp_codegen_object_new(InAttribute_t1394050551_il2cpp_TypeInfo_var);
		InAttribute__ctor_m1401060713(L_14, /*hidden argument*/NULL);
		NullCheck(L_11);
		ArrayElementTypeCheck (L_11, L_14);
		(L_11)->SetAt(static_cast<il2cpp_array_size_t>(L_13), (Il2CppObject *)L_14);
	}

IL_0066:
	{
		bool L_15 = ParameterInfo_get_IsOptional_m2877290948(__this, /*hidden argument*/NULL);
		if (!L_15)
		{
			goto IL_007d;
		}
	}
	{
		ObjectU5BU5D_t3614634134* L_16 = V_1;
		int32_t L_17 = V_0;
		int32_t L_18 = L_17;
		V_0 = ((int32_t)((int32_t)L_18+(int32_t)1));
		OptionalAttribute_t827982902 * L_19 = (OptionalAttribute_t827982902 *)il2cpp_codegen_object_new(OptionalAttribute_t827982902_il2cpp_TypeInfo_var);
		OptionalAttribute__ctor_m1739107582(L_19, /*hidden argument*/NULL);
		NullCheck(L_16);
		ArrayElementTypeCheck (L_16, L_19);
		(L_16)->SetAt(static_cast<il2cpp_array_size_t>(L_18), (Il2CppObject *)L_19);
	}

IL_007d:
	{
		bool L_20 = ParameterInfo_get_IsOut_m3097675062(__this, /*hidden argument*/NULL);
		if (!L_20)
		{
			goto IL_0094;
		}
	}
	{
		ObjectU5BU5D_t3614634134* L_21 = V_1;
		int32_t L_22 = V_0;
		int32_t L_23 = L_22;
		V_0 = ((int32_t)((int32_t)L_23+(int32_t)1));
		OutAttribute_t1539424546 * L_24 = (OutAttribute_t1539424546 *)il2cpp_codegen_object_new(OutAttribute_t1539424546_il2cpp_TypeInfo_var);
		OutAttribute__ctor_m1447235100(L_24, /*hidden argument*/NULL);
		NullCheck(L_21);
		ArrayElementTypeCheck (L_21, L_24);
		(L_21)->SetAt(static_cast<il2cpp_array_size_t>(L_23), (Il2CppObject *)L_24);
	}

IL_0094:
	{
		UnmanagedMarshal_t4270021860 * L_25 = __this->get_marshalAs_6();
		if (!L_25)
		{
			goto IL_00b1;
		}
	}
	{
		ObjectU5BU5D_t3614634134* L_26 = V_1;
		int32_t L_27 = V_0;
		int32_t L_28 = L_27;
		V_0 = ((int32_t)((int32_t)L_28+(int32_t)1));
		UnmanagedMarshal_t4270021860 * L_29 = __this->get_marshalAs_6();
		NullCheck(L_29);
		MarshalAsAttribute_t2900773360 * L_30 = UnmanagedMarshal_ToMarshalAsAttribute_m3695569337(L_29, /*hidden argument*/NULL);
		NullCheck(L_26);
		ArrayElementTypeCheck (L_26, L_30);
		(L_26)->SetAt(static_cast<il2cpp_array_size_t>(L_28), (Il2CppObject *)L_30);
	}

IL_00b1:
	{
		ObjectU5BU5D_t3614634134* L_31 = V_1;
		return L_31;
	}
}
// Conversion methods for marshalling of: System.Reflection.ParameterModifier
extern "C" void ParameterModifier_t1820634920_marshal_pinvoke(const ParameterModifier_t1820634920& unmarshaled, ParameterModifier_t1820634920_marshaled_pinvoke& marshaled)
{
	if (unmarshaled.get__byref_0() != NULL)
	{
		int32_t _unmarshaled__byref_Length = (unmarshaled.get__byref_0())->max_length;
		marshaled.____byref_0 = il2cpp_codegen_marshal_allocate_array<int32_t>(_unmarshaled__byref_Length);
		for (int32_t i = 0; i < _unmarshaled__byref_Length; i++)
		{
			(marshaled.____byref_0)[i] = static_cast<int32_t>((unmarshaled.get__byref_0())->GetAtUnchecked(static_cast<il2cpp_array_size_t>(i)));
		}
	}
	else
	{
		marshaled.____byref_0 = NULL;
	}
}
extern Il2CppClass* BooleanU5BU5D_t3568034315_il2cpp_TypeInfo_var;
extern const uint32_t ParameterModifier_t1820634920_pinvoke_FromNativeMethodDefinition_MetadataUsageId;
extern "C" void ParameterModifier_t1820634920_marshal_pinvoke_back(const ParameterModifier_t1820634920_marshaled_pinvoke& marshaled, ParameterModifier_t1820634920& unmarshaled)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ParameterModifier_t1820634920_pinvoke_FromNativeMethodDefinition_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	if (marshaled.____byref_0 != NULL)
	{
		if (unmarshaled.get__byref_0() == NULL)
		{
			unmarshaled.set__byref_0(reinterpret_cast<BooleanU5BU5D_t3568034315*>(SZArrayNew(BooleanU5BU5D_t3568034315_il2cpp_TypeInfo_var, 1)));
		}
		int32_t _arrayLength = (unmarshaled.get__byref_0())->max_length;
		for (int32_t i = 0; i < _arrayLength; i++)
		{
			(unmarshaled.get__byref_0())->SetAtUnchecked(static_cast<il2cpp_array_size_t>(i), static_cast<bool>((marshaled.____byref_0)[i]));
		}
	}
}
// Conversion method for clean up from marshalling of: System.Reflection.ParameterModifier
extern "C" void ParameterModifier_t1820634920_marshal_pinvoke_cleanup(ParameterModifier_t1820634920_marshaled_pinvoke& marshaled)
{
	if (marshaled.____byref_0 != NULL)
	{
		il2cpp_codegen_marshal_free(marshaled.____byref_0);
		marshaled.____byref_0 = NULL;
	}
}
// Conversion methods for marshalling of: System.Reflection.ParameterModifier
extern "C" void ParameterModifier_t1820634920_marshal_com(const ParameterModifier_t1820634920& unmarshaled, ParameterModifier_t1820634920_marshaled_com& marshaled)
{
	if (unmarshaled.get__byref_0() != NULL)
	{
		int32_t _unmarshaled__byref_Length = (unmarshaled.get__byref_0())->max_length;
		marshaled.____byref_0 = il2cpp_codegen_marshal_allocate_array<int32_t>(_unmarshaled__byref_Length);
		for (int32_t i = 0; i < _unmarshaled__byref_Length; i++)
		{
			(marshaled.____byref_0)[i] = static_cast<int32_t>((unmarshaled.get__byref_0())->GetAtUnchecked(static_cast<il2cpp_array_size_t>(i)));
		}
	}
	else
	{
		marshaled.____byref_0 = NULL;
	}
}
extern Il2CppClass* BooleanU5BU5D_t3568034315_il2cpp_TypeInfo_var;
extern const uint32_t ParameterModifier_t1820634920_com_FromNativeMethodDefinition_MetadataUsageId;
extern "C" void ParameterModifier_t1820634920_marshal_com_back(const ParameterModifier_t1820634920_marshaled_com& marshaled, ParameterModifier_t1820634920& unmarshaled)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ParameterModifier_t1820634920_com_FromNativeMethodDefinition_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	if (marshaled.____byref_0 != NULL)
	{
		if (unmarshaled.get__byref_0() == NULL)
		{
			unmarshaled.set__byref_0(reinterpret_cast<BooleanU5BU5D_t3568034315*>(SZArrayNew(BooleanU5BU5D_t3568034315_il2cpp_TypeInfo_var, 1)));
		}
		int32_t _arrayLength = (unmarshaled.get__byref_0())->max_length;
		for (int32_t i = 0; i < _arrayLength; i++)
		{
			(unmarshaled.get__byref_0())->SetAtUnchecked(static_cast<il2cpp_array_size_t>(i), static_cast<bool>((marshaled.____byref_0)[i]));
		}
	}
}
// Conversion method for clean up from marshalling of: System.Reflection.ParameterModifier
extern "C" void ParameterModifier_t1820634920_marshal_com_cleanup(ParameterModifier_t1820634920_marshaled_com& marshaled)
{
	if (marshaled.____byref_0 != NULL)
	{
		il2cpp_codegen_marshal_free(marshaled.____byref_0);
		marshaled.____byref_0 = NULL;
	}
}
// System.Void System.Reflection.Pointer::.ctor()
extern "C"  void Pointer__ctor_m906226785 (Pointer_t937075087 * __this, const MethodInfo* method)
{
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Reflection.Pointer::System.Runtime.Serialization.ISerializable.GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern Il2CppClass* NotSupportedException_t1793819818_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral506242180;
extern const uint32_t Pointer_System_Runtime_Serialization_ISerializable_GetObjectData_m4103721774_MetadataUsageId;
extern "C"  void Pointer_System_Runtime_Serialization_ISerializable_GetObjectData_m4103721774 (Pointer_t937075087 * __this, SerializationInfo_t228987430 * ___info0, StreamingContext_t1417235061  ___context1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Pointer_System_Runtime_Serialization_ISerializable_GetObjectData_m4103721774_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		NotSupportedException_t1793819818 * L_0 = (NotSupportedException_t1793819818 *)il2cpp_codegen_object_new(NotSupportedException_t1793819818_il2cpp_TypeInfo_var);
		NotSupportedException__ctor_m836173213(L_0, _stringLiteral506242180, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Void System.Reflection.PropertyInfo::.ctor()
extern "C"  void PropertyInfo__ctor_m1808219471 (PropertyInfo_t * __this, const MethodInfo* method)
{
	{
		MemberInfo__ctor_m2808577188(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Reflection.MemberTypes System.Reflection.PropertyInfo::get_MemberType()
extern "C"  int32_t PropertyInfo_get_MemberType_m1634143880 (PropertyInfo_t * __this, const MethodInfo* method)
{
	{
		return (int32_t)(((int32_t)16));
	}
}
// System.Object System.Reflection.PropertyInfo::GetValue(System.Object,System.Object[])
extern "C"  Il2CppObject * PropertyInfo_GetValue_m3655964945 (PropertyInfo_t * __this, Il2CppObject * ___obj0, ObjectU5BU5D_t3614634134* ___index1, const MethodInfo* method)
{
	{
		Il2CppObject * L_0 = ___obj0;
		ObjectU5BU5D_t3614634134* L_1 = ___index1;
		Il2CppObject * L_2 = VirtFuncInvoker5< Il2CppObject *, Il2CppObject *, int32_t, Binder_t3404612058 *, ObjectU5BU5D_t3614634134*, CultureInfo_t3500843524 * >::Invoke(23 /* System.Object System.Reflection.PropertyInfo::GetValue(System.Object,System.Reflection.BindingFlags,System.Reflection.Binder,System.Object[],System.Globalization.CultureInfo) */, __this, L_0, 0, (Binder_t3404612058 *)NULL, L_1, (CultureInfo_t3500843524 *)NULL);
		return L_2;
	}
}
// System.Void System.Reflection.PropertyInfo::SetValue(System.Object,System.Object,System.Object[])
extern "C"  void PropertyInfo_SetValue_m2961483868 (PropertyInfo_t * __this, Il2CppObject * ___obj0, Il2CppObject * ___value1, ObjectU5BU5D_t3614634134* ___index2, const MethodInfo* method)
{
	{
		Il2CppObject * L_0 = ___obj0;
		Il2CppObject * L_1 = ___value1;
		ObjectU5BU5D_t3614634134* L_2 = ___index2;
		VirtActionInvoker6< Il2CppObject *, Il2CppObject *, int32_t, Binder_t3404612058 *, ObjectU5BU5D_t3614634134*, CultureInfo_t3500843524 * >::Invoke(25 /* System.Void System.Reflection.PropertyInfo::SetValue(System.Object,System.Object,System.Reflection.BindingFlags,System.Reflection.Binder,System.Object[],System.Globalization.CultureInfo) */, __this, L_0, L_1, 0, (Binder_t3404612058 *)NULL, L_2, (CultureInfo_t3500843524 *)NULL);
		return;
	}
}
// System.Type[] System.Reflection.PropertyInfo::GetOptionalCustomModifiers()
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern const uint32_t PropertyInfo_GetOptionalCustomModifiers_m747937176_MetadataUsageId;
extern "C"  TypeU5BU5D_t1664964607* PropertyInfo_GetOptionalCustomModifiers_m747937176 (PropertyInfo_t * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (PropertyInfo_GetOptionalCustomModifiers_m747937176_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		TypeU5BU5D_t1664964607* L_0 = ((Type_t_StaticFields*)Type_t_il2cpp_TypeInfo_var->static_fields)->get_EmptyTypes_3();
		return L_0;
	}
}
// System.Type[] System.Reflection.PropertyInfo::GetRequiredCustomModifiers()
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern const uint32_t PropertyInfo_GetRequiredCustomModifiers_m2291294773_MetadataUsageId;
extern "C"  TypeU5BU5D_t1664964607* PropertyInfo_GetRequiredCustomModifiers_m2291294773 (PropertyInfo_t * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (PropertyInfo_GetRequiredCustomModifiers_m2291294773_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		TypeU5BU5D_t1664964607* L_0 = ((Type_t_StaticFields*)Type_t_il2cpp_TypeInfo_var->static_fields)->get_EmptyTypes_3();
		return L_0;
	}
}
// System.Void System.Reflection.StrongNameKeyPair::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern const Il2CppType* ByteU5BU5D_t3397334013_0_0_0_var;
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern Il2CppClass* ByteU5BU5D_t3397334013_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral3721378849;
extern Il2CppCodeGenString* _stringLiteral3423086453;
extern Il2CppCodeGenString* _stringLiteral2645312083;
extern Il2CppCodeGenString* _stringLiteral622693823;
extern const uint32_t StrongNameKeyPair__ctor_m1022407102_MetadataUsageId;
extern "C"  void StrongNameKeyPair__ctor_m1022407102 (StrongNameKeyPair_t4090869089 * __this, SerializationInfo_t228987430 * ___info0, StreamingContext_t1417235061  ___context1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (StrongNameKeyPair__ctor_m1022407102_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		SerializationInfo_t228987430 * L_0 = ___info0;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_1 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(ByteU5BU5D_t3397334013_0_0_0_var), /*hidden argument*/NULL);
		NullCheck(L_0);
		Il2CppObject * L_2 = SerializationInfo_GetValue_m1127314592(L_0, _stringLiteral3721378849, L_1, /*hidden argument*/NULL);
		__this->set__publicKey_0(((ByteU5BU5D_t3397334013*)Castclass(L_2, ByteU5BU5D_t3397334013_il2cpp_TypeInfo_var)));
		SerializationInfo_t228987430 * L_3 = ___info0;
		NullCheck(L_3);
		String_t* L_4 = SerializationInfo_GetString_m547109409(L_3, _stringLiteral3423086453, /*hidden argument*/NULL);
		__this->set__keyPairContainer_1(L_4);
		SerializationInfo_t228987430 * L_5 = ___info0;
		NullCheck(L_5);
		bool L_6 = SerializationInfo_GetBoolean_m3573708305(L_5, _stringLiteral2645312083, /*hidden argument*/NULL);
		__this->set__keyPairExported_2(L_6);
		SerializationInfo_t228987430 * L_7 = ___info0;
		Type_t * L_8 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(ByteU5BU5D_t3397334013_0_0_0_var), /*hidden argument*/NULL);
		NullCheck(L_7);
		Il2CppObject * L_9 = SerializationInfo_GetValue_m1127314592(L_7, _stringLiteral622693823, L_8, /*hidden argument*/NULL);
		__this->set__keyPairArray_3(((ByteU5BU5D_t3397334013*)Castclass(L_9, ByteU5BU5D_t3397334013_il2cpp_TypeInfo_var)));
		return;
	}
}
// System.Void System.Reflection.StrongNameKeyPair::System.Runtime.Serialization.ISerializable.GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern const Il2CppType* ByteU5BU5D_t3397334013_0_0_0_var;
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral3721378849;
extern Il2CppCodeGenString* _stringLiteral3423086453;
extern Il2CppCodeGenString* _stringLiteral2645312083;
extern Il2CppCodeGenString* _stringLiteral622693823;
extern const uint32_t StrongNameKeyPair_System_Runtime_Serialization_ISerializable_GetObjectData_m1693082120_MetadataUsageId;
extern "C"  void StrongNameKeyPair_System_Runtime_Serialization_ISerializable_GetObjectData_m1693082120 (StrongNameKeyPair_t4090869089 * __this, SerializationInfo_t228987430 * ___info0, StreamingContext_t1417235061  ___context1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (StrongNameKeyPair_System_Runtime_Serialization_ISerializable_GetObjectData_m1693082120_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		SerializationInfo_t228987430 * L_0 = ___info0;
		ByteU5BU5D_t3397334013* L_1 = __this->get__publicKey_0();
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_2 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(ByteU5BU5D_t3397334013_0_0_0_var), /*hidden argument*/NULL);
		NullCheck(L_0);
		SerializationInfo_AddValue_m1781549036(L_0, _stringLiteral3721378849, (Il2CppObject *)(Il2CppObject *)L_1, L_2, /*hidden argument*/NULL);
		SerializationInfo_t228987430 * L_3 = ___info0;
		String_t* L_4 = __this->get__keyPairContainer_1();
		NullCheck(L_3);
		SerializationInfo_AddValue_m1740888931(L_3, _stringLiteral3423086453, L_4, /*hidden argument*/NULL);
		SerializationInfo_t228987430 * L_5 = ___info0;
		bool L_6 = __this->get__keyPairExported_2();
		NullCheck(L_5);
		SerializationInfo_AddValue_m1192926088(L_5, _stringLiteral2645312083, L_6, /*hidden argument*/NULL);
		SerializationInfo_t228987430 * L_7 = ___info0;
		ByteU5BU5D_t3397334013* L_8 = __this->get__keyPairArray_3();
		Type_t * L_9 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(ByteU5BU5D_t3397334013_0_0_0_var), /*hidden argument*/NULL);
		NullCheck(L_7);
		SerializationInfo_AddValue_m1781549036(L_7, _stringLiteral622693823, (Il2CppObject *)(Il2CppObject *)L_8, L_9, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Reflection.StrongNameKeyPair::System.Runtime.Serialization.IDeserializationCallback.OnDeserialization(System.Object)
extern "C"  void StrongNameKeyPair_System_Runtime_Serialization_IDeserializationCallback_OnDeserialization_m2330221363 (StrongNameKeyPair_t4090869089 * __this, Il2CppObject * ___sender0, const MethodInfo* method)
{
	{
		return;
	}
}
// System.Void System.Reflection.TargetException::.ctor()
extern Il2CppCodeGenString* _stringLiteral3413494879;
extern const uint32_t TargetException__ctor_m104994274_MetadataUsageId;
extern "C"  void TargetException__ctor_m104994274 (TargetException_t1572104820 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (TargetException__ctor_m104994274_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		String_t* L_0 = Locale_GetText_m1954433032(NULL /*static, unused*/, _stringLiteral3413494879, /*hidden argument*/NULL);
		Exception__ctor_m485833136(__this, L_0, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Reflection.TargetException::.ctor(System.String)
extern "C"  void TargetException__ctor_m3228808416 (TargetException_t1572104820 * __this, String_t* ___message0, const MethodInfo* method)
{
	{
		String_t* L_0 = ___message0;
		Exception__ctor_m485833136(__this, L_0, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Reflection.TargetException::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern "C"  void TargetException__ctor_m2630053835 (TargetException_t1572104820 * __this, SerializationInfo_t228987430 * ___info0, StreamingContext_t1417235061  ___context1, const MethodInfo* method)
{
	{
		SerializationInfo_t228987430 * L_0 = ___info0;
		StreamingContext_t1417235061  L_1 = ___context1;
		Exception__ctor_m3836998015(__this, L_0, L_1, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Reflection.TargetInvocationException::.ctor(System.Exception)
extern Il2CppCodeGenString* _stringLiteral2114161008;
extern const uint32_t TargetInvocationException__ctor_m1059845570_MetadataUsageId;
extern "C"  void TargetInvocationException__ctor_m1059845570 (TargetInvocationException_t4098620458 * __this, Exception_t1927440687 * ___inner0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (TargetInvocationException__ctor_m1059845570_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Exception_t1927440687 * L_0 = ___inner0;
		Exception__ctor_m2453009240(__this, _stringLiteral2114161008, L_0, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Reflection.TargetInvocationException::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern "C"  void TargetInvocationException__ctor_m2308614207 (TargetInvocationException_t4098620458 * __this, SerializationInfo_t228987430 * ___info0, StreamingContext_t1417235061  ___sc1, const MethodInfo* method)
{
	{
		SerializationInfo_t228987430 * L_0 = ___info0;
		StreamingContext_t1417235061  L_1 = ___sc1;
		Exception__ctor_m3836998015(__this, L_0, L_1, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Reflection.TargetParameterCountException::.ctor()
extern Il2CppCodeGenString* _stringLiteral212474851;
extern const uint32_t TargetParameterCountException__ctor_m1256521036_MetadataUsageId;
extern "C"  void TargetParameterCountException__ctor_m1256521036 (TargetParameterCountException_t1554451430 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (TargetParameterCountException__ctor_m1256521036_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		String_t* L_0 = Locale_GetText_m1954433032(NULL /*static, unused*/, _stringLiteral212474851, /*hidden argument*/NULL);
		Exception__ctor_m485833136(__this, L_0, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Reflection.TargetParameterCountException::.ctor(System.String)
extern "C"  void TargetParameterCountException__ctor_m2760108938 (TargetParameterCountException_t1554451430 * __this, String_t* ___message0, const MethodInfo* method)
{
	{
		String_t* L_0 = ___message0;
		Exception__ctor_m485833136(__this, L_0, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Reflection.TargetParameterCountException::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern "C"  void TargetParameterCountException__ctor_m2091252449 (TargetParameterCountException_t1554451430 * __this, SerializationInfo_t228987430 * ___info0, StreamingContext_t1417235061  ___context1, const MethodInfo* method)
{
	{
		SerializationInfo_t228987430 * L_0 = ___info0;
		StreamingContext_t1417235061  L_1 = ___context1;
		Exception__ctor_m3836998015(__this, L_0, L_1, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Reflection.TypeFilter::.ctor(System.Object,System.IntPtr)
extern "C"  void TypeFilter__ctor_m1798016172 (TypeFilter_t2905709404 * __this, Il2CppObject * ___object0, IntPtr_t ___method1, const MethodInfo* method)
{
	__this->set_method_ptr_0((Il2CppMethodPointer)((MethodInfo*)___method1.get_m_value_0())->methodPointer);
	__this->set_method_3(___method1);
	__this->set_m_target_2(___object0);
}
// System.Boolean System.Reflection.TypeFilter::Invoke(System.Type,System.Object)
extern "C"  bool TypeFilter_Invoke_m2156848151 (TypeFilter_t2905709404 * __this, Type_t * ___m0, Il2CppObject * ___filterCriteria1, const MethodInfo* method)
{
	if(__this->get_prev_9() != NULL)
	{
		TypeFilter_Invoke_m2156848151((TypeFilter_t2905709404 *)__this->get_prev_9(),___m0, ___filterCriteria1, method);
	}
	il2cpp_codegen_raise_execution_engine_exception_if_method_is_not_found((MethodInfo*)(__this->get_method_3().get_m_value_0()));
	bool ___methodIsStatic = MethodIsStatic((MethodInfo*)(__this->get_method_3().get_m_value_0()));
	if (__this->get_m_target_2() != NULL && ___methodIsStatic)
	{
		typedef bool (*FunctionPointerType) (Il2CppObject *, void* __this, Type_t * ___m0, Il2CppObject * ___filterCriteria1, const MethodInfo* method);
		return ((FunctionPointerType)__this->get_method_ptr_0())(NULL,__this->get_m_target_2(),___m0, ___filterCriteria1,(MethodInfo*)(__this->get_method_3().get_m_value_0()));
	}
	else if (__this->get_m_target_2() != NULL || ___methodIsStatic)
	{
		typedef bool (*FunctionPointerType) (void* __this, Type_t * ___m0, Il2CppObject * ___filterCriteria1, const MethodInfo* method);
		return ((FunctionPointerType)__this->get_method_ptr_0())(__this->get_m_target_2(),___m0, ___filterCriteria1,(MethodInfo*)(__this->get_method_3().get_m_value_0()));
	}
	else
	{
		typedef bool (*FunctionPointerType) (void* __this, Il2CppObject * ___filterCriteria1, const MethodInfo* method);
		return ((FunctionPointerType)__this->get_method_ptr_0())(___m0, ___filterCriteria1,(MethodInfo*)(__this->get_method_3().get_m_value_0()));
	}
}
// System.IAsyncResult System.Reflection.TypeFilter::BeginInvoke(System.Type,System.Object,System.AsyncCallback,System.Object)
extern "C"  Il2CppObject * TypeFilter_BeginInvoke_m2395188690 (TypeFilter_t2905709404 * __this, Type_t * ___m0, Il2CppObject * ___filterCriteria1, AsyncCallback_t163412349 * ___callback2, Il2CppObject * ___object3, const MethodInfo* method)
{
	void *__d_args[3] = {0};
	__d_args[0] = ___m0;
	__d_args[1] = ___filterCriteria1;
	return (Il2CppObject *)il2cpp_codegen_delegate_begin_invoke((Il2CppDelegate*)__this, __d_args, (Il2CppDelegate*)___callback2, (Il2CppObject*)___object3);
}
// System.Boolean System.Reflection.TypeFilter::EndInvoke(System.IAsyncResult)
extern "C"  bool TypeFilter_EndInvoke_m997625354 (TypeFilter_t2905709404 * __this, Il2CppObject * ___result0, const MethodInfo* method)
{
	Il2CppObject *__result = il2cpp_codegen_delegate_end_invoke((Il2CppAsyncResult*) ___result0, 0);
	return *(bool*)UnBox ((Il2CppCodeGenObject*)__result);
}
// System.Void System.ResolveEventArgs::.ctor(System.String)
extern Il2CppClass* EventArgs_t3289624707_il2cpp_TypeInfo_var;
extern const uint32_t ResolveEventArgs__ctor_m1927258464_MetadataUsageId;
extern "C"  void ResolveEventArgs__ctor_m1927258464 (ResolveEventArgs_t1859808873 * __this, String_t* ___name0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ResolveEventArgs__ctor_m1927258464_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(EventArgs_t3289624707_il2cpp_TypeInfo_var);
		EventArgs__ctor_m3696060910(__this, /*hidden argument*/NULL);
		String_t* L_0 = ___name0;
		__this->set_m_Name_1(L_0);
		return;
	}
}
// System.Void System.ResolveEventHandler::.ctor(System.Object,System.IntPtr)
extern "C"  void ResolveEventHandler__ctor_m3098271043 (ResolveEventHandler_t3842432458 * __this, Il2CppObject * ___object0, IntPtr_t ___method1, const MethodInfo* method)
{
	__this->set_method_ptr_0((Il2CppMethodPointer)((MethodInfo*)___method1.get_m_value_0())->methodPointer);
	__this->set_method_3(___method1);
	__this->set_m_target_2(___object0);
}
// System.Reflection.Assembly System.ResolveEventHandler::Invoke(System.Object,System.ResolveEventArgs)
extern "C"  Assembly_t4268412390 * ResolveEventHandler_Invoke_m3343892466 (ResolveEventHandler_t3842432458 * __this, Il2CppObject * ___sender0, ResolveEventArgs_t1859808873 * ___args1, const MethodInfo* method)
{
	if(__this->get_prev_9() != NULL)
	{
		ResolveEventHandler_Invoke_m3343892466((ResolveEventHandler_t3842432458 *)__this->get_prev_9(),___sender0, ___args1, method);
	}
	il2cpp_codegen_raise_execution_engine_exception_if_method_is_not_found((MethodInfo*)(__this->get_method_3().get_m_value_0()));
	bool ___methodIsStatic = MethodIsStatic((MethodInfo*)(__this->get_method_3().get_m_value_0()));
	if (__this->get_m_target_2() != NULL && ___methodIsStatic)
	{
		typedef Assembly_t4268412390 * (*FunctionPointerType) (Il2CppObject *, void* __this, Il2CppObject * ___sender0, ResolveEventArgs_t1859808873 * ___args1, const MethodInfo* method);
		return ((FunctionPointerType)__this->get_method_ptr_0())(NULL,__this->get_m_target_2(),___sender0, ___args1,(MethodInfo*)(__this->get_method_3().get_m_value_0()));
	}
	else if (__this->get_m_target_2() != NULL || ___methodIsStatic)
	{
		typedef Assembly_t4268412390 * (*FunctionPointerType) (void* __this, Il2CppObject * ___sender0, ResolveEventArgs_t1859808873 * ___args1, const MethodInfo* method);
		return ((FunctionPointerType)__this->get_method_ptr_0())(__this->get_m_target_2(),___sender0, ___args1,(MethodInfo*)(__this->get_method_3().get_m_value_0()));
	}
	else
	{
		typedef Assembly_t4268412390 * (*FunctionPointerType) (void* __this, ResolveEventArgs_t1859808873 * ___args1, const MethodInfo* method);
		return ((FunctionPointerType)__this->get_method_ptr_0())(___sender0, ___args1,(MethodInfo*)(__this->get_method_3().get_m_value_0()));
	}
}
// System.IAsyncResult System.ResolveEventHandler::BeginInvoke(System.Object,System.ResolveEventArgs,System.AsyncCallback,System.Object)
extern "C"  Il2CppObject * ResolveEventHandler_BeginInvoke_m916075374 (ResolveEventHandler_t3842432458 * __this, Il2CppObject * ___sender0, ResolveEventArgs_t1859808873 * ___args1, AsyncCallback_t163412349 * ___callback2, Il2CppObject * ___object3, const MethodInfo* method)
{
	void *__d_args[3] = {0};
	__d_args[0] = ___sender0;
	__d_args[1] = ___args1;
	return (Il2CppObject *)il2cpp_codegen_delegate_begin_invoke((Il2CppDelegate*)__this, __d_args, (Il2CppDelegate*)___callback2, (Il2CppObject*)___object3);
}
// System.Reflection.Assembly System.ResolveEventHandler::EndInvoke(System.IAsyncResult)
extern "C"  Assembly_t4268412390 * ResolveEventHandler_EndInvoke_m1489338158 (ResolveEventHandler_t3842432458 * __this, Il2CppObject * ___result0, const MethodInfo* method)
{
	Il2CppObject *__result = il2cpp_codegen_delegate_end_invoke((Il2CppAsyncResult*) ___result0, 0);
	return (Assembly_t4268412390 *)__result;
}
// System.Void System.Resources.NeutralResourcesLanguageAttribute::.ctor(System.String)
extern Il2CppClass* ArgumentNullException_t628810857_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral1377061773;
extern const uint32_t NeutralResourcesLanguageAttribute__ctor_m1145808404_MetadataUsageId;
extern "C"  void NeutralResourcesLanguageAttribute__ctor_m1145808404 (NeutralResourcesLanguageAttribute_t3267676636 * __this, String_t* ___cultureName0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (NeutralResourcesLanguageAttribute__ctor_m1145808404_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Attribute__ctor_m1730479323(__this, /*hidden argument*/NULL);
		String_t* L_0 = ___cultureName0;
		if (L_0)
		{
			goto IL_0017;
		}
	}
	{
		ArgumentNullException_t628810857 * L_1 = (ArgumentNullException_t628810857 *)il2cpp_codegen_object_new(ArgumentNullException_t628810857_il2cpp_TypeInfo_var);
		ArgumentNullException__ctor_m3380712306(L_1, _stringLiteral1377061773, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_1);
	}

IL_0017:
	{
		String_t* L_2 = ___cultureName0;
		__this->set_culture_0(L_2);
		return;
	}
}
// System.Void System.Resources.ResourceManager::.ctor()
extern const Il2CppType* RuntimeResourceSet_t1442459318_0_0_0_var;
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern const uint32_t ResourceManager__ctor_m498829021_MetadataUsageId;
extern "C"  void ResourceManager__ctor_m498829021 (ResourceManager_t264715885 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ResourceManager__ctor_m498829021_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_0 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(RuntimeResourceSet_t1442459318_0_0_0_var), /*hidden argument*/NULL);
		__this->set_resourceSetType_4(L_0);
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Resources.ResourceManager::.cctor()
extern Il2CppClass* Hashtable_t909839986_il2cpp_TypeInfo_var;
extern Il2CppClass* ResourceManager_t264715885_il2cpp_TypeInfo_var;
extern const uint32_t ResourceManager__cctor_m2190112652_MetadataUsageId;
extern "C"  void ResourceManager__cctor_m2190112652 (Il2CppObject * __this /* static, unused */, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ResourceManager__cctor_m2190112652_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Hashtable_t909839986 * L_0 = (Hashtable_t909839986 *)il2cpp_codegen_object_new(Hashtable_t909839986_il2cpp_TypeInfo_var);
		Hashtable__ctor_m1884964176(L_0, /*hidden argument*/NULL);
		((ResourceManager_t264715885_StaticFields*)ResourceManager_t264715885_il2cpp_TypeInfo_var->static_fields)->set_ResourceCache_0(L_0);
		Hashtable_t909839986 * L_1 = (Hashtable_t909839986 *)il2cpp_codegen_object_new(Hashtable_t909839986_il2cpp_TypeInfo_var);
		Hashtable__ctor_m1884964176(L_1, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(Hashtable_t909839986_il2cpp_TypeInfo_var);
		Hashtable_t909839986 * L_2 = Hashtable_Synchronized_m225390213(NULL /*static, unused*/, L_1, /*hidden argument*/NULL);
		((ResourceManager_t264715885_StaticFields*)ResourceManager_t264715885_il2cpp_TypeInfo_var->static_fields)->set_NonExistent_1(L_2);
		((ResourceManager_t264715885_StaticFields*)ResourceManager_t264715885_il2cpp_TypeInfo_var->static_fields)->set_HeaderVersionNumber_2(1);
		((ResourceManager_t264715885_StaticFields*)ResourceManager_t264715885_il2cpp_TypeInfo_var->static_fields)->set_MagicNumber_3(((int32_t)-1091581234));
		return;
	}
}
// System.Void System.Resources.ResourceReader::.ctor(System.IO.Stream)
extern Il2CppClass* Il2CppObject_il2cpp_TypeInfo_var;
extern Il2CppClass* ArgumentNullException_t628810857_il2cpp_TypeInfo_var;
extern Il2CppClass* ArgumentException_t3259014390_il2cpp_TypeInfo_var;
extern Il2CppClass* Encoding_t663144255_il2cpp_TypeInfo_var;
extern Il2CppClass* BinaryReader_t2491843768_il2cpp_TypeInfo_var;
extern Il2CppClass* BinaryFormatter_t1866979105_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral3909163458;
extern Il2CppCodeGenString* _stringLiteral552183552;
extern const uint32_t ResourceReader__ctor_m1562845828_MetadataUsageId;
extern "C"  void ResourceReader__ctor_m1562845828 (ResourceReader_t2463923611 * __this, Stream_t3255436806 * ___stream0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ResourceReader__ctor_m1562845828_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Il2CppObject * L_0 = (Il2CppObject *)il2cpp_codegen_object_new(Il2CppObject_il2cpp_TypeInfo_var);
		Object__ctor_m2551263788(L_0, /*hidden argument*/NULL);
		__this->set_readerLock_1(L_0);
		Il2CppObject * L_1 = (Il2CppObject *)il2cpp_codegen_object_new(Il2CppObject_il2cpp_TypeInfo_var);
		Object__ctor_m2551263788(L_1, /*hidden argument*/NULL);
		__this->set_cache_lock_12(L_1);
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		Stream_t3255436806 * L_2 = ___stream0;
		if (L_2)
		{
			goto IL_002d;
		}
	}
	{
		ArgumentNullException_t628810857 * L_3 = (ArgumentNullException_t628810857 *)il2cpp_codegen_object_new(ArgumentNullException_t628810857_il2cpp_TypeInfo_var);
		ArgumentNullException__ctor_m3380712306(L_3, _stringLiteral3909163458, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_3);
	}

IL_002d:
	{
		Stream_t3255436806 * L_4 = ___stream0;
		NullCheck(L_4);
		bool L_5 = VirtFuncInvoker0< bool >::Invoke(5 /* System.Boolean System.IO.Stream::get_CanRead() */, L_4);
		if (L_5)
		{
			goto IL_0043;
		}
	}
	{
		ArgumentException_t3259014390 * L_6 = (ArgumentException_t3259014390 *)il2cpp_codegen_object_new(ArgumentException_t3259014390_il2cpp_TypeInfo_var);
		ArgumentException__ctor_m3739475201(L_6, _stringLiteral552183552, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_6);
	}

IL_0043:
	{
		Stream_t3255436806 * L_7 = ___stream0;
		IL2CPP_RUNTIME_CLASS_INIT(Encoding_t663144255_il2cpp_TypeInfo_var);
		Encoding_t663144255 * L_8 = Encoding_get_UTF8_m1752852937(NULL /*static, unused*/, /*hidden argument*/NULL);
		BinaryReader_t2491843768 * L_9 = (BinaryReader_t2491843768 *)il2cpp_codegen_object_new(BinaryReader_t2491843768_il2cpp_TypeInfo_var);
		BinaryReader__ctor_m1387916481(L_9, L_7, L_8, /*hidden argument*/NULL);
		__this->set_reader_0(L_9);
		StreamingContext_t1417235061  L_10;
		memset(&L_10, 0, sizeof(L_10));
		StreamingContext__ctor_m3756336578(&L_10, ((int32_t)12), /*hidden argument*/NULL);
		BinaryFormatter_t1866979105 * L_11 = (BinaryFormatter_t1866979105 *)il2cpp_codegen_object_new(BinaryFormatter_t1866979105_il2cpp_TypeInfo_var);
		BinaryFormatter__ctor_m3750141051(L_11, (Il2CppObject *)NULL, L_10, /*hidden argument*/NULL);
		__this->set_formatter_2(L_11);
		ResourceReader_ReadHeaders_m881647957(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Resources.ResourceReader::.ctor(System.String)
extern Il2CppClass* Il2CppObject_il2cpp_TypeInfo_var;
extern Il2CppClass* FileStream_t1695958676_il2cpp_TypeInfo_var;
extern Il2CppClass* BinaryReader_t2491843768_il2cpp_TypeInfo_var;
extern Il2CppClass* BinaryFormatter_t1866979105_il2cpp_TypeInfo_var;
extern const uint32_t ResourceReader__ctor_m2324926185_MetadataUsageId;
extern "C"  void ResourceReader__ctor_m2324926185 (ResourceReader_t2463923611 * __this, String_t* ___fileName0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ResourceReader__ctor_m2324926185_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Il2CppObject * L_0 = (Il2CppObject *)il2cpp_codegen_object_new(Il2CppObject_il2cpp_TypeInfo_var);
		Object__ctor_m2551263788(L_0, /*hidden argument*/NULL);
		__this->set_readerLock_1(L_0);
		Il2CppObject * L_1 = (Il2CppObject *)il2cpp_codegen_object_new(Il2CppObject_il2cpp_TypeInfo_var);
		Object__ctor_m2551263788(L_1, /*hidden argument*/NULL);
		__this->set_cache_lock_12(L_1);
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		String_t* L_2 = ___fileName0;
		FileStream_t1695958676 * L_3 = (FileStream_t1695958676 *)il2cpp_codegen_object_new(FileStream_t1695958676_il2cpp_TypeInfo_var);
		FileStream__ctor_m3699774824(L_3, L_2, 3, 1, 1, /*hidden argument*/NULL);
		BinaryReader_t2491843768 * L_4 = (BinaryReader_t2491843768 *)il2cpp_codegen_object_new(BinaryReader_t2491843768_il2cpp_TypeInfo_var);
		BinaryReader__ctor_m4190061006(L_4, L_3, /*hidden argument*/NULL);
		__this->set_reader_0(L_4);
		StreamingContext_t1417235061  L_5;
		memset(&L_5, 0, sizeof(L_5));
		StreamingContext__ctor_m3756336578(&L_5, ((int32_t)12), /*hidden argument*/NULL);
		BinaryFormatter_t1866979105 * L_6 = (BinaryFormatter_t1866979105 *)il2cpp_codegen_object_new(BinaryFormatter_t1866979105_il2cpp_TypeInfo_var);
		BinaryFormatter__ctor_m3750141051(L_6, (Il2CppObject *)NULL, L_5, /*hidden argument*/NULL);
		__this->set_formatter_2(L_6);
		ResourceReader_ReadHeaders_m881647957(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Collections.IEnumerator System.Resources.ResourceReader::System.Collections.IEnumerable.GetEnumerator()
extern Il2CppClass* IResourceReader_t3222588482_il2cpp_TypeInfo_var;
extern const uint32_t ResourceReader_System_Collections_IEnumerable_GetEnumerator_m1456908404_MetadataUsageId;
extern "C"  Il2CppObject * ResourceReader_System_Collections_IEnumerable_GetEnumerator_m1456908404 (ResourceReader_t2463923611 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ResourceReader_System_Collections_IEnumerable_GetEnumerator_m1456908404_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Il2CppObject * L_0 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(1 /* System.Collections.IDictionaryEnumerator System.Resources.IResourceReader::GetEnumerator() */, IResourceReader_t3222588482_il2cpp_TypeInfo_var, __this);
		return L_0;
	}
}
// System.Void System.Resources.ResourceReader::System.IDisposable.Dispose()
extern "C"  void ResourceReader_System_IDisposable_Dispose_m1825886190 (ResourceReader_t2463923611 * __this, const MethodInfo* method)
{
	{
		ResourceReader_Dispose_m3925831971(__this, (bool)1, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Resources.ResourceReader::ReadHeaders()
extern const Il2CppType* ResourceSet_t1348327650_0_0_0_var;
extern Il2CppClass* ResourceManager_t264715885_il2cpp_TypeInfo_var;
extern Il2CppClass* Int32_t2071877448_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* ArgumentException_t3259014390_il2cpp_TypeInfo_var;
extern Il2CppClass* NotSupportedException_t1793819818_il2cpp_TypeInfo_var;
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern Il2CppClass* StringU5BU5D_t1642385972_il2cpp_TypeInfo_var;
extern Il2CppClass* Int32U5BU5D_t3030399641_il2cpp_TypeInfo_var;
extern Il2CppClass* Int64U5BU5D_t717125112_il2cpp_TypeInfo_var;
extern Il2CppClass* ResourceInfoU5BU5D_t1013133725_il2cpp_TypeInfo_var;
extern Il2CppClass* EndOfStreamException_t1711658693_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral3346801017;
extern Il2CppCodeGenString* _stringLiteral1209756179;
extern Il2CppCodeGenString* _stringLiteral121826570;
extern Il2CppCodeGenString* _stringLiteral188291886;
extern Il2CppCodeGenString* _stringLiteral822759061;
extern Il2CppCodeGenString* _stringLiteral4210250130;
extern Il2CppCodeGenString* _stringLiteral3566076869;
extern Il2CppCodeGenString* _stringLiteral1483797907;
extern Il2CppCodeGenString* _stringLiteral1593944905;
extern const uint32_t ResourceReader_ReadHeaders_m881647957_MetadataUsageId;
extern "C"  void ResourceReader_ReadHeaders_m881647957 (ResourceReader_t2463923611 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ResourceReader_ReadHeaders_m881647957_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	String_t* V_3 = NULL;
	String_t* V_4 = NULL;
	int32_t V_5 = 0;
	int32_t V_6 = 0;
	int32_t V_7 = 0;
	int32_t V_8 = 0;
	uint8_t V_9 = 0x0;
	int32_t V_10 = 0;
	Int64U5BU5D_t717125112* V_11 = NULL;
	int32_t V_12 = 0;
	int64_t V_13 = 0;
	int32_t V_14 = 0;
	EndOfStreamException_t1711658693 * V_15 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);

IL_0000:
	try
	{ // begin try (depth: 1)
		{
			BinaryReader_t2491843768 * L_0 = __this->get_reader_0();
			NullCheck(L_0);
			int32_t L_1 = VirtFuncInvoker0< int32_t >::Invoke(19 /* System.Int32 System.IO.BinaryReader::ReadInt32() */, L_0);
			V_0 = L_1;
			int32_t L_2 = V_0;
			IL2CPP_RUNTIME_CLASS_INIT(ResourceManager_t264715885_il2cpp_TypeInfo_var);
			int32_t L_3 = ((ResourceManager_t264715885_StaticFields*)ResourceManager_t264715885_il2cpp_TypeInfo_var->static_fields)->get_MagicNumber_3();
			if ((((int32_t)L_2) == ((int32_t)L_3)))
			{
				goto IL_002d;
			}
		}

IL_0017:
		{
			int32_t L_4 = V_0;
			int32_t L_5 = L_4;
			Il2CppObject * L_6 = Box(Int32_t2071877448_il2cpp_TypeInfo_var, &L_5);
			IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
			String_t* L_7 = String_Format_m2024975688(NULL /*static, unused*/, _stringLiteral3346801017, L_6, /*hidden argument*/NULL);
			ArgumentException_t3259014390 * L_8 = (ArgumentException_t3259014390 *)il2cpp_codegen_object_new(ArgumentException_t3259014390_il2cpp_TypeInfo_var);
			ArgumentException__ctor_m3739475201(L_8, L_7, /*hidden argument*/NULL);
			IL2CPP_RAISE_MANAGED_EXCEPTION(L_8);
		}

IL_002d:
		{
			BinaryReader_t2491843768 * L_9 = __this->get_reader_0();
			NullCheck(L_9);
			int32_t L_10 = VirtFuncInvoker0< int32_t >::Invoke(19 /* System.Int32 System.IO.BinaryReader::ReadInt32() */, L_9);
			V_1 = L_10;
			BinaryReader_t2491843768 * L_11 = __this->get_reader_0();
			NullCheck(L_11);
			int32_t L_12 = VirtFuncInvoker0< int32_t >::Invoke(19 /* System.Int32 System.IO.BinaryReader::ReadInt32() */, L_11);
			V_2 = L_12;
			int32_t L_13 = V_1;
			IL2CPP_RUNTIME_CLASS_INIT(ResourceManager_t264715885_il2cpp_TypeInfo_var);
			int32_t L_14 = ((ResourceManager_t264715885_StaticFields*)ResourceManager_t264715885_il2cpp_TypeInfo_var->static_fields)->get_HeaderVersionNumber_2();
			if ((((int32_t)L_13) <= ((int32_t)L_14)))
			{
				goto IL_0069;
			}
		}

IL_0050:
		{
			BinaryReader_t2491843768 * L_15 = __this->get_reader_0();
			NullCheck(L_15);
			Stream_t3255436806 * L_16 = VirtFuncInvoker0< Stream_t3255436806 * >::Invoke(5 /* System.IO.Stream System.IO.BinaryReader::get_BaseStream() */, L_15);
			int32_t L_17 = V_2;
			NullCheck(L_16);
			VirtFuncInvoker2< int64_t, int64_t, int32_t >::Invoke(16 /* System.Int64 System.IO.Stream::Seek(System.Int64,System.IO.SeekOrigin) */, L_16, (((int64_t)((int64_t)L_17))), 1);
			goto IL_00e1;
		}

IL_0069:
		{
			BinaryReader_t2491843768 * L_18 = __this->get_reader_0();
			NullCheck(L_18);
			String_t* L_19 = VirtFuncInvoker0< String_t* >::Invoke(22 /* System.String System.IO.BinaryReader::ReadString() */, L_18);
			V_3 = L_19;
			String_t* L_20 = V_3;
			NullCheck(L_20);
			bool L_21 = String_StartsWith_m1841920685(L_20, _stringLiteral1209756179, /*hidden argument*/NULL);
			if (L_21)
			{
				goto IL_0096;
			}
		}

IL_0085:
		{
			String_t* L_22 = V_3;
			IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
			String_t* L_23 = String_Concat_m2596409543(NULL /*static, unused*/, _stringLiteral121826570, L_22, /*hidden argument*/NULL);
			NotSupportedException_t1793819818 * L_24 = (NotSupportedException_t1793819818 *)il2cpp_codegen_object_new(NotSupportedException_t1793819818_il2cpp_TypeInfo_var);
			NotSupportedException__ctor_m836173213(L_24, L_23, /*hidden argument*/NULL);
			IL2CPP_RAISE_MANAGED_EXCEPTION(L_24);
		}

IL_0096:
		{
			BinaryReader_t2491843768 * L_25 = __this->get_reader_0();
			NullCheck(L_25);
			String_t* L_26 = VirtFuncInvoker0< String_t* >::Invoke(22 /* System.String System.IO.BinaryReader::ReadString() */, L_25);
			V_4 = L_26;
			String_t* L_27 = V_4;
			IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
			Type_t * L_28 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(ResourceSet_t1348327650_0_0_0_var), /*hidden argument*/NULL);
			NullCheck(L_28);
			String_t* L_29 = VirtFuncInvoker0< String_t* >::Invoke(18 /* System.String System.Type::get_FullName() */, L_28);
			NullCheck(L_27);
			bool L_30 = String_StartsWith_m1841920685(L_27, L_29, /*hidden argument*/NULL);
			if (L_30)
			{
				goto IL_00e1;
			}
		}

IL_00be:
		{
			String_t* L_31 = V_4;
			NullCheck(L_31);
			bool L_32 = String_StartsWith_m1841920685(L_31, _stringLiteral188291886, /*hidden argument*/NULL);
			if (L_32)
			{
				goto IL_00e1;
			}
		}

IL_00cf:
		{
			String_t* L_33 = V_4;
			IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
			String_t* L_34 = String_Concat_m2596409543(NULL /*static, unused*/, _stringLiteral822759061, L_33, /*hidden argument*/NULL);
			NotSupportedException_t1793819818 * L_35 = (NotSupportedException_t1793819818 *)il2cpp_codegen_object_new(NotSupportedException_t1793819818_il2cpp_TypeInfo_var);
			NotSupportedException__ctor_m836173213(L_35, L_34, /*hidden argument*/NULL);
			IL2CPP_RAISE_MANAGED_EXCEPTION(L_35);
		}

IL_00e1:
		{
			BinaryReader_t2491843768 * L_36 = __this->get_reader_0();
			NullCheck(L_36);
			int32_t L_37 = VirtFuncInvoker0< int32_t >::Invoke(19 /* System.Int32 System.IO.BinaryReader::ReadInt32() */, L_36);
			__this->set_resource_ver_10(L_37);
			int32_t L_38 = __this->get_resource_ver_10();
			if ((((int32_t)L_38) == ((int32_t)1)))
			{
				goto IL_0125;
			}
		}

IL_00fe:
		{
			int32_t L_39 = __this->get_resource_ver_10();
			if ((((int32_t)L_39) == ((int32_t)2)))
			{
				goto IL_0125;
			}
		}

IL_010a:
		{
			int32_t* L_40 = __this->get_address_of_resource_ver_10();
			String_t* L_41 = Int32_ToString_m2960866144(L_40, /*hidden argument*/NULL);
			IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
			String_t* L_42 = String_Concat_m2596409543(NULL /*static, unused*/, _stringLiteral4210250130, L_41, /*hidden argument*/NULL);
			NotSupportedException_t1793819818 * L_43 = (NotSupportedException_t1793819818 *)il2cpp_codegen_object_new(NotSupportedException_t1793819818_il2cpp_TypeInfo_var);
			NotSupportedException__ctor_m836173213(L_43, L_42, /*hidden argument*/NULL);
			IL2CPP_RAISE_MANAGED_EXCEPTION(L_43);
		}

IL_0125:
		{
			BinaryReader_t2491843768 * L_44 = __this->get_reader_0();
			NullCheck(L_44);
			int32_t L_45 = VirtFuncInvoker0< int32_t >::Invoke(19 /* System.Int32 System.IO.BinaryReader::ReadInt32() */, L_44);
			__this->set_resourceCount_3(L_45);
			BinaryReader_t2491843768 * L_46 = __this->get_reader_0();
			NullCheck(L_46);
			int32_t L_47 = VirtFuncInvoker0< int32_t >::Invoke(19 /* System.Int32 System.IO.BinaryReader::ReadInt32() */, L_46);
			__this->set_typeCount_4(L_47);
			int32_t L_48 = __this->get_typeCount_4();
			__this->set_typeNames_5(((StringU5BU5D_t1642385972*)SZArrayNew(StringU5BU5D_t1642385972_il2cpp_TypeInfo_var, (uint32_t)L_48)));
			V_5 = 0;
			goto IL_017a;
		}

IL_0160:
		{
			StringU5BU5D_t1642385972* L_49 = __this->get_typeNames_5();
			int32_t L_50 = V_5;
			BinaryReader_t2491843768 * L_51 = __this->get_reader_0();
			NullCheck(L_51);
			String_t* L_52 = VirtFuncInvoker0< String_t* >::Invoke(22 /* System.String System.IO.BinaryReader::ReadString() */, L_51);
			NullCheck(L_49);
			ArrayElementTypeCheck (L_49, L_52);
			(L_49)->SetAt(static_cast<il2cpp_array_size_t>(L_50), (String_t*)L_52);
			int32_t L_53 = V_5;
			V_5 = ((int32_t)((int32_t)L_53+(int32_t)1));
		}

IL_017a:
		{
			int32_t L_54 = V_5;
			int32_t L_55 = __this->get_typeCount_4();
			if ((((int32_t)L_54) < ((int32_t)L_55)))
			{
				goto IL_0160;
			}
		}

IL_0187:
		{
			BinaryReader_t2491843768 * L_56 = __this->get_reader_0();
			NullCheck(L_56);
			Stream_t3255436806 * L_57 = VirtFuncInvoker0< Stream_t3255436806 * >::Invoke(5 /* System.IO.Stream System.IO.BinaryReader::get_BaseStream() */, L_56);
			NullCheck(L_57);
			int64_t L_58 = VirtFuncInvoker0< int64_t >::Invoke(9 /* System.Int64 System.IO.Stream::get_Position() */, L_57);
			V_6 = (((int32_t)((int32_t)((int64_t)((int64_t)L_58&(int64_t)(((int64_t)((int64_t)7))))))));
			V_7 = 0;
			int32_t L_59 = V_6;
			if (!L_59)
			{
				goto IL_01ad;
			}
		}

IL_01a7:
		{
			int32_t L_60 = V_6;
			V_7 = ((int32_t)((int32_t)8-(int32_t)L_60));
		}

IL_01ad:
		{
			V_8 = 0;
			goto IL_01e8;
		}

IL_01b5:
		{
			BinaryReader_t2491843768 * L_61 = __this->get_reader_0();
			NullCheck(L_61);
			uint8_t L_62 = VirtFuncInvoker0< uint8_t >::Invoke(13 /* System.Byte System.IO.BinaryReader::ReadByte() */, L_61);
			V_9 = L_62;
			uint8_t L_63 = V_9;
			int32_t L_64 = V_8;
			NullCheck(_stringLiteral3566076869);
			Il2CppChar L_65 = String_get_Chars_m4230566705(_stringLiteral3566076869, ((int32_t)((int32_t)L_64%(int32_t)3)), /*hidden argument*/NULL);
			if ((((int32_t)L_63) == ((int32_t)L_65)))
			{
				goto IL_01e2;
			}
		}

IL_01d7:
		{
			ArgumentException_t3259014390 * L_66 = (ArgumentException_t3259014390 *)il2cpp_codegen_object_new(ArgumentException_t3259014390_il2cpp_TypeInfo_var);
			ArgumentException__ctor_m3739475201(L_66, _stringLiteral1483797907, /*hidden argument*/NULL);
			IL2CPP_RAISE_MANAGED_EXCEPTION(L_66);
		}

IL_01e2:
		{
			int32_t L_67 = V_8;
			V_8 = ((int32_t)((int32_t)L_67+(int32_t)1));
		}

IL_01e8:
		{
			int32_t L_68 = V_8;
			int32_t L_69 = V_7;
			if ((((int32_t)L_68) < ((int32_t)L_69)))
			{
				goto IL_01b5;
			}
		}

IL_01f1:
		{
			int32_t L_70 = __this->get_resourceCount_3();
			__this->set_hashes_6(((Int32U5BU5D_t3030399641*)SZArrayNew(Int32U5BU5D_t3030399641_il2cpp_TypeInfo_var, (uint32_t)L_70)));
			V_10 = 0;
			goto IL_0224;
		}

IL_020a:
		{
			Int32U5BU5D_t3030399641* L_71 = __this->get_hashes_6();
			int32_t L_72 = V_10;
			BinaryReader_t2491843768 * L_73 = __this->get_reader_0();
			NullCheck(L_73);
			int32_t L_74 = VirtFuncInvoker0< int32_t >::Invoke(19 /* System.Int32 System.IO.BinaryReader::ReadInt32() */, L_73);
			NullCheck(L_71);
			(L_71)->SetAt(static_cast<il2cpp_array_size_t>(L_72), (int32_t)L_74);
			int32_t L_75 = V_10;
			V_10 = ((int32_t)((int32_t)L_75+(int32_t)1));
		}

IL_0224:
		{
			int32_t L_76 = V_10;
			int32_t L_77 = __this->get_resourceCount_3();
			if ((((int32_t)L_76) < ((int32_t)L_77)))
			{
				goto IL_020a;
			}
		}

IL_0231:
		{
			int32_t L_78 = __this->get_resourceCount_3();
			V_11 = ((Int64U5BU5D_t717125112*)SZArrayNew(Int64U5BU5D_t717125112_il2cpp_TypeInfo_var, (uint32_t)L_78));
			V_12 = 0;
			goto IL_025d;
		}

IL_0246:
		{
			Int64U5BU5D_t717125112* L_79 = V_11;
			int32_t L_80 = V_12;
			BinaryReader_t2491843768 * L_81 = __this->get_reader_0();
			NullCheck(L_81);
			int32_t L_82 = VirtFuncInvoker0< int32_t >::Invoke(19 /* System.Int32 System.IO.BinaryReader::ReadInt32() */, L_81);
			NullCheck(L_79);
			(L_79)->SetAt(static_cast<il2cpp_array_size_t>(L_80), (int64_t)(((int64_t)((int64_t)L_82))));
			int32_t L_83 = V_12;
			V_12 = ((int32_t)((int32_t)L_83+(int32_t)1));
		}

IL_025d:
		{
			int32_t L_84 = V_12;
			int32_t L_85 = __this->get_resourceCount_3();
			if ((((int32_t)L_84) < ((int32_t)L_85)))
			{
				goto IL_0246;
			}
		}

IL_026a:
		{
			BinaryReader_t2491843768 * L_86 = __this->get_reader_0();
			NullCheck(L_86);
			int32_t L_87 = VirtFuncInvoker0< int32_t >::Invoke(19 /* System.Int32 System.IO.BinaryReader::ReadInt32() */, L_86);
			__this->set_dataSectionOffset_8(L_87);
			BinaryReader_t2491843768 * L_88 = __this->get_reader_0();
			NullCheck(L_88);
			Stream_t3255436806 * L_89 = VirtFuncInvoker0< Stream_t3255436806 * >::Invoke(5 /* System.IO.Stream System.IO.BinaryReader::get_BaseStream() */, L_88);
			NullCheck(L_89);
			int64_t L_90 = VirtFuncInvoker0< int64_t >::Invoke(9 /* System.Int64 System.IO.Stream::get_Position() */, L_89);
			__this->set_nameSectionOffset_9(L_90);
			BinaryReader_t2491843768 * L_91 = __this->get_reader_0();
			NullCheck(L_91);
			Stream_t3255436806 * L_92 = VirtFuncInvoker0< Stream_t3255436806 * >::Invoke(5 /* System.IO.Stream System.IO.BinaryReader::get_BaseStream() */, L_91);
			NullCheck(L_92);
			int64_t L_93 = VirtFuncInvoker0< int64_t >::Invoke(9 /* System.Int64 System.IO.Stream::get_Position() */, L_92);
			V_13 = L_93;
			int32_t L_94 = __this->get_resourceCount_3();
			__this->set_infos_7(((ResourceInfoU5BU5D_t1013133725*)SZArrayNew(ResourceInfoU5BU5D_t1013133725_il2cpp_TypeInfo_var, (uint32_t)L_94)));
			V_14 = 0;
			goto IL_02da;
		}

IL_02bc:
		{
			Int64U5BU5D_t717125112* L_95 = V_11;
			int32_t L_96 = V_14;
			NullCheck(L_95);
			int32_t L_97 = L_96;
			int64_t L_98 = (L_95)->GetAt(static_cast<il2cpp_array_size_t>(L_97));
			ResourceInfoU5BU5D_t1013133725* L_99 = __this->get_infos_7();
			int32_t L_100 = V_14;
			NullCheck(L_99);
			ResourceReader_CreateResourceInfo_m2376522667(__this, L_98, ((L_99)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_100))), /*hidden argument*/NULL);
			int32_t L_101 = V_14;
			V_14 = ((int32_t)((int32_t)L_101+(int32_t)1));
		}

IL_02da:
		{
			int32_t L_102 = V_14;
			int32_t L_103 = __this->get_resourceCount_3();
			if ((((int32_t)L_102) < ((int32_t)L_103)))
			{
				goto IL_02bc;
			}
		}

IL_02e7:
		{
			BinaryReader_t2491843768 * L_104 = __this->get_reader_0();
			NullCheck(L_104);
			Stream_t3255436806 * L_105 = VirtFuncInvoker0< Stream_t3255436806 * >::Invoke(5 /* System.IO.Stream System.IO.BinaryReader::get_BaseStream() */, L_104);
			int64_t L_106 = V_13;
			NullCheck(L_105);
			VirtFuncInvoker2< int64_t, int64_t, int32_t >::Invoke(16 /* System.Int64 System.IO.Stream::Seek(System.Int64,System.IO.SeekOrigin) */, L_105, L_106, 0);
			V_11 = (Int64U5BU5D_t717125112*)NULL;
			goto IL_0317;
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__exception_local = (Exception_t1927440687 *)e.ex;
		if(il2cpp_codegen_class_is_assignable_from (EndOfStreamException_t1711658693_il2cpp_TypeInfo_var, e.ex->object.klass))
			goto CATCH_0303;
		throw e;
	}

CATCH_0303:
	{ // begin catch(System.IO.EndOfStreamException)
		{
			V_15 = ((EndOfStreamException_t1711658693 *)__exception_local);
			EndOfStreamException_t1711658693 * L_107 = V_15;
			ArgumentException_t3259014390 * L_108 = (ArgumentException_t3259014390 *)il2cpp_codegen_object_new(ArgumentException_t3259014390_il2cpp_TypeInfo_var);
			ArgumentException__ctor_m3553968249(L_108, _stringLiteral1593944905, L_107, /*hidden argument*/NULL);
			IL2CPP_RAISE_MANAGED_EXCEPTION(L_108);
		}

IL_0312:
		{
			goto IL_0317;
		}
	} // end catch (depth: 1)

IL_0317:
	{
		return;
	}
}
// System.Void System.Resources.ResourceReader::CreateResourceInfo(System.Int64,System.Resources.ResourceReader/ResourceInfo&)
extern Il2CppClass* ByteU5BU5D_t3397334013_il2cpp_TypeInfo_var;
extern Il2CppClass* Encoding_t663144255_il2cpp_TypeInfo_var;
extern const uint32_t ResourceReader_CreateResourceInfo_m2376522667_MetadataUsageId;
extern "C"  void ResourceReader_CreateResourceInfo_m2376522667 (ResourceReader_t2463923611 * __this, int64_t ___position0, ResourceInfo_t3933049236 * ___info1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ResourceReader_CreateResourceInfo_m2376522667_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int64_t V_0 = 0;
	int32_t V_1 = 0;
	ByteU5BU5D_t3397334013* V_2 = NULL;
	String_t* V_3 = NULL;
	int64_t V_4 = 0;
	int32_t V_5 = 0;
	{
		int64_t L_0 = ___position0;
		int64_t L_1 = __this->get_nameSectionOffset_9();
		V_0 = ((int64_t)((int64_t)L_0+(int64_t)L_1));
		BinaryReader_t2491843768 * L_2 = __this->get_reader_0();
		NullCheck(L_2);
		Stream_t3255436806 * L_3 = VirtFuncInvoker0< Stream_t3255436806 * >::Invoke(5 /* System.IO.Stream System.IO.BinaryReader::get_BaseStream() */, L_2);
		int64_t L_4 = V_0;
		NullCheck(L_3);
		VirtFuncInvoker2< int64_t, int64_t, int32_t >::Invoke(16 /* System.Int64 System.IO.Stream::Seek(System.Int64,System.IO.SeekOrigin) */, L_3, L_4, 0);
		int32_t L_5 = ResourceReader_Read7BitEncodedInt_m2962317104(__this, /*hidden argument*/NULL);
		V_1 = L_5;
		int32_t L_6 = V_1;
		V_2 = ((ByteU5BU5D_t3397334013*)SZArrayNew(ByteU5BU5D_t3397334013_il2cpp_TypeInfo_var, (uint32_t)L_6));
		BinaryReader_t2491843768 * L_7 = __this->get_reader_0();
		ByteU5BU5D_t3397334013* L_8 = V_2;
		int32_t L_9 = V_1;
		NullCheck(L_7);
		VirtFuncInvoker3< int32_t, ByteU5BU5D_t3397334013*, int32_t, int32_t >::Invoke(10 /* System.Int32 System.IO.BinaryReader::Read(System.Byte[],System.Int32,System.Int32) */, L_7, L_8, 0, L_9);
		IL2CPP_RUNTIME_CLASS_INIT(Encoding_t663144255_il2cpp_TypeInfo_var);
		Encoding_t663144255 * L_10 = Encoding_get_Unicode_m1382741113(NULL /*static, unused*/, /*hidden argument*/NULL);
		ByteU5BU5D_t3397334013* L_11 = V_2;
		NullCheck(L_10);
		String_t* L_12 = VirtFuncInvoker1< String_t*, ByteU5BU5D_t3397334013* >::Invoke(22 /* System.String System.Text.Encoding::GetString(System.Byte[]) */, L_10, L_11);
		V_3 = L_12;
		BinaryReader_t2491843768 * L_13 = __this->get_reader_0();
		NullCheck(L_13);
		int32_t L_14 = VirtFuncInvoker0< int32_t >::Invoke(19 /* System.Int32 System.IO.BinaryReader::ReadInt32() */, L_13);
		int32_t L_15 = __this->get_dataSectionOffset_8();
		V_4 = (((int64_t)((int64_t)((int32_t)((int32_t)L_14+(int32_t)L_15)))));
		BinaryReader_t2491843768 * L_16 = __this->get_reader_0();
		NullCheck(L_16);
		Stream_t3255436806 * L_17 = VirtFuncInvoker0< Stream_t3255436806 * >::Invoke(5 /* System.IO.Stream System.IO.BinaryReader::get_BaseStream() */, L_16);
		int64_t L_18 = V_4;
		NullCheck(L_17);
		VirtFuncInvoker2< int64_t, int64_t, int32_t >::Invoke(16 /* System.Int64 System.IO.Stream::Seek(System.Int64,System.IO.SeekOrigin) */, L_17, L_18, 0);
		int32_t L_19 = ResourceReader_Read7BitEncodedInt_m2962317104(__this, /*hidden argument*/NULL);
		V_5 = L_19;
		ResourceInfo_t3933049236 * L_20 = ___info1;
		String_t* L_21 = V_3;
		BinaryReader_t2491843768 * L_22 = __this->get_reader_0();
		NullCheck(L_22);
		Stream_t3255436806 * L_23 = VirtFuncInvoker0< Stream_t3255436806 * >::Invoke(5 /* System.IO.Stream System.IO.BinaryReader::get_BaseStream() */, L_22);
		NullCheck(L_23);
		int64_t L_24 = VirtFuncInvoker0< int64_t >::Invoke(9 /* System.Int64 System.IO.Stream::get_Position() */, L_23);
		int32_t L_25 = V_5;
		ResourceInfo__ctor_m2401359321(L_20, L_21, L_24, L_25, /*hidden argument*/NULL);
		return;
	}
}
// System.Int32 System.Resources.ResourceReader::Read7BitEncodedInt()
extern "C"  int32_t ResourceReader_Read7BitEncodedInt_m2962317104 (ResourceReader_t2463923611 * __this, const MethodInfo* method)
{
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	uint8_t V_2 = 0x0;
	{
		V_0 = 0;
		V_1 = 0;
	}

IL_0004:
	{
		BinaryReader_t2491843768 * L_0 = __this->get_reader_0();
		NullCheck(L_0);
		uint8_t L_1 = VirtFuncInvoker0< uint8_t >::Invoke(13 /* System.Byte System.IO.BinaryReader::ReadByte() */, L_0);
		V_2 = L_1;
		int32_t L_2 = V_0;
		uint8_t L_3 = V_2;
		int32_t L_4 = V_1;
		V_0 = ((int32_t)((int32_t)L_2|(int32_t)((int32_t)((int32_t)((int32_t)((int32_t)L_3&(int32_t)((int32_t)127)))<<(int32_t)((int32_t)((int32_t)L_4&(int32_t)((int32_t)31)))))));
		int32_t L_5 = V_1;
		V_1 = ((int32_t)((int32_t)L_5+(int32_t)7));
		uint8_t L_6 = V_2;
		if ((((int32_t)((int32_t)((int32_t)L_6&(int32_t)((int32_t)128)))) == ((int32_t)((int32_t)128))))
		{
			goto IL_0004;
		}
	}
	{
		int32_t L_7 = V_0;
		return L_7;
	}
}
// System.Object System.Resources.ResourceReader::ReadValueVer2(System.Int32)
extern Il2CppClass* Boolean_t3825574718_il2cpp_TypeInfo_var;
extern Il2CppClass* Char_t3454481338_il2cpp_TypeInfo_var;
extern Il2CppClass* Byte_t3683104436_il2cpp_TypeInfo_var;
extern Il2CppClass* SByte_t454417549_il2cpp_TypeInfo_var;
extern Il2CppClass* Int16_t4041245914_il2cpp_TypeInfo_var;
extern Il2CppClass* UInt16_t986882611_il2cpp_TypeInfo_var;
extern Il2CppClass* Int32_t2071877448_il2cpp_TypeInfo_var;
extern Il2CppClass* UInt32_t2149682021_il2cpp_TypeInfo_var;
extern Il2CppClass* Int64_t909078037_il2cpp_TypeInfo_var;
extern Il2CppClass* UInt64_t2909196914_il2cpp_TypeInfo_var;
extern Il2CppClass* Single_t2076509932_il2cpp_TypeInfo_var;
extern Il2CppClass* Double_t4078015681_il2cpp_TypeInfo_var;
extern Il2CppClass* Decimal_t724701077_il2cpp_TypeInfo_var;
extern Il2CppClass* DateTime_t693205669_il2cpp_TypeInfo_var;
extern Il2CppClass* TimeSpan_t3430258949_il2cpp_TypeInfo_var;
extern Il2CppClass* ByteU5BU5D_t3397334013_il2cpp_TypeInfo_var;
extern Il2CppClass* MemoryStream_t743994179_il2cpp_TypeInfo_var;
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern const uint32_t ResourceReader_ReadValueVer2_m252146049_MetadataUsageId;
extern "C"  Il2CppObject * ResourceReader_ReadValueVer2_m252146049 (ResourceReader_t2463923611 * __this, int32_t ___type_index0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ResourceReader_ReadValueVer2_m252146049_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ByteU5BU5D_t3397334013* V_0 = NULL;
	int32_t V_1 = 0;
	{
		int32_t L_0 = ___type_index0;
		V_1 = L_0;
		int32_t L_1 = V_1;
		if (L_1 == 0)
		{
			goto IL_0095;
		}
		if (L_1 == 1)
		{
			goto IL_0097;
		}
		if (L_1 == 2)
		{
			goto IL_00a3;
		}
		if (L_1 == 3)
		{
			goto IL_00b4;
		}
		if (L_1 == 4)
		{
			goto IL_00c5;
		}
		if (L_1 == 5)
		{
			goto IL_00d6;
		}
		if (L_1 == 6)
		{
			goto IL_00e7;
		}
		if (L_1 == 7)
		{
			goto IL_00f8;
		}
		if (L_1 == 8)
		{
			goto IL_0109;
		}
		if (L_1 == 9)
		{
			goto IL_011a;
		}
		if (L_1 == 10)
		{
			goto IL_012b;
		}
		if (L_1 == 11)
		{
			goto IL_013c;
		}
		if (L_1 == 12)
		{
			goto IL_014d;
		}
		if (L_1 == 13)
		{
			goto IL_015e;
		}
		if (L_1 == 14)
		{
			goto IL_016f;
		}
		if (L_1 == 15)
		{
			goto IL_0180;
		}
		if (L_1 == 16)
		{
			goto IL_0196;
		}
		if (L_1 == 17)
		{
			goto IL_01ed;
		}
		if (L_1 == 18)
		{
			goto IL_01ed;
		}
		if (L_1 == 19)
		{
			goto IL_01ed;
		}
		if (L_1 == 20)
		{
			goto IL_01ed;
		}
		if (L_1 == 21)
		{
			goto IL_01ed;
		}
		if (L_1 == 22)
		{
			goto IL_01ed;
		}
		if (L_1 == 23)
		{
			goto IL_01ed;
		}
		if (L_1 == 24)
		{
			goto IL_01ed;
		}
		if (L_1 == 25)
		{
			goto IL_01ed;
		}
		if (L_1 == 26)
		{
			goto IL_01ed;
		}
		if (L_1 == 27)
		{
			goto IL_01ed;
		}
		if (L_1 == 28)
		{
			goto IL_01ed;
		}
		if (L_1 == 29)
		{
			goto IL_01ed;
		}
		if (L_1 == 30)
		{
			goto IL_01ed;
		}
		if (L_1 == 31)
		{
			goto IL_01ed;
		}
		if (L_1 == 32)
		{
			goto IL_01ac;
		}
		if (L_1 == 33)
		{
			goto IL_01c3;
		}
	}
	{
		goto IL_01ed;
	}

IL_0095:
	{
		return NULL;
	}

IL_0097:
	{
		BinaryReader_t2491843768 * L_2 = __this->get_reader_0();
		NullCheck(L_2);
		String_t* L_3 = VirtFuncInvoker0< String_t* >::Invoke(22 /* System.String System.IO.BinaryReader::ReadString() */, L_2);
		return L_3;
	}

IL_00a3:
	{
		BinaryReader_t2491843768 * L_4 = __this->get_reader_0();
		NullCheck(L_4);
		bool L_5 = VirtFuncInvoker0< bool >::Invoke(12 /* System.Boolean System.IO.BinaryReader::ReadBoolean() */, L_4);
		bool L_6 = L_5;
		Il2CppObject * L_7 = Box(Boolean_t3825574718_il2cpp_TypeInfo_var, &L_6);
		return L_7;
	}

IL_00b4:
	{
		BinaryReader_t2491843768 * L_8 = __this->get_reader_0();
		NullCheck(L_8);
		uint16_t L_9 = VirtFuncInvoker0< uint16_t >::Invoke(24 /* System.UInt16 System.IO.BinaryReader::ReadUInt16() */, L_8);
		Il2CppChar L_10 = ((Il2CppChar)L_9);
		Il2CppObject * L_11 = Box(Char_t3454481338_il2cpp_TypeInfo_var, &L_10);
		return L_11;
	}

IL_00c5:
	{
		BinaryReader_t2491843768 * L_12 = __this->get_reader_0();
		NullCheck(L_12);
		uint8_t L_13 = VirtFuncInvoker0< uint8_t >::Invoke(13 /* System.Byte System.IO.BinaryReader::ReadByte() */, L_12);
		uint8_t L_14 = L_13;
		Il2CppObject * L_15 = Box(Byte_t3683104436_il2cpp_TypeInfo_var, &L_14);
		return L_15;
	}

IL_00d6:
	{
		BinaryReader_t2491843768 * L_16 = __this->get_reader_0();
		NullCheck(L_16);
		int8_t L_17 = VirtFuncInvoker0< int8_t >::Invoke(21 /* System.SByte System.IO.BinaryReader::ReadSByte() */, L_16);
		int8_t L_18 = L_17;
		Il2CppObject * L_19 = Box(SByte_t454417549_il2cpp_TypeInfo_var, &L_18);
		return L_19;
	}

IL_00e7:
	{
		BinaryReader_t2491843768 * L_20 = __this->get_reader_0();
		NullCheck(L_20);
		int16_t L_21 = VirtFuncInvoker0< int16_t >::Invoke(18 /* System.Int16 System.IO.BinaryReader::ReadInt16() */, L_20);
		int16_t L_22 = L_21;
		Il2CppObject * L_23 = Box(Int16_t4041245914_il2cpp_TypeInfo_var, &L_22);
		return L_23;
	}

IL_00f8:
	{
		BinaryReader_t2491843768 * L_24 = __this->get_reader_0();
		NullCheck(L_24);
		uint16_t L_25 = VirtFuncInvoker0< uint16_t >::Invoke(24 /* System.UInt16 System.IO.BinaryReader::ReadUInt16() */, L_24);
		uint16_t L_26 = L_25;
		Il2CppObject * L_27 = Box(UInt16_t986882611_il2cpp_TypeInfo_var, &L_26);
		return L_27;
	}

IL_0109:
	{
		BinaryReader_t2491843768 * L_28 = __this->get_reader_0();
		NullCheck(L_28);
		int32_t L_29 = VirtFuncInvoker0< int32_t >::Invoke(19 /* System.Int32 System.IO.BinaryReader::ReadInt32() */, L_28);
		int32_t L_30 = L_29;
		Il2CppObject * L_31 = Box(Int32_t2071877448_il2cpp_TypeInfo_var, &L_30);
		return L_31;
	}

IL_011a:
	{
		BinaryReader_t2491843768 * L_32 = __this->get_reader_0();
		NullCheck(L_32);
		uint32_t L_33 = VirtFuncInvoker0< uint32_t >::Invoke(25 /* System.UInt32 System.IO.BinaryReader::ReadUInt32() */, L_32);
		uint32_t L_34 = L_33;
		Il2CppObject * L_35 = Box(UInt32_t2149682021_il2cpp_TypeInfo_var, &L_34);
		return L_35;
	}

IL_012b:
	{
		BinaryReader_t2491843768 * L_36 = __this->get_reader_0();
		NullCheck(L_36);
		int64_t L_37 = VirtFuncInvoker0< int64_t >::Invoke(20 /* System.Int64 System.IO.BinaryReader::ReadInt64() */, L_36);
		int64_t L_38 = L_37;
		Il2CppObject * L_39 = Box(Int64_t909078037_il2cpp_TypeInfo_var, &L_38);
		return L_39;
	}

IL_013c:
	{
		BinaryReader_t2491843768 * L_40 = __this->get_reader_0();
		NullCheck(L_40);
		uint64_t L_41 = VirtFuncInvoker0< uint64_t >::Invoke(26 /* System.UInt64 System.IO.BinaryReader::ReadUInt64() */, L_40);
		uint64_t L_42 = L_41;
		Il2CppObject * L_43 = Box(UInt64_t2909196914_il2cpp_TypeInfo_var, &L_42);
		return L_43;
	}

IL_014d:
	{
		BinaryReader_t2491843768 * L_44 = __this->get_reader_0();
		NullCheck(L_44);
		float L_45 = VirtFuncInvoker0< float >::Invoke(23 /* System.Single System.IO.BinaryReader::ReadSingle() */, L_44);
		float L_46 = L_45;
		Il2CppObject * L_47 = Box(Single_t2076509932_il2cpp_TypeInfo_var, &L_46);
		return L_47;
	}

IL_015e:
	{
		BinaryReader_t2491843768 * L_48 = __this->get_reader_0();
		NullCheck(L_48);
		double L_49 = VirtFuncInvoker0< double >::Invoke(17 /* System.Double System.IO.BinaryReader::ReadDouble() */, L_48);
		double L_50 = L_49;
		Il2CppObject * L_51 = Box(Double_t4078015681_il2cpp_TypeInfo_var, &L_50);
		return L_51;
	}

IL_016f:
	{
		BinaryReader_t2491843768 * L_52 = __this->get_reader_0();
		NullCheck(L_52);
		Decimal_t724701077  L_53 = VirtFuncInvoker0< Decimal_t724701077  >::Invoke(16 /* System.Decimal System.IO.BinaryReader::ReadDecimal() */, L_52);
		Decimal_t724701077  L_54 = L_53;
		Il2CppObject * L_55 = Box(Decimal_t724701077_il2cpp_TypeInfo_var, &L_54);
		return L_55;
	}

IL_0180:
	{
		BinaryReader_t2491843768 * L_56 = __this->get_reader_0();
		NullCheck(L_56);
		int64_t L_57 = VirtFuncInvoker0< int64_t >::Invoke(20 /* System.Int64 System.IO.BinaryReader::ReadInt64() */, L_56);
		DateTime_t693205669  L_58;
		memset(&L_58, 0, sizeof(L_58));
		DateTime__ctor_m2586249130(&L_58, L_57, /*hidden argument*/NULL);
		DateTime_t693205669  L_59 = L_58;
		Il2CppObject * L_60 = Box(DateTime_t693205669_il2cpp_TypeInfo_var, &L_59);
		return L_60;
	}

IL_0196:
	{
		BinaryReader_t2491843768 * L_61 = __this->get_reader_0();
		NullCheck(L_61);
		int64_t L_62 = VirtFuncInvoker0< int64_t >::Invoke(20 /* System.Int64 System.IO.BinaryReader::ReadInt64() */, L_61);
		TimeSpan_t3430258949  L_63;
		memset(&L_63, 0, sizeof(L_63));
		TimeSpan__ctor_m96381766(&L_63, L_62, /*hidden argument*/NULL);
		TimeSpan_t3430258949  L_64 = L_63;
		Il2CppObject * L_65 = Box(TimeSpan_t3430258949_il2cpp_TypeInfo_var, &L_64);
		return L_65;
	}

IL_01ac:
	{
		BinaryReader_t2491843768 * L_66 = __this->get_reader_0();
		BinaryReader_t2491843768 * L_67 = __this->get_reader_0();
		NullCheck(L_67);
		int32_t L_68 = VirtFuncInvoker0< int32_t >::Invoke(19 /* System.Int32 System.IO.BinaryReader::ReadInt32() */, L_67);
		NullCheck(L_66);
		ByteU5BU5D_t3397334013* L_69 = VirtFuncInvoker1< ByteU5BU5D_t3397334013*, int32_t >::Invoke(14 /* System.Byte[] System.IO.BinaryReader::ReadBytes(System.Int32) */, L_66, L_68);
		return (Il2CppObject *)L_69;
	}

IL_01c3:
	{
		BinaryReader_t2491843768 * L_70 = __this->get_reader_0();
		NullCheck(L_70);
		uint32_t L_71 = VirtFuncInvoker0< uint32_t >::Invoke(25 /* System.UInt32 System.IO.BinaryReader::ReadUInt32() */, L_70);
		V_0 = ((ByteU5BU5D_t3397334013*)SZArrayNew(ByteU5BU5D_t3397334013_il2cpp_TypeInfo_var, (uint32_t)(((uintptr_t)L_71))));
		BinaryReader_t2491843768 * L_72 = __this->get_reader_0();
		ByteU5BU5D_t3397334013* L_73 = V_0;
		ByteU5BU5D_t3397334013* L_74 = V_0;
		NullCheck(L_74);
		NullCheck(L_72);
		VirtFuncInvoker3< int32_t, ByteU5BU5D_t3397334013*, int32_t, int32_t >::Invoke(10 /* System.Int32 System.IO.BinaryReader::Read(System.Byte[],System.Int32,System.Int32) */, L_72, L_73, 0, (((int32_t)((int32_t)(((Il2CppArray *)L_74)->max_length)))));
		ByteU5BU5D_t3397334013* L_75 = V_0;
		MemoryStream_t743994179 * L_76 = (MemoryStream_t743994179 *)il2cpp_codegen_object_new(MemoryStream_t743994179_il2cpp_TypeInfo_var);
		MemoryStream__ctor_m4073175573(L_76, L_75, /*hidden argument*/NULL);
		return L_76;
	}

IL_01ed:
	{
		int32_t L_77 = ___type_index0;
		___type_index0 = ((int32_t)((int32_t)L_77-(int32_t)((int32_t)64)));
		StringU5BU5D_t1642385972* L_78 = __this->get_typeNames_5();
		int32_t L_79 = ___type_index0;
		NullCheck(L_78);
		int32_t L_80 = L_79;
		String_t* L_81 = (L_78)->GetAt(static_cast<il2cpp_array_size_t>(L_80));
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_82 = il2cpp_codegen_get_type((Il2CppMethodPointer)&Type_GetType_m402049910, L_81, (bool)1, "mscorlib, Version=2.0.5.0, Culture=neutral, PublicKeyToken=7cec85d7bea7798e");
		Il2CppObject * L_83 = ResourceReader_ReadNonPredefinedValue_m715286753(__this, L_82, /*hidden argument*/NULL);
		return L_83;
	}
}
// System.Object System.Resources.ResourceReader::ReadValueVer1(System.Type)
extern const Il2CppType* String_t_0_0_0_var;
extern const Il2CppType* Int32_t2071877448_0_0_0_var;
extern const Il2CppType* Byte_t3683104436_0_0_0_var;
extern const Il2CppType* Double_t4078015681_0_0_0_var;
extern const Il2CppType* Int16_t4041245914_0_0_0_var;
extern const Il2CppType* Int64_t909078037_0_0_0_var;
extern const Il2CppType* SByte_t454417549_0_0_0_var;
extern const Il2CppType* Single_t2076509932_0_0_0_var;
extern const Il2CppType* TimeSpan_t3430258949_0_0_0_var;
extern const Il2CppType* UInt16_t986882611_0_0_0_var;
extern const Il2CppType* UInt32_t2149682021_0_0_0_var;
extern const Il2CppType* UInt64_t2909196914_0_0_0_var;
extern const Il2CppType* Decimal_t724701077_0_0_0_var;
extern const Il2CppType* DateTime_t693205669_0_0_0_var;
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern Il2CppClass* Int32_t2071877448_il2cpp_TypeInfo_var;
extern Il2CppClass* Byte_t3683104436_il2cpp_TypeInfo_var;
extern Il2CppClass* Double_t4078015681_il2cpp_TypeInfo_var;
extern Il2CppClass* Int16_t4041245914_il2cpp_TypeInfo_var;
extern Il2CppClass* Int64_t909078037_il2cpp_TypeInfo_var;
extern Il2CppClass* SByte_t454417549_il2cpp_TypeInfo_var;
extern Il2CppClass* Single_t2076509932_il2cpp_TypeInfo_var;
extern Il2CppClass* TimeSpan_t3430258949_il2cpp_TypeInfo_var;
extern Il2CppClass* UInt16_t986882611_il2cpp_TypeInfo_var;
extern Il2CppClass* UInt32_t2149682021_il2cpp_TypeInfo_var;
extern Il2CppClass* UInt64_t2909196914_il2cpp_TypeInfo_var;
extern Il2CppClass* Decimal_t724701077_il2cpp_TypeInfo_var;
extern Il2CppClass* DateTime_t693205669_il2cpp_TypeInfo_var;
extern const uint32_t ResourceReader_ReadValueVer1_m3519678454_MetadataUsageId;
extern "C"  Il2CppObject * ResourceReader_ReadValueVer1_m3519678454 (ResourceReader_t2463923611 * __this, Type_t * ___type0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ResourceReader_ReadValueVer1_m3519678454_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Type_t * L_0 = ___type0;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_1 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(String_t_0_0_0_var), /*hidden argument*/NULL);
		if ((!(((Il2CppObject*)(Type_t *)L_0) == ((Il2CppObject*)(Type_t *)L_1))))
		{
			goto IL_001c;
		}
	}
	{
		BinaryReader_t2491843768 * L_2 = __this->get_reader_0();
		NullCheck(L_2);
		String_t* L_3 = VirtFuncInvoker0< String_t* >::Invoke(22 /* System.String System.IO.BinaryReader::ReadString() */, L_2);
		return L_3;
	}

IL_001c:
	{
		Type_t * L_4 = ___type0;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_5 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Int32_t2071877448_0_0_0_var), /*hidden argument*/NULL);
		if ((!(((Il2CppObject*)(Type_t *)L_4) == ((Il2CppObject*)(Type_t *)L_5))))
		{
			goto IL_003d;
		}
	}
	{
		BinaryReader_t2491843768 * L_6 = __this->get_reader_0();
		NullCheck(L_6);
		int32_t L_7 = VirtFuncInvoker0< int32_t >::Invoke(19 /* System.Int32 System.IO.BinaryReader::ReadInt32() */, L_6);
		int32_t L_8 = L_7;
		Il2CppObject * L_9 = Box(Int32_t2071877448_il2cpp_TypeInfo_var, &L_8);
		return L_9;
	}

IL_003d:
	{
		Type_t * L_10 = ___type0;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_11 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Byte_t3683104436_0_0_0_var), /*hidden argument*/NULL);
		if ((!(((Il2CppObject*)(Type_t *)L_10) == ((Il2CppObject*)(Type_t *)L_11))))
		{
			goto IL_005e;
		}
	}
	{
		BinaryReader_t2491843768 * L_12 = __this->get_reader_0();
		NullCheck(L_12);
		uint8_t L_13 = VirtFuncInvoker0< uint8_t >::Invoke(13 /* System.Byte System.IO.BinaryReader::ReadByte() */, L_12);
		uint8_t L_14 = L_13;
		Il2CppObject * L_15 = Box(Byte_t3683104436_il2cpp_TypeInfo_var, &L_14);
		return L_15;
	}

IL_005e:
	{
		Type_t * L_16 = ___type0;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_17 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Double_t4078015681_0_0_0_var), /*hidden argument*/NULL);
		if ((!(((Il2CppObject*)(Type_t *)L_16) == ((Il2CppObject*)(Type_t *)L_17))))
		{
			goto IL_007f;
		}
	}
	{
		BinaryReader_t2491843768 * L_18 = __this->get_reader_0();
		NullCheck(L_18);
		double L_19 = VirtFuncInvoker0< double >::Invoke(17 /* System.Double System.IO.BinaryReader::ReadDouble() */, L_18);
		double L_20 = L_19;
		Il2CppObject * L_21 = Box(Double_t4078015681_il2cpp_TypeInfo_var, &L_20);
		return L_21;
	}

IL_007f:
	{
		Type_t * L_22 = ___type0;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_23 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Int16_t4041245914_0_0_0_var), /*hidden argument*/NULL);
		if ((!(((Il2CppObject*)(Type_t *)L_22) == ((Il2CppObject*)(Type_t *)L_23))))
		{
			goto IL_00a0;
		}
	}
	{
		BinaryReader_t2491843768 * L_24 = __this->get_reader_0();
		NullCheck(L_24);
		int16_t L_25 = VirtFuncInvoker0< int16_t >::Invoke(18 /* System.Int16 System.IO.BinaryReader::ReadInt16() */, L_24);
		int16_t L_26 = L_25;
		Il2CppObject * L_27 = Box(Int16_t4041245914_il2cpp_TypeInfo_var, &L_26);
		return L_27;
	}

IL_00a0:
	{
		Type_t * L_28 = ___type0;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_29 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Int64_t909078037_0_0_0_var), /*hidden argument*/NULL);
		if ((!(((Il2CppObject*)(Type_t *)L_28) == ((Il2CppObject*)(Type_t *)L_29))))
		{
			goto IL_00c1;
		}
	}
	{
		BinaryReader_t2491843768 * L_30 = __this->get_reader_0();
		NullCheck(L_30);
		int64_t L_31 = VirtFuncInvoker0< int64_t >::Invoke(20 /* System.Int64 System.IO.BinaryReader::ReadInt64() */, L_30);
		int64_t L_32 = L_31;
		Il2CppObject * L_33 = Box(Int64_t909078037_il2cpp_TypeInfo_var, &L_32);
		return L_33;
	}

IL_00c1:
	{
		Type_t * L_34 = ___type0;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_35 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(SByte_t454417549_0_0_0_var), /*hidden argument*/NULL);
		if ((!(((Il2CppObject*)(Type_t *)L_34) == ((Il2CppObject*)(Type_t *)L_35))))
		{
			goto IL_00e2;
		}
	}
	{
		BinaryReader_t2491843768 * L_36 = __this->get_reader_0();
		NullCheck(L_36);
		int8_t L_37 = VirtFuncInvoker0< int8_t >::Invoke(21 /* System.SByte System.IO.BinaryReader::ReadSByte() */, L_36);
		int8_t L_38 = L_37;
		Il2CppObject * L_39 = Box(SByte_t454417549_il2cpp_TypeInfo_var, &L_38);
		return L_39;
	}

IL_00e2:
	{
		Type_t * L_40 = ___type0;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_41 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Single_t2076509932_0_0_0_var), /*hidden argument*/NULL);
		if ((!(((Il2CppObject*)(Type_t *)L_40) == ((Il2CppObject*)(Type_t *)L_41))))
		{
			goto IL_0103;
		}
	}
	{
		BinaryReader_t2491843768 * L_42 = __this->get_reader_0();
		NullCheck(L_42);
		float L_43 = VirtFuncInvoker0< float >::Invoke(23 /* System.Single System.IO.BinaryReader::ReadSingle() */, L_42);
		float L_44 = L_43;
		Il2CppObject * L_45 = Box(Single_t2076509932_il2cpp_TypeInfo_var, &L_44);
		return L_45;
	}

IL_0103:
	{
		Type_t * L_46 = ___type0;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_47 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(TimeSpan_t3430258949_0_0_0_var), /*hidden argument*/NULL);
		if ((!(((Il2CppObject*)(Type_t *)L_46) == ((Il2CppObject*)(Type_t *)L_47))))
		{
			goto IL_0129;
		}
	}
	{
		BinaryReader_t2491843768 * L_48 = __this->get_reader_0();
		NullCheck(L_48);
		int64_t L_49 = VirtFuncInvoker0< int64_t >::Invoke(20 /* System.Int64 System.IO.BinaryReader::ReadInt64() */, L_48);
		TimeSpan_t3430258949  L_50;
		memset(&L_50, 0, sizeof(L_50));
		TimeSpan__ctor_m96381766(&L_50, L_49, /*hidden argument*/NULL);
		TimeSpan_t3430258949  L_51 = L_50;
		Il2CppObject * L_52 = Box(TimeSpan_t3430258949_il2cpp_TypeInfo_var, &L_51);
		return L_52;
	}

IL_0129:
	{
		Type_t * L_53 = ___type0;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_54 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(UInt16_t986882611_0_0_0_var), /*hidden argument*/NULL);
		if ((!(((Il2CppObject*)(Type_t *)L_53) == ((Il2CppObject*)(Type_t *)L_54))))
		{
			goto IL_014a;
		}
	}
	{
		BinaryReader_t2491843768 * L_55 = __this->get_reader_0();
		NullCheck(L_55);
		uint16_t L_56 = VirtFuncInvoker0< uint16_t >::Invoke(24 /* System.UInt16 System.IO.BinaryReader::ReadUInt16() */, L_55);
		uint16_t L_57 = L_56;
		Il2CppObject * L_58 = Box(UInt16_t986882611_il2cpp_TypeInfo_var, &L_57);
		return L_58;
	}

IL_014a:
	{
		Type_t * L_59 = ___type0;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_60 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(UInt32_t2149682021_0_0_0_var), /*hidden argument*/NULL);
		if ((!(((Il2CppObject*)(Type_t *)L_59) == ((Il2CppObject*)(Type_t *)L_60))))
		{
			goto IL_016b;
		}
	}
	{
		BinaryReader_t2491843768 * L_61 = __this->get_reader_0();
		NullCheck(L_61);
		uint32_t L_62 = VirtFuncInvoker0< uint32_t >::Invoke(25 /* System.UInt32 System.IO.BinaryReader::ReadUInt32() */, L_61);
		uint32_t L_63 = L_62;
		Il2CppObject * L_64 = Box(UInt32_t2149682021_il2cpp_TypeInfo_var, &L_63);
		return L_64;
	}

IL_016b:
	{
		Type_t * L_65 = ___type0;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_66 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(UInt64_t2909196914_0_0_0_var), /*hidden argument*/NULL);
		if ((!(((Il2CppObject*)(Type_t *)L_65) == ((Il2CppObject*)(Type_t *)L_66))))
		{
			goto IL_018c;
		}
	}
	{
		BinaryReader_t2491843768 * L_67 = __this->get_reader_0();
		NullCheck(L_67);
		uint64_t L_68 = VirtFuncInvoker0< uint64_t >::Invoke(26 /* System.UInt64 System.IO.BinaryReader::ReadUInt64() */, L_67);
		uint64_t L_69 = L_68;
		Il2CppObject * L_70 = Box(UInt64_t2909196914_il2cpp_TypeInfo_var, &L_69);
		return L_70;
	}

IL_018c:
	{
		Type_t * L_71 = ___type0;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_72 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(Decimal_t724701077_0_0_0_var), /*hidden argument*/NULL);
		if ((!(((Il2CppObject*)(Type_t *)L_71) == ((Il2CppObject*)(Type_t *)L_72))))
		{
			goto IL_01ad;
		}
	}
	{
		BinaryReader_t2491843768 * L_73 = __this->get_reader_0();
		NullCheck(L_73);
		Decimal_t724701077  L_74 = VirtFuncInvoker0< Decimal_t724701077  >::Invoke(16 /* System.Decimal System.IO.BinaryReader::ReadDecimal() */, L_73);
		Decimal_t724701077  L_75 = L_74;
		Il2CppObject * L_76 = Box(Decimal_t724701077_il2cpp_TypeInfo_var, &L_75);
		return L_76;
	}

IL_01ad:
	{
		Type_t * L_77 = ___type0;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_78 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(DateTime_t693205669_0_0_0_var), /*hidden argument*/NULL);
		if ((!(((Il2CppObject*)(Type_t *)L_77) == ((Il2CppObject*)(Type_t *)L_78))))
		{
			goto IL_01d3;
		}
	}
	{
		BinaryReader_t2491843768 * L_79 = __this->get_reader_0();
		NullCheck(L_79);
		int64_t L_80 = VirtFuncInvoker0< int64_t >::Invoke(20 /* System.Int64 System.IO.BinaryReader::ReadInt64() */, L_79);
		DateTime_t693205669  L_81;
		memset(&L_81, 0, sizeof(L_81));
		DateTime__ctor_m2586249130(&L_81, L_80, /*hidden argument*/NULL);
		DateTime_t693205669  L_82 = L_81;
		Il2CppObject * L_83 = Box(DateTime_t693205669_il2cpp_TypeInfo_var, &L_82);
		return L_83;
	}

IL_01d3:
	{
		Type_t * L_84 = ___type0;
		Il2CppObject * L_85 = ResourceReader_ReadNonPredefinedValue_m715286753(__this, L_84, /*hidden argument*/NULL);
		return L_85;
	}
}
// System.Object System.Resources.ResourceReader::ReadNonPredefinedValue(System.Type)
extern Il2CppClass* IFormatter_t936711909_il2cpp_TypeInfo_var;
extern Il2CppClass* InvalidOperationException_t721527559_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral3004388167;
extern const uint32_t ResourceReader_ReadNonPredefinedValue_m715286753_MetadataUsageId;
extern "C"  Il2CppObject * ResourceReader_ReadNonPredefinedValue_m715286753 (ResourceReader_t2463923611 * __this, Type_t * ___exp_type0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ResourceReader_ReadNonPredefinedValue_m715286753_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Il2CppObject * V_0 = NULL;
	{
		Il2CppObject * L_0 = __this->get_formatter_2();
		BinaryReader_t2491843768 * L_1 = __this->get_reader_0();
		NullCheck(L_1);
		Stream_t3255436806 * L_2 = VirtFuncInvoker0< Stream_t3255436806 * >::Invoke(5 /* System.IO.Stream System.IO.BinaryReader::get_BaseStream() */, L_1);
		NullCheck(L_0);
		Il2CppObject * L_3 = InterfaceFuncInvoker1< Il2CppObject *, Stream_t3255436806 * >::Invoke(0 /* System.Object System.Runtime.Serialization.IFormatter::Deserialize(System.IO.Stream) */, IFormatter_t936711909_il2cpp_TypeInfo_var, L_0, L_2);
		V_0 = L_3;
		Il2CppObject * L_4 = V_0;
		NullCheck(L_4);
		Type_t * L_5 = Object_GetType_m191970594(L_4, /*hidden argument*/NULL);
		Type_t * L_6 = ___exp_type0;
		if ((((Il2CppObject*)(Type_t *)L_5) == ((Il2CppObject*)(Type_t *)L_6)))
		{
			goto IL_002e;
		}
	}
	{
		InvalidOperationException_t721527559 * L_7 = (InvalidOperationException_t721527559 *)il2cpp_codegen_object_new(InvalidOperationException_t721527559_il2cpp_TypeInfo_var);
		InvalidOperationException__ctor_m2801133788(L_7, _stringLiteral3004388167, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_7);
	}

IL_002e:
	{
		Il2CppObject * L_8 = V_0;
		return L_8;
	}
}
// System.Void System.Resources.ResourceReader::LoadResourceValues(System.Resources.ResourceReader/ResourceCacheItem[])
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern const uint32_t ResourceReader_LoadResourceValues_m1346096618_MetadataUsageId;
extern "C"  void ResourceReader_LoadResourceValues_m1346096618 (ResourceReader_t2463923611 * __this, ResourceCacheItemU5BU5D_t2265014744* ___store0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ResourceReader_LoadResourceValues_m1346096618_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ResourceInfo_t3933049236  V_0;
	memset(&V_0, 0, sizeof(V_0));
	Il2CppObject * V_1 = NULL;
	Il2CppObject * V_2 = NULL;
	int32_t V_3 = 0;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		Il2CppObject * L_0 = __this->get_readerLock_1();
		V_2 = L_0;
		Il2CppObject * L_1 = V_2;
		Monitor_Enter_m2136705809(NULL /*static, unused*/, L_1, /*hidden argument*/NULL);
	}

IL_000d:
	try
	{ // begin try (depth: 1)
		{
			V_3 = 0;
			goto IL_00c1;
		}

IL_0014:
		{
			ResourceInfoU5BU5D_t1013133725* L_2 = __this->get_infos_7();
			int32_t L_3 = V_3;
			NullCheck(L_2);
			V_0 = (*(ResourceInfo_t3933049236 *)((L_2)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3))));
			int32_t L_4 = (&V_0)->get_TypeIndex_2();
			if ((!(((uint32_t)L_4) == ((uint32_t)(-1)))))
			{
				goto IL_0051;
			}
		}

IL_0033:
		{
			ResourceCacheItemU5BU5D_t2265014744* L_5 = ___store0;
			int32_t L_6 = V_3;
			NullCheck(L_5);
			String_t* L_7 = (&V_0)->get_ResourceName_1();
			ResourceCacheItem_t333236149  L_8;
			memset(&L_8, 0, sizeof(L_8));
			ResourceCacheItem__ctor_m3209157611(&L_8, L_7, NULL, /*hidden argument*/NULL);
			(*(ResourceCacheItem_t333236149 *)((L_5)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_6)))) = L_8;
			goto IL_00bd;
		}

IL_0051:
		{
			BinaryReader_t2491843768 * L_9 = __this->get_reader_0();
			NullCheck(L_9);
			Stream_t3255436806 * L_10 = VirtFuncInvoker0< Stream_t3255436806 * >::Invoke(5 /* System.IO.Stream System.IO.BinaryReader::get_BaseStream() */, L_9);
			int64_t L_11 = (&V_0)->get_ValuePosition_0();
			NullCheck(L_10);
			VirtFuncInvoker2< int64_t, int64_t, int32_t >::Invoke(16 /* System.Int64 System.IO.Stream::Seek(System.Int64,System.IO.SeekOrigin) */, L_10, L_11, 0);
			int32_t L_12 = __this->get_resource_ver_10();
			if ((!(((uint32_t)L_12) == ((uint32_t)2))))
			{
				goto IL_0089;
			}
		}

IL_0076:
		{
			int32_t L_13 = (&V_0)->get_TypeIndex_2();
			Il2CppObject * L_14 = ResourceReader_ReadValueVer2_m252146049(__this, L_13, /*hidden argument*/NULL);
			V_1 = L_14;
			goto IL_00a4;
		}

IL_0089:
		{
			StringU5BU5D_t1642385972* L_15 = __this->get_typeNames_5();
			int32_t L_16 = (&V_0)->get_TypeIndex_2();
			NullCheck(L_15);
			int32_t L_17 = L_16;
			String_t* L_18 = (L_15)->GetAt(static_cast<il2cpp_array_size_t>(L_17));
			IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
			Type_t * L_19 = il2cpp_codegen_get_type((Il2CppMethodPointer)&Type_GetType_m402049910, L_18, (bool)1, "mscorlib, Version=2.0.5.0, Culture=neutral, PublicKeyToken=7cec85d7bea7798e");
			Il2CppObject * L_20 = ResourceReader_ReadValueVer1_m3519678454(__this, L_19, /*hidden argument*/NULL);
			V_1 = L_20;
		}

IL_00a4:
		{
			ResourceCacheItemU5BU5D_t2265014744* L_21 = ___store0;
			int32_t L_22 = V_3;
			NullCheck(L_21);
			String_t* L_23 = (&V_0)->get_ResourceName_1();
			Il2CppObject * L_24 = V_1;
			ResourceCacheItem_t333236149  L_25;
			memset(&L_25, 0, sizeof(L_25));
			ResourceCacheItem__ctor_m3209157611(&L_25, L_23, L_24, /*hidden argument*/NULL);
			(*(ResourceCacheItem_t333236149 *)((L_21)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_22)))) = L_25;
		}

IL_00bd:
		{
			int32_t L_26 = V_3;
			V_3 = ((int32_t)((int32_t)L_26+(int32_t)1));
		}

IL_00c1:
		{
			int32_t L_27 = V_3;
			int32_t L_28 = __this->get_resourceCount_3();
			if ((((int32_t)L_27) < ((int32_t)L_28)))
			{
				goto IL_0014;
			}
		}

IL_00cd:
		{
			IL2CPP_LEAVE(0xD9, FINALLY_00d2);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_00d2;
	}

FINALLY_00d2:
	{ // begin finally (depth: 1)
		Il2CppObject * L_29 = V_2;
		Monitor_Exit_m2677760297(NULL /*static, unused*/, L_29, /*hidden argument*/NULL);
		IL2CPP_END_FINALLY(210)
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(210)
	{
		IL2CPP_JUMP_TBL(0xD9, IL_00d9)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_00d9:
	{
		return;
	}
}
// System.Void System.Resources.ResourceReader::Close()
extern "C"  void ResourceReader_Close_m3256966401 (ResourceReader_t2463923611 * __this, const MethodInfo* method)
{
	{
		ResourceReader_Dispose_m3925831971(__this, (bool)1, /*hidden argument*/NULL);
		return;
	}
}
// System.Collections.IDictionaryEnumerator System.Resources.ResourceReader::GetEnumerator()
extern Il2CppClass* InvalidOperationException_t721527559_il2cpp_TypeInfo_var;
extern Il2CppClass* ResourceEnumerator_t2665690338_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral2797207597;
extern const uint32_t ResourceReader_GetEnumerator_m2759477183_MetadataUsageId;
extern "C"  Il2CppObject * ResourceReader_GetEnumerator_m2759477183 (ResourceReader_t2463923611 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ResourceReader_GetEnumerator_m2759477183_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		BinaryReader_t2491843768 * L_0 = __this->get_reader_0();
		if (L_0)
		{
			goto IL_0016;
		}
	}
	{
		InvalidOperationException_t721527559 * L_1 = (InvalidOperationException_t721527559 *)il2cpp_codegen_object_new(InvalidOperationException_t721527559_il2cpp_TypeInfo_var);
		InvalidOperationException__ctor_m2801133788(L_1, _stringLiteral2797207597, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_1);
	}

IL_0016:
	{
		ResourceEnumerator_t2665690338 * L_2 = (ResourceEnumerator_t2665690338 *)il2cpp_codegen_object_new(ResourceEnumerator_t2665690338_il2cpp_TypeInfo_var);
		ResourceEnumerator__ctor_m1679839941(L_2, __this, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.Void System.Resources.ResourceReader::Dispose(System.Boolean)
extern "C"  void ResourceReader_Dispose_m3925831971 (ResourceReader_t2463923611 * __this, bool ___disposing0, const MethodInfo* method)
{
	{
		bool L_0 = ___disposing0;
		if (!L_0)
		{
			goto IL_001c;
		}
	}
	{
		BinaryReader_t2491843768 * L_1 = __this->get_reader_0();
		if (!L_1)
		{
			goto IL_001c;
		}
	}
	{
		BinaryReader_t2491843768 * L_2 = __this->get_reader_0();
		NullCheck(L_2);
		VirtActionInvoker0::Invoke(6 /* System.Void System.IO.BinaryReader::Close() */, L_2);
	}

IL_001c:
	{
		__this->set_reader_0((BinaryReader_t2491843768 *)NULL);
		__this->set_hashes_6((Int32U5BU5D_t3030399641*)NULL);
		__this->set_infos_7((ResourceInfoU5BU5D_t1013133725*)NULL);
		__this->set_typeNames_5((StringU5BU5D_t1642385972*)NULL);
		__this->set_cache_11((ResourceCacheItemU5BU5D_t2265014744*)NULL);
		return;
	}
}
// System.Void System.Resources.ResourceReader/ResourceCacheItem::.ctor(System.String,System.Object)
extern "C"  void ResourceCacheItem__ctor_m3209157611 (ResourceCacheItem_t333236149 * __this, String_t* ___name0, Il2CppObject * ___value1, const MethodInfo* method)
{
	{
		String_t* L_0 = ___name0;
		__this->set_ResourceName_0(L_0);
		Il2CppObject * L_1 = ___value1;
		__this->set_ResourceValue_1(L_1);
		return;
	}
}
extern "C"  void ResourceCacheItem__ctor_m3209157611_AdjustorThunk (Il2CppObject * __this, String_t* ___name0, Il2CppObject * ___value1, const MethodInfo* method)
{
	ResourceCacheItem_t333236149 * _thisAdjusted = reinterpret_cast<ResourceCacheItem_t333236149 *>(__this + 1);
	ResourceCacheItem__ctor_m3209157611(_thisAdjusted, ___name0, ___value1, method);
}
// Conversion methods for marshalling of: System.Resources.ResourceReader/ResourceCacheItem
extern "C" void ResourceCacheItem_t333236149_marshal_pinvoke(const ResourceCacheItem_t333236149& unmarshaled, ResourceCacheItem_t333236149_marshaled_pinvoke& marshaled)
{
	Il2CppCodeGenException* ___ResourceValue_1Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'ResourceValue' of type 'ResourceCacheItem'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___ResourceValue_1Exception);
}
extern "C" void ResourceCacheItem_t333236149_marshal_pinvoke_back(const ResourceCacheItem_t333236149_marshaled_pinvoke& marshaled, ResourceCacheItem_t333236149& unmarshaled)
{
	Il2CppCodeGenException* ___ResourceValue_1Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'ResourceValue' of type 'ResourceCacheItem'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___ResourceValue_1Exception);
}
// Conversion method for clean up from marshalling of: System.Resources.ResourceReader/ResourceCacheItem
extern "C" void ResourceCacheItem_t333236149_marshal_pinvoke_cleanup(ResourceCacheItem_t333236149_marshaled_pinvoke& marshaled)
{
}
// Conversion methods for marshalling of: System.Resources.ResourceReader/ResourceCacheItem
extern "C" void ResourceCacheItem_t333236149_marshal_com(const ResourceCacheItem_t333236149& unmarshaled, ResourceCacheItem_t333236149_marshaled_com& marshaled)
{
	Il2CppCodeGenException* ___ResourceValue_1Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'ResourceValue' of type 'ResourceCacheItem'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___ResourceValue_1Exception);
}
extern "C" void ResourceCacheItem_t333236149_marshal_com_back(const ResourceCacheItem_t333236149_marshaled_com& marshaled, ResourceCacheItem_t333236149& unmarshaled)
{
	Il2CppCodeGenException* ___ResourceValue_1Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'ResourceValue' of type 'ResourceCacheItem'.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___ResourceValue_1Exception);
}
// Conversion method for clean up from marshalling of: System.Resources.ResourceReader/ResourceCacheItem
extern "C" void ResourceCacheItem_t333236149_marshal_com_cleanup(ResourceCacheItem_t333236149_marshaled_com& marshaled)
{
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
