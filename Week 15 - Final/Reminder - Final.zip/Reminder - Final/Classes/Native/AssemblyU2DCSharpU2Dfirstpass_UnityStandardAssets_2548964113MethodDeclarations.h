﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// UnityStandardAssets.Utility.SmoothFollow
struct SmoothFollow_t2548964113;

#include "codegen/il2cpp-codegen.h"

// System.Void UnityStandardAssets.Utility.SmoothFollow::.ctor()
extern "C"  void SmoothFollow__ctor_m1875676101 (SmoothFollow_t2548964113 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Utility.SmoothFollow::Start()
extern "C"  void SmoothFollow_Start_m3564433925 (SmoothFollow_t2548964113 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Utility.SmoothFollow::LateUpdate()
extern "C"  void SmoothFollow_LateUpdate_m2873001880 (SmoothFollow_t2548964113 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
