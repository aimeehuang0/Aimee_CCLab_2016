﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// UnityStandardAssets.Utility.ObjectResetter/<ResetCoroutine>c__Iterator0
struct U3CResetCoroutineU3Ec__Iterator0_t2926400505;
// System.Object
struct Il2CppObject;

#include "codegen/il2cpp-codegen.h"

// System.Void UnityStandardAssets.Utility.ObjectResetter/<ResetCoroutine>c__Iterator0::.ctor()
extern "C"  void U3CResetCoroutineU3Ec__Iterator0__ctor_m1085609780 (U3CResetCoroutineU3Ec__Iterator0_t2926400505 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Boolean UnityStandardAssets.Utility.ObjectResetter/<ResetCoroutine>c__Iterator0::MoveNext()
extern "C"  bool U3CResetCoroutineU3Ec__Iterator0_MoveNext_m3281238908 (U3CResetCoroutineU3Ec__Iterator0_t2926400505 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Object UnityStandardAssets.Utility.ObjectResetter/<ResetCoroutine>c__Iterator0::System.Collections.Generic.IEnumerator<object>.get_Current()
extern "C"  Il2CppObject * U3CResetCoroutineU3Ec__Iterator0_System_Collections_Generic_IEnumeratorU3CobjectU3E_get_Current_m2769897854 (U3CResetCoroutineU3Ec__Iterator0_t2926400505 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Object UnityStandardAssets.Utility.ObjectResetter/<ResetCoroutine>c__Iterator0::System.Collections.IEnumerator.get_Current()
extern "C"  Il2CppObject * U3CResetCoroutineU3Ec__Iterator0_System_Collections_IEnumerator_get_Current_m2952801302 (U3CResetCoroutineU3Ec__Iterator0_t2926400505 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Utility.ObjectResetter/<ResetCoroutine>c__Iterator0::Dispose()
extern "C"  void U3CResetCoroutineU3Ec__Iterator0_Dispose_m4181806541 (U3CResetCoroutineU3Ec__Iterator0_t2926400505 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Utility.ObjectResetter/<ResetCoroutine>c__Iterator0::Reset()
extern "C"  void U3CResetCoroutineU3Ec__Iterator0_Reset_m3234586927 (U3CResetCoroutineU3Ec__Iterator0_t2926400505 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
