﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// UnityStandardAssets.Utility.PlatformSpecificContent
struct PlatformSpecificContent_t935951820;

#include "codegen/il2cpp-codegen.h"

// System.Void UnityStandardAssets.Utility.PlatformSpecificContent::.ctor()
extern "C"  void PlatformSpecificContent__ctor_m1236193750 (PlatformSpecificContent_t935951820 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Utility.PlatformSpecificContent::OnEnable()
extern "C"  void PlatformSpecificContent_OnEnable_m172039910 (PlatformSpecificContent_t935951820 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Utility.PlatformSpecificContent::CheckEnableContent()
extern "C"  void PlatformSpecificContent_CheckEnableContent_m904153216 (PlatformSpecificContent_t935951820 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Utility.PlatformSpecificContent::EnableContent(System.Boolean)
extern "C"  void PlatformSpecificContent_EnableContent_m3733363435 (PlatformSpecificContent_t935951820 * __this, bool ___enabled0, const MethodInfo* method) IL2CPP_METHOD_ATTR;
