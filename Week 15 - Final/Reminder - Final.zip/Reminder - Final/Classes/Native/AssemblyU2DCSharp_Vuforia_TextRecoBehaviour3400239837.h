﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>


#include "Vuforia_UnityExtensions_Vuforia_TextRecoAbstractBe2386081773.h"

#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Vuforia.TextRecoBehaviour
struct  TextRecoBehaviour_t3400239837  : public TextRecoAbstractBehaviour_t2386081773
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
