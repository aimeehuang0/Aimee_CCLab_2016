﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// UnityStandardAssets.Utility.FPSCounter
struct FPSCounter_t584591591;

#include "codegen/il2cpp-codegen.h"

// System.Void UnityStandardAssets.Utility.FPSCounter::.ctor()
extern "C"  void FPSCounter__ctor_m3928815195 (FPSCounter_t584591591 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Utility.FPSCounter::Start()
extern "C"  void FPSCounter_Start_m687599895 (FPSCounter_t584591591 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Utility.FPSCounter::Update()
extern "C"  void FPSCounter_Update_m1120895194 (FPSCounter_t584591591 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
