﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// UnityStandardAssets.Utility.WaypointProgressTracker
struct WaypointProgressTracker_t2206407592;

#include "codegen/il2cpp-codegen.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_U318924311.h"

// System.Void UnityStandardAssets.Utility.WaypointProgressTracker::.ctor()
extern "C"  void WaypointProgressTracker__ctor_m2297978002 (WaypointProgressTracker_t2206407592 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// UnityStandardAssets.Utility.WaypointCircuit/RoutePoint UnityStandardAssets.Utility.WaypointProgressTracker::get_targetPoint()
extern "C"  RoutePoint_t318924311  WaypointProgressTracker_get_targetPoint_m318709112 (WaypointProgressTracker_t2206407592 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Utility.WaypointProgressTracker::set_targetPoint(UnityStandardAssets.Utility.WaypointCircuit/RoutePoint)
extern "C"  void WaypointProgressTracker_set_targetPoint_m3824746949 (WaypointProgressTracker_t2206407592 * __this, RoutePoint_t318924311  ___value0, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// UnityStandardAssets.Utility.WaypointCircuit/RoutePoint UnityStandardAssets.Utility.WaypointProgressTracker::get_speedPoint()
extern "C"  RoutePoint_t318924311  WaypointProgressTracker_get_speedPoint_m1154736426 (WaypointProgressTracker_t2206407592 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Utility.WaypointProgressTracker::set_speedPoint(UnityStandardAssets.Utility.WaypointCircuit/RoutePoint)
extern "C"  void WaypointProgressTracker_set_speedPoint_m3329005199 (WaypointProgressTracker_t2206407592 * __this, RoutePoint_t318924311  ___value0, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// UnityStandardAssets.Utility.WaypointCircuit/RoutePoint UnityStandardAssets.Utility.WaypointProgressTracker::get_progressPoint()
extern "C"  RoutePoint_t318924311  WaypointProgressTracker_get_progressPoint_m3395225926 (WaypointProgressTracker_t2206407592 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Utility.WaypointProgressTracker::set_progressPoint(UnityStandardAssets.Utility.WaypointCircuit/RoutePoint)
extern "C"  void WaypointProgressTracker_set_progressPoint_m4057042469 (WaypointProgressTracker_t2206407592 * __this, RoutePoint_t318924311  ___value0, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Utility.WaypointProgressTracker::Start()
extern "C"  void WaypointProgressTracker_Start_m2999634794 (WaypointProgressTracker_t2206407592 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Utility.WaypointProgressTracker::Reset()
extern "C"  void WaypointProgressTracker_Reset_m1013515717 (WaypointProgressTracker_t2206407592 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Utility.WaypointProgressTracker::Update()
extern "C"  void WaypointProgressTracker_Update_m4274946821 (WaypointProgressTracker_t2206407592 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Utility.WaypointProgressTracker::OnDrawGizmos()
extern "C"  void WaypointProgressTracker_OnDrawGizmos_m3153626988 (WaypointProgressTracker_t2206407592 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
