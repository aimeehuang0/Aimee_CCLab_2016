﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// UnityStandardAssets.Effects.Explosive/<OnCollisionEnter>c__Iterator0
struct U3COnCollisionEnterU3Ec__Iterator0_t455343489;
// System.Object
struct Il2CppObject;

#include "codegen/il2cpp-codegen.h"

// System.Void UnityStandardAssets.Effects.Explosive/<OnCollisionEnter>c__Iterator0::.ctor()
extern "C"  void U3COnCollisionEnterU3Ec__Iterator0__ctor_m1295094886 (U3COnCollisionEnterU3Ec__Iterator0_t455343489 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Boolean UnityStandardAssets.Effects.Explosive/<OnCollisionEnter>c__Iterator0::MoveNext()
extern "C"  bool U3COnCollisionEnterU3Ec__Iterator0_MoveNext_m806175698 (U3COnCollisionEnterU3Ec__Iterator0_t455343489 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Object UnityStandardAssets.Effects.Explosive/<OnCollisionEnter>c__Iterator0::System.Collections.Generic.IEnumerator<object>.get_Current()
extern "C"  Il2CppObject * U3COnCollisionEnterU3Ec__Iterator0_System_Collections_Generic_IEnumeratorU3CobjectU3E_get_Current_m1078760006 (U3COnCollisionEnterU3Ec__Iterator0_t455343489 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Object UnityStandardAssets.Effects.Explosive/<OnCollisionEnter>c__Iterator0::System.Collections.IEnumerator.get_Current()
extern "C"  Il2CppObject * U3COnCollisionEnterU3Ec__Iterator0_System_Collections_IEnumerator_get_Current_m4219061950 (U3COnCollisionEnterU3Ec__Iterator0_t455343489 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Effects.Explosive/<OnCollisionEnter>c__Iterator0::Dispose()
extern "C"  void U3COnCollisionEnterU3Ec__Iterator0_Dispose_m1413850461 (U3COnCollisionEnterU3Ec__Iterator0_t455343489 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Effects.Explosive/<OnCollisionEnter>c__Iterator0::Reset()
extern "C"  void U3COnCollisionEnterU3Ec__Iterator0_Reset_m497510087 (U3COnCollisionEnterU3Ec__Iterator0_t455343489 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
