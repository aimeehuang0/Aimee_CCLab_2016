﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// CameraFlyScript
struct CameraFlyScript_t1126393843;

#include "codegen/il2cpp-codegen.h"

// System.Void CameraFlyScript::.ctor()
extern "C"  void CameraFlyScript__ctor_m2454634147 (CameraFlyScript_t1126393843 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void CameraFlyScript::Update()
extern "C"  void CameraFlyScript_Update_m834546700 (CameraFlyScript_t1126393843 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void CameraFlyScript::Main()
extern "C"  void CameraFlyScript_Main_m3216879160 (CameraFlyScript_t1126393843 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
