﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// Vuforia.TextRecoBehaviour
struct TextRecoBehaviour_t3400239837;

#include "codegen/il2cpp-codegen.h"

// System.Void Vuforia.TextRecoBehaviour::.ctor()
extern "C"  void TextRecoBehaviour__ctor_m2446679806 (TextRecoBehaviour_t3400239837 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
