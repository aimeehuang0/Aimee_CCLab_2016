﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <cstring>
#include <string.h>
#include <stdio.h>
#include <cmath>
#include <limits>
#include <assert.h>


#include "class-internals.h"
#include "codegen/il2cpp-codegen.h"
#include "Vuforia_UnityExtensions_Vuforia_CameraDevice_Camer3847513849.h"
#include "Vuforia_UnityExtensions_Vuforia_CameraDevice_Camer3959695208.h"
#include "Vuforia_UnityExtensions_Vuforia_CameraDevice_Int64Ra56370998.h"
#include "Vuforia_UnityExtensions_Vuforia_CloudRecoAbstractB2070832277.h"
#include "Vuforia_UnityExtensions_Vuforia_ReconstructionImpl2149050756.h"
#include "Vuforia_UnityExtensions_Vuforia_HideExcessAreaAbst2687577327.h"
#include "Vuforia_UnityExtensions_Vuforia_HideExcessAreaAbst2100449024.h"
#include "Vuforia_UnityExtensions_Vuforia_UnityPlayer3164516142.h"
#include "Vuforia_UnityExtensions_Vuforia_NullUnityPlayer754446093.h"
#include "Vuforia_UnityExtensions_Vuforia_PlayModeUnityPlayer918240325.h"
#include "Vuforia_UnityExtensions_Vuforia_ReconstructionFrom1192715795.h"
#include "Vuforia_UnityExtensions_Vuforia_ViewerButtonType413015468.h"
#include "Vuforia_UnityExtensions_Vuforia_ViewerTrayAlignment791464321.h"
#include "Vuforia_UnityExtensions_Vuforia_VuMarkAbstractBeha1830666997.h"
#include "Vuforia_UnityExtensions_Vuforia_InstanceIdType467315012.h"
#include "Vuforia_UnityExtensions_Vuforia_ReconstructionFrom4122236588.h"
#include "Vuforia_UnityExtensions_Vuforia_SmartTerrainBuilde1628525337.h"
#include "Vuforia_UnityExtensions_Vuforia_SmartTerrainInitia1102352056.h"
#include "Vuforia_UnityExtensions_Vuforia_SmartTerrainTracka2391102074.h"
#include "Vuforia_UnityExtensions_Vuforia_SmartTerrainTracke4026264541.h"
#include "Vuforia_UnityExtensions_Vuforia_SurfaceAbstractBeh2669615494.h"
#include "Vuforia_UnityExtensions_Vuforia_CylinderTargetAbstr665872082.h"
#include "Vuforia_UnityExtensions_Vuforia_DataSet626511550.h"
#include "Vuforia_UnityExtensions_Vuforia_DataSet_StorageTyp4268322930.h"
#include "Vuforia_UnityExtensions_Vuforia_DatabaseLoadAbstra1458632096.h"
#include "Vuforia_UnityExtensions_Vuforia_RectangleData934532407.h"
#include "Vuforia_UnityExtensions_Vuforia_RectangleIntData2869769236.h"
#include "Vuforia_UnityExtensions_Vuforia_OrientedBoundingBo3172429123.h"
#include "Vuforia_UnityExtensions_Vuforia_OrientedBoundingBo1484796416.h"
#include "Vuforia_UnityExtensions_Vuforia_BehaviourComponent3267823770.h"
#include "Vuforia_UnityExtensions_Vuforia_BehaviourComponent3849641556.h"
#include "Vuforia_UnityExtensions_Vuforia_CloudRecoImageTarg2427143318.h"
#include "Vuforia_UnityExtensions_Vuforia_CylinderTargetImpl259286421.h"
#include "Vuforia_UnityExtensions_Vuforia_ImageTargetType3906864138.h"
#include "Vuforia_UnityExtensions_Vuforia_ImageTargetData1326050618.h"
#include "Vuforia_UnityExtensions_Vuforia_ImageTargetBuilder518883741.h"
#include "Vuforia_UnityExtensions_Vuforia_ImageTargetBuilder2061101710.h"
#include "Vuforia_UnityExtensions_Vuforia_CameraDeviceImpl610967511.h"
#include "Vuforia_UnityExtensions_Vuforia_CameraDeviceImpl_C1695136893.h"
#include "Vuforia_UnityExtensions_Vuforia_DataSetImpl2819025280.h"
#include "Vuforia_UnityExtensions_Vuforia_Image1391689025.h"
#include "Vuforia_UnityExtensions_Vuforia_Image_PIXEL_FORMAT3010530044.h"
#include "Vuforia_UnityExtensions_Vuforia_ImageImpl2564717533.h"
#include "Vuforia_UnityExtensions_Vuforia_ImageTargetBuilder2457446201.h"
#include "Vuforia_UnityExtensions_Vuforia_ImageTargetImpl869063580.h"
#include "Vuforia_UnityExtensions_Vuforia_ObjectTracker1568044035.h"
#include "Vuforia_UnityExtensions_Vuforia_ObjectTrackerImpl1691118791.h"
#include "Vuforia_UnityExtensions_Vuforia_MarkerImpl2101172390.h"
#include "Vuforia_UnityExtensions_Vuforia_MarkerTracker2959118800.h"
#include "Vuforia_UnityExtensions_Vuforia_MarkerTrackerImpl654952814.h"
#include "Vuforia_UnityExtensions_Vuforia_MultiTargetImpl2151485576.h"
#include "Vuforia_UnityExtensions_Vuforia_WebCamTexAdaptor2106169489.h"
#include "Vuforia_UnityExtensions_Vuforia_NullWebCamTexAdapt2136158928.h"
#include "Vuforia_UnityExtensions_Vuforia_PlayModeEditorUtil1237840826.h"
#include "Vuforia_UnityExtensions_Vuforia_PlayModeEditorUtil1550651348.h"
#include "Vuforia_UnityExtensions_Vuforia_PremiumObjectFactor787152098.h"
#include "Vuforia_UnityExtensions_Vuforia_PremiumObjectFacto2032979060.h"
#include "Vuforia_UnityExtensions_Vuforia_VuforiaManager2424874861.h"
#include "Vuforia_UnityExtensions_Vuforia_VuforiaManager_Tra1329355276.h"
#include "Vuforia_UnityExtensions_Vuforia_VuforiaManagerImpl3289840897.h"
#include "Vuforia_UnityExtensions_Vuforia_VuforiaManagerImpl1264148721.h"
#include "Vuforia_UnityExtensions_Vuforia_VuforiaManagerImpl1947527974.h"
#include "Vuforia_UnityExtensions_Vuforia_VuforiaManagerImpl1223885651.h"
#include "Vuforia_UnityExtensions_Vuforia_VuforiaManagerImpl3491121689.h"
#include "Vuforia_UnityExtensions_Vuforia_VuforiaManagerImpl3491121690.h"
#include "Vuforia_UnityExtensions_Vuforia_VuforiaManagerImpl3742236631.h"
#include "Vuforia_UnityExtensions_Vuforia_VuforiaManagerImpl1273964084.h"
#include "Vuforia_UnityExtensions_Vuforia_VuforiaManagerImpl3150040852.h"
#include "Vuforia_UnityExtensions_Vuforia_VuforiaManagerImpl1863273727.h"
#include "Vuforia_UnityExtensions_Vuforia_VuforiaManagerImpl2613089982.h"
#include "Vuforia_UnityExtensions_Vuforia_VuforiaManagerImpl2130450083.h"
#include "Vuforia_UnityExtensions_Vuforia_VuforiaManagerImpl1453372369.h"
#include "Vuforia_UnityExtensions_Vuforia_VuforiaManagerImpl2968608989.h"
#include "Vuforia_UnityExtensions_Vuforia_VuforiaManagerImpl4033919773.h"
#include "Vuforia_UnityExtensions_Vuforia_VuforiaManagerImpl4188455712.h"
#include "Vuforia_UnityExtensions_Vuforia_VuforiaManagerImpl3635099966.h"
#include "Vuforia_UnityExtensions_Vuforia_VuforiaManagerImpl3090691518.h"
#include "Vuforia_UnityExtensions_Vuforia_VuforiaManagerImpl2337328198.h"
#include "Vuforia_UnityExtensions_Vuforia_VuforiaRenderer2933102835.h"
#include "Vuforia_UnityExtensions_Vuforia_VuforiaRenderer_Fp1598668988.h"
#include "Vuforia_UnityExtensions_Vuforia_VuforiaRenderer_Vi4106934884.h"
#include "Vuforia_UnityExtensions_Vuforia_VuforiaRenderer_Vi4137084396.h"
#include "Vuforia_UnityExtensions_Vuforia_VuforiaRenderer_Vec829768013.h"
#include "Vuforia_UnityExtensions_Vuforia_VuforiaRenderer_Vi2617831468.h"
#include "Vuforia_UnityExtensions_Vuforia_VuforiaRenderer_Ren804170727.h"
#include "Vuforia_UnityExtensions_Vuforia_VuforiaRendererImp3510735303.h"
#include "Vuforia_UnityExtensions_Vuforia_VuforiaRendererImp4076072164.h"
#include "Vuforia_UnityExtensions_Vuforia_VuforiaUnityImpl149264205.h"



#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1800 = { sizeof (CameraField_t3847513849)+ sizeof (Il2CppObject), sizeof(CameraField_t3847513849_marshaled_pinvoke), 0, 0 };
extern const int32_t g_FieldOffsetTable1800[2] = 
{
	CameraField_t3847513849::get_offset_of_Type_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	CameraField_t3847513849::get_offset_of_Key_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1801 = { sizeof (DataType_t3959695208)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable1801[7] = 
{
	DataType_t3959695208::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1802 = { sizeof (Int64Range_t56370998)+ sizeof (Il2CppObject), sizeof(Int64Range_t56370998 ), 0, 0 };
extern const int32_t g_FieldOffsetTable1802[2] = 
{
	Int64Range_t56370998::get_offset_of_fromInt_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Int64Range_t56370998::get_offset_of_toInt_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1803 = { sizeof (CloudRecoAbstractBehaviour_t2070832277), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1803[9] = 
{
	CloudRecoAbstractBehaviour_t2070832277::get_offset_of_mObjectTracker_2(),
	CloudRecoAbstractBehaviour_t2070832277::get_offset_of_mCurrentlyInitializing_3(),
	CloudRecoAbstractBehaviour_t2070832277::get_offset_of_mInitSuccess_4(),
	CloudRecoAbstractBehaviour_t2070832277::get_offset_of_mCloudRecoStarted_5(),
	CloudRecoAbstractBehaviour_t2070832277::get_offset_of_mOnInitializedCalled_6(),
	CloudRecoAbstractBehaviour_t2070832277::get_offset_of_mHandlers_7(),
	CloudRecoAbstractBehaviour_t2070832277::get_offset_of_mTargetFinderStartedBeforeDisable_8(),
	CloudRecoAbstractBehaviour_t2070832277::get_offset_of_AccessKey_9(),
	CloudRecoAbstractBehaviour_t2070832277::get_offset_of_SecretKey_10(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1804 = { sizeof (ReconstructionImpl_t2149050756), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1804[5] = 
{
	ReconstructionImpl_t2149050756::get_offset_of_mNativeReconstructionPtr_0(),
	ReconstructionImpl_t2149050756::get_offset_of_mMaximumAreaIsSet_1(),
	ReconstructionImpl_t2149050756::get_offset_of_mMaximumArea_2(),
	ReconstructionImpl_t2149050756::get_offset_of_mNavMeshPadding_3(),
	ReconstructionImpl_t2149050756::get_offset_of_mNavMeshUpdatesEnabled_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1805 = { sizeof (HideExcessAreaAbstractBehaviour_t2687577327), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1805[7] = 
{
	HideExcessAreaAbstractBehaviour_t2687577327::get_offset_of_mClippingImpl_2(),
	HideExcessAreaAbstractBehaviour_t2687577327::get_offset_of_mClippingMode_3(),
	HideExcessAreaAbstractBehaviour_t2687577327::get_offset_of_mVuforiaBehaviour_4(),
	HideExcessAreaAbstractBehaviour_t2687577327::get_offset_of_mVideoBgMgr_5(),
	HideExcessAreaAbstractBehaviour_t2687577327::get_offset_of_mPlaneOffset_6(),
	HideExcessAreaAbstractBehaviour_t2687577327::get_offset_of_mSceneScaledDown_7(),
	HideExcessAreaAbstractBehaviour_t2687577327::get_offset_of_mStarted_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1806 = { sizeof (CLIPPING_MODE_t2100449024)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable1806[4] = 
{
	CLIPPING_MODE_t2100449024::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1807 = { sizeof (UnityPlayer_t3164516142), -1, sizeof(UnityPlayer_t3164516142_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable1807[1] = 
{
	UnityPlayer_t3164516142_StaticFields::get_offset_of_sPlayer_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1808 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1809 = { sizeof (NullUnityPlayer_t754446093), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1810 = { sizeof (PlayModeUnityPlayer_t918240325), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1811 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1812 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1813 = { sizeof (ReconstructionFromTargetImpl_t1192715795), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1813[6] = 
{
	ReconstructionFromTargetImpl_t1192715795::get_offset_of_mOccluderMin_5(),
	ReconstructionFromTargetImpl_t1192715795::get_offset_of_mOccluderMax_6(),
	ReconstructionFromTargetImpl_t1192715795::get_offset_of_mOccluderOffset_7(),
	ReconstructionFromTargetImpl_t1192715795::get_offset_of_mOccluderRotation_8(),
	ReconstructionFromTargetImpl_t1192715795::get_offset_of_mInitializationTarget_9(),
	ReconstructionFromTargetImpl_t1192715795::get_offset_of_mCanAutoSetInitializationTarget_10(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1814 = { sizeof (ViewerButtonType_t413015468)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable1814[5] = 
{
	ViewerButtonType_t413015468::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1815 = { sizeof (ViewerTrayAlignment_t791464321)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable1815[4] = 
{
	ViewerTrayAlignment_t791464321::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1816 = { sizeof (VuMarkAbstractBehaviour_t1830666997), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1816[16] = 
{
	VuMarkAbstractBehaviour_t1830666997::get_offset_of_mAspectRatio_20(),
	VuMarkAbstractBehaviour_t1830666997::get_offset_of_mWidth_21(),
	VuMarkAbstractBehaviour_t1830666997::get_offset_of_mHeight_22(),
	VuMarkAbstractBehaviour_t1830666997::get_offset_of_mPreviewImage_23(),
	VuMarkAbstractBehaviour_t1830666997::get_offset_of_mIdType_24(),
	VuMarkAbstractBehaviour_t1830666997::get_offset_of_mIdLength_25(),
	VuMarkAbstractBehaviour_t1830666997::get_offset_of_mBoundingBox_26(),
	VuMarkAbstractBehaviour_t1830666997::get_offset_of_mOrigin_27(),
	VuMarkAbstractBehaviour_t1830666997::get_offset_of_mTrackingFromRuntimeAppearance_28(),
	VuMarkAbstractBehaviour_t1830666997::get_offset_of_mVuMarkTemplate_29(),
	VuMarkAbstractBehaviour_t1830666997::get_offset_of_mVuMarkTarget_30(),
	VuMarkAbstractBehaviour_t1830666997::get_offset_of_mVuMarkResultId_31(),
	VuMarkAbstractBehaviour_t1830666997::get_offset_of_mOnTargetAssigned_32(),
	VuMarkAbstractBehaviour_t1830666997::get_offset_of_mOnTargetLost_33(),
	VuMarkAbstractBehaviour_t1830666997::get_offset_of_mLastTransformScale_34(),
	VuMarkAbstractBehaviour_t1830666997::get_offset_of_mLastSize_35(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1817 = { sizeof (InstanceIdType_t467315012)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable1817[4] = 
{
	InstanceIdType_t467315012::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1818 = { sizeof (ReconstructionFromTargetAbstractBehaviour_t4122236588), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1818[2] = 
{
	ReconstructionFromTargetAbstractBehaviour_t4122236588::get_offset_of_mReconstructionFromTarget_2(),
	ReconstructionFromTargetAbstractBehaviour_t4122236588::get_offset_of_mReconstructionBehaviour_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1819 = { sizeof (SmartTerrainBuilder_t1628525337), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1820 = { sizeof (SmartTerrainInitializationInfo_t1102352056)+ sizeof (Il2CppObject), sizeof(SmartTerrainInitializationInfo_t1102352056 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1821 = { sizeof (SmartTerrainTrackableBehaviour_t2391102074), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1821[4] = 
{
	SmartTerrainTrackableBehaviour_t2391102074::get_offset_of_mSmartTerrainTrackable_10(),
	SmartTerrainTrackableBehaviour_t2391102074::get_offset_of_mDisableAutomaticUpdates_11(),
	SmartTerrainTrackableBehaviour_t2391102074::get_offset_of_mMeshFilterToUpdate_12(),
	SmartTerrainTrackableBehaviour_t2391102074::get_offset_of_mMeshColliderToUpdate_13(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1822 = { sizeof (SmartTerrainTrackerAbstractBehaviour_t4026264541), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1822[7] = 
{
	SmartTerrainTrackerAbstractBehaviour_t4026264541::get_offset_of_mAutoInitTracker_2(),
	SmartTerrainTrackerAbstractBehaviour_t4026264541::get_offset_of_mAutoStartTracker_3(),
	SmartTerrainTrackerAbstractBehaviour_t4026264541::get_offset_of_mAutoInitBuilder_4(),
	SmartTerrainTrackerAbstractBehaviour_t4026264541::get_offset_of_mSceneUnitsToMillimeter_5(),
	SmartTerrainTrackerAbstractBehaviour_t4026264541::get_offset_of_mTrackerStarted_6(),
	SmartTerrainTrackerAbstractBehaviour_t4026264541::get_offset_of_mTrackerWasActiveBeforePause_7(),
	SmartTerrainTrackerAbstractBehaviour_t4026264541::get_offset_of_mTrackerWasActiveBeforeDisabling_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1823 = { sizeof (SurfaceAbstractBehaviour_t2669615494), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1823[1] = 
{
	SurfaceAbstractBehaviour_t2669615494::get_offset_of_mSurface_14(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1824 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1825 = { sizeof (CylinderTargetAbstractBehaviour_t665872082), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1825[10] = 
{
	CylinderTargetAbstractBehaviour_t665872082::get_offset_of_mCylinderTarget_20(),
	CylinderTargetAbstractBehaviour_t665872082::get_offset_of_mTopDiameterRatio_21(),
	CylinderTargetAbstractBehaviour_t665872082::get_offset_of_mBottomDiameterRatio_22(),
	CylinderTargetAbstractBehaviour_t665872082::get_offset_of_mSideLength_23(),
	CylinderTargetAbstractBehaviour_t665872082::get_offset_of_mTopDiameter_24(),
	CylinderTargetAbstractBehaviour_t665872082::get_offset_of_mBottomDiameter_25(),
	CylinderTargetAbstractBehaviour_t665872082::get_offset_of_mFrameIndex_26(),
	CylinderTargetAbstractBehaviour_t665872082::get_offset_of_mUpdateFrameIndex_27(),
	CylinderTargetAbstractBehaviour_t665872082::get_offset_of_mFutureScale_28(),
	CylinderTargetAbstractBehaviour_t665872082::get_offset_of_mLastTransformScale_29(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1826 = { sizeof (DataSet_t626511550), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1827 = { sizeof (StorageType_t4268322930)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable1827[4] = 
{
	StorageType_t4268322930::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1828 = { sizeof (DatabaseLoadAbstractBehaviour_t1458632096), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1828[4] = 
{
	DatabaseLoadAbstractBehaviour_t1458632096::get_offset_of_mDatasetsLoaded_2(),
	DatabaseLoadAbstractBehaviour_t1458632096::get_offset_of_mDataSetsToLoad_3(),
	DatabaseLoadAbstractBehaviour_t1458632096::get_offset_of_mDataSetsToActivate_4(),
	DatabaseLoadAbstractBehaviour_t1458632096::get_offset_of_mExternalDatasetRoots_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1829 = { sizeof (RectangleData_t934532407)+ sizeof (Il2CppObject), sizeof(RectangleData_t934532407 ), 0, 0 };
extern const int32_t g_FieldOffsetTable1829[4] = 
{
	RectangleData_t934532407::get_offset_of_leftTopX_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	RectangleData_t934532407::get_offset_of_leftTopY_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	RectangleData_t934532407::get_offset_of_rightBottomX_2() + static_cast<int32_t>(sizeof(Il2CppObject)),
	RectangleData_t934532407::get_offset_of_rightBottomY_3() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1830 = { sizeof (RectangleIntData_t2869769236)+ sizeof (Il2CppObject), sizeof(RectangleIntData_t2869769236 ), 0, 0 };
extern const int32_t g_FieldOffsetTable1830[4] = 
{
	RectangleIntData_t2869769236::get_offset_of_leftTopX_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	RectangleIntData_t2869769236::get_offset_of_leftTopY_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	RectangleIntData_t2869769236::get_offset_of_rightBottomX_2() + static_cast<int32_t>(sizeof(Il2CppObject)),
	RectangleIntData_t2869769236::get_offset_of_rightBottomY_3() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1831 = { sizeof (OrientedBoundingBox_t3172429123)+ sizeof (Il2CppObject), sizeof(OrientedBoundingBox_t3172429123 ), 0, 0 };
extern const int32_t g_FieldOffsetTable1831[3] = 
{
	OrientedBoundingBox_t3172429123::get_offset_of_U3CCenterU3Ek__BackingField_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	OrientedBoundingBox_t3172429123::get_offset_of_U3CHalfExtentsU3Ek__BackingField_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	OrientedBoundingBox_t3172429123::get_offset_of_U3CRotationU3Ek__BackingField_2() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1832 = { sizeof (OrientedBoundingBox3D_t1484796416)+ sizeof (Il2CppObject), sizeof(OrientedBoundingBox3D_t1484796416 ), 0, 0 };
extern const int32_t g_FieldOffsetTable1832[3] = 
{
	OrientedBoundingBox3D_t1484796416::get_offset_of_U3CCenterU3Ek__BackingField_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	OrientedBoundingBox3D_t1484796416::get_offset_of_U3CHalfExtentsU3Ek__BackingField_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	OrientedBoundingBox3D_t1484796416::get_offset_of_U3CRotationYU3Ek__BackingField_2() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1833 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1834 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1835 = { sizeof (BehaviourComponentFactory_t3267823770), -1, sizeof(BehaviourComponentFactory_t3267823770_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable1835[1] = 
{
	BehaviourComponentFactory_t3267823770_StaticFields::get_offset_of_sInstance_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1836 = { sizeof (NullBehaviourComponentFactory_t3849641556), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1837 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1838 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1839 = { sizeof (CloudRecoImageTargetImpl_t2427143318), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1839[1] = 
{
	CloudRecoImageTargetImpl_t2427143318::get_offset_of_mSize_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1840 = { sizeof (CylinderTargetImpl_t259286421), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1840[3] = 
{
	CylinderTargetImpl_t259286421::get_offset_of_mSideLength_4(),
	CylinderTargetImpl_t259286421::get_offset_of_mTopDiameter_5(),
	CylinderTargetImpl_t259286421::get_offset_of_mBottomDiameter_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1841 = { sizeof (ImageTargetType_t3906864138)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable1841[4] = 
{
	ImageTargetType_t3906864138::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1842 = { sizeof (ImageTargetData_t1326050618)+ sizeof (Il2CppObject), sizeof(ImageTargetData_t1326050618 ), 0, 0 };
extern const int32_t g_FieldOffsetTable1842[2] = 
{
	ImageTargetData_t1326050618::get_offset_of_id_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	ImageTargetData_t1326050618::get_offset_of_size_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1843 = { sizeof (ImageTargetBuilder_t518883741), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1844 = { sizeof (FrameQuality_t2061101710)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable1844[5] = 
{
	FrameQuality_t2061101710::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1845 = { sizeof (CameraDeviceImpl_t610967511), -1, sizeof(CameraDeviceImpl_t610967511_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable1845[12] = 
{
	CameraDeviceImpl_t610967511::get_offset_of_mCameraImages_1(),
	CameraDeviceImpl_t610967511::get_offset_of_mForcedCameraFormats_2(),
	CameraDeviceImpl_t610967511_StaticFields::get_offset_of_mWebCam_3(),
	CameraDeviceImpl_t610967511::get_offset_of_mCameraReady_4(),
	CameraDeviceImpl_t610967511::get_offset_of_mIsDirty_5(),
	CameraDeviceImpl_t610967511::get_offset_of_mActualCameraDirection_6(),
	CameraDeviceImpl_t610967511::get_offset_of_mSelectedCameraDirection_7(),
	CameraDeviceImpl_t610967511::get_offset_of_mCameraDeviceMode_8(),
	CameraDeviceImpl_t610967511::get_offset_of_mVideoModeData_9(),
	CameraDeviceImpl_t610967511::get_offset_of_mVideoModeDataNeedsUpdate_10(),
	CameraDeviceImpl_t610967511::get_offset_of_mHasCameraDeviceModeBeenSet_11(),
	CameraDeviceImpl_t610967511::get_offset_of_mCameraActive_12(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1846 = { sizeof (CameraFieldData_t1695136893)+ sizeof (Il2CppObject), sizeof(CameraFieldData_t1695136893_marshaled_pinvoke), 0, 0 };
extern const int32_t g_FieldOffsetTable1846[3] = 
{
	CameraFieldData_t1695136893::get_offset_of_KeyValue_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	CameraFieldData_t1695136893::get_offset_of_DataType_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	CameraFieldData_t1695136893::get_offset_of_Unused_2() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1847 = { sizeof (DataSetImpl_t2819025280), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1847[5] = 
{
	0,
	DataSetImpl_t2819025280::get_offset_of_mDataSetPtr_1(),
	DataSetImpl_t2819025280::get_offset_of_mPath_2(),
	DataSetImpl_t2819025280::get_offset_of_mStorageType_3(),
	DataSetImpl_t2819025280::get_offset_of_mTrackablesDict_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1848 = { sizeof (Image_t1391689025), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1849 = { sizeof (PIXEL_FORMAT_t3010530044)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable1849[7] = 
{
	PIXEL_FORMAT_t3010530044::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1850 = { sizeof (ImageImpl_t2564717533), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1850[10] = 
{
	ImageImpl_t2564717533::get_offset_of_mWidth_0(),
	ImageImpl_t2564717533::get_offset_of_mHeight_1(),
	ImageImpl_t2564717533::get_offset_of_mStride_2(),
	ImageImpl_t2564717533::get_offset_of_mBufferWidth_3(),
	ImageImpl_t2564717533::get_offset_of_mBufferHeight_4(),
	ImageImpl_t2564717533::get_offset_of_mPixelFormat_5(),
	ImageImpl_t2564717533::get_offset_of_mData_6(),
	ImageImpl_t2564717533::get_offset_of_mUnmanagedData_7(),
	ImageImpl_t2564717533::get_offset_of_mDataSet_8(),
	ImageImpl_t2564717533::get_offset_of_mPixel32_9(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1851 = { sizeof (ImageTargetBuilderImpl_t2457446201), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1851[2] = 
{
	ImageTargetBuilderImpl_t2457446201::get_offset_of_mTrackableSource_0(),
	ImageTargetBuilderImpl_t2457446201::get_offset_of_mIsScanning_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1852 = { sizeof (ImageTargetImpl_t869063580), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1852[2] = 
{
	ImageTargetImpl_t869063580::get_offset_of_mImageTargetType_4(),
	ImageTargetImpl_t869063580::get_offset_of_mVirtualButtons_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1853 = { sizeof (ObjectTracker_t1568044035), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1854 = { sizeof (ObjectTrackerImpl_t1691118791), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1854[4] = 
{
	ObjectTrackerImpl_t1691118791::get_offset_of_mActiveDataSets_1(),
	ObjectTrackerImpl_t1691118791::get_offset_of_mDataSets_2(),
	ObjectTrackerImpl_t1691118791::get_offset_of_mImageTargetBuilder_3(),
	ObjectTrackerImpl_t1691118791::get_offset_of_mTargetFinder_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1855 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1856 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1857 = { sizeof (MarkerImpl_t2101172390), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1857[2] = 
{
	MarkerImpl_t2101172390::get_offset_of_mSize_2(),
	MarkerImpl_t2101172390::get_offset_of_U3CMarkerIDU3Ek__BackingField_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1858 = { sizeof (MarkerTracker_t2959118800), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1859 = { sizeof (MarkerTrackerImpl_t654952814), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1859[1] = 
{
	MarkerTrackerImpl_t654952814::get_offset_of_mMarkerDict_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1860 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1861 = { sizeof (MultiTargetImpl_t2151485576), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1862 = { sizeof (WebCamTexAdaptor_t2106169489), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1863 = { sizeof (NullWebCamTexAdaptor_t2136158928), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1863[5] = 
{
	0,
	NullWebCamTexAdaptor_t2136158928::get_offset_of_mTexture_1(),
	NullWebCamTexAdaptor_t2136158928::get_offset_of_mPseudoPlaying_2(),
	NullWebCamTexAdaptor_t2136158928::get_offset_of_mMsBetweenFrames_3(),
	NullWebCamTexAdaptor_t2136158928::get_offset_of_mLastFrame_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1864 = { sizeof (PlayModeEditorUtility_t1237840826), -1, sizeof(PlayModeEditorUtility_t1237840826_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable1864[1] = 
{
	PlayModeEditorUtility_t1237840826_StaticFields::get_offset_of_sInstance_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1865 = { sizeof (NullPlayModeEditorUtility_t1550651348), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1866 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1867 = { sizeof (PremiumObjectFactory_t787152098), -1, sizeof(PremiumObjectFactory_t787152098_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable1867[1] = 
{
	PremiumObjectFactory_t787152098_StaticFields::get_offset_of_sInstance_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1868 = { sizeof (NullPremiumObjectFactory_t2032979060), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1869 = { sizeof (VuforiaManager_t2424874861), -1, sizeof(VuforiaManager_t2424874861_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable1869[1] = 
{
	VuforiaManager_t2424874861_StaticFields::get_offset_of_sInstance_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1870 = { sizeof (TrackableIdPair_t1329355276)+ sizeof (Il2CppObject), sizeof(TrackableIdPair_t1329355276 ), 0, 0 };
extern const int32_t g_FieldOffsetTable1870[2] = 
{
	TrackableIdPair_t1329355276::get_offset_of_TrackableId_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	TrackableIdPair_t1329355276::get_offset_of_ResultId_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1871 = { sizeof (VuforiaManagerImpl_t3289840897), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1871[26] = 
{
	VuforiaManagerImpl_t3289840897::get_offset_of_mWorldCenterMode_1(),
	VuforiaManagerImpl_t3289840897::get_offset_of_mWorldCenter_2(),
	VuforiaManagerImpl_t3289840897::get_offset_of_mVuMarkWorldCenter_3(),
	VuforiaManagerImpl_t3289840897::get_offset_of_mARCameraTransform_4(),
	VuforiaManagerImpl_t3289840897::get_offset_of_mCentralAnchorPoint_5(),
	VuforiaManagerImpl_t3289840897::get_offset_of_mParentAnchorPoint_6(),
	VuforiaManagerImpl_t3289840897::get_offset_of_mTrackableResultDataArray_7(),
	VuforiaManagerImpl_t3289840897::get_offset_of_mWordDataArray_8(),
	VuforiaManagerImpl_t3289840897::get_offset_of_mWordResultDataArray_9(),
	VuforiaManagerImpl_t3289840897::get_offset_of_mVuMarkDataArray_10(),
	VuforiaManagerImpl_t3289840897::get_offset_of_mVuMarkResultDataArray_11(),
	VuforiaManagerImpl_t3289840897::get_offset_of_mTrackableFoundQueue_12(),
	VuforiaManagerImpl_t3289840897::get_offset_of_mImageHeaderData_13(),
	VuforiaManagerImpl_t3289840897::get_offset_of_mNumImageHeaders_14(),
	VuforiaManagerImpl_t3289840897::get_offset_of_mInjectedFrameIdx_15(),
	VuforiaManagerImpl_t3289840897::get_offset_of_mLastProcessedFrameStatePtr_16(),
	VuforiaManagerImpl_t3289840897::get_offset_of_mInitialized_17(),
	VuforiaManagerImpl_t3289840897::get_offset_of_mPaused_18(),
	VuforiaManagerImpl_t3289840897::get_offset_of_mFrameState_19(),
	VuforiaManagerImpl_t3289840897::get_offset_of_mAutoRotationState_20(),
	VuforiaManagerImpl_t3289840897::get_offset_of_mVideoBackgroundNeedsRedrawing_21(),
	VuforiaManagerImpl_t3289840897::get_offset_of_mDiscardStatesForRendering_22(),
	VuforiaManagerImpl_t3289840897::get_offset_of_mVideoBackgroundMgr_23(),
	VuforiaManagerImpl_t3289840897::get_offset_of_mLastFrameIdx_24(),
	VuforiaManagerImpl_t3289840897::get_offset_of_mIsSeeThroughDevice_25(),
	VuforiaManagerImpl_t3289840897::get_offset_of_U3CVideoBackgroundTextureSetU3Ek__BackingField_26(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1872 = { sizeof (PoseData_t1264148721)+ sizeof (Il2CppObject), sizeof(PoseData_t1264148721 ), 0, 0 };
extern const int32_t g_FieldOffsetTable1872[3] = 
{
	PoseData_t1264148721::get_offset_of_position_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	PoseData_t1264148721::get_offset_of_orientation_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	PoseData_t1264148721::get_offset_of_csInteger_2() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1873 = { sizeof (TrackableResultData_t1947527974)+ sizeof (Il2CppObject), sizeof(TrackableResultData_t1947527974 ), 0, 0 };
extern const int32_t g_FieldOffsetTable1873[4] = 
{
	TrackableResultData_t1947527974::get_offset_of_pose_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	TrackableResultData_t1947527974::get_offset_of_timeStamp_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	TrackableResultData_t1947527974::get_offset_of_statusInteger_2() + static_cast<int32_t>(sizeof(Il2CppObject)),
	TrackableResultData_t1947527974::get_offset_of_id_3() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1874 = { sizeof (VirtualButtonData_t1223885651)+ sizeof (Il2CppObject), sizeof(VirtualButtonData_t1223885651 ), 0, 0 };
extern const int32_t g_FieldOffsetTable1874[2] = 
{
	VirtualButtonData_t1223885651::get_offset_of_id_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	VirtualButtonData_t1223885651::get_offset_of_isPressed_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1875 = { sizeof (Obb2D_t3491121689)+ sizeof (Il2CppObject), sizeof(Obb2D_t3491121689 ), 0, 0 };
extern const int32_t g_FieldOffsetTable1875[4] = 
{
	Obb2D_t3491121689::get_offset_of_center_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Obb2D_t3491121689::get_offset_of_halfExtents_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Obb2D_t3491121689::get_offset_of_rotation_2() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Obb2D_t3491121689::get_offset_of_unused_3() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1876 = { sizeof (Obb3D_t3491121690)+ sizeof (Il2CppObject), sizeof(Obb3D_t3491121690 ), 0, 0 };
extern const int32_t g_FieldOffsetTable1876[4] = 
{
	Obb3D_t3491121690::get_offset_of_center_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Obb3D_t3491121690::get_offset_of_halfExtents_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Obb3D_t3491121690::get_offset_of_rotationZ_2() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Obb3D_t3491121690::get_offset_of_unused_3() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1877 = { sizeof (WordResultData_t3742236631)+ sizeof (Il2CppObject), sizeof(WordResultData_t3742236631 ), 0, 0 };
extern const int32_t g_FieldOffsetTable1877[5] = 
{
	WordResultData_t3742236631::get_offset_of_pose_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	WordResultData_t3742236631::get_offset_of_timeStamp_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	WordResultData_t3742236631::get_offset_of_statusInteger_2() + static_cast<int32_t>(sizeof(Il2CppObject)),
	WordResultData_t3742236631::get_offset_of_id_3() + static_cast<int32_t>(sizeof(Il2CppObject)),
	WordResultData_t3742236631::get_offset_of_orientedBoundingBox_4() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1878 = { sizeof (WordData_t1273964084)+ sizeof (Il2CppObject), sizeof(WordData_t1273964084 ), 0, 0 };
extern const int32_t g_FieldOffsetTable1878[4] = 
{
	WordData_t1273964084::get_offset_of_stringValue_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	WordData_t1273964084::get_offset_of_id_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	WordData_t1273964084::get_offset_of_size_2() + static_cast<int32_t>(sizeof(Il2CppObject)),
	WordData_t1273964084::get_offset_of_unused_3() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1879 = { sizeof (ImageHeaderData_t3150040852)+ sizeof (Il2CppObject), sizeof(ImageHeaderData_t3150040852 ), 0, 0 };
extern const int32_t g_FieldOffsetTable1879[9] = 
{
	ImageHeaderData_t3150040852::get_offset_of_data_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	ImageHeaderData_t3150040852::get_offset_of_width_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	ImageHeaderData_t3150040852::get_offset_of_height_2() + static_cast<int32_t>(sizeof(Il2CppObject)),
	ImageHeaderData_t3150040852::get_offset_of_stride_3() + static_cast<int32_t>(sizeof(Il2CppObject)),
	ImageHeaderData_t3150040852::get_offset_of_bufferWidth_4() + static_cast<int32_t>(sizeof(Il2CppObject)),
	ImageHeaderData_t3150040852::get_offset_of_bufferHeight_5() + static_cast<int32_t>(sizeof(Il2CppObject)),
	ImageHeaderData_t3150040852::get_offset_of_format_6() + static_cast<int32_t>(sizeof(Il2CppObject)),
	ImageHeaderData_t3150040852::get_offset_of_reallocate_7() + static_cast<int32_t>(sizeof(Il2CppObject)),
	ImageHeaderData_t3150040852::get_offset_of_updated_8() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1880 = { sizeof (MeshData_t1863273727)+ sizeof (Il2CppObject), sizeof(MeshData_t1863273727 ), 0, 0 };
extern const int32_t g_FieldOffsetTable1880[8] = 
{
	MeshData_t1863273727::get_offset_of_positionsArray_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	MeshData_t1863273727::get_offset_of_normalsArray_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	MeshData_t1863273727::get_offset_of_texCoordsArray_2() + static_cast<int32_t>(sizeof(Il2CppObject)),
	MeshData_t1863273727::get_offset_of_triangleIdxArray_3() + static_cast<int32_t>(sizeof(Il2CppObject)),
	MeshData_t1863273727::get_offset_of_numVertexValues_4() + static_cast<int32_t>(sizeof(Il2CppObject)),
	MeshData_t1863273727::get_offset_of_hasNormals_5() + static_cast<int32_t>(sizeof(Il2CppObject)),
	MeshData_t1863273727::get_offset_of_hasTexCoords_6() + static_cast<int32_t>(sizeof(Il2CppObject)),
	MeshData_t1863273727::get_offset_of_numTriangleIndices_7() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1881 = { sizeof (InstanceIdData_t2613089982)+ sizeof (Il2CppObject), sizeof(InstanceIdData_t2613089982 ), 0, 0 };
extern const int32_t g_FieldOffsetTable1881[5] = 
{
	InstanceIdData_t2613089982::get_offset_of_numericValue_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	InstanceIdData_t2613089982::get_offset_of_buffer_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	InstanceIdData_t2613089982::get_offset_of_reserved_2() + static_cast<int32_t>(sizeof(Il2CppObject)),
	InstanceIdData_t2613089982::get_offset_of_dataLength_3() + static_cast<int32_t>(sizeof(Il2CppObject)),
	InstanceIdData_t2613089982::get_offset_of_dataType_4() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1882 = { sizeof (VuMarkTargetData_t2130450083)+ sizeof (Il2CppObject), sizeof(VuMarkTargetData_t2130450083 ), 0, 0 };
extern const int32_t g_FieldOffsetTable1882[5] = 
{
	VuMarkTargetData_t2130450083::get_offset_of_instanceId_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	VuMarkTargetData_t2130450083::get_offset_of_id_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	VuMarkTargetData_t2130450083::get_offset_of_templateId_2() + static_cast<int32_t>(sizeof(Il2CppObject)),
	VuMarkTargetData_t2130450083::get_offset_of_size_3() + static_cast<int32_t>(sizeof(Il2CppObject)),
	VuMarkTargetData_t2130450083::get_offset_of_unused_4() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1883 = { sizeof (SmartTerrainRevisionData_t1453372369)+ sizeof (Il2CppObject), sizeof(SmartTerrainRevisionData_t1453372369 ), 0, 0 };
extern const int32_t g_FieldOffsetTable1883[2] = 
{
	SmartTerrainRevisionData_t1453372369::get_offset_of_id_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	SmartTerrainRevisionData_t1453372369::get_offset_of_revision_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1884 = { sizeof (SurfaceData_t2968608989)+ sizeof (Il2CppObject), sizeof(SurfaceData_t2968608989 ), 0, 0 };
extern const int32_t g_FieldOffsetTable1884[9] = 
{
	SurfaceData_t2968608989::get_offset_of_meshBoundaryArray_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	SurfaceData_t2968608989::get_offset_of_meshData_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	SurfaceData_t2968608989::get_offset_of_navMeshData_2() + static_cast<int32_t>(sizeof(Il2CppObject)),
	SurfaceData_t2968608989::get_offset_of_boundingBox_3() + static_cast<int32_t>(sizeof(Il2CppObject)),
	SurfaceData_t2968608989::get_offset_of_localPose_4() + static_cast<int32_t>(sizeof(Il2CppObject)),
	SurfaceData_t2968608989::get_offset_of_id_5() + static_cast<int32_t>(sizeof(Il2CppObject)),
	SurfaceData_t2968608989::get_offset_of_parentID_6() + static_cast<int32_t>(sizeof(Il2CppObject)),
	SurfaceData_t2968608989::get_offset_of_numBoundaryIndices_7() + static_cast<int32_t>(sizeof(Il2CppObject)),
	SurfaceData_t2968608989::get_offset_of_revision_8() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1885 = { sizeof (PropData_t4033919773)+ sizeof (Il2CppObject), sizeof(PropData_t4033919773 ), 0, 0 };
extern const int32_t g_FieldOffsetTable1885[8] = 
{
	PropData_t4033919773::get_offset_of_meshData_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	PropData_t4033919773::get_offset_of_id_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	PropData_t4033919773::get_offset_of_parentID_2() + static_cast<int32_t>(sizeof(Il2CppObject)),
	PropData_t4033919773::get_offset_of_boundingBox_3() + static_cast<int32_t>(sizeof(Il2CppObject)),
	PropData_t4033919773::get_offset_of_localPosition_4() + static_cast<int32_t>(sizeof(Il2CppObject)),
	PropData_t4033919773::get_offset_of_localPose_5() + static_cast<int32_t>(sizeof(Il2CppObject)),
	PropData_t4033919773::get_offset_of_revision_6() + static_cast<int32_t>(sizeof(Il2CppObject)),
	PropData_t4033919773::get_offset_of_unused_7() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1886 = { sizeof (VuMarkTargetResultData_t4188455712)+ sizeof (Il2CppObject), sizeof(VuMarkTargetResultData_t4188455712 ), 0, 0 };
extern const int32_t g_FieldOffsetTable1886[6] = 
{
	VuMarkTargetResultData_t4188455712::get_offset_of_pose_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	VuMarkTargetResultData_t4188455712::get_offset_of_timeStamp_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	VuMarkTargetResultData_t4188455712::get_offset_of_statusInteger_2() + static_cast<int32_t>(sizeof(Il2CppObject)),
	VuMarkTargetResultData_t4188455712::get_offset_of_targetID_3() + static_cast<int32_t>(sizeof(Il2CppObject)),
	VuMarkTargetResultData_t4188455712::get_offset_of_resultID_4() + static_cast<int32_t>(sizeof(Il2CppObject)),
	VuMarkTargetResultData_t4188455712::get_offset_of_unused_5() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1887 = { sizeof (FrameState_t3635099966)+ sizeof (Il2CppObject), sizeof(FrameState_t3635099966 ), 0, 0 };
extern const int32_t g_FieldOffsetTable1887[22] = 
{
	FrameState_t3635099966::get_offset_of_trackableDataArray_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	FrameState_t3635099966::get_offset_of_vbDataArray_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	FrameState_t3635099966::get_offset_of_wordResultArray_2() + static_cast<int32_t>(sizeof(Il2CppObject)),
	FrameState_t3635099966::get_offset_of_newWordDataArray_3() + static_cast<int32_t>(sizeof(Il2CppObject)),
	FrameState_t3635099966::get_offset_of_vuMarkResultArray_4() + static_cast<int32_t>(sizeof(Il2CppObject)),
	FrameState_t3635099966::get_offset_of_newVuMarkDataArray_5() + static_cast<int32_t>(sizeof(Il2CppObject)),
	FrameState_t3635099966::get_offset_of_propTrackableDataArray_6() + static_cast<int32_t>(sizeof(Il2CppObject)),
	FrameState_t3635099966::get_offset_of_smartTerrainRevisionsArray_7() + static_cast<int32_t>(sizeof(Il2CppObject)),
	FrameState_t3635099966::get_offset_of_updatedSurfacesArray_8() + static_cast<int32_t>(sizeof(Il2CppObject)),
	FrameState_t3635099966::get_offset_of_updatedPropsArray_9() + static_cast<int32_t>(sizeof(Il2CppObject)),
	FrameState_t3635099966::get_offset_of_numTrackableResults_10() + static_cast<int32_t>(sizeof(Il2CppObject)),
	FrameState_t3635099966::get_offset_of_numVirtualButtonResults_11() + static_cast<int32_t>(sizeof(Il2CppObject)),
	FrameState_t3635099966::get_offset_of_frameIndex_12() + static_cast<int32_t>(sizeof(Il2CppObject)),
	FrameState_t3635099966::get_offset_of_numWordResults_13() + static_cast<int32_t>(sizeof(Il2CppObject)),
	FrameState_t3635099966::get_offset_of_numNewWords_14() + static_cast<int32_t>(sizeof(Il2CppObject)),
	FrameState_t3635099966::get_offset_of_numVuMarkResults_15() + static_cast<int32_t>(sizeof(Il2CppObject)),
	FrameState_t3635099966::get_offset_of_numNewVuMarks_16() + static_cast<int32_t>(sizeof(Il2CppObject)),
	FrameState_t3635099966::get_offset_of_numPropTrackableResults_17() + static_cast<int32_t>(sizeof(Il2CppObject)),
	FrameState_t3635099966::get_offset_of_numSmartTerrainRevisions_18() + static_cast<int32_t>(sizeof(Il2CppObject)),
	FrameState_t3635099966::get_offset_of_numUpdatedSurfaces_19() + static_cast<int32_t>(sizeof(Il2CppObject)),
	FrameState_t3635099966::get_offset_of_numUpdatedProps_20() + static_cast<int32_t>(sizeof(Il2CppObject)),
	FrameState_t3635099966::get_offset_of_deviceTrackableId_21() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1888 = { sizeof (AutoRotationState_t3090691518)+ sizeof (Il2CppObject), sizeof(AutoRotationState_t3090691518_marshaled_pinvoke), 0, 0 };
extern const int32_t g_FieldOffsetTable1888[5] = 
{
	AutoRotationState_t3090691518::get_offset_of_setOnPause_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	AutoRotationState_t3090691518::get_offset_of_autorotateToPortrait_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	AutoRotationState_t3090691518::get_offset_of_autorotateToPortraitUpsideDown_2() + static_cast<int32_t>(sizeof(Il2CppObject)),
	AutoRotationState_t3090691518::get_offset_of_autorotateToLandscapeLeft_3() + static_cast<int32_t>(sizeof(Il2CppObject)),
	AutoRotationState_t3090691518::get_offset_of_autorotateToLandscapeRight_4() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1889 = { sizeof (U3CU3Ec__DisplayClass9_t2337328198), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1889[1] = 
{
	U3CU3Ec__DisplayClass9_t2337328198::get_offset_of_id_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1890 = { sizeof (VuforiaRenderer_t2933102835), -1, sizeof(VuforiaRenderer_t2933102835_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable1890[1] = 
{
	VuforiaRenderer_t2933102835_StaticFields::get_offset_of_sInstance_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1891 = { sizeof (FpsHint_t1598668988)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable1891[5] = 
{
	FpsHint_t1598668988::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1892 = { sizeof (VideoBackgroundReflection_t4106934884)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable1892[4] = 
{
	VideoBackgroundReflection_t4106934884::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1893 = { sizeof (VideoBGCfgData_t4137084396)+ sizeof (Il2CppObject), sizeof(VideoBGCfgData_t4137084396 ), 0, 0 };
extern const int32_t g_FieldOffsetTable1893[4] = 
{
	VideoBGCfgData_t4137084396::get_offset_of_position_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	VideoBGCfgData_t4137084396::get_offset_of_size_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	VideoBGCfgData_t4137084396::get_offset_of_enabled_2() + static_cast<int32_t>(sizeof(Il2CppObject)),
	VideoBGCfgData_t4137084396::get_offset_of_reflectionInteger_3() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1894 = { sizeof (Vec2I_t829768013)+ sizeof (Il2CppObject), sizeof(Vec2I_t829768013 ), 0, 0 };
extern const int32_t g_FieldOffsetTable1894[2] = 
{
	Vec2I_t829768013::get_offset_of_x_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Vec2I_t829768013::get_offset_of_y_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1895 = { sizeof (VideoTextureInfo_t2617831468)+ sizeof (Il2CppObject), sizeof(VideoTextureInfo_t2617831468 ), 0, 0 };
extern const int32_t g_FieldOffsetTable1895[2] = 
{
	VideoTextureInfo_t2617831468::get_offset_of_textureSize_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	VideoTextureInfo_t2617831468::get_offset_of_imageSize_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1896 = { sizeof (RendererAPI_t804170727)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable1896[4] = 
{
	RendererAPI_t804170727::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1897 = { sizeof (VuforiaRendererImpl_t3510735303), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1897[6] = 
{
	VuforiaRendererImpl_t3510735303::get_offset_of_mVideoBGConfig_1(),
	VuforiaRendererImpl_t3510735303::get_offset_of_mVideoBGConfigSet_2(),
	VuforiaRendererImpl_t3510735303::get_offset_of_mVideoBackgroundTexture_3(),
	VuforiaRendererImpl_t3510735303::get_offset_of_mBackgroundTextureHasChanged_4(),
	VuforiaRendererImpl_t3510735303::get_offset_of_mLastSetReflection_5(),
	VuforiaRendererImpl_t3510735303::get_offset_of_mNativeRenderingCallback_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1898 = { sizeof (RenderEvent_t4076072164)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable1898[7] = 
{
	RenderEvent_t4076072164::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1899 = { sizeof (VuforiaUnityImpl_t149264205), -1, sizeof(VuforiaUnityImpl_t149264205_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable1899[1] = 
{
	VuforiaUnityImpl_t149264205_StaticFields::get_offset_of_mRendererDirty_0(),
};
#ifdef __clang__
#pragma clang diagnostic pop
#endif
