﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "class-internals.h"
#include "codegen/il2cpp-codegen.h"

extern "C" void __Il2CppComDelegate_t3311706788_create_ccw ();
extern const Il2CppMethodPointer g_CcwMarshalingFunctions[2] = 
{
	__Il2CppComDelegate_t3311706788_create_ccw,
	NULL,
};
