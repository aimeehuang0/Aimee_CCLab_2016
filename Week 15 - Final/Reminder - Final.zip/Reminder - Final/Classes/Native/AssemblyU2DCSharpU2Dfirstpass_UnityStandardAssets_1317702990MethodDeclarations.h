﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// UnityStandardAssets.Utility.SimpleActivatorMenu
struct SimpleActivatorMenu_t1317702990;

#include "codegen/il2cpp-codegen.h"

// System.Void UnityStandardAssets.Utility.SimpleActivatorMenu::.ctor()
extern "C"  void SimpleActivatorMenu__ctor_m2390016872 (SimpleActivatorMenu_t1317702990 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Utility.SimpleActivatorMenu::OnEnable()
extern "C"  void SimpleActivatorMenu_OnEnable_m718106068 (SimpleActivatorMenu_t1317702990 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Utility.SimpleActivatorMenu::NextCamera()
extern "C"  void SimpleActivatorMenu_NextCamera_m3491293984 (SimpleActivatorMenu_t1317702990 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
