﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// Mono.Security.Cryptography.MD4
struct MD4_t1888998593;
// System.String
struct String_t;

#include "codegen/il2cpp-codegen.h"
#include "mscorlib_System_String2029220233.h"

// System.Void Mono.Security.Cryptography.MD4::.ctor()
extern "C"  void MD4__ctor_m2366413460 (MD4_t1888998593 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// Mono.Security.Cryptography.MD4 Mono.Security.Cryptography.MD4::Create()
extern "C"  MD4_t1888998593 * MD4_Create_m3565183915 (Il2CppObject * __this /* static, unused */, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// Mono.Security.Cryptography.MD4 Mono.Security.Cryptography.MD4::Create(System.String)
extern "C"  MD4_t1888998593 * MD4_Create_m2582504069 (Il2CppObject * __this /* static, unused */, String_t* ___hashName0, const MethodInfo* method) IL2CPP_METHOD_ATTR;
