﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// UnityStandardAssets.Utility.AutoMobileShaderSwitch/ReplacementList
struct ReplacementList_t3608854452;

#include "codegen/il2cpp-codegen.h"

// System.Void UnityStandardAssets.Utility.AutoMobileShaderSwitch/ReplacementList::.ctor()
extern "C"  void ReplacementList__ctor_m829451201 (ReplacementList_t3608854452 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
