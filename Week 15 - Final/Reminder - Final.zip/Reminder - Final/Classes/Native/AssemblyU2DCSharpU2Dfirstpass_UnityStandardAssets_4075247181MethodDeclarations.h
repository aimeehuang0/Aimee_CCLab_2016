﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// UnityStandardAssets.Utility.DragRigidbody/<DragObject>c__Iterator0
struct U3CDragObjectU3Ec__Iterator0_t4075247181;
// System.Object
struct Il2CppObject;

#include "codegen/il2cpp-codegen.h"

// System.Void UnityStandardAssets.Utility.DragRigidbody/<DragObject>c__Iterator0::.ctor()
extern "C"  void U3CDragObjectU3Ec__Iterator0__ctor_m3601998388 (U3CDragObjectU3Ec__Iterator0_t4075247181 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Boolean UnityStandardAssets.Utility.DragRigidbody/<DragObject>c__Iterator0::MoveNext()
extern "C"  bool U3CDragObjectU3Ec__Iterator0_MoveNext_m651360680 (U3CDragObjectU3Ec__Iterator0_t4075247181 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Object UnityStandardAssets.Utility.DragRigidbody/<DragObject>c__Iterator0::System.Collections.Generic.IEnumerator<object>.get_Current()
extern "C"  Il2CppObject * U3CDragObjectU3Ec__Iterator0_System_Collections_Generic_IEnumeratorU3CobjectU3E_get_Current_m323031380 (U3CDragObjectU3Ec__Iterator0_t4075247181 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Object UnityStandardAssets.Utility.DragRigidbody/<DragObject>c__Iterator0::System.Collections.IEnumerator.get_Current()
extern "C"  Il2CppObject * U3CDragObjectU3Ec__Iterator0_System_Collections_IEnumerator_get_Current_m1225729884 (U3CDragObjectU3Ec__Iterator0_t4075247181 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Utility.DragRigidbody/<DragObject>c__Iterator0::Dispose()
extern "C"  void U3CDragObjectU3Ec__Iterator0_Dispose_m4045646525 (U3CDragObjectU3Ec__Iterator0_t4075247181 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Utility.DragRigidbody/<DragObject>c__Iterator0::Reset()
extern "C"  void U3CDragObjectU3Ec__Iterator0_Reset_m102451091 (U3CDragObjectU3Ec__Iterator0_t4075247181 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
