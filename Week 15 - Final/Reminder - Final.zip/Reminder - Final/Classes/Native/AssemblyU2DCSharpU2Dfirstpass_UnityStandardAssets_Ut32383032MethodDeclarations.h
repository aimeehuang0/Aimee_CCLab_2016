﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// UnityStandardAssets.Utility.SimpleMouseRotator
struct SimpleMouseRotator_t32383032;

#include "codegen/il2cpp-codegen.h"

// System.Void UnityStandardAssets.Utility.SimpleMouseRotator::.ctor()
extern "C"  void SimpleMouseRotator__ctor_m10307302 (SimpleMouseRotator_t32383032 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Utility.SimpleMouseRotator::Start()
extern "C"  void SimpleMouseRotator_Start_m3953175470 (SimpleMouseRotator_t32383032 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Utility.SimpleMouseRotator::Update()
extern "C"  void SimpleMouseRotator_Update_m4246691885 (SimpleMouseRotator_t32383032 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
