﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// UnityStandardAssets.Effects.ExplosionPhysicsForce
struct ExplosionPhysicsForce_t3442124285;
// System.Collections.IEnumerator
struct IEnumerator_t1466026749;

#include "codegen/il2cpp-codegen.h"

// System.Void UnityStandardAssets.Effects.ExplosionPhysicsForce::.ctor()
extern "C"  void ExplosionPhysicsForce__ctor_m3315875033 (ExplosionPhysicsForce_t3442124285 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Collections.IEnumerator UnityStandardAssets.Effects.ExplosionPhysicsForce::Start()
extern "C"  Il2CppObject * ExplosionPhysicsForce_Start_m1882562815 (ExplosionPhysicsForce_t3442124285 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
