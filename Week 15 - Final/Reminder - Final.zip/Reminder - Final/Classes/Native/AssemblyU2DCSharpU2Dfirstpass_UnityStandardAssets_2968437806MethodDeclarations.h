﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// UnityStandardAssets.Utility.FollowTarget
struct FollowTarget_t2968437806;

#include "codegen/il2cpp-codegen.h"

// System.Void UnityStandardAssets.Utility.FollowTarget::.ctor()
extern "C"  void FollowTarget__ctor_m861771268 (FollowTarget_t2968437806 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Utility.FollowTarget::LateUpdate()
extern "C"  void FollowTarget_LateUpdate_m2775261415 (FollowTarget_t2968437806 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
