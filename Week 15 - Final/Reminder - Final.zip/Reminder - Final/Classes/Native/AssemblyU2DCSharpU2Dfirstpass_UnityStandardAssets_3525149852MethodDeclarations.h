﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// UnityStandardAssets.Utility.LerpControlledBob
struct LerpControlledBob_t3525149852;
// System.Collections.IEnumerator
struct IEnumerator_t1466026749;

#include "codegen/il2cpp-codegen.h"

// System.Void UnityStandardAssets.Utility.LerpControlledBob::.ctor()
extern "C"  void LerpControlledBob__ctor_m1697802732 (LerpControlledBob_t3525149852 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Single UnityStandardAssets.Utility.LerpControlledBob::Offset()
extern "C"  float LerpControlledBob_Offset_m2903143299 (LerpControlledBob_t3525149852 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Collections.IEnumerator UnityStandardAssets.Utility.LerpControlledBob::DoBobCycle()
extern "C"  Il2CppObject * LerpControlledBob_DoBobCycle_m4244417976 (LerpControlledBob_t3525149852 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
