﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <cstring>
#include <string.h>
#include <stdio.h>
#include <cmath>
#include <limits>
#include <assert.h>


#include "class-internals.h"
#include "codegen/il2cpp-codegen.h"
#include "AssemblyU2DCSharp_Vuforia_DigitalEyewearBehaviour495394589.h"
#include "AssemblyU2DCSharp_Vuforia_GLErrorHandler3809113141.h"
#include "AssemblyU2DCSharp_Vuforia_HideExcessAreaBehaviour3495034315.h"
#include "AssemblyU2DCSharp_Vuforia_ImageTargetBehaviour2654589389.h"
#include "AssemblyU2DCSharp_Vuforia_AndroidUnityPlayer852788525.h"
#include "AssemblyU2DCSharp_Vuforia_ComponentFactoryStarterB3249343815.h"
#include "AssemblyU2DCSharp_Vuforia_IOSUnityPlayer3656371703.h"
#include "AssemblyU2DCSharp_Vuforia_VuforiaBehaviourComponen1383853028.h"
#include "AssemblyU2DCSharp_Vuforia_WSAUnityPlayer425981959.h"
#include "AssemblyU2DCSharp_Vuforia_KeepAliveBehaviour1532923751.h"
#include "AssemblyU2DCSharp_Vuforia_MarkerBehaviour1265232977.h"
#include "AssemblyU2DCSharp_Vuforia_MaskOutBehaviour2994129365.h"
#include "AssemblyU2DCSharp_Vuforia_MultiTargetBehaviour3504654311.h"
#include "AssemblyU2DCSharp_Vuforia_ObjectTargetBehaviour3836044259.h"
#include "AssemblyU2DCSharp_Vuforia_PropBehaviour966064926.h"
#include "AssemblyU2DCSharp_Vuforia_ReconstructionBehaviour4009935945.h"
#include "AssemblyU2DCSharp_Vuforia_ReconstructionFromTarget2111803406.h"
#include "AssemblyU2DCSharp_Vuforia_SmartTerrainTrackerBehav3844158157.h"
#include "AssemblyU2DCSharp_Vuforia_SurfaceBehaviour2405314212.h"
#include "AssemblyU2DCSharp_Vuforia_TextRecoBehaviour3400239837.h"
#include "AssemblyU2DCSharp_Vuforia_TurnOffBehaviour3058161409.h"
#include "AssemblyU2DCSharp_Vuforia_TurnOffWordBehaviour584991835.h"
#include "AssemblyU2DCSharp_Vuforia_UserDefinedTargetBuildin4184040062.h"
#include "AssemblyU2DCSharp_VRIntegrationHelper556656694.h"
#include "AssemblyU2DCSharp_Vuforia_VideoBackgroundBehaviour3161817952.h"
#include "AssemblyU2DCSharp_Vuforia_VideoBackgroundManager3515346924.h"
#include "AssemblyU2DCSharp_Vuforia_VirtualButtonBehaviour2515041812.h"
#include "AssemblyU2DCSharp_Vuforia_VuMarkBehaviour2060629989.h"
#include "AssemblyU2DCSharp_Vuforia_VuforiaBehaviour359035403.h"
#include "AssemblyU2DCSharp_Vuforia_WebCamBehaviour407765638.h"
#include "AssemblyU2DCSharp_Vuforia_WireframeBehaviour2494532455.h"
#include "AssemblyU2DCSharp_Vuforia_WireframeTrackableEventH1535150527.h"
#include "AssemblyU2DCSharp_Vuforia_WordBehaviour3366478421.h"
#include "AssemblyU2DCSharpU2Dfirstpass_U3CModuleU3E3783534214.h"
#include "AssemblyU2DCSharpU2Dfirstpass_MouseLook2643707144.h"
#include "AssemblyU2DCSharpU2Dfirstpass_MouseLook_RotationAx2150291266.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_3842535002.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_1749519406.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_1746754562.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_C900829694.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_2691167515.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_2157404822.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_3369627127.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_2144252492.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_3675451859.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_3634411257.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_2607665220.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_3273007553.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_3398611001.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_1039424009.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_Cr69389957.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_4103805620.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_1952940174.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_3887193949.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_C113868641.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_3347016329.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_E706380940.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_1174895067.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_2348924364.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_3442124285.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_1741822950.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_E641737877.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_E455343489.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_2151802939.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_2590751060.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_4212470145.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_3377687064.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_1461062090.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_2638123957.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_2794485791.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_U639433180.h"
#include "AssemblyU2DCSharpU2Dfirstpass_AlphaButtonClickMask1798481236.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_1108113546.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_4021787953.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_3608854452.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_2592441618.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_U245510835.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_2688848816.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_2107922160.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_2127994057.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_4075247181.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_U859033236.h"
#include "AssemblyU2DCSharpU2Dfirstpass_EventSystemChecker3549249260.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_1823436477.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_1277509062.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_1597325334.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_U584591591.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_2968437806.h"
#include "AssemblyU2DCSharpU2Dfirstpass_ForcedReset935499500.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_3525149852.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_1181024807.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_2090656575.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_2926400505.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_U190286178.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_3769115865.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_U935951820.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_1911586150.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_1317702990.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_Ut32383032.h"
#include "AssemblyU2DCSharpU2Dfirstpass_UnityStandardAssets_2548964113.h"



#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2000 = { sizeof (DigitalEyewearBehaviour_t495394589), -1, sizeof(DigitalEyewearBehaviour_t495394589_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2000[1] = 
{
	DigitalEyewearBehaviour_t495394589_StaticFields::get_offset_of_mDigitalEyewearBehaviour_28(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2001 = { sizeof (GLErrorHandler_t3809113141), -1, sizeof(GLErrorHandler_t3809113141_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2001[3] = 
{
	GLErrorHandler_t3809113141_StaticFields::get_offset_of_mErrorText_2(),
	GLErrorHandler_t3809113141_StaticFields::get_offset_of_mErrorOccurred_3(),
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2002 = { sizeof (HideExcessAreaBehaviour_t3495034315), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2003 = { sizeof (ImageTargetBehaviour_t2654589389), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2004 = { sizeof (AndroidUnityPlayer_t852788525), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2004[6] = 
{
	0,
	0,
	AndroidUnityPlayer_t852788525::get_offset_of_mScreenOrientation_2(),
	AndroidUnityPlayer_t852788525::get_offset_of_mJavaScreenOrientation_3(),
	AndroidUnityPlayer_t852788525::get_offset_of_mFramesSinceLastOrientationReset_4(),
	AndroidUnityPlayer_t852788525::get_offset_of_mFramesSinceLastJavaOrientationCheck_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2005 = { sizeof (ComponentFactoryStarterBehaviour_t3249343815), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2006 = { sizeof (IOSUnityPlayer_t3656371703), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2006[1] = 
{
	IOSUnityPlayer_t3656371703::get_offset_of_mScreenOrientation_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2007 = { sizeof (VuforiaBehaviourComponentFactory_t1383853028), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2008 = { sizeof (WSAUnityPlayer_t425981959), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2008[1] = 
{
	WSAUnityPlayer_t425981959::get_offset_of_mScreenOrientation_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2009 = { sizeof (KeepAliveBehaviour_t1532923751), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2010 = { sizeof (MarkerBehaviour_t1265232977), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2011 = { sizeof (MaskOutBehaviour_t2994129365), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2012 = { sizeof (MultiTargetBehaviour_t3504654311), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2013 = { sizeof (ObjectTargetBehaviour_t3836044259), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2014 = { sizeof (PropBehaviour_t966064926), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2015 = { sizeof (ReconstructionBehaviour_t4009935945), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2016 = { sizeof (ReconstructionFromTargetBehaviour_t2111803406), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2017 = { sizeof (SmartTerrainTrackerBehaviour_t3844158157), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2018 = { sizeof (SurfaceBehaviour_t2405314212), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2019 = { sizeof (TextRecoBehaviour_t3400239837), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2020 = { sizeof (TurnOffBehaviour_t3058161409), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2021 = { sizeof (TurnOffWordBehaviour_t584991835), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2022 = { sizeof (UserDefinedTargetBuildingBehaviour_t4184040062), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2023 = { sizeof (VRIntegrationHelper_t556656694), -1, sizeof(VRIntegrationHelper_t556656694_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2023[12] = 
{
	VRIntegrationHelper_t556656694_StaticFields::get_offset_of_mLeftCameraMatrixOriginal_2(),
	VRIntegrationHelper_t556656694_StaticFields::get_offset_of_mRightCameraMatrixOriginal_3(),
	VRIntegrationHelper_t556656694_StaticFields::get_offset_of_mLeftCamera_4(),
	VRIntegrationHelper_t556656694_StaticFields::get_offset_of_mRightCamera_5(),
	VRIntegrationHelper_t556656694_StaticFields::get_offset_of_mLeftExcessAreaBehaviour_6(),
	VRIntegrationHelper_t556656694_StaticFields::get_offset_of_mRightExcessAreaBehaviour_7(),
	VRIntegrationHelper_t556656694_StaticFields::get_offset_of_mLeftCameraPixelRect_8(),
	VRIntegrationHelper_t556656694_StaticFields::get_offset_of_mRightCameraPixelRect_9(),
	VRIntegrationHelper_t556656694_StaticFields::get_offset_of_mLeftCameraDataAcquired_10(),
	VRIntegrationHelper_t556656694_StaticFields::get_offset_of_mRightCameraDataAcquired_11(),
	VRIntegrationHelper_t556656694::get_offset_of_IsLeft_12(),
	VRIntegrationHelper_t556656694::get_offset_of_TrackableParent_13(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2024 = { sizeof (VideoBackgroundBehaviour_t3161817952), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2025 = { sizeof (VideoBackgroundManager_t3515346924), -1, sizeof(VideoBackgroundManager_t3515346924_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2025[1] = 
{
	VideoBackgroundManager_t3515346924_StaticFields::get_offset_of_mInstance_9(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2026 = { sizeof (VirtualButtonBehaviour_t2515041812), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2027 = { sizeof (VuMarkBehaviour_t2060629989), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2028 = { sizeof (VuforiaBehaviour_t359035403), -1, sizeof(VuforiaBehaviour_t359035403_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2028[1] = 
{
	VuforiaBehaviour_t359035403_StaticFields::get_offset_of_mVuforiaBehaviour_44(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2029 = { sizeof (WebCamBehaviour_t407765638), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2030 = { sizeof (WireframeBehaviour_t2494532455), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2030[4] = 
{
	WireframeBehaviour_t2494532455::get_offset_of_lineMaterial_2(),
	WireframeBehaviour_t2494532455::get_offset_of_ShowLines_3(),
	WireframeBehaviour_t2494532455::get_offset_of_LineColor_4(),
	WireframeBehaviour_t2494532455::get_offset_of_mLineMaterial_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2031 = { sizeof (WireframeTrackableEventHandler_t1535150527), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2031[1] = 
{
	WireframeTrackableEventHandler_t1535150527::get_offset_of_mTrackableBehaviour_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2032 = { sizeof (WordBehaviour_t3366478421), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2033 = { sizeof (U3CModuleU3E_t3783534223), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2034 = { sizeof (MouseLook_t2643707144), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2034[10] = 
{
	MouseLook_t2643707144::get_offset_of_axes_2(),
	MouseLook_t2643707144::get_offset_of_sensitivityX_3(),
	MouseLook_t2643707144::get_offset_of_sensitivityY_4(),
	MouseLook_t2643707144::get_offset_of_minimumX_5(),
	MouseLook_t2643707144::get_offset_of_maximumX_6(),
	MouseLook_t2643707144::get_offset_of_minimumY_7(),
	MouseLook_t2643707144::get_offset_of_maximumY_8(),
	MouseLook_t2643707144::get_offset_of_rotationX_9(),
	MouseLook_t2643707144::get_offset_of_rotationY_10(),
	MouseLook_t2643707144::get_offset_of_originalRotation_11(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2035 = { sizeof (RotationAxes_t2150291266)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2035[4] = 
{
	RotationAxes_t2150291266::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2036 = { sizeof (AxisTouchButton_t3842535002), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2036[6] = 
{
	AxisTouchButton_t3842535002::get_offset_of_axisName_2(),
	AxisTouchButton_t3842535002::get_offset_of_axisValue_3(),
	AxisTouchButton_t3842535002::get_offset_of_responseSpeed_4(),
	AxisTouchButton_t3842535002::get_offset_of_returnToCentreSpeed_5(),
	AxisTouchButton_t3842535002::get_offset_of_m_PairedWith_6(),
	AxisTouchButton_t3842535002::get_offset_of_m_Axis_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2037 = { sizeof (ButtonHandler_t1749519406), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2037[1] = 
{
	ButtonHandler_t1749519406::get_offset_of_Name_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2038 = { sizeof (CrossPlatformInputManager_t1746754562), -1, sizeof(CrossPlatformInputManager_t1746754562_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2038[3] = 
{
	CrossPlatformInputManager_t1746754562_StaticFields::get_offset_of_activeInput_0(),
	CrossPlatformInputManager_t1746754562_StaticFields::get_offset_of_s_TouchInput_1(),
	CrossPlatformInputManager_t1746754562_StaticFields::get_offset_of_s_HardwareInput_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2039 = { sizeof (ActiveInputMethod_t900829694)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2039[3] = 
{
	ActiveInputMethod_t900829694::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2040 = { sizeof (VirtualAxis_t2691167515), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2040[3] = 
{
	VirtualAxis_t2691167515::get_offset_of_U3CnameU3Ek__BackingField_0(),
	VirtualAxis_t2691167515::get_offset_of_m_Value_1(),
	VirtualAxis_t2691167515::get_offset_of_U3CmatchWithInputManagerU3Ek__BackingField_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2041 = { sizeof (VirtualButton_t2157404822), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2041[5] = 
{
	VirtualButton_t2157404822::get_offset_of_U3CnameU3Ek__BackingField_0(),
	VirtualButton_t2157404822::get_offset_of_U3CmatchWithInputManagerU3Ek__BackingField_1(),
	VirtualButton_t2157404822::get_offset_of_m_LastPressedFrame_2(),
	VirtualButton_t2157404822::get_offset_of_m_ReleasedFrame_3(),
	VirtualButton_t2157404822::get_offset_of_m_Pressed_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2042 = { sizeof (InputAxisScrollbar_t3369627127), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2042[1] = 
{
	InputAxisScrollbar_t3369627127::get_offset_of_axis_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2043 = { sizeof (Joystick_t2144252492), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2043[9] = 
{
	Joystick_t2144252492::get_offset_of_MovementRange_2(),
	Joystick_t2144252492::get_offset_of_axesToUse_3(),
	Joystick_t2144252492::get_offset_of_horizontalAxisName_4(),
	Joystick_t2144252492::get_offset_of_verticalAxisName_5(),
	Joystick_t2144252492::get_offset_of_m_StartPos_6(),
	Joystick_t2144252492::get_offset_of_m_UseX_7(),
	Joystick_t2144252492::get_offset_of_m_UseY_8(),
	Joystick_t2144252492::get_offset_of_m_HorizontalVirtualAxis_9(),
	Joystick_t2144252492::get_offset_of_m_VerticalVirtualAxis_10(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2044 = { sizeof (AxisOption_t3675451859)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2044[4] = 
{
	AxisOption_t3675451859::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2045 = { sizeof (MobileControlRig_t3634411257), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2046 = { sizeof (MobileInput_t2607665220), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2047 = { sizeof (StandaloneInput_t3273007553), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2048 = { sizeof (TiltInput_t3398611001), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2048[5] = 
{
	TiltInput_t3398611001::get_offset_of_mapping_2(),
	TiltInput_t3398611001::get_offset_of_tiltAroundAxis_3(),
	TiltInput_t3398611001::get_offset_of_fullTiltAngle_4(),
	TiltInput_t3398611001::get_offset_of_centreAngleOffset_5(),
	TiltInput_t3398611001::get_offset_of_m_SteerAxis_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2049 = { sizeof (AxisOptions_t1039424009)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2049[3] = 
{
	AxisOptions_t1039424009::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2050 = { sizeof (AxisMapping_t69389957), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2050[2] = 
{
	AxisMapping_t69389957::get_offset_of_type_0(),
	AxisMapping_t69389957::get_offset_of_axisName_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2051 = { sizeof (MappingType_t4103805620)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2051[5] = 
{
	MappingType_t4103805620::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2052 = { sizeof (TouchPad_t1952940174), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2052[18] = 
{
	TouchPad_t1952940174::get_offset_of_axesToUse_2(),
	TouchPad_t1952940174::get_offset_of_controlStyle_3(),
	TouchPad_t1952940174::get_offset_of_horizontalAxisName_4(),
	TouchPad_t1952940174::get_offset_of_verticalAxisName_5(),
	TouchPad_t1952940174::get_offset_of_Xsensitivity_6(),
	TouchPad_t1952940174::get_offset_of_Ysensitivity_7(),
	TouchPad_t1952940174::get_offset_of_m_StartPos_8(),
	TouchPad_t1952940174::get_offset_of_m_PreviousDelta_9(),
	TouchPad_t1952940174::get_offset_of_m_JoytickOutput_10(),
	TouchPad_t1952940174::get_offset_of_m_UseX_11(),
	TouchPad_t1952940174::get_offset_of_m_UseY_12(),
	TouchPad_t1952940174::get_offset_of_m_HorizontalVirtualAxis_13(),
	TouchPad_t1952940174::get_offset_of_m_VerticalVirtualAxis_14(),
	TouchPad_t1952940174::get_offset_of_m_Dragging_15(),
	TouchPad_t1952940174::get_offset_of_m_Id_16(),
	TouchPad_t1952940174::get_offset_of_m_PreviousTouchPos_17(),
	TouchPad_t1952940174::get_offset_of_m_Center_18(),
	TouchPad_t1952940174::get_offset_of_m_Image_19(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2053 = { sizeof (AxisOption_t3887193949)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2053[4] = 
{
	AxisOption_t3887193949::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2054 = { sizeof (ControlStyle_t113868641)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2054[4] = 
{
	ControlStyle_t113868641::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2055 = { sizeof (VirtualInput_t3347016329), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2055[4] = 
{
	VirtualInput_t3347016329::get_offset_of_U3CvirtualMousePositionU3Ek__BackingField_0(),
	VirtualInput_t3347016329::get_offset_of_m_VirtualAxes_1(),
	VirtualInput_t3347016329::get_offset_of_m_VirtualButtons_2(),
	VirtualInput_t3347016329::get_offset_of_m_AlwaysUseVirtual_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2056 = { sizeof (AfterburnerPhysicsForce_t706380940), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2056[6] = 
{
	AfterburnerPhysicsForce_t706380940::get_offset_of_effectAngle_2(),
	AfterburnerPhysicsForce_t706380940::get_offset_of_effectWidth_3(),
	AfterburnerPhysicsForce_t706380940::get_offset_of_effectDistance_4(),
	AfterburnerPhysicsForce_t706380940::get_offset_of_force_5(),
	AfterburnerPhysicsForce_t706380940::get_offset_of_m_Cols_6(),
	AfterburnerPhysicsForce_t706380940::get_offset_of_m_Sphere_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2057 = { sizeof (ExplosionFireAndDebris_t1174895067), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2057[4] = 
{
	ExplosionFireAndDebris_t1174895067::get_offset_of_debrisPrefabs_2(),
	ExplosionFireAndDebris_t1174895067::get_offset_of_firePrefab_3(),
	ExplosionFireAndDebris_t1174895067::get_offset_of_numDebrisPieces_4(),
	ExplosionFireAndDebris_t1174895067::get_offset_of_numFires_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2058 = { sizeof (U3CStartU3Ec__Iterator0_t2348924364), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2058[10] = 
{
	U3CStartU3Ec__Iterator0_t2348924364::get_offset_of_U3CmultiplierU3E__0_0(),
	U3CStartU3Ec__Iterator0_t2348924364::get_offset_of_U3CrU3E__1_1(),
	U3CStartU3Ec__Iterator0_t2348924364::get_offset_of_U3CcolsU3E__2_2(),
	U3CStartU3Ec__Iterator0_t2348924364::get_offset_of_U24locvar0_3(),
	U3CStartU3Ec__Iterator0_t2348924364::get_offset_of_U24locvar1_4(),
	U3CStartU3Ec__Iterator0_t2348924364::get_offset_of_U3CtestRU3E__3_5(),
	U3CStartU3Ec__Iterator0_t2348924364::get_offset_of_U24this_6(),
	U3CStartU3Ec__Iterator0_t2348924364::get_offset_of_U24current_7(),
	U3CStartU3Ec__Iterator0_t2348924364::get_offset_of_U24disposing_8(),
	U3CStartU3Ec__Iterator0_t2348924364::get_offset_of_U24PC_9(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2059 = { sizeof (ExplosionPhysicsForce_t3442124285), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2059[1] = 
{
	ExplosionPhysicsForce_t3442124285::get_offset_of_explosionForce_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2060 = { sizeof (U3CStartU3Ec__Iterator0_t1741822950), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2060[11] = 
{
	U3CStartU3Ec__Iterator0_t1741822950::get_offset_of_U3CmultiplierU3E__0_0(),
	U3CStartU3Ec__Iterator0_t1741822950::get_offset_of_U3CrU3E__1_1(),
	U3CStartU3Ec__Iterator0_t1741822950::get_offset_of_U3CcolsU3E__2_2(),
	U3CStartU3Ec__Iterator0_t1741822950::get_offset_of_U3CrigidbodiesU3E__3_3(),
	U3CStartU3Ec__Iterator0_t1741822950::get_offset_of_U24locvar0_4(),
	U3CStartU3Ec__Iterator0_t1741822950::get_offset_of_U24locvar1_5(),
	U3CStartU3Ec__Iterator0_t1741822950::get_offset_of_U24locvar2_6(),
	U3CStartU3Ec__Iterator0_t1741822950::get_offset_of_U24this_7(),
	U3CStartU3Ec__Iterator0_t1741822950::get_offset_of_U24current_8(),
	U3CStartU3Ec__Iterator0_t1741822950::get_offset_of_U24disposing_9(),
	U3CStartU3Ec__Iterator0_t1741822950::get_offset_of_U24PC_10(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2061 = { sizeof (Explosive_t641737877), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2061[7] = 
{
	Explosive_t641737877::get_offset_of_explosionPrefab_2(),
	Explosive_t641737877::get_offset_of_detonationImpactVelocity_3(),
	Explosive_t641737877::get_offset_of_sizeMultiplier_4(),
	Explosive_t641737877::get_offset_of_reset_5(),
	Explosive_t641737877::get_offset_of_resetTimeDelay_6(),
	Explosive_t641737877::get_offset_of_m_Exploded_7(),
	Explosive_t641737877::get_offset_of_m_ObjectResetter_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2062 = { sizeof (U3COnCollisionEnterU3Ec__Iterator0_t455343489), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2062[5] = 
{
	U3COnCollisionEnterU3Ec__Iterator0_t455343489::get_offset_of_col_0(),
	U3COnCollisionEnterU3Ec__Iterator0_t455343489::get_offset_of_U24this_1(),
	U3COnCollisionEnterU3Ec__Iterator0_t455343489::get_offset_of_U24current_2(),
	U3COnCollisionEnterU3Ec__Iterator0_t455343489::get_offset_of_U24disposing_3(),
	U3COnCollisionEnterU3Ec__Iterator0_t455343489::get_offset_of_U24PC_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2063 = { sizeof (ExtinguishableParticleSystem_t2151802939), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2063[2] = 
{
	ExtinguishableParticleSystem_t2151802939::get_offset_of_multiplier_2(),
	ExtinguishableParticleSystem_t2151802939::get_offset_of_m_Systems_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2064 = { sizeof (FireLight_t2590751060), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2064[3] = 
{
	FireLight_t2590751060::get_offset_of_m_Rnd_2(),
	FireLight_t2590751060::get_offset_of_m_Burning_3(),
	FireLight_t2590751060::get_offset_of_m_Light_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2065 = { sizeof (Hose_t4212470145), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2065[6] = 
{
	Hose_t4212470145::get_offset_of_maxPower_2(),
	Hose_t4212470145::get_offset_of_minPower_3(),
	Hose_t4212470145::get_offset_of_changeSpeed_4(),
	Hose_t4212470145::get_offset_of_hoseWaterSystems_5(),
	Hose_t4212470145::get_offset_of_systemRenderer_6(),
	Hose_t4212470145::get_offset_of_m_Power_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2066 = { sizeof (ParticleSystemMultiplier_t3377687064), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2066[1] = 
{
	ParticleSystemMultiplier_t3377687064::get_offset_of_multiplier_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2067 = { sizeof (SmokeParticles_t1461062090), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2067[1] = 
{
	SmokeParticles_t1461062090::get_offset_of_extinguishSounds_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2068 = { sizeof (WaterHoseParticles_t2638123957), -1, sizeof(WaterHoseParticles_t2638123957_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2068[4] = 
{
	WaterHoseParticles_t2638123957_StaticFields::get_offset_of_lastSoundTime_2(),
	WaterHoseParticles_t2638123957::get_offset_of_force_3(),
	WaterHoseParticles_t2638123957::get_offset_of_m_CollisionEvents_4(),
	WaterHoseParticles_t2638123957::get_offset_of_m_ParticleSystem_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2069 = { sizeof (ActivateTrigger_t2794485791), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2069[5] = 
{
	ActivateTrigger_t2794485791::get_offset_of_action_2(),
	ActivateTrigger_t2794485791::get_offset_of_target_3(),
	ActivateTrigger_t2794485791::get_offset_of_source_4(),
	ActivateTrigger_t2794485791::get_offset_of_triggerCount_5(),
	ActivateTrigger_t2794485791::get_offset_of_repeatTrigger_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2070 = { sizeof (Mode_t639433180)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2070[7] = 
{
	Mode_t639433180::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2071 = { sizeof (AlphaButtonClickMask_t1798481236), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2071[1] = 
{
	AlphaButtonClickMask_t1798481236::get_offset_of__image_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2072 = { sizeof (AutoMobileShaderSwitch_t1108113546), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2072[1] = 
{
	AutoMobileShaderSwitch_t1108113546::get_offset_of_m_ReplacementList_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2073 = { sizeof (ReplacementDefinition_t4021787953), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2073[2] = 
{
	ReplacementDefinition_t4021787953::get_offset_of_original_0(),
	ReplacementDefinition_t4021787953::get_offset_of_replacement_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2074 = { sizeof (ReplacementList_t3608854452), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2074[1] = 
{
	ReplacementList_t3608854452::get_offset_of_items_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2075 = { sizeof (AutoMoveAndRotate_t2592441618), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2075[4] = 
{
	AutoMoveAndRotate_t2592441618::get_offset_of_moveUnitsPerSecond_2(),
	AutoMoveAndRotate_t2592441618::get_offset_of_rotateDegreesPerSecond_3(),
	AutoMoveAndRotate_t2592441618::get_offset_of_ignoreTimescale_4(),
	AutoMoveAndRotate_t2592441618::get_offset_of_m_LastRealTime_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2076 = { sizeof (Vector3andSpace_t245510835), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2076[2] = 
{
	Vector3andSpace_t245510835::get_offset_of_value_0(),
	Vector3andSpace_t245510835::get_offset_of_space_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2077 = { sizeof (CameraRefocus_t2688848816), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2077[5] = 
{
	CameraRefocus_t2688848816::get_offset_of_Camera_0(),
	CameraRefocus_t2688848816::get_offset_of_Lookatpoint_1(),
	CameraRefocus_t2688848816::get_offset_of_Parent_2(),
	CameraRefocus_t2688848816::get_offset_of_m_OrigCameraPos_3(),
	CameraRefocus_t2688848816::get_offset_of_m_Refocus_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2078 = { sizeof (CurveControlledBob_t2107922160), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2078[9] = 
{
	CurveControlledBob_t2107922160::get_offset_of_HorizontalBobRange_0(),
	CurveControlledBob_t2107922160::get_offset_of_VerticalBobRange_1(),
	CurveControlledBob_t2107922160::get_offset_of_Bobcurve_2(),
	CurveControlledBob_t2107922160::get_offset_of_VerticaltoHorizontalRatio_3(),
	CurveControlledBob_t2107922160::get_offset_of_m_CyclePositionX_4(),
	CurveControlledBob_t2107922160::get_offset_of_m_CyclePositionY_5(),
	CurveControlledBob_t2107922160::get_offset_of_m_BobBaseInterval_6(),
	CurveControlledBob_t2107922160::get_offset_of_m_OriginalCameraPosition_7(),
	CurveControlledBob_t2107922160::get_offset_of_m_Time_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2079 = { sizeof (DragRigidbody_t2127994057), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2079[7] = 
{
	0,
	0,
	0,
	0,
	0,
	0,
	DragRigidbody_t2127994057::get_offset_of_m_SpringJoint_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2080 = { sizeof (U3CDragObjectU3Ec__Iterator0_t4075247181), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2080[9] = 
{
	U3CDragObjectU3Ec__Iterator0_t4075247181::get_offset_of_U3ColdDragU3E__0_0(),
	U3CDragObjectU3Ec__Iterator0_t4075247181::get_offset_of_U3ColdAngularDragU3E__1_1(),
	U3CDragObjectU3Ec__Iterator0_t4075247181::get_offset_of_U3CmainCameraU3E__2_2(),
	U3CDragObjectU3Ec__Iterator0_t4075247181::get_offset_of_U3CrayU3E__3_3(),
	U3CDragObjectU3Ec__Iterator0_t4075247181::get_offset_of_distance_4(),
	U3CDragObjectU3Ec__Iterator0_t4075247181::get_offset_of_U24this_5(),
	U3CDragObjectU3Ec__Iterator0_t4075247181::get_offset_of_U24current_6(),
	U3CDragObjectU3Ec__Iterator0_t4075247181::get_offset_of_U24disposing_7(),
	U3CDragObjectU3Ec__Iterator0_t4075247181::get_offset_of_U24PC_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2081 = { sizeof (DynamicShadowSettings_t859033236), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2081[11] = 
{
	DynamicShadowSettings_t859033236::get_offset_of_sunLight_2(),
	DynamicShadowSettings_t859033236::get_offset_of_minHeight_3(),
	DynamicShadowSettings_t859033236::get_offset_of_minShadowDistance_4(),
	DynamicShadowSettings_t859033236::get_offset_of_minShadowBias_5(),
	DynamicShadowSettings_t859033236::get_offset_of_maxHeight_6(),
	DynamicShadowSettings_t859033236::get_offset_of_maxShadowDistance_7(),
	DynamicShadowSettings_t859033236::get_offset_of_maxShadowBias_8(),
	DynamicShadowSettings_t859033236::get_offset_of_adaptTime_9(),
	DynamicShadowSettings_t859033236::get_offset_of_m_SmoothHeight_10(),
	DynamicShadowSettings_t859033236::get_offset_of_m_ChangeSpeed_11(),
	DynamicShadowSettings_t859033236::get_offset_of_m_OriginalStrength_12(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2082 = { sizeof (EventSystemChecker_t3549249260), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2083 = { sizeof (FOVKick_t1823436477), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2083[6] = 
{
	FOVKick_t1823436477::get_offset_of_Camera_0(),
	FOVKick_t1823436477::get_offset_of_originalFov_1(),
	FOVKick_t1823436477::get_offset_of_FOVIncrease_2(),
	FOVKick_t1823436477::get_offset_of_TimeToIncrease_3(),
	FOVKick_t1823436477::get_offset_of_TimeToDecrease_4(),
	FOVKick_t1823436477::get_offset_of_IncreaseCurve_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2084 = { sizeof (U3CFOVKickUpU3Ec__Iterator0_t1277509062), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2084[5] = 
{
	U3CFOVKickUpU3Ec__Iterator0_t1277509062::get_offset_of_U3CtU3E__0_0(),
	U3CFOVKickUpU3Ec__Iterator0_t1277509062::get_offset_of_U24this_1(),
	U3CFOVKickUpU3Ec__Iterator0_t1277509062::get_offset_of_U24current_2(),
	U3CFOVKickUpU3Ec__Iterator0_t1277509062::get_offset_of_U24disposing_3(),
	U3CFOVKickUpU3Ec__Iterator0_t1277509062::get_offset_of_U24PC_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2085 = { sizeof (U3CFOVKickDownU3Ec__Iterator1_t1597325334), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2085[5] = 
{
	U3CFOVKickDownU3Ec__Iterator1_t1597325334::get_offset_of_U3CtU3E__0_0(),
	U3CFOVKickDownU3Ec__Iterator1_t1597325334::get_offset_of_U24this_1(),
	U3CFOVKickDownU3Ec__Iterator1_t1597325334::get_offset_of_U24current_2(),
	U3CFOVKickDownU3Ec__Iterator1_t1597325334::get_offset_of_U24disposing_3(),
	U3CFOVKickDownU3Ec__Iterator1_t1597325334::get_offset_of_U24PC_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2086 = { sizeof (FPSCounter_t584591591), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2086[6] = 
{
	0,
	FPSCounter_t584591591::get_offset_of_m_FpsAccumulator_3(),
	FPSCounter_t584591591::get_offset_of_m_FpsNextPeriod_4(),
	FPSCounter_t584591591::get_offset_of_m_CurrentFps_5(),
	0,
	FPSCounter_t584591591::get_offset_of_m_Text_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2087 = { sizeof (FollowTarget_t2968437806), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2087[2] = 
{
	FollowTarget_t2968437806::get_offset_of_target_2(),
	FollowTarget_t2968437806::get_offset_of_offset_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2088 = { sizeof (ForcedReset_t935499500), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2089 = { sizeof (LerpControlledBob_t3525149852), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2089[3] = 
{
	LerpControlledBob_t3525149852::get_offset_of_BobDuration_0(),
	LerpControlledBob_t3525149852::get_offset_of_BobAmount_1(),
	LerpControlledBob_t3525149852::get_offset_of_m_Offset_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2090 = { sizeof (U3CDoBobCycleU3Ec__Iterator0_t1181024807), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2090[5] = 
{
	U3CDoBobCycleU3Ec__Iterator0_t1181024807::get_offset_of_U3CtU3E__0_0(),
	U3CDoBobCycleU3Ec__Iterator0_t1181024807::get_offset_of_U24this_1(),
	U3CDoBobCycleU3Ec__Iterator0_t1181024807::get_offset_of_U24current_2(),
	U3CDoBobCycleU3Ec__Iterator0_t1181024807::get_offset_of_U24disposing_3(),
	U3CDoBobCycleU3Ec__Iterator0_t1181024807::get_offset_of_U24PC_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2091 = { sizeof (ObjectResetter_t2090656575), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2091[4] = 
{
	ObjectResetter_t2090656575::get_offset_of_originalPosition_2(),
	ObjectResetter_t2090656575::get_offset_of_originalRotation_3(),
	ObjectResetter_t2090656575::get_offset_of_originalStructure_4(),
	ObjectResetter_t2090656575::get_offset_of_Rigidbody_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2092 = { sizeof (U3CResetCoroutineU3Ec__Iterator0_t2926400505), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2092[7] = 
{
	U3CResetCoroutineU3Ec__Iterator0_t2926400505::get_offset_of_delay_0(),
	U3CResetCoroutineU3Ec__Iterator0_t2926400505::get_offset_of_U24locvar0_1(),
	U3CResetCoroutineU3Ec__Iterator0_t2926400505::get_offset_of_U24locvar1_2(),
	U3CResetCoroutineU3Ec__Iterator0_t2926400505::get_offset_of_U24this_3(),
	U3CResetCoroutineU3Ec__Iterator0_t2926400505::get_offset_of_U24current_4(),
	U3CResetCoroutineU3Ec__Iterator0_t2926400505::get_offset_of_U24disposing_5(),
	U3CResetCoroutineU3Ec__Iterator0_t2926400505::get_offset_of_U24PC_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2093 = { sizeof (ParticleSystemDestroyer_t190286178), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2093[4] = 
{
	ParticleSystemDestroyer_t190286178::get_offset_of_minDuration_2(),
	ParticleSystemDestroyer_t190286178::get_offset_of_maxDuration_3(),
	ParticleSystemDestroyer_t190286178::get_offset_of_m_MaxLifetime_4(),
	ParticleSystemDestroyer_t190286178::get_offset_of_m_EarlyStop_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2094 = { sizeof (U3CStartU3Ec__Iterator0_t3769115865), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2094[10] = 
{
	U3CStartU3Ec__Iterator0_t3769115865::get_offset_of_U3CsystemsU3E__0_0(),
	U3CStartU3Ec__Iterator0_t3769115865::get_offset_of_U24locvar0_1(),
	U3CStartU3Ec__Iterator0_t3769115865::get_offset_of_U24locvar1_2(),
	U3CStartU3Ec__Iterator0_t3769115865::get_offset_of_U3CstopTimeU3E__1_3(),
	U3CStartU3Ec__Iterator0_t3769115865::get_offset_of_U24locvar2_4(),
	U3CStartU3Ec__Iterator0_t3769115865::get_offset_of_U24locvar3_5(),
	U3CStartU3Ec__Iterator0_t3769115865::get_offset_of_U24this_6(),
	U3CStartU3Ec__Iterator0_t3769115865::get_offset_of_U24current_7(),
	U3CStartU3Ec__Iterator0_t3769115865::get_offset_of_U24disposing_8(),
	U3CStartU3Ec__Iterator0_t3769115865::get_offset_of_U24PC_9(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2095 = { sizeof (PlatformSpecificContent_t935951820), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2095[4] = 
{
	PlatformSpecificContent_t935951820::get_offset_of_m_BuildTargetGroup_2(),
	PlatformSpecificContent_t935951820::get_offset_of_m_Content_3(),
	PlatformSpecificContent_t935951820::get_offset_of_m_MonoBehaviours_4(),
	PlatformSpecificContent_t935951820::get_offset_of_m_ChildrenOfThisObject_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2096 = { sizeof (BuildTargetGroup_t1911586150)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2096[3] = 
{
	BuildTargetGroup_t1911586150::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2097 = { sizeof (SimpleActivatorMenu_t1317702990), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2097[3] = 
{
	SimpleActivatorMenu_t1317702990::get_offset_of_camSwitchButton_2(),
	SimpleActivatorMenu_t1317702990::get_offset_of_objects_3(),
	SimpleActivatorMenu_t1317702990::get_offset_of_m_CurrentActiveObject_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2098 = { sizeof (SimpleMouseRotator_t32383032), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2098[10] = 
{
	SimpleMouseRotator_t32383032::get_offset_of_rotationRange_2(),
	SimpleMouseRotator_t32383032::get_offset_of_rotationSpeed_3(),
	SimpleMouseRotator_t32383032::get_offset_of_dampingTime_4(),
	SimpleMouseRotator_t32383032::get_offset_of_autoZeroVerticalOnMobile_5(),
	SimpleMouseRotator_t32383032::get_offset_of_autoZeroHorizontalOnMobile_6(),
	SimpleMouseRotator_t32383032::get_offset_of_relative_7(),
	SimpleMouseRotator_t32383032::get_offset_of_m_TargetAngles_8(),
	SimpleMouseRotator_t32383032::get_offset_of_m_FollowAngles_9(),
	SimpleMouseRotator_t32383032::get_offset_of_m_FollowVelocity_10(),
	SimpleMouseRotator_t32383032::get_offset_of_m_OriginalRotation_11(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2099 = { sizeof (SmoothFollow_t2548964113), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2099[5] = 
{
	SmoothFollow_t2548964113::get_offset_of_target_2(),
	SmoothFollow_t2548964113::get_offset_of_distance_3(),
	SmoothFollow_t2548964113::get_offset_of_height_4(),
	SmoothFollow_t2548964113::get_offset_of_rotationDamping_5(),
	SmoothFollow_t2548964113::get_offset_of_heightDamping_6(),
};
#ifdef __clang__
#pragma clang diagnostic pop
#endif
