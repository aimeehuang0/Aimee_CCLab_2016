﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// UnityStandardAssets.Utility.TimedObjectActivator/<Deactivate>c__Iterator1
struct U3CDeactivateU3Ec__Iterator1_t707185157;
// System.Object
struct Il2CppObject;

#include "codegen/il2cpp-codegen.h"

// System.Void UnityStandardAssets.Utility.TimedObjectActivator/<Deactivate>c__Iterator1::.ctor()
extern "C"  void U3CDeactivateU3Ec__Iterator1__ctor_m632552262 (U3CDeactivateU3Ec__Iterator1_t707185157 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Boolean UnityStandardAssets.Utility.TimedObjectActivator/<Deactivate>c__Iterator1::MoveNext()
extern "C"  bool U3CDeactivateU3Ec__Iterator1_MoveNext_m2935864074 (U3CDeactivateU3Ec__Iterator1_t707185157 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Object UnityStandardAssets.Utility.TimedObjectActivator/<Deactivate>c__Iterator1::System.Collections.Generic.IEnumerator<object>.get_Current()
extern "C"  Il2CppObject * U3CDeactivateU3Ec__Iterator1_System_Collections_Generic_IEnumeratorU3CobjectU3E_get_Current_m2158398432 (U3CDeactivateU3Ec__Iterator1_t707185157 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Object UnityStandardAssets.Utility.TimedObjectActivator/<Deactivate>c__Iterator1::System.Collections.IEnumerator.get_Current()
extern "C"  Il2CppObject * U3CDeactivateU3Ec__Iterator1_System_Collections_IEnumerator_get_Current_m3578940872 (U3CDeactivateU3Ec__Iterator1_t707185157 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Utility.TimedObjectActivator/<Deactivate>c__Iterator1::Dispose()
extern "C"  void U3CDeactivateU3Ec__Iterator1_Dispose_m354924873 (U3CDeactivateU3Ec__Iterator1_t707185157 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Utility.TimedObjectActivator/<Deactivate>c__Iterator1::Reset()
extern "C"  void U3CDeactivateU3Ec__Iterator1_Reset_m449732571 (U3CDeactivateU3Ec__Iterator1_t707185157 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
