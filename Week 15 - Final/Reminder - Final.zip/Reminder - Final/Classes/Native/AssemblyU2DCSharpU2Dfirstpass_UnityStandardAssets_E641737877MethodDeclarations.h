﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// UnityStandardAssets.Effects.Explosive
struct Explosive_t641737877;
// System.Collections.IEnumerator
struct IEnumerator_t1466026749;
// UnityEngine.Collision
struct Collision_t2876846408;

#include "codegen/il2cpp-codegen.h"
#include "UnityEngine_UnityEngine_Collision2876846408.h"

// System.Void UnityStandardAssets.Effects.Explosive::.ctor()
extern "C"  void Explosive__ctor_m4106462065 (Explosive_t641737877 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Effects.Explosive::Start()
extern "C"  void Explosive_Start_m2478100361 (Explosive_t641737877 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Collections.IEnumerator UnityStandardAssets.Effects.Explosive::OnCollisionEnter(UnityEngine.Collision)
extern "C"  Il2CppObject * Explosive_OnCollisionEnter_m3802117901 (Explosive_t641737877 * __this, Collision_t2876846408 * ___col0, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Effects.Explosive::Reset()
extern "C"  void Explosive_Reset_m3082935302 (Explosive_t641737877 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
