﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// Vuforia.CloudRecoBehaviour
struct CloudRecoBehaviour_t3077176941;

#include "codegen/il2cpp-codegen.h"

// System.Void Vuforia.CloudRecoBehaviour::.ctor()
extern "C"  void CloudRecoBehaviour__ctor_m2555627024 (CloudRecoBehaviour_t3077176941 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
