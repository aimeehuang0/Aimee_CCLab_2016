﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <cstring>
#include <string.h>
#include <stdio.h>
#include <cmath>
#include <limits>
#include <assert.h>


#include "class-internals.h"
#include "codegen/il2cpp-codegen.h"
#include "mscorlib_System_MethodAccessException4093255254.h"
#include "mscorlib_System_MissingFieldException3702079619.h"
#include "mscorlib_System_MissingMemberException1839900847.h"
#include "mscorlib_System_MissingMethodException3441205986.h"
#include "mscorlib_System_MonoAsyncCall3796687503.h"
#include "mscorlib_System_MonoCustomAttrs2976585698.h"
#include "mscorlib_System_MonoCustomAttrs_AttributeInfo2366110328.h"
#include "mscorlib_System_MonoTouchAOTHelper2464748856.h"
#include "mscorlib_System_MonoTypeInfo1976057079.h"
#include "mscorlib_System_MonoType42245407.h"
#include "mscorlib_System_MulticastNotSupportedException1815247018.h"
#include "mscorlib_System_NonSerializedAttribute399263003.h"
#include "mscorlib_System_NotImplementedException2785117854.h"
#include "mscorlib_System_NotSupportedException1793819818.h"
#include "mscorlib_System_NullReferenceException3156209119.h"
#include "mscorlib_System_NumberFormatter2933946347.h"
#include "mscorlib_System_NumberFormatter_CustomInfo128587492.h"
#include "mscorlib_System_ObjectDisposedException2695136451.h"
#include "mscorlib_System_OperatingSystem290860502.h"
#include "mscorlib_System_OutOfMemoryException1181064283.h"
#include "mscorlib_System_OverflowException1075868493.h"
#include "mscorlib_System_PlatformID1006634368.h"
#include "mscorlib_System_PlatformNotSupportedException3778770305.h"
#include "mscorlib_System_RankException1539875949.h"
#include "mscorlib_System_ResolveEventArgs1859808873.h"
#include "mscorlib_System_RuntimeMethodHandle894824333.h"
#include "mscorlib_System_StringComparer1574862926.h"
#include "mscorlib_System_CultureAwareComparer1533343251.h"
#include "mscorlib_System_OrdinalComparer1018219584.h"
#include "mscorlib_System_StringComparison2376310518.h"
#include "mscorlib_System_StringSplitOptions2996162939.h"
#include "mscorlib_System_SystemException3877406272.h"
#include "mscorlib_System_ThreadStaticAttribute1787731584.h"
#include "mscorlib_System_TimeSpan3430258949.h"
#include "mscorlib_System_TimeZone4008205267.h"
#include "mscorlib_System_CurrentSystemTimeZone1172150369.h"
#include "mscorlib_System_TypeCode2536926201.h"
#include "mscorlib_System_TypeInitializationException3654642183.h"
#include "mscorlib_System_TypeLoadException723359155.h"
#include "mscorlib_System_UnauthorizedAccessException886535555.h"
#include "mscorlib_System_UnhandledExceptionEventArgs3067050131.h"
#include "mscorlib_System_UnitySerializationHolder2045574117.h"
#include "mscorlib_System_UnitySerializationHolder_UnityType2934041722.h"
#include "mscorlib_System_Version1755874712.h"
#include "mscorlib_System_WeakReference1077405567.h"
#include "mscorlib_Mono_Math_Prime_PrimalityTest572679901.h"
#include "mscorlib_System_Reflection_MemberFilter3405857066.h"
#include "mscorlib_System_Reflection_TypeFilter2905709404.h"
#include "mscorlib_System_Runtime_Remoting_Contexts_CrossCont754146990.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_HeaderHa324204131.h"
#include "mscorlib_System_Threading_ThreadStart3437517264.h"
#include "mscorlib_System_Threading_TimerCallback1684927372.h"
#include "mscorlib_System_Threading_WaitCallback2798937288.h"
#include "mscorlib_System_AppDomainInitializer3898244613.h"
#include "mscorlib_System_AssemblyLoadEventHandler2169307382.h"
#include "mscorlib_System_EventHandler277755526.h"
#include "mscorlib_System_ResolveEventHandler3842432458.h"
#include "mscorlib_System_UnhandledExceptionEventHandler1916531888.h"
#include "mscorlib_U3CPrivateImplementationDetailsU3E1486305137.h"
#include "mscorlib_U3CPrivateImplementationDetailsU3E_U24Arr1703410330.h"
#include "mscorlib_U3CPrivateImplementationDetailsU3E_U24Arr2866209749.h"
#include "mscorlib_U3CPrivateImplementationDetailsU3E_U24Arr1703410334.h"
#include "mscorlib_U3CPrivateImplementationDetailsU3E_U24Arra116038562.h"
#include "mscorlib_U3CPrivateImplementationDetailsU3E_U24Arr1892466092.h"
#include "mscorlib_U3CPrivateImplementationDetailsU3E_U24Arra540610921.h"
#include "mscorlib_U3CPrivateImplementationDetailsU3E_U24Arr3672778804.h"
#include "mscorlib_U3CPrivateImplementationDetailsU3E_U24Arra896841275.h"
#include "mscorlib_U3CPrivateImplementationDetailsU3E_U24Arr2866209745.h"
#include "mscorlib_U3CPrivateImplementationDetailsU3E_U24Arr3672778802.h"
#include "mscorlib_U3CPrivateImplementationDetailsU3E_U24Arr2844921915.h"
#include "mscorlib_U3CPrivateImplementationDetailsU3E_U24Arr1957337327.h"
#include "mscorlib_U3CPrivateImplementationDetailsU3E_U24Arr3672778800.h"
#include "mscorlib_U3CPrivateImplementationDetailsU3E_U24Arra116038558.h"
#include "mscorlib_U3CPrivateImplementationDetailsU3E_U24Arr1703410326.h"
#include "mscorlib_U3CPrivateImplementationDetailsU3E_U24Arra702815517.h"
#include "mscorlib_U3CPrivateImplementationDetailsU3E_U24Arr2038352954.h"
#include "mscorlib_U3CPrivateImplementationDetailsU3E_U24Arr2672183894.h"
#include "mscorlib_U3CPrivateImplementationDetailsU3E_U24Arr3604436769.h"
#include "mscorlib_U3CPrivateImplementationDetailsU3E_U24Arra116038554.h"
#include "mscorlib_U3CPrivateImplementationDetailsU3E_U24Arr3672778798.h"
#include "mscorlib_System___Il2CppComObject4064417062.h"
#include "mscorlib_System___Il2CppComDelegate3311706788.h"
#include "System_U3CModuleU3E3783534214.h"
#include "System_Locale4255929014.h"
#include "System_System_MonoTODOAttribute3487514019.h"
#include "System_System_Collections_Specialized_HybridDiction290043810.h"
#include "System_System_Collections_Specialized_ListDictiona3458713452.h"
#include "System_System_Collections_Specialized_ListDictiona2725637098.h"
#include "System_System_Collections_Specialized_ListDictiona1923170152.h"
#include "System_System_Collections_Specialized_NameObjectCo2034248631.h"
#include "System_System_Collections_Specialized_NameObjectCo3244489099.h"



#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize800 = { sizeof (MethodAccessException_t4093255254), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize801 = { sizeof (MissingFieldException_t3702079619), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize802 = { sizeof (MissingMemberException_t1839900847), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable802[3] = 
{
	MissingMemberException_t1839900847::get_offset_of_ClassName_11(),
	MissingMemberException_t1839900847::get_offset_of_MemberName_12(),
	MissingMemberException_t1839900847::get_offset_of_Signature_13(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize803 = { sizeof (MissingMethodException_t3441205986), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable803[1] = 
{
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize804 = { sizeof (MonoAsyncCall_t3796687503), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable804[7] = 
{
	MonoAsyncCall_t3796687503::get_offset_of_msg_0(),
	MonoAsyncCall_t3796687503::get_offset_of_cb_method_1(),
	MonoAsyncCall_t3796687503::get_offset_of_cb_target_2(),
	MonoAsyncCall_t3796687503::get_offset_of_state_3(),
	MonoAsyncCall_t3796687503::get_offset_of_res_4(),
	MonoAsyncCall_t3796687503::get_offset_of_out_args_5(),
	MonoAsyncCall_t3796687503::get_offset_of_wait_event_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize805 = { sizeof (MonoCustomAttrs_t2976585698), -1, sizeof(MonoCustomAttrs_t2976585698_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable805[3] = 
{
	MonoCustomAttrs_t2976585698_StaticFields::get_offset_of_corlib_0(),
	MonoCustomAttrs_t2976585698_StaticFields::get_offset_of_AttributeUsageType_1(),
	MonoCustomAttrs_t2976585698_StaticFields::get_offset_of_DefaultAttributeUsage_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize806 = { sizeof (AttributeInfo_t2366110328), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable806[2] = 
{
	AttributeInfo_t2366110328::get_offset_of__usage_0(),
	AttributeInfo_t2366110328::get_offset_of__inheritanceLevel_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize807 = { sizeof (MonoTouchAOTHelper_t2464748856), -1, sizeof(MonoTouchAOTHelper_t2464748856_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable807[1] = 
{
	MonoTouchAOTHelper_t2464748856_StaticFields::get_offset_of_FalseFlag_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize808 = { sizeof (MonoTypeInfo_t1976057079), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable808[2] = 
{
	MonoTypeInfo_t1976057079::get_offset_of_full_name_0(),
	MonoTypeInfo_t1976057079::get_offset_of_default_ctor_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize809 = { sizeof (MonoType_t), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable809[1] = 
{
	MonoType_t::get_offset_of_type_info_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize810 = { sizeof (MulticastNotSupportedException_t1815247018), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize811 = { sizeof (NonSerializedAttribute_t399263003), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize812 = { sizeof (NotImplementedException_t2785117854), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize813 = { sizeof (NotSupportedException_t1793819818), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable813[1] = 
{
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize814 = { sizeof (NullReferenceException_t3156209119), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable814[1] = 
{
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize815 = { sizeof (NumberFormatter_t2933946347), -1, sizeof(NumberFormatter_t2933946347_StaticFields), sizeof(NumberFormatter_t2933946347_ThreadStaticFields) };
extern const int32_t g_FieldOffsetTable815[26] = 
{
	NumberFormatter_t2933946347_StaticFields::get_offset_of_MantissaBitsTable_0(),
	NumberFormatter_t2933946347_StaticFields::get_offset_of_TensExponentTable_1(),
	NumberFormatter_t2933946347_StaticFields::get_offset_of_DigitLowerTable_2(),
	NumberFormatter_t2933946347_StaticFields::get_offset_of_DigitUpperTable_3(),
	NumberFormatter_t2933946347_StaticFields::get_offset_of_TenPowersList_4(),
	NumberFormatter_t2933946347_StaticFields::get_offset_of_DecHexDigits_5(),
	NumberFormatter_t2933946347::get_offset_of__thread_6(),
	NumberFormatter_t2933946347::get_offset_of__nfi_7(),
	NumberFormatter_t2933946347::get_offset_of__NaN_8(),
	NumberFormatter_t2933946347::get_offset_of__infinity_9(),
	NumberFormatter_t2933946347::get_offset_of__isCustomFormat_10(),
	NumberFormatter_t2933946347::get_offset_of__specifierIsUpper_11(),
	NumberFormatter_t2933946347::get_offset_of__positive_12(),
	NumberFormatter_t2933946347::get_offset_of__specifier_13(),
	NumberFormatter_t2933946347::get_offset_of__precision_14(),
	NumberFormatter_t2933946347::get_offset_of__defPrecision_15(),
	NumberFormatter_t2933946347::get_offset_of__digitsLen_16(),
	NumberFormatter_t2933946347::get_offset_of__offset_17(),
	NumberFormatter_t2933946347::get_offset_of__decPointPos_18(),
	NumberFormatter_t2933946347::get_offset_of__val1_19(),
	NumberFormatter_t2933946347::get_offset_of__val2_20(),
	NumberFormatter_t2933946347::get_offset_of__val3_21(),
	NumberFormatter_t2933946347::get_offset_of__val4_22(),
	NumberFormatter_t2933946347::get_offset_of__cbuf_23(),
	NumberFormatter_t2933946347::get_offset_of__ind_24(),
	THREAD_STATIC_FIELD_OFFSET,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize816 = { sizeof (CustomInfo_t128587492), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable816[14] = 
{
	CustomInfo_t128587492::get_offset_of_UseGroup_0(),
	CustomInfo_t128587492::get_offset_of_DecimalDigits_1(),
	CustomInfo_t128587492::get_offset_of_DecimalPointPos_2(),
	CustomInfo_t128587492::get_offset_of_DecimalTailSharpDigits_3(),
	CustomInfo_t128587492::get_offset_of_IntegerDigits_4(),
	CustomInfo_t128587492::get_offset_of_IntegerHeadSharpDigits_5(),
	CustomInfo_t128587492::get_offset_of_IntegerHeadPos_6(),
	CustomInfo_t128587492::get_offset_of_UseExponent_7(),
	CustomInfo_t128587492::get_offset_of_ExponentDigits_8(),
	CustomInfo_t128587492::get_offset_of_ExponentTailSharpDigits_9(),
	CustomInfo_t128587492::get_offset_of_ExponentNegativeSignOnly_10(),
	CustomInfo_t128587492::get_offset_of_DividePlaces_11(),
	CustomInfo_t128587492::get_offset_of_Percents_12(),
	CustomInfo_t128587492::get_offset_of_Permilles_13(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize817 = { sizeof (ObjectDisposedException_t2695136451), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable817[2] = 
{
	ObjectDisposedException_t2695136451::get_offset_of_obj_name_12(),
	ObjectDisposedException_t2695136451::get_offset_of_msg_13(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize818 = { sizeof (OperatingSystem_t290860502), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable818[3] = 
{
	OperatingSystem_t290860502::get_offset_of__platform_0(),
	OperatingSystem_t290860502::get_offset_of__version_1(),
	OperatingSystem_t290860502::get_offset_of__servicePack_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize819 = { sizeof (OutOfMemoryException_t1181064283), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable819[1] = 
{
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize820 = { sizeof (OverflowException_t1075868493), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable820[1] = 
{
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize821 = { sizeof (PlatformID_t1006634368)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable821[8] = 
{
	PlatformID_t1006634368::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize822 = { sizeof (PlatformNotSupportedException_t3778770305), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable822[1] = 
{
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize823 = { sizeof (RankException_t1539875949), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize824 = { sizeof (ResolveEventArgs_t1859808873), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable824[1] = 
{
	ResolveEventArgs_t1859808873::get_offset_of_m_Name_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize825 = { sizeof (RuntimeMethodHandle_t894824333)+ sizeof (Il2CppObject), sizeof(RuntimeMethodHandle_t894824333 ), 0, 0 };
extern const int32_t g_FieldOffsetTable825[1] = 
{
	RuntimeMethodHandle_t894824333::get_offset_of_value_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize826 = { sizeof (StringComparer_t1574862926), -1, sizeof(StringComparer_t1574862926_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable826[4] = 
{
	StringComparer_t1574862926_StaticFields::get_offset_of_invariantCultureIgnoreCase_0(),
	StringComparer_t1574862926_StaticFields::get_offset_of_invariantCulture_1(),
	StringComparer_t1574862926_StaticFields::get_offset_of_ordinalIgnoreCase_2(),
	StringComparer_t1574862926_StaticFields::get_offset_of_ordinal_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize827 = { sizeof (CultureAwareComparer_t1533343251), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable827[2] = 
{
	CultureAwareComparer_t1533343251::get_offset_of__ignoreCase_4(),
	CultureAwareComparer_t1533343251::get_offset_of__compareInfo_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize828 = { sizeof (OrdinalComparer_t1018219584), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable828[1] = 
{
	OrdinalComparer_t1018219584::get_offset_of__ignoreCase_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize829 = { sizeof (StringComparison_t2376310518)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable829[7] = 
{
	StringComparison_t2376310518::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize830 = { sizeof (StringSplitOptions_t2996162939)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable830[3] = 
{
	StringSplitOptions_t2996162939::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize831 = { sizeof (SystemException_t3877406272), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize832 = { sizeof (ThreadStaticAttribute_t1787731584), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize833 = { sizeof (TimeSpan_t3430258949)+ sizeof (Il2CppObject), sizeof(TimeSpan_t3430258949 ), sizeof(TimeSpan_t3430258949_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable833[4] = 
{
	TimeSpan_t3430258949_StaticFields::get_offset_of_MaxValue_0(),
	TimeSpan_t3430258949_StaticFields::get_offset_of_MinValue_1(),
	TimeSpan_t3430258949_StaticFields::get_offset_of_Zero_2(),
	TimeSpan_t3430258949::get_offset_of__ticks_3() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize834 = { sizeof (TimeZone_t4008205267), -1, sizeof(TimeZone_t4008205267_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable834[3] = 
{
	TimeZone_t4008205267_StaticFields::get_offset_of_currentTimeZone_0(),
	TimeZone_t4008205267_StaticFields::get_offset_of_tz_lock_1(),
	TimeZone_t4008205267_StaticFields::get_offset_of_timezone_check_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize835 = { sizeof (CurrentSystemTimeZone_t1172150369), -1, sizeof(CurrentSystemTimeZone_t1172150369_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable835[8] = 
{
	CurrentSystemTimeZone_t1172150369::get_offset_of_m_standardName_3(),
	CurrentSystemTimeZone_t1172150369::get_offset_of_m_daylightName_4(),
	CurrentSystemTimeZone_t1172150369::get_offset_of_m_CachedDaylightChanges_5(),
	CurrentSystemTimeZone_t1172150369::get_offset_of_m_ticksOffset_6(),
	CurrentSystemTimeZone_t1172150369::get_offset_of_utcOffsetWithOutDLS_7(),
	CurrentSystemTimeZone_t1172150369::get_offset_of_utcOffsetWithDLS_8(),
	CurrentSystemTimeZone_t1172150369_StaticFields::get_offset_of_this_year_9(),
	CurrentSystemTimeZone_t1172150369_StaticFields::get_offset_of_this_year_dlt_10(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize836 = { sizeof (TypeCode_t2536926201)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable836[19] = 
{
	TypeCode_t2536926201::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize837 = { sizeof (TypeInitializationException_t3654642183), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable837[1] = 
{
	TypeInitializationException_t3654642183::get_offset_of_type_name_11(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize838 = { sizeof (TypeLoadException_t723359155), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable838[3] = 
{
	0,
	TypeLoadException_t723359155::get_offset_of_className_12(),
	TypeLoadException_t723359155::get_offset_of_assemblyName_13(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize839 = { sizeof (UnauthorizedAccessException_t886535555), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize840 = { sizeof (UnhandledExceptionEventArgs_t3067050131), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable840[2] = 
{
	UnhandledExceptionEventArgs_t3067050131::get_offset_of_exception_1(),
	UnhandledExceptionEventArgs_t3067050131::get_offset_of_m_isTerminating_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize841 = { sizeof (UnitySerializationHolder_t2045574117), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable841[3] = 
{
	UnitySerializationHolder_t2045574117::get_offset_of__data_0(),
	UnitySerializationHolder_t2045574117::get_offset_of__unityType_1(),
	UnitySerializationHolder_t2045574117::get_offset_of__assemblyName_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize842 = { sizeof (UnityType_t2934041722)+ sizeof (Il2CppObject), sizeof(uint8_t), 0, 0 };
extern const int32_t g_FieldOffsetTable842[5] = 
{
	UnityType_t2934041722::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize843 = { sizeof (Version_t1755874712), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable843[5] = 
{
	0,
	Version_t1755874712::get_offset_of__Major_1(),
	Version_t1755874712::get_offset_of__Minor_2(),
	Version_t1755874712::get_offset_of__Build_3(),
	Version_t1755874712::get_offset_of__Revision_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize844 = { sizeof (WeakReference_t1077405567), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable844[2] = 
{
	WeakReference_t1077405567::get_offset_of_isLongReference_0(),
	WeakReference_t1077405567::get_offset_of_gcHandle_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize845 = { sizeof (PrimalityTest_t572679901), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize846 = { sizeof (MemberFilter_t3405857066), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize847 = { sizeof (TypeFilter_t2905709404), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize848 = { sizeof (CrossContextDelegate_t754146990), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize849 = { sizeof (HeaderHandler_t324204131), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize850 = { sizeof (ThreadStart_t3437517264), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize851 = { sizeof (TimerCallback_t1684927372), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize852 = { sizeof (WaitCallback_t2798937288), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize853 = { 0, 0, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize854 = { sizeof (AppDomainInitializer_t3898244613), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize855 = { sizeof (AssemblyLoadEventHandler_t2169307382), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize856 = { 0, 0, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize857 = { 0, 0, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize858 = { sizeof (EventHandler_t277755526), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize859 = { 0, 0, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize860 = { sizeof (ResolveEventHandler_t3842432458), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize861 = { sizeof (UnhandledExceptionEventHandler_t1916531888), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize862 = { sizeof (U3CPrivateImplementationDetailsU3E_t1486305137), -1, sizeof(U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable862[53] = 
{
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D0_0(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D1_1(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D2_2(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D3_3(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D4_4(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D5_5(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D6_6(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D15_7(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D16_8(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D17_9(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D18_10(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D19_11(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D20_12(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D21_13(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D22_14(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D23_15(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D24_16(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D25_17(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D26_18(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D27_19(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D30_20(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D31_21(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D32_22(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D33_23(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D34_24(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D35_25(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D36_26(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D37_27(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D38_28(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D39_29(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D40_30(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D41_31(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D42_32(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D43_33(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D44_34(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D45_35(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D46_36(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D47_37(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D48_38(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D49_39(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D50_40(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D51_41(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D52_42(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D53_43(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D54_44(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D55_45(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D56_46(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D57_47(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D60_48(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D62_49(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D63_50(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D64_51(),
	U3CPrivateImplementationDetailsU3E_t1486305137_StaticFields::get_offset_of_U24U24fieldU2D65_52(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize863 = { sizeof (U24ArrayTypeU2456_t1703410330)+ sizeof (Il2CppObject), sizeof(U24ArrayTypeU2456_t1703410330 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize864 = { sizeof (U24ArrayTypeU2424_t2866209749)+ sizeof (Il2CppObject), sizeof(U24ArrayTypeU2424_t2866209749 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize865 = { sizeof (U24ArrayTypeU2416_t1703410334)+ sizeof (Il2CppObject), sizeof(U24ArrayTypeU2416_t1703410334 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize866 = { sizeof (U24ArrayTypeU24120_t116038562)+ sizeof (Il2CppObject), sizeof(U24ArrayTypeU24120_t116038562 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize867 = { sizeof (U24ArrayTypeU243132_t1892466092)+ sizeof (Il2CppObject), sizeof(U24ArrayTypeU243132_t1892466092 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize868 = { sizeof (U24ArrayTypeU2420_t540610921)+ sizeof (Il2CppObject), sizeof(U24ArrayTypeU2420_t540610921 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize869 = { sizeof (U24ArrayTypeU2432_t3672778804)+ sizeof (Il2CppObject), sizeof(U24ArrayTypeU2432_t3672778804 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize870 = { sizeof (U24ArrayTypeU2448_t896841275)+ sizeof (Il2CppObject), sizeof(U24ArrayTypeU2448_t896841275 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize871 = { sizeof (U24ArrayTypeU2464_t2866209745)+ sizeof (Il2CppObject), sizeof(U24ArrayTypeU2464_t2866209745 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize872 = { sizeof (U24ArrayTypeU2412_t3672778802)+ sizeof (Il2CppObject), sizeof(U24ArrayTypeU2412_t3672778802 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize873 = { sizeof (U24ArrayTypeU24136_t2844921915)+ sizeof (Il2CppObject), sizeof(U24ArrayTypeU24136_t2844921915 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize874 = { sizeof (U24ArrayTypeU248_t1957337327)+ sizeof (Il2CppObject), sizeof(U24ArrayTypeU248_t1957337327 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize875 = { sizeof (U24ArrayTypeU2472_t3672778800)+ sizeof (Il2CppObject), sizeof(U24ArrayTypeU2472_t3672778800 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize876 = { sizeof (U24ArrayTypeU24124_t116038558)+ sizeof (Il2CppObject), sizeof(U24ArrayTypeU24124_t116038558 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize877 = { sizeof (U24ArrayTypeU2496_t1703410326)+ sizeof (Il2CppObject), sizeof(U24ArrayTypeU2496_t1703410326 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize878 = { sizeof (U24ArrayTypeU242048_t702815517)+ sizeof (Il2CppObject), sizeof(U24ArrayTypeU242048_t702815517 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize879 = { sizeof (U24ArrayTypeU24256_t2038352954)+ sizeof (Il2CppObject), sizeof(U24ArrayTypeU24256_t2038352954 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize880 = { sizeof (U24ArrayTypeU241024_t2672183894)+ sizeof (Il2CppObject), sizeof(U24ArrayTypeU241024_t2672183894 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize881 = { sizeof (U24ArrayTypeU24640_t3604436769)+ sizeof (Il2CppObject), sizeof(U24ArrayTypeU24640_t3604436769 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize882 = { sizeof (U24ArrayTypeU24128_t116038554)+ sizeof (Il2CppObject), sizeof(U24ArrayTypeU24128_t116038554 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize883 = { sizeof (U24ArrayTypeU2452_t3672778798)+ sizeof (Il2CppObject), sizeof(U24ArrayTypeU2452_t3672778798 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize884 = { sizeof (Il2CppComObject), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize885 = { sizeof (__Il2CppComDelegate_t3311706788), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize886 = { sizeof (U3CModuleU3E_t3783534215), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize887 = { sizeof (Locale_t4255929015), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize888 = { sizeof (MonoTODOAttribute_t3487514020), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable888[1] = 
{
	MonoTODOAttribute_t3487514020::get_offset_of_comment_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize889 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable889[5] = 
{
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize890 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable890[4] = 
{
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize891 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable891[4] = 
{
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize892 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable892[3] = 
{
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize893 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable893[3] = 
{
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize894 = { sizeof (HybridDictionary_t290043810), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable894[3] = 
{
	HybridDictionary_t290043810::get_offset_of_caseInsensitive_0(),
	HybridDictionary_t290043810::get_offset_of_hashtable_1(),
	HybridDictionary_t290043810::get_offset_of_list_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize895 = { sizeof (ListDictionary_t3458713452), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable895[4] = 
{
	ListDictionary_t3458713452::get_offset_of_count_0(),
	ListDictionary_t3458713452::get_offset_of_version_1(),
	ListDictionary_t3458713452::get_offset_of_head_2(),
	ListDictionary_t3458713452::get_offset_of_comparer_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize896 = { sizeof (DictionaryNode_t2725637098), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable896[3] = 
{
	DictionaryNode_t2725637098::get_offset_of_key_0(),
	DictionaryNode_t2725637098::get_offset_of_value_1(),
	DictionaryNode_t2725637098::get_offset_of_next_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize897 = { sizeof (DictionaryNodeEnumerator_t1923170152), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable897[4] = 
{
	DictionaryNodeEnumerator_t1923170152::get_offset_of_dict_0(),
	DictionaryNodeEnumerator_t1923170152::get_offset_of_isAtStart_1(),
	DictionaryNodeEnumerator_t1923170152::get_offset_of_current_2(),
	DictionaryNodeEnumerator_t1923170152::get_offset_of_version_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize898 = { sizeof (NameObjectCollectionBase_t2034248631), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable898[10] = 
{
	NameObjectCollectionBase_t2034248631::get_offset_of_m_ItemsContainer_0(),
	NameObjectCollectionBase_t2034248631::get_offset_of_m_NullKeyItem_1(),
	NameObjectCollectionBase_t2034248631::get_offset_of_m_ItemsArray_2(),
	NameObjectCollectionBase_t2034248631::get_offset_of_m_hashprovider_3(),
	NameObjectCollectionBase_t2034248631::get_offset_of_m_comparer_4(),
	NameObjectCollectionBase_t2034248631::get_offset_of_m_defCapacity_5(),
	NameObjectCollectionBase_t2034248631::get_offset_of_m_readonly_6(),
	NameObjectCollectionBase_t2034248631::get_offset_of_infoCopy_7(),
	NameObjectCollectionBase_t2034248631::get_offset_of_keyscoll_8(),
	NameObjectCollectionBase_t2034248631::get_offset_of_equality_comparer_9(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize899 = { sizeof (_Item_t3244489099), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable899[2] = 
{
	_Item_t3244489099::get_offset_of_key_0(),
	_Item_t3244489099::get_offset_of_value_1(),
};
#ifdef __clang__
#pragma clang diagnostic pop
#endif
