﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// UnityStandardAssets.Utility.TimedObjectActivator/Entries
struct Entries_t1135469853;

#include "codegen/il2cpp-codegen.h"

// System.Void UnityStandardAssets.Utility.TimedObjectActivator/Entries::.ctor()
extern "C"  void Entries__ctor_m2479311460 (Entries_t1135469853 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
