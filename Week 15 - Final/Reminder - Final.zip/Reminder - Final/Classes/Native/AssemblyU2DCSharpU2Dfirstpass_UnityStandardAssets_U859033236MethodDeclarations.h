﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// UnityStandardAssets.Utility.DynamicShadowSettings
struct DynamicShadowSettings_t859033236;

#include "codegen/il2cpp-codegen.h"

// System.Void UnityStandardAssets.Utility.DynamicShadowSettings::.ctor()
extern "C"  void DynamicShadowSettings__ctor_m1092595070 (DynamicShadowSettings_t859033236 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Utility.DynamicShadowSettings::Start()
extern "C"  void DynamicShadowSettings_Start_m2543111910 (DynamicShadowSettings_t859033236 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void UnityStandardAssets.Utility.DynamicShadowSettings::Update()
extern "C"  void DynamicShadowSettings_Update_m2495492137 (DynamicShadowSettings_t859033236 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
